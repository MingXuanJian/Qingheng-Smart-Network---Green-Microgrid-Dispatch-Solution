from pathlib import Path


PRIMARY = "#2FB463"
PRIMARY_DARK = "#258F50"
PRIMARY_LIGHT = "#E8F7EC"
BLUE = "#4C8DF6"
GOLD = "#E6A23C"
BG = "#F7F9FB"
CARD = "#FFFFFF"
TEXT = "#1F2937"
MUTED = "#6B7280"
BORDER = "#E5E7EB"


def setup_chinese_font(app) -> str:
    from PySide6.QtGui import QFont, QFontDatabase

    candidates = [
        Path("C:/Windows/Fonts/msyh.ttc"),
        Path("C:/Windows/Fonts/msyhbd.ttc"),
        Path("C:/Windows/Fonts/simhei.ttf"),
    ]
    family = "Microsoft YaHei"
    for font_path in candidates:
        if font_path.exists():
            font_id = QFontDatabase.addApplicationFont(str(font_path))
            families = QFontDatabase.applicationFontFamilies(font_id)
            if families:
                family = families[0]
                break
    app.setFont(QFont(family, 10))
    return family


def app_stylesheet() -> str:
    return f"""
    QWidget {{
        font-family: "Microsoft YaHei", "Segoe UI", Arial, sans-serif;
        color: {TEXT};
        background: {BG};
        font-size: 14px;
    }}
    QFrame#Card {{
        background: {CARD};
        border: 1px solid {BORDER};
        border-radius: 12px;
    }}
    QFrame#SoftPanel {{
        background: #FBFCFD;
        border: 1px solid {BORDER};
        border-radius: 12px;
    }}
    QLabel#Title {{ font-size: 22px; font-weight: 800; background: transparent; }}
    QLabel#PageTitle {{ font-size: 19px; font-weight: 800; background: transparent; }}
    QLabel#Subtle {{ color: {MUTED}; background: transparent; }}
    QLabel#KpiValue {{ font-size: 25px; font-weight: 900; background: transparent; }}
    QPushButton {{
        border: 1px solid {BORDER};
        border-radius: 8px;
        padding: 8px 14px;
        background: #FFFFFF;
    }}
    QPushButton:hover {{ background: #F3F8F5; border-color: #B8E2C5; }}
    QPushButton#PrimaryButton {{
        background: {PRIMARY};
        border-color: {PRIMARY};
        color: white;
        font-weight: 700;
    }}
    QPushButton#PrimaryButton:hover {{ background: {PRIMARY_DARK}; }}
    QPushButton#GhostButton {{
        color: {PRIMARY_DARK};
        border-color: #A9DDB8;
        background: #FFFFFF;
        font-weight: 700;
    }}
    QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateEdit {{
        background: #FFFFFF;
        border: 1px solid {BORDER};
        border-radius: 8px;
        padding: 8px 10px;
        min-height: 22px;
    }}
    QLineEdit:focus, QComboBox:focus, QDoubleSpinBox:focus, QDateEdit:focus {{
        border-color: {PRIMARY};
    }}
    QDoubleSpinBox {{
        padding-right: 30px;
    }}
    QDoubleSpinBox::up-button {{
        subcontrol-origin: border;
        subcontrol-position: top right;
        width: 26px;
        border-left: 1px solid {BORDER};
        border-bottom: 1px solid {BORDER};
        border-top-right-radius: 8px;
        background: #FFFFFF;
    }}
    QDoubleSpinBox::down-button {{
        subcontrol-origin: border;
        subcontrol-position: bottom right;
        width: 26px;
        border-left: 1px solid {BORDER};
        border-bottom-right-radius: 8px;
        background: #FFFFFF;
    }}
    QDoubleSpinBox::up-button:hover,
    QDoubleSpinBox::down-button:hover {{
        background: #F3F8F5;
    }}
    QSlider::groove:horizontal {{
        height: 6px;
        background: #E9EEF2;
        border-radius: 3px;
    }}
    QSlider::handle:horizontal {{
        width: 16px;
        height: 16px;
        margin: -6px 0;
        border-radius: 8px;
        background: {PRIMARY};
    }}
    QTableWidget {{
        background: #FFFFFF;
        border: 1px solid {BORDER};
        border-radius: 10px;
        gridline-color: #EDF0F3;
        selection-background-color: {PRIMARY_LIGHT};
        selection-color: {TEXT};
        alternate-background-color: #FAFBFC;
    }}
    QTableWidget::item {{
        padding: 6px;
    }}
    QHeaderView::section {{
        background: #F4F7F6;
        color: #374151;
        border: none;
        border-bottom: 1px solid {BORDER};
        padding: 8px;
        font-weight: 700;
    }}
    QCheckBox {{ background: transparent; spacing: 8px; }}
    QCheckBox#TileCheck {{
        background: #F7FBF8;
        border: 1px solid #DCEFE3;
        border-radius: 10px;
        padding: 12px 14px;
        font-weight: 700;
        color: {TEXT};
    }}
    QCheckBox#TileCheck:hover {{
        background: #F0FAF3;
        border-color: #B9E5C6;
    }}
    QCheckBox#TileCheck::indicator {{
        width: 16px;
        height: 16px;
    }}
    """


def format_unit(label: str) -> str:
    units = {
        "绿电消费占比": "%",
        "单位用电碳强度": " kgCO2e/kWh",
        "储能供能占比": "%",
        "年减排量": " tCO2e",
        "经济收益": " 万元",
    }
    return units.get(label, "")
