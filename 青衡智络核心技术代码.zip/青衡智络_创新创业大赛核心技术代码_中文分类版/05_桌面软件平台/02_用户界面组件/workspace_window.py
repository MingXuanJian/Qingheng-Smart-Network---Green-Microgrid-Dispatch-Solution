from __future__ import annotations

from PySide6.QtCore import QRectF, Qt, Signal
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from .icon_widgets import LineIcon
from .theme import BLUE, GOLD, PRIMARY


class EnergyFlowWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setMinimumHeight(138)

    def paintEvent(self, event):
        del event
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(QPen(QColor("#A9DDB8"), 1, Qt.DashLine))
        painter.setBrush(QColor("#F7FCF8"))
        painter.drawRoundedRect(QRectF(1, 1, self.width() - 2, self.height() - 2), 16, 16)
        labels = ["光伏 / 风电", "储能系统", "数据处理", "指标核算", "报告输出"]
        positions = [0.10, 0.30, 0.50, 0.70, 0.90]
        y = self.height() * 0.48
        painter.setPen(QPen(QColor(PRIMARY), 2, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        for index, (position, label) in enumerate(zip(positions, labels)):
            center = self.width() * position
            rect = QRectF(center - 42, y - 18, 84, 36)
            painter.setBrush(QColor("#FFFFFF"))
            painter.drawRoundedRect(rect, 10, 10)
            painter.drawText(rect, Qt.AlignCenter, label)
            if index < len(positions) - 1:
                endpoint = self.width() * positions[index + 1] - 48
                painter.drawLine(center + 48, y, endpoint, y)
                painter.drawLine(endpoint - 8, y - 5, endpoint, y)
                painter.drawLine(endpoint - 8, y + 5, endpoint, y)
        painter.setPen(QPen(QColor("#6B7280"), 1))
        painter.drawText(
            QRectF(0, self.height() - 36, self.width(), 24),
            Qt.AlignCenter,
            "导入运行数据 → 校验数据质量 → 统一口径核算 → 导出分析结果",
        )


class WorkspaceWindow(QWidget):
    workspace_opened = Signal(str)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("微电网能碳数据分析与报告软件 - 项目工作区")
        self.resize(1280, 720)
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(self._left_brand(), 3)
        root.addWidget(self._workspace_card(), 2)

    def _left_brand(self) -> QWidget:
        panel = QFrame()
        panel.setStyleSheet(
            "QFrame{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #FFFFFF,stop:1 #EFF8F2);}"
            "QLabel{background:transparent;}"
        )
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(54, 34, 54, 34)
        header_row = QHBoxLayout()
        header_row.addWidget(LineIcon("bolt", PRIMARY, "#E8F7EC", 34))
        header = QLabel("微电网能碳数据分析与报告软件")
        header.setStyleSheet("font-size:22px;font-weight:800;")
        header_row.addWidget(header, 1)
        layout.addLayout(header_row)
        layout.addSpacing(22)
        title = QLabel("微电网能碳数据分析与\n报告软件")
        title.setStyleSheet("font-size:36px;font-weight:900;line-height:1.25;")
        intro = QLabel("绿电消纳、碳减排与经济效益评估")
        intro.setStyleSheet("font-size:16px;color:#6B7280;")
        layout.addWidget(title)
        layout.addWidget(intro)
        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(12)
        features = [
            ("leaf", "绿电消费核算", "核算绿电消费量与占比", PRIMARY),
            ("carbon", "碳减排评估", "按配置因子核算减排量", PRIMARY),
            ("monitor", "运行数据分析", "查看光伏、储能、负荷与并网数据", BLUE),
            ("report", "报告导出", "导出 HTML、CSV 和 Excel 文件", GOLD),
        ]
        for index, (icon, name, description, color) in enumerate(features):
            grid.addWidget(self._feature_card(icon, name, description, color), index // 2, index % 2)
        layout.addSpacing(18)
        layout.addLayout(grid)
        layout.addSpacing(18)
        layout.addWidget(EnergyFlowWidget())
        layout.addStretch(1)
        return panel

    def _feature_card(self, icon: str, name: str, description: str, color: str) -> QFrame:
        card = QFrame()
        card.setObjectName("FeatureCard")
        card.setStyleSheet("#FeatureCard{background:#FFFFFF;border:1px solid #E5E7EB;border-radius:14px;}")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.addWidget(LineIcon(icon, color, f"{color}22", 46), 0, Qt.AlignCenter)
        name_label = QLabel(name)
        name_label.setAlignment(Qt.AlignCenter)
        name_label.setStyleSheet("font-weight:800;font-size:15px;")
        text = QLabel(description)
        text.setWordWrap(True)
        text.setAlignment(Qt.AlignCenter)
        text.setStyleSheet("color:#6B7280;")
        layout.addWidget(name_label)
        layout.addWidget(text)
        return card

    def _workspace_card(self) -> QWidget:
        outer = QFrame()
        outer.setStyleSheet("QFrame{background:#F7F9FB;}")
        wrap = QVBoxLayout(outer)
        wrap.setContentsMargins(46, 60, 46, 60)
        card = QFrame()
        card.setObjectName("WorkspaceCard")
        card.setStyleSheet("#WorkspaceCard{background:#FFFFFF;border:1px solid #E5E7EB;border-radius:18px;}")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(42, 34, 42, 34)
        title = QLabel("项目工作区")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size:30px;font-weight:900;background:transparent;")
        subtitle = QLabel("选择或填写项目名称后进入分析")
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setStyleSheet("color:#6B7280;background:transparent;")
        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addSpacing(18)
        layout.addWidget(self._access_summary())
        self.project = QLineEdit()
        self.project.setPlaceholderText("请输入项目名称")
        layout.addLayout(self._row("项目名称", self.project))
        enter = QPushButton("进入工作台")
        enter.setObjectName("PrimaryButton")
        enter.clicked.connect(self._submit)
        layout.addWidget(enter)
        layout.addStretch(1)
        wrap.addWidget(card)
        return outer

    def _access_summary(self) -> QWidget:
        panel = QFrame()
        panel.setStyleSheet("background:#F7FCF8;border:1px solid #D9EFDF;border-radius:12px;")
        layout = QHBoxLayout(panel)
        layout.setContentsMargins(12, 10, 12, 10)
        for icon, title, description in [
            ("system", "运行方式", "本地桌面"),
            ("data", "数据来源", "CSV / 验证数据"),
            ("carbon", "核算口径", "参数可配置"),
        ]:
            item = QHBoxLayout()
            item.addWidget(LineIcon(icon, PRIMARY, "#E8F7EC", 30))
            label = QLabel(f"{title}\n{description}")
            label.setStyleSheet("color:#2D7D46;font-weight:700;background:transparent;")
            item.addWidget(label)
            layout.addLayout(item, 1)
        return panel

    def _row(self, label: str, widget) -> QHBoxLayout:
        row = QHBoxLayout()
        name = QLabel(label)
        name.setFixedWidth(88)
        name.setStyleSheet("font-weight:700;background:transparent;")
        row.addWidget(name)
        row.addWidget(widget, 1)
        return row

    def _submit(self) -> None:
        project_name = self.project.text().strip()
        if not project_name:
            QMessageBox.warning(self, "项目信息不完整", "请输入项目名称。")
            return
        self.workspace_opened.emit(project_name)
