from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from .icon_widgets import LineIcon
from .theme import BLUE, GOLD, PRIMARY, format_unit


class Card(QFrame):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setObjectName("Card")


class KpiCard(Card):
    def __init__(self, title: str, value: float | str, note: str, color: str = PRIMARY, icon: str = "leaf"):
        super().__init__()
        self.title = title
        self.value_label = QLabel()
        self.value_label.setObjectName("KpiValue")
        self.set_value(value)
        title_label = QLabel(title)
        title_label.setStyleSheet("font-weight:700; background:transparent;")
        note_label = QLabel(note)
        note_label.setStyleSheet(f"color:{color}; background:transparent;font-size:12px;")
        top = QHBoxLayout()
        top.setSpacing(12)
        text = QVBoxLayout()
        text.setSpacing(2)
        text.addWidget(title_label)
        text.addWidget(self.value_label)
        top.addWidget(LineIcon(icon, color, "#E8F7EC", 50))
        top.addLayout(text, 1)
        bottom = QHBoxLayout()
        bottom.addStretch(1)
        bottom.addWidget(note_label)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 10)
        layout.setSpacing(6)
        layout.addLayout(top)
        layout.addLayout(bottom)

    def set_value(self, value: float | str) -> None:
        self.value_label.setText(f"{value}{format_unit(self.title)}")


class MetricCard(Card):
    def __init__(self, title: str, value: str, accent: str = PRIMARY):
        super().__init__()
        title_label = QLabel(title)
        title_label.setObjectName("Subtle")
        value_label = QLabel(value)
        value_label.setStyleSheet(f"font-size:23px;font-weight:800;color:{accent};background:transparent;")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.addWidget(title_label)
        layout.addWidget(value_label)


class ReportCard(Card):
    def __init__(self, title: str, desc: str, color: str = PRIMARY):
        super().__init__()
        icon_name = "export" if "导出" in title else "report"
        title_label = QLabel(title)
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("font-weight:700;background:transparent;")
        desc_label = QLabel(desc)
        desc_label.setObjectName("Subtle")
        desc_label.setWordWrap(True)
        desc_label.setAlignment(Qt.AlignCenter)
        self.button = QPushButton("导出数据" if "导出" in title else "生成报告")
        self.button.setObjectName("GhostButton")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(6)
        layout.addWidget(LineIcon(icon_name, color, f"{color}22", 42), 0, Qt.AlignCenter)
        layout.addWidget(title_label)
        layout.addWidget(desc_label)
        layout.addStretch(1)
        layout.addWidget(self.button)


def default_kpi_cards(values: dict[str, float]) -> list[KpiCard]:
    return [
        KpiCard("绿电消费占比", values.get("绿电消费占比", 0), "按当前数据计算", PRIMARY, "leaf"),
        KpiCard("单位用电碳强度", values.get("单位用电碳强度", 0), "按购电量核算", BLUE, "carbon"),
        KpiCard("储能供能占比", values.get("储能供能占比", 0), "仅计绿色储能", PRIMARY, "data"),
        KpiCard("年减排量", values.get("年减排量", 0), "按数据周期年化", "#4BA083", "carbon"),
        KpiCard("经济收益", values.get("经济收益", 0), "节电与碳价值", GOLD, "scenario"),
    ]
