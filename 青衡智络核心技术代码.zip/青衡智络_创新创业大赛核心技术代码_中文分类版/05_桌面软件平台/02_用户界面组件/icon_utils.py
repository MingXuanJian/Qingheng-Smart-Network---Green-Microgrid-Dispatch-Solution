from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter


def generate_app_icon(png_path: str | Path, ico_path: str | Path | None = None, size: int = 512) -> tuple[Path, Path | None]:
    png_path = Path(png_path)
    png_path.parent.mkdir(parents=True, exist_ok=True)
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    margin = int(size * 0.08)
    radius = int(size * 0.12)
    draw.rounded_rectangle(
        [margin, margin, size - margin, size - margin],
        radius=radius,
        fill=(246, 251, 248, 255),
        outline=(213, 238, 224, 255),
        width=max(3, size // 80),
    )

    shadow = Image.new("RGBA", img.size, (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    hex_points = _hex_points(size, center=(size / 2, size / 2), radius=size * 0.33)
    sd.line(hex_points + [hex_points[0]], fill=(41, 130, 94, 72), width=size // 18, joint="curve")
    shadow = shadow.filter(ImageFilter.GaussianBlur(size // 70))
    img.alpha_composite(shadow)

    draw = ImageDraw.Draw(img)
    colors = [(76, 141, 246, 255), (47, 180, 99, 255), (56, 201, 184, 255)]
    for offset, color in [(0, colors[0]), (size // 62, colors[2]), (size // 31, colors[1])]:
        points = _hex_points(size, center=(size / 2 + offset / 5, size / 2 - offset / 7), radius=size * 0.31)
        draw.line(points + [points[0]], fill=color, width=size // 22, joint="curve")

    inner = _hex_points(size, center=(size / 2, size / 2), radius=size * 0.20)
    draw.polygon(inner, fill=(238, 250, 243, 255))
    draw.line(inner + [inner[0]], fill=(183, 226, 201, 255), width=size // 80)

    bolt = [
        (size * 0.54, size * 0.22),
        (size * 0.36, size * 0.51),
        (size * 0.50, size * 0.51),
        (size * 0.43, size * 0.77),
        (size * 0.67, size * 0.43),
        (size * 0.53, size * 0.43),
    ]
    draw.polygon(bolt, fill=(42, 171, 92, 255))
    draw.line(bolt + [bolt[0]], fill=(255, 255, 255, 120), width=size // 95)

    leaf = [(size * 0.25, size * 0.60), (size * 0.36, size * 0.47), (size * 0.43, size * 0.61), (size * 0.32, size * 0.72)]
    draw.ellipse([size * 0.22, size * 0.52, size * 0.43, size * 0.74], fill=(113, 191, 121, 210))
    draw.line(leaf, fill=(255, 255, 255, 170), width=size // 90)

    img.save(png_path)
    ico_result = None
    if ico_path:
        ico_result = Path(ico_path)
        ico_result.parent.mkdir(parents=True, exist_ok=True)
        img.save(ico_result, sizes=[(256, 256), (128, 128), (64, 64), (32, 32), (16, 16)])
    return png_path, ico_result


def _hex_points(size: int, center: tuple[float, float], radius: float) -> list[tuple[float, float]]:
    import math

    cx, cy = center
    return [
        (cx + radius * math.cos(math.pi / 6 + i * math.pi / 3), cy + radius * math.sin(math.pi / 6 + i * math.pi / 3))
        for i in range(6)
    ]
