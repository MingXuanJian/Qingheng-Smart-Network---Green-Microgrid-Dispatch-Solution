from __future__ import annotations

from PySide6.QtWidgets import QHBoxLayout, QMainWindow, QScrollArea, QStackedWidget, QVBoxLayout, QWidget

from microgrid_app.calculator import recalculate_derived_columns
from microgrid_app.config import REPORTS_DIR, save_project_context
from microgrid_app.data_io import DataValidationError, load_initial_data
from microgrid_app.models import AppInfo, CarbonParams, ProjectContext
from microgrid_app.reference_data import load_validation_data

from .pages.analysis_page import AnalysisPage
from .pages.dashboard_page import DashboardPage
from .pages.data_page import DataPage
from .pages.export_page import ExportPage
from .pages.params_page import ParamsPage
from .pages.scenario_page import ScenarioPage
from .pages.system_page import SystemPage
from .sidebar import Sidebar
from .topbar import TopBar


class MainWindow(QMainWindow):
    def __init__(self, project_name: str, params: CarbonParams | None = None):
        super().__init__()
        self.project_name = project_name
        self.params = params or CarbonParams(report_output_dir=str(REPORTS_DIR))
        self.data_warning = ""
        self.setWindowTitle(AppInfo().name)
        self.resize(1600, 900)
        try:
            self.data, self.data_source = load_initial_data(self.params)
        except DataValidationError as error:
            self.data = load_validation_data(self.params)
            self.data_source = "内置计算验证数据"
            self.data_warning = f"已保存的项目数据无法读取：{error}"
        save_project_context(ProjectContext(project_name=self.project_name, data_source=self.data_source))
        self.sidebar = Sidebar()
        self.topbar = TopBar(project_name)
        self.stack = QStackedWidget()
        self.pages = []
        self._build()

    def _build(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        main_layout = QHBoxLayout(root)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        main_layout.addWidget(self.sidebar)
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)
        right_layout.addWidget(self.topbar)
        right_layout.addWidget(self.stack, 1)
        main_layout.addWidget(right, 1)
        self._add_pages()
        self.sidebar.page_changed.connect(self.switch_page)

    def _add_pages(self) -> None:
        self.dashboard = DashboardPage(self.data, self.params, self.data_source, self.project_name)
        self.data_page = DataPage(self.data, self.params, self.data_source)
        self.scenario_page = ScenarioPage(self.data, self.params)
        self.params_page = ParamsPage(self.params)
        self.analysis_page = AnalysisPage(self.data, self.params)
        self.export_page = ExportPage(self.data, self.params, self.project_name, self.data_source)
        self.system_page = SystemPage()
        self.data_page.data_changed.connect(self._set_data)
        self.params_page.params_saved.connect(self._set_params)
        self.pages = [
            self.dashboard,
            self.data_page,
            self.params_page,
            self.scenario_page,
            self.analysis_page,
            self.export_page,
            self.system_page,
        ]
        for page in self.pages:
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QScrollArea.NoFrame)
            scroll.setWidget(page)
            self.stack.addWidget(scroll)

    def switch_page(self, index: int) -> None:
        self.stack.setCurrentIndex(index)
        self.sidebar.set_current(index)

    def _set_data(self, data, data_source: str) -> None:
        self.data = data
        self.data_source = data_source
        save_project_context(ProjectContext(project_name=self.project_name, data_source=data_source))
        self.dashboard.set_data(data, data_source)
        self.scenario_page.set_data(data)
        self.analysis_page.set_data(data)
        self.export_page.set_data(data, data_source)

    def _set_params(self, params: CarbonParams) -> None:
        self.params = params
        self.data = recalculate_derived_columns(self.data, params)
        self.dashboard.set_params(params)
        self.dashboard.set_data(self.data, self.data_source)
        self.data_page.set_params(params)
        self.scenario_page.set_params(params)
        self.analysis_page.set_params(params)
        self.export_page.set_params(params)
        self.export_page.set_data(self.data, self.data_source)
