from __future__ import annotations

import numpy as np
import pandas as pd
from matplotlib import rcParams
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
rcParams["axes.unicode_minus"] = False


class MplCanvas(FigureCanvas):
    def __init__(self, width: float = 5, height: float = 3, dpi: int = 100):
        self.fig = Figure(figsize=(width, height), dpi=dpi, facecolor="white")
        super().__init__(self.fig)
        self.setStyleSheet("background:white;")


class OperationalEnergyChart(MplCanvas):
    def __init__(self, data):
        super().__init__(8.8, 3.05, 100)
        self.ax = self.fig.add_subplot(111)
        self.mode = "最近24条"
        self.data = data.copy()
        self.draw_chart()

    def set_data(self, data) -> None:
        self.data = data.copy()
        self.draw_chart()

    def set_range_mode(self, mode: str) -> None:
        self.mode = mode
        self.draw_chart()

    def _visible_data(self):
        if self.mode == "全部数据":
            return self.data
        return self.data.tail(24)

    def draw_chart(self) -> None:
        self.ax.clear()
        visible = self._visible_data()
        if visible.empty:
            self.ax.text(0.5, 0.5, "暂无可绘制数据", ha="center", va="center", transform=self.ax.transAxes)
            self.draw_idle()
            return

        x = np.arange(len(visible))
        palette = {
            "光伏发电量(kWh)": ("光伏发电量", "#63B276"),
            "负荷用电量(kWh)": ("负荷用电量", "#6E8FEF"),
            "储能充放电量(kWh)": ("储能充放电量", "#E4B64B"),
            "并网电量(kWh)": ("并网电量", "#9277E8"),
        }
        for column, (label, color) in palette.items():
            values = pd.to_numeric(visible.get(column, 0), errors="coerce").fillna(0).to_numpy()
            self.ax.plot(x, values, label=f"{label}(kWh)", color=color, linewidth=1.85)

        self.ax.axhline(0, color="#A9B1BC", linewidth=0.8)
        self.ax.grid(True, color="#E7EBEF", linewidth=0.8)
        self.ax.set_facecolor("white")
        self.ax.set_ylabel("每个数据周期的电量")
        tick_count = min(6, len(x))
        ticks = np.linspace(0, len(x) - 1, tick_count, dtype=int)
        labels = [str(visible.iloc[index].get("时间", index))[-11:] for index in ticks]
        self.ax.set_xticks(ticks)
        self.ax.set_xticklabels(labels)
        self.ax.tick_params(axis="both", labelsize=9, colors="#1F2937")
        for spine in self.ax.spines.values():
            spine.set_color("#E5E7EB")
        self.ax.legend(
            ncol=4,
            loc="upper center",
            bbox_to_anchor=(0.5, 1.18),
            frameon=False,
            fontsize=9,
            handlelength=2.5,
            columnspacing=1.6,
        )
        self.fig.subplots_adjust(left=0.09, right=0.98, top=0.78, bottom=0.20)
        self.draw_idle()


class DonutChart(MplCanvas):
    def __init__(self, values: dict[str, float] | None = None):
        super().__init__(3.05, 2.55, 100)
        self.values = values or {}
        self.draw_chart()

    def set_values(self, values: dict[str, float]) -> None:
        self.values = values
        self.draw_chart()

    def draw_chart(self) -> None:
        self.fig.clear()
        ax = self.fig.add_subplot(111)
        labels = list(self.values)
        values = [max(float(value), 0.0) for value in self.values.values()]
        total = sum(values)
        colors = ["#4D9B57", "#A8D8B0", "#D8EEDF", "#78BD7F"]
        if total > 0:
            ax.pie(
                values,
                colors=colors[: len(values)],
                startangle=90,
                counterclock=False,
                wedgeprops=dict(width=0.34, edgecolor="white"),
            )
        else:
            ax.pie([1], colors=["#E5E7EB"], wedgeprops=dict(width=0.34, edgecolor="white"))
        ax.text(0, 0.12, f"{total:,.2f}", ha="center", va="center", fontsize=15, fontweight="bold", color="#1F2937")
        ax.text(0, -0.13, "tCO2e\n年化减排量", ha="center", va="center", fontsize=9, color="#374151")
        ax.set(aspect="equal")
        if labels:
            ax.set_title("", fontsize=1)
        self.fig.subplots_adjust(left=0.02, right=0.98, top=0.98, bottom=0.02)
        self.draw_idle()


class SimpleLineChart(MplCanvas):
    def __init__(self, title: str = "", values: list[float] | None = None):
        super().__init__(4.8, 2.55, 100)
        self.title = title
        self.values = values or []
        self.draw_chart()

    def set_values(self, values: list[float]) -> None:
        self.values = values
        self.draw_chart()

    def draw_chart(self) -> None:
        self.fig.clear()
        ax = self.fig.add_subplot(111)
        values = np.asarray(self.values if self.values else [0.0], dtype=float)
        x = np.arange(len(values))
        ax.plot(x, values, color="#2FB463", linewidth=2.1)
        ax.fill_between(x, 0, values, color="#E8F7EC")
        ax.set_title(self.title, loc="left", fontsize=11, fontweight="bold")
        ax.grid(True, color="#E7EBEF")
        ax.tick_params(labelsize=9)
        self.fig.tight_layout(pad=1.0)
        self.draw_idle()


class BarCompareChart(MplCanvas):
    def __init__(self, names: list[str] | None = None, values: list[float] | None = None):
        super().__init__(4.8, 2.55, 100)
        self.names = names or []
        self.values = values or []
        self.draw_chart()

    def set_values(self, names: list[str], values: list[float]) -> None:
        self.names = names
        self.values = values
        self.draw_chart()

    def draw_chart(self) -> None:
        self.fig.clear()
        ax = self.fig.add_subplot(111)
        names = self.names or ["暂无数据"]
        values = self.values or [0.0]
        colors = ["#A8D8B0", "#78BD7F", "#4D9B57", "#2FB463"]
        ax.bar(names, values, color=colors[: len(names)], width=0.55)
        upper = max(values) * 1.18 if max(values) > 0 else 100
        ax.set_ylim(0, max(upper, 10))
        ax.set_ylabel("绿电消费占比(%)")
        ax.grid(True, axis="y", color="#E7EBEF")
        ax.tick_params(labelsize=9)
        self.fig.tight_layout(pad=1.0)
        self.draw_idle()
