from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QVBoxLayout

from .icon_widgets import ICON_COLORS, LineIcon
from .theme import MUTED, PRIMARY, PRIMARY_LIGHT


class NavItem(QFrame):
    clicked = Signal()

    def __init__(self, icon_name: str, text: str):
        super().__init__()
        self.setObjectName("NavItem")
        self.text_label = QLabel(text)
        self.text_label.setObjectName("NavText")
        self.icon = LineIcon(icon_name, ICON_COLORS.get(icon_name, PRIMARY), "#F4F7F6", 28)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 9, 12, 9)
        layout.setSpacing(12)
        layout.addWidget(self.icon)
        layout.addWidget(self.text_label, 1)
        self.set_selected(False)

    def mousePressEvent(self, event):
        del event
        self.clicked.emit()

    def set_selected(self, selected: bool) -> None:
        if selected:
            self.setStyleSheet(f"#NavItem{{background:{PRIMARY_LIGHT};border-left:4px solid {PRIMARY};border-radius:10px;}}")
            self.text_label.setStyleSheet(f"#NavText{{font-size:15px;font-weight:800;color:{PRIMARY};background:transparent;border:none;}}")
            self.icon.bg = QColor("#D8F0DF")
        else:
            self.setStyleSheet("#NavItem{background:#FFFFFF;border-left:4px solid transparent;border-radius:10px;}")
            self.text_label.setStyleSheet("#NavText{font-size:15px;font-weight:700;color:#344054;background:transparent;border:none;}")
            self.icon.bg = QColor("#F4F7F6")
        self.icon.update()


class Sidebar(QFrame):
    page_changed = Signal(int)

    def __init__(self):
        super().__init__()
        self.setObjectName("Sidebar")
        self.setFixedWidth(220)
        self.setStyleSheet("#Sidebar{background:#FFFFFF;border-right:1px solid #E5E7EB;}")
        self.buttons: list[NavItem] = []
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 18, 14, 18)
        logo_row = QHBoxLayout()
        logo_row.setSpacing(10)
        logo_row.addWidget(LineIcon("bolt", PRIMARY, "#E8F7EC", 38))
        logo = QLabel("微电网能碳\n数据分析与\n报告软件")
        logo.setStyleSheet("font-size:15px;font-weight:800;color:#1F2937;background:transparent;border:none;line-height:1.45;")
        logo_row.addWidget(logo, 1)
        layout.addLayout(logo_row)
        layout.addSpacing(22)
        items = [
            ("home", "首页概览"),
            ("data", "数据管理"),
            ("params", "参数配置"),
            ("scenario", "情景试算"),
            ("report", "分析报告"),
            ("export", "导出中心"),
            ("system", "系统管理"),
        ]
        for index, (icon, text) in enumerate(items):
            item = NavItem(icon, text)
            item.clicked.connect(lambda i=index: self.page_changed.emit(i))
            self.buttons.append(item)
            layout.addWidget(item)
            layout.addSpacing(3)
        layout.addStretch(1)
        footer = QLabel("本地离线版")
        footer.setStyleSheet(f"color:{MUTED};font-size:12px;background:transparent;border:none;")
        layout.addWidget(footer)
        self.set_current(0)

    def set_current(self, index: int) -> None:
        for i, btn in enumerate(self.buttons):
            btn.set_selected(i == index)
