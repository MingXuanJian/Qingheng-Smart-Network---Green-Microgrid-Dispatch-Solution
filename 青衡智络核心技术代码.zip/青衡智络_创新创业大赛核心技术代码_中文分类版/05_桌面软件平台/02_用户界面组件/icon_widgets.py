from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QWidget

from .theme import BLUE, GOLD, PRIMARY


class LineIcon(QWidget):
    def __init__(self, name: str, color: str = PRIMARY, bg: str = "#E8F7EC", size: int = 34):
        super().__init__()
        self.name = name
        self.color = QColor(color)
        self.bg = QColor(bg)
        self.setFixedSize(size, size)

    def paintEvent(self, event):
        del event
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(1, 1, self.width() - 2, self.height() - 2)
        p.setPen(Qt.NoPen)
        p.setBrush(self.bg)
        p.drawRoundedRect(r, self.width() * 0.28, self.height() * 0.28)
        p.setPen(QPen(self.color, max(2, self.width() // 15), Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        if self.name == "home":
            self._home(p)
        elif self.name == "data":
            self._data(p)
        elif self.name == "params":
            self._params(p)
        elif self.name == "scenario":
            self._scenario(p)
        elif self.name == "report":
            self._report(p)
        elif self.name == "export":
            self._export(p)
        elif self.name == "system":
            self._system(p)
        elif self.name == "carbon":
            self._carbon(p)
        elif self.name == "monitor":
            self._monitor(p)
        elif self.name == "leaf":
            self._leaf(p)
        else:
            self._bolt(p)

    def _scale(self, x: float, y: float) -> QPointF:
        return QPointF(self.width() * x, self.height() * y)

    def _home(self, p: QPainter) -> None:
        p.drawLine(self._scale(0.28, 0.50), self._scale(0.50, 0.30))
        p.drawLine(self._scale(0.50, 0.30), self._scale(0.72, 0.50))
        p.drawRoundedRect(QRectF(self.width() * 0.34, self.height() * 0.50, self.width() * 0.32, self.height() * 0.25), 2, 2)

    def _data(self, p: QPainter) -> None:
        for y in [0.34, 0.50, 0.66]:
            p.drawLine(self._scale(0.30, y), self._scale(0.70, y))
        p.drawLine(self._scale(0.36, 0.28), self._scale(0.36, 0.72))

    def _params(self, p: QPainter) -> None:
        p.drawEllipse(QRectF(self.width() * 0.35, self.height() * 0.35, self.width() * 0.30, self.height() * 0.30))
        p.drawLine(self._scale(0.50, 0.20), self._scale(0.50, 0.30))
        p.drawLine(self._scale(0.50, 0.70), self._scale(0.50, 0.80))
        p.drawLine(self._scale(0.20, 0.50), self._scale(0.30, 0.50))
        p.drawLine(self._scale(0.70, 0.50), self._scale(0.80, 0.50))

    def _scenario(self, p: QPainter) -> None:
        p.drawLine(self._scale(0.28, 0.64), self._scale(0.45, 0.42))
        p.drawLine(self._scale(0.45, 0.42), self._scale(0.58, 0.55))
        p.drawLine(self._scale(0.58, 0.55), self._scale(0.74, 0.32))
        p.drawLine(self._scale(0.30, 0.72), self._scale(0.76, 0.72))

    def _report(self, p: QPainter) -> None:
        p.drawRoundedRect(QRectF(self.width() * 0.32, self.height() * 0.24, self.width() * 0.36, self.height() * 0.52), 2, 2)
        p.drawLine(self._scale(0.40, 0.40), self._scale(0.60, 0.40))
        p.drawLine(self._scale(0.40, 0.53), self._scale(0.60, 0.53))

    def _export(self, p: QPainter) -> None:
        p.drawLine(self._scale(0.50, 0.25), self._scale(0.50, 0.58))
        p.drawLine(self._scale(0.38, 0.47), self._scale(0.50, 0.60))
        p.drawLine(self._scale(0.62, 0.47), self._scale(0.50, 0.60))
        p.drawLine(self._scale(0.32, 0.74), self._scale(0.68, 0.74))

    def _system(self, p: QPainter) -> None:
        p.drawEllipse(QRectF(self.width() * 0.36, self.height() * 0.36, self.width() * 0.28, self.height() * 0.28))
        for x, y in [(0.50, 0.22), (0.50, 0.78), (0.22, 0.50), (0.78, 0.50)]:
            p.drawPoint(self._scale(x, y))

    def _carbon(self, p: QPainter) -> None:
        p.drawText(QRectF(0, self.height() * 0.24, self.width(), self.height() * 0.50), Qt.AlignCenter, "CO2")

    def _monitor(self, p: QPainter) -> None:
        p.drawRoundedRect(QRectF(self.width() * 0.28, self.height() * 0.28, self.width() * 0.44, self.height() * 0.32), 3, 3)
        p.drawLine(self._scale(0.38, 0.72), self._scale(0.62, 0.72))
        p.drawLine(self._scale(0.50, 0.60), self._scale(0.50, 0.72))

    def _leaf(self, p: QPainter) -> None:
        path = QPainterPath(self._scale(0.32, 0.60))
        path.cubicTo(self._scale(0.34, 0.30), self._scale(0.68, 0.26), self._scale(0.70, 0.48))
        path.cubicTo(self._scale(0.66, 0.72), self._scale(0.42, 0.74), self._scale(0.32, 0.60))
        p.drawPath(path)
        p.drawLine(self._scale(0.38, 0.61), self._scale(0.65, 0.43))

    def _bolt(self, p: QPainter) -> None:
        points = [self._scale(0.56, 0.22), self._scale(0.36, 0.52), self._scale(0.50, 0.52), self._scale(0.42, 0.78), self._scale(0.66, 0.44), self._scale(0.52, 0.44)]
        p.drawPolygon(points)


ICON_COLORS = {
    "home": PRIMARY,
    "data": "#37A2A0",
    "params": "#8A6DE9",
    "scenario": GOLD,
    "report": BLUE,
    "export": "#4BA083",
    "system": "#667085",
}
