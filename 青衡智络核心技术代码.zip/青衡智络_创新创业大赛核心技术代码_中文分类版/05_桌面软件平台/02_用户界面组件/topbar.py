from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel


class TopBar(QFrame):
    def __init__(self, project_name: str):
        super().__init__()
        self.setFixedHeight(62)
        self.setStyleSheet("QFrame{background:#FFFFFF;border-bottom:1px solid #E5E7EB;} QLabel{background:transparent;}")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(24, 9, 24, 9)
        layout.setSpacing(12)
        title = QLabel("微电网绿碳分析工作台")
        title.setStyleSheet("font-size:17px;font-weight:800;color:#1F2937;background:transparent;")
        self.project = QLabel(f"当前项目：{project_name}")
        self.time = QLabel()
        self.mode = QLabel("● 本地离线分析")
        self.mode.setStyleSheet("color:#2FB463;font-weight:700;background:transparent;")
        for label in [self.project, self.time]:
            label.setStyleSheet("color:#1F2937;background:transparent;")
        layout.addWidget(title)
        layout.addStretch(1)
        layout.addWidget(self.project)
        layout.addWidget(QLabel("|"))
        layout.addWidget(self.time)
        layout.addWidget(QLabel("|"))
        layout.addWidget(self.mode)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(1000)
        self._tick()

    def _tick(self) -> None:
        self.time.setText(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
