from __future__ import annotations

from PySide6.QtCore import Signal, Qt
from PySide6.QtWidgets import (
    QDoubleSpinBox,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QSlider,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from microgrid_app.calculator import run_scenario, scenario_comparison
from microgrid_app.models import CarbonParams

from ..cards import Card
from ..charts import BarCompareChart
from ..theme import BLUE, GOLD, PRIMARY


class ScenarioPage(QWidget):
    def __init__(self, data, params: CarbonParams):
        super().__init__()
        self.data = data
        self.params = params
        self.result = {}
        self.inputs: dict[str, QDoubleSpinBox] = {}
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 22, 26, 22)
        root.setSpacing(12)
        title = QLabel("情景试算")
        title.setObjectName("Title")
        subtitle = QLabel("调整关键参数，评估绿电消纳、碳减排和经济收益变化。")
        subtitle.setObjectName("Subtle")
        root.addWidget(title)
        root.addWidget(subtitle)
        top = QHBoxLayout()
        top.setSpacing(12)
        top.addWidget(self._parameter_card(), 1)
        top.addWidget(self._result_card(), 3)
        root.addLayout(top, 3)
        bottom = QHBoxLayout()
        bottom.setSpacing(12)
        bottom.addWidget(self._compare_card(), 2)
        bottom.addWidget(self._advice_card(), 1)
        root.addLayout(bottom, 2)
        self.run()

    def _parameter_card(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel("试算参数")
        title.setObjectName("PageTitle")
        layout.addWidget(title)
        for key, label, default in [
            ("load_factor", "负荷倍率", 1.00),
            ("pv_factor", "光伏倍率", 1.00),
            ("wind_factor", "风电倍率", 1.00),
            ("storage_factor", "储能容量倍率", 1.00),
            ("carbon_price_factor", "碳价倍率", 1.00),
        ]:
            layout.addLayout(self._factor_row(key, label, default))
        btns = QHBoxLayout()
        run = QPushButton("运行试算")
        run.setObjectName("PrimaryButton")
        run.clicked.connect(self.run)
        apply = QPushButton("确认试算")
        apply.setObjectName("GhostButton")
        apply.clicked.connect(self.apply)
        btns.addWidget(run)
        btns.addWidget(apply)
        layout.addLayout(btns)
        tips = QLabel("优先调整光伏和储能参数，关注弃电率与综合收益。")
        tips.setWordWrap(True)
        tips.setStyleSheet("background:#F7FCF8;border:1px solid #DDEFE3;border-radius:10px;padding:12px;color:#2D7D46;")
        layout.addWidget(tips)
        return card

    def _factor_row(self, key: str, label: str, default: float) -> QVBoxLayout:
        outer = QVBoxLayout()
        title_row = QHBoxLayout()
        title_row.addWidget(QLabel(label))
        title_row.addStretch(1)
        spin = QDoubleSpinBox()
        spin.setRange(0.1, 3.0)
        spin.setSingleStep(0.05)
        spin.setDecimals(2)
        spin.setValue(default)
        spin.setAlignment(Qt.AlignCenter)
        spin.setFixedWidth(116)
        slider = QSlider(Qt.Horizontal)
        slider.setRange(10, 300)
        slider.setValue(int(default * 100))
        slider.valueChanged.connect(lambda value, s=spin: s.setValue(value / 100))
        spin.valueChanged.connect(lambda value, sl=slider: sl.setValue(int(value * 100)))
        spin.valueChanged.connect(self.run)
        self.inputs[key] = spin
        title_row.addWidget(spin)
        outer.addLayout(title_row)
        outer.addWidget(slider)
        return outer

    def set_data(self, data) -> None:
        self.data = data
        self.run()

    def set_params(self, params: CarbonParams) -> None:
        self.params = params
        self.run()

    def _result_card(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        head = QHBoxLayout()
        title = QLabel("试算结果")
        title.setObjectName("PageTitle")
        self.result_hint = QLabel("参数变化后自动更新")
        self.result_hint.setObjectName("Subtle")
        head.addWidget(title)
        head.addStretch(1)
        head.addWidget(self.result_hint)
        layout.addLayout(head)
        self.result_grid = QGridLayout()
        self.result_grid.setHorizontalSpacing(10)
        self.result_grid.setVerticalSpacing(10)
        layout.addLayout(self.result_grid)
        self.summary = QLabel()
        self.summary.setWordWrap(True)
        self.summary.setStyleSheet("background:#F7FCF8;border:1px solid #DDEFE3;border-radius:10px;padding:12px;color:#2D7D46;font-weight:700;")
        layout.addWidget(self.summary)
        return card

    def _compact_metric(self, title: str, value: str, accent: str) -> Card:
        card = Card()
        card.setMinimumHeight(112)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(8)
        label = QLabel(title)
        label.setStyleSheet("color:#6B7280;background:transparent;font-weight:700;")
        number = QLabel(value)
        number.setStyleSheet(f"font-size:27px;font-weight:900;color:{accent};background:transparent;")
        visual = QHBoxLayout()
        visual.addStretch(1)
        visual.addWidget(number, 0, Qt.AlignVCenter)
        visual.addStretch(1)
        layout.addWidget(label)
        layout.addStretch(1)
        layout.addLayout(visual)
        layout.addStretch(1)
        return card

    def _compare_card(self) -> Card:
        card = Card()
        layout = QHBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        left = QVBoxLayout()
        title = QLabel("方案对比")
        title.setObjectName("PageTitle")
        self.compare_table = QTableWidget(4, 4)
        self.compare_table.verticalHeader().setVisible(False)
        self.compare_table.setHorizontalHeaderLabels(["方案", "绿电消费占比", "碳减排量", "综合收益"])
        left.addWidget(title)
        left.addWidget(self.compare_table)
        layout.addLayout(left, 1)
        self.compare_chart = BarCompareChart()
        layout.addWidget(self.compare_chart, 1)
        return card

    def _advice_card(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel("试算建议")
        title.setObjectName("PageTitle")
        layout.addWidget(title)
        self.advice_labels = []
        for _ in range(4):
            label = QLabel()
            label.setWordWrap(True)
            label.setStyleSheet("background:#FFFFFF;border:1px solid #E5E7EB;border-radius:10px;padding:10px;color:#344054;")
            self.advice_labels.append(label)
            layout.addWidget(label)
        layout.addStretch(1)
        return card

    def run(self) -> None:
        if not self.inputs:
            return
        values = {}
        for key, spin in self.inputs.items():
            values[key] = spin.value()
        self.result = run_scenario(self.data, self.params, **values)
        while self.result_grid.count():
            item = self.result_grid.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        colors = [PRIMARY, BLUE, GOLD, PRIMARY, "#4BA083", "#7C5CC4"]
        for i, (key, val) in enumerate(self.result.items()):
            units = {
                "绿电消费占比": "%",
                "年碳减排量": " tCO2e",
                "上网电量": " kWh",
                "弃电量": " kWh",
                "弃电率": "%",
                "储能供能占比": "%",
                "单位用电碳强度": " kgCO2e/kWh",
                "避免购电价值": " 万元",
                "售电收入": " 万元",
                "碳价值": " 万元",
                "综合收益": " 万元",
            }
            suffix = units.get(key, "")
            accent = colors[i] if i < len(colors) else PRIMARY
            metric = self._compact_metric(key, f"{val}{suffix}", accent)
            self.result_grid.addWidget(metric, i // 3, i % 3)
        self.summary.setText(
            f"当前方案绿电消费占比为 {self.result['绿电消费占比']}%，年碳减排量为 "
            f"{self.result['年碳减排量']} tCO2e，综合收益为 {self.result['综合收益']} 万元。"
        )
        self._refresh_compare_table()
        self._refresh_advice()

    def _refresh_compare_table(self) -> None:
        comparison = scenario_comparison(self.data, self.params)
        rows = []
        for name, result in comparison:
            row = [
                name,
                f"{result['绿电消费占比']}%",
                f"{result['年碳减排量']}",
                f"{result['综合收益']}",
            ]
            rows.append(row)
        for r, row in enumerate(rows):
            for c, text in enumerate(row):
                item = QTableWidgetItem(text)
                item.setTextAlignment(Qt.AlignCenter)
                self.compare_table.setItem(r, c, item)
        self.compare_table.horizontalHeader().setStretchLastSection(True)
        chart_names = []
        chart_values = []
        for name, result in comparison:
            chart_names.append(name.replace("方案", ""))
            chart_values.append(result["绿电消费占比"])
        self.compare_chart.set_values(chart_names, chart_values)

    def _refresh_advice(self) -> None:
        advice = [
            "提高光伏倍率可提升绿电供给，但需要关注中午时段弃电风险。",
            "储能容量倍率提升后，低谷充电和高峰放电能力更强。",
            "当碳价倍率上升时，碳减排收益权重增大。",
            "应用方案后首页 KPI 会按同一核算口径同步刷新。",
        ]
        for label, text in zip(self.advice_labels, advice):
            label.setText(f"●  {text}")

    def apply(self) -> None:
        QMessageBox.information(self, "试算完成", "当前试算结果已更新，可在本页与分析报告中查看方案对比。")
