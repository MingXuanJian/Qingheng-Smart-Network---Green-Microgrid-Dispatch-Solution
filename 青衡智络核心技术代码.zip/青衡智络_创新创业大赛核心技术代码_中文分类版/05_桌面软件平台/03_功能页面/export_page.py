from __future__ import annotations

from datetime import date
from pathlib import Path

import pandas as pd
from PySide6.QtCore import QDate, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateEdit,
    QFormLayout,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from microgrid_app.config import OUTPUTS_DIR
from microgrid_app.models import CarbonParams, ProjectContext
from microgrid_app.report import export_dataset

from ..cards import Card


class ExportPage(QWidget):
    def __init__(self, data, params: CarbonParams, project_name: str, data_source: str):
        super().__init__()
        self.data = data
        self.params = params
        self.project = ProjectContext(project_name=project_name, data_source=data_source)
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 22, 26, 22)
        title = QLabel("导出中心")
        title.setObjectName("Title")
        subtitle = QLabel("按所选范围生成分析报告与数据文件。")
        subtitle.setObjectName("Subtle")
        root.addWidget(title)
        root.addWidget(subtitle)
        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(12)
        grid.addWidget(self._config_card(), 0, 0)
        grid.addWidget(self._content_card(), 1, 0)
        grid.addWidget(self._operation_card(), 2, 0)
        grid.addWidget(self._recent_card(), 0, 1, 3, 1)
        grid.setColumnStretch(0, 3)
        grid.setColumnStretch(1, 2)
        root.addLayout(grid, 1)

    def set_data(self, data, data_source: str | None = None) -> None:
        self.data = data
        if data_source is not None:
            self.project.data_source = data_source
        timestamps = pd.to_datetime(self.data.get("时间", pd.Series(dtype=str)), errors="coerce").dropna()
        if not timestamps.empty and hasattr(self, "start"):
            start_date = timestamps.min().date()
            end_date = timestamps.max().date()
            self.start.setDate(QDate(start_date.year, start_date.month, start_date.day))
            self.end.setDate(QDate(end_date.year, end_date.month, end_date.day))

    def set_params(self, params: CarbonParams) -> None:
        self.params = params

    def _config_card(self) -> Card:
        card = Card()
        form = QFormLayout(card)
        form.setContentsMargins(18, 16, 18, 16)
        self.report_type = QComboBox()
        self.report_type.addItems(["月度报告", "季度报告", "年度报告", "自定义报告"])
        timestamps = pd.to_datetime(self.data.get("时间", pd.Series(dtype=str)), errors="coerce").dropna()
        start_date = timestamps.min().date() if not timestamps.empty else date.today()
        end_date = timestamps.max().date() if not timestamps.empty else date.today()
        self.start = QDateEdit()
        self.start.setCalendarPopup(True)
        self.start.setDate(QDate(start_date.year, start_date.month, start_date.day))
        self.end = QDateEdit()
        self.end.setCalendarPopup(True)
        self.end.setDate(QDate(end_date.year, end_date.month, end_date.day))
        self.format = QComboBox()
        self.format.addItems(["HTML", "CSV", "Excel"])
        form.addRow("报告类型", self.report_type)
        form.addRow("开始时间", self.start)
        form.addRow("结束时间", self.end)
        form.addRow("导出格式", self.format)
        return card

    def _content_card(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(12)
        title = QLabel("报告内容选择")
        title.setObjectName("PageTitle")
        layout.addWidget(title)
        hint = QLabel("选择需要写入报告的内容。")
        hint.setObjectName("Subtle")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(10)
        self.content_checks = []
        items = [
            ("项目概况", "项目范围与设备规模"),
            ("绿电消纳", "清洁能源供需匹配结果"),
            ("碳减排分析", "减排量与单位碳强度"),
            ("经济收益", "购售电与碳收益测算"),
            ("情景试算", "不同参数方案对比"),
            ("结论建议", "分析结论与优化建议"),
        ]
        for i, (text, desc) in enumerate(items):
            c = QCheckBox(f"{text}\n{desc}")
            c.setObjectName("TileCheck")
            c.setChecked(True)
            c.setMinimumHeight(76)
            c.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            self.content_checks.append(c)
            grid.addWidget(c, i // 3, i % 3)
        for col in range(3):
            grid.setColumnStretch(col, 1)
        layout.addLayout(grid)
        layout.addStretch(1)
        return card

    def _operation_card(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel("导出操作")
        title.setObjectName("PageTitle")
        layout.addWidget(title)
        buttons = QHBoxLayout()
        for text, handler, primary in [("预览报告", self.preview, False), ("生成报告", self.generate, True), ("打开输出目录", self.open_dir, False)]:
            btn = QPushButton(text)
            if primary:
                btn.setObjectName("PrimaryButton")
            else:
                btn.setObjectName("GhostButton")
            btn.clicked.connect(handler)
            buttons.addWidget(btn)
        layout.addLayout(buttons)
        self.preview_label = QLabel("请设置报告范围并生成文件。")
        self.preview_label.setWordWrap(True)
        self.preview_label.setStyleSheet("background:#F8FAF9;border:1px solid #E5E7EB;border-radius:10px;padding:12px;color:#4B5563;")
        layout.addWidget(self.preview_label)
        return card

    def _recent_card(self) -> Card:
        card = Card()
        self.recent_layout = QVBoxLayout(card)
        self.recent_layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel("最近导出记录")
        title.setObjectName("PageTitle")
        self.recent_layout.addWidget(title)
        self.refresh_recent()
        return card

    def _output_dir(self) -> Path:
        return Path(self.params.report_output_dir or OUTPUTS_DIR)

    def refresh_recent(self) -> None:
        while self.recent_layout.count() > 1:
            item = self.recent_layout.takeAt(1)
            if item.widget():
                item.widget().deleteLater()
        output_dir = self._output_dir()
        output_dir.mkdir(parents=True, exist_ok=True)
        files = sorted(
            [p for p in output_dir.iterdir() if p.suffix.lower() in {".html", ".csv", ".xlsx"}],
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )[:6]
        if not files:
            files = []
        for path in files:
            label = QLabel(path.name)
            label.setStyleSheet("background:#F7FBF8;border:1px solid #E5E7EB;border-radius:8px;padding:10px;")
            self.recent_layout.addWidget(label)
        if not files:
            empty = QLabel("暂无导出文件。")
            empty.setObjectName("Subtle")
            empty.setWordWrap(True)
            self.recent_layout.addWidget(empty)
        self.recent_layout.addStretch(1)

    def preview(self) -> None:
        selected = "、".join(c.text().splitlines()[0] for c in self.content_checks if c.isChecked())
        self.preview_label.setText(
            f"预览：{self.report_type.currentText()}，时间范围 {self.start.date().toString('yyyy-MM-dd')} 至 "
            f"{self.end.date().toString('yyyy-MM-dd')}，格式 {self.format.currentText()}。\n已选章节：{selected or '未选择'}。"
        )

    def generate(self) -> None:
        timestamps = pd.to_datetime(self.data.get("时间", pd.Series(dtype=str)), errors="coerce")
        start = pd.Timestamp(self.start.date().toPython())
        end = pd.Timestamp(self.end.date().toPython()) + pd.Timedelta(days=1)
        filtered = self.data.loc[(timestamps >= start) & (timestamps < end)].copy()
        if filtered.empty:
            QMessageBox.warning(self, "无法生成", "所选日期范围内没有运行数据。")
            return
        sections = {check.text().splitlines()[0] for check in self.content_checks if check.isChecked()}
        try:
            path = export_dataset(
                filtered,
                self.format.currentText(),
                params=self.params,
                project=self.project,
                sections=sections,
            )
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, "导出失败", str(error))
            return
        self.preview_label.setText(f"已生成：{path}")
        self.refresh_recent()
        QMessageBox.information(self, "导出完成", f"文件已生成：{path}")

    def open_dir(self) -> None:
        output_dir = self._output_dir()
        output_dir.mkdir(parents=True, exist_ok=True)
        self.preview_label.setText(f"输出目录：{output_dir}")
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(output_dir.resolve())))
