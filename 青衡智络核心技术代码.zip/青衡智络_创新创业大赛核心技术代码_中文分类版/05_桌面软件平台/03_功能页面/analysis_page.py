from __future__ import annotations

import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QLabel, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget

from microgrid_app.calculator import compute_dashboard_kpis, recalculate_derived_columns, run_scenario, scenario_comparison
from microgrid_app.models import CarbonParams

from ..cards import Card
from ..charts import BarCompareChart, SimpleLineChart
from ..theme import PRIMARY


class AnalysisPage(QWidget):
    def __init__(self, data, params: CarbonParams):
        super().__init__()
        self.data = data
        self.params = params
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 22, 26, 22)
        title = QLabel("分析报告")
        title.setObjectName("Title")
        subtitle = QLabel("基于当前数据和参数生成方案对比、减排趋势与优化建议。")
        subtitle.setObjectName("Subtle")
        root.addWidget(title)
        root.addWidget(subtitle)
        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(12)
        grid.addWidget(self._summary(), 0, 0, 1, 2)
        grid.addWidget(self._sensitivity(), 1, 0)
        self.compare_chart = BarCompareChart()
        grid.addWidget(self._chart_card("方案对比图", self.compare_chart), 1, 1)
        self.trend_chart = SimpleLineChart("累计碳减排量(kgCO2e)")
        grid.addWidget(self._chart_card("碳减排趋势图", self.trend_chart), 2, 0)
        grid.addWidget(self._advice(), 2, 1)
        root.addLayout(grid, 1)
        self.refresh()

    def _summary(self) -> Card:
        card = Card()
        layout = QHBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel("分析结论")
        title.setObjectName("PageTitle")
        layout.addWidget(title)
        self.summary_labels = []
        for _ in range(4):
            box = QLabel()
            box.setAlignment(Qt.AlignCenter)
            box.setStyleSheet(
                "background:#F0FAF3;border:1px solid #CFEBD8;border-radius:10px;"
                f"padding:10px;font-weight:800;color:{PRIMARY};"
            )
            self.summary_labels.append(box)
            layout.addWidget(box, 1)
        return card

    def _sensitivity(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel("灵敏度分析表格")
        title.setObjectName("PageTitle")
        self.sensitivity_table = QTableWidget(5, 4)
        self.sensitivity_table.verticalHeader().setVisible(False)
        self.sensitivity_table.setHorizontalHeaderLabels(["参数", "变化范围", "占比变化", "收益变化"])
        self.sensitivity_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(title)
        layout.addWidget(self.sensitivity_table)
        return card

    def _chart_card(self, title_text: str, chart) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel(title_text)
        title.setObjectName("PageTitle")
        layout.addWidget(title)
        layout.addWidget(chart)
        return card

    def _advice(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel("优化建议")
        title.setObjectName("PageTitle")
        layout.addWidget(title)
        self.advice_labels = []
        for _ in range(4):
            label = QLabel()
            label.setWordWrap(True)
            label.setStyleSheet("background:#F7FBF8;border:1px solid #E5E7EB;border-radius:8px;padding:10px;")
            self.advice_labels.append(label)
            layout.addWidget(label)
        layout.addStretch(1)
        return card

    def set_data(self, data) -> None:
        self.data = data
        self.refresh()

    def set_params(self, params: CarbonParams) -> None:
        self.params = params
        self.refresh()

    def refresh(self) -> None:
        comparison = scenario_comparison(self.data, self.params)
        base_name, base = comparison[0]
        best_name, best = max(comparison, key=lambda item: item[1]["综合收益"])
        summary = [
            ("基准方案", base_name),
            ("推荐方案", best_name),
            ("占比变化", f"{best['绿电消费占比'] - base['绿电消费占比']:+.2f}%"),
            ("收益变化", f"{best['综合收益'] - base['综合收益']:+.2f} 万元"),
        ]
        for label, (name, value) in zip(self.summary_labels, summary):
            label.setText(f"{name}\n{value}")

        self.compare_chart.set_values(
            [name.replace("方案", "") for name, _ in comparison],
            [result["绿电消费占比"] for _, result in comparison],
        )
        recalculated = recalculate_derived_columns(self.data, self.params)
        reductions = pd.to_numeric(recalculated["碳减排量(kgCO2e)"], errors="coerce").fillna(0).cumsum().tolist()
        self.trend_chart.set_values(reductions)
        self._refresh_sensitivity()
        self._refresh_advice(compute_dashboard_kpis(self.data, self.params))

    def _refresh_sensitivity(self) -> None:
        cases = [
            ("光伏倍率", "0.80-1.20", {"pv_factor": 0.80}, {"pv_factor": 1.20}),
            ("储能容量倍率", "0.80-1.20", {"storage_factor": 0.80}, {"storage_factor": 1.20}),
            ("风电倍率", "0.80-1.20", {"wind_factor": 0.80}, {"wind_factor": 1.20}),
            ("负荷倍率", "0.90-1.10", {"load_factor": 0.90}, {"load_factor": 1.10}),
            ("碳价倍率", "0.80-1.20", {"carbon_price_factor": 0.80}, {"carbon_price_factor": 1.20}),
        ]
        for row, (name, value_range, low_args, high_args) in enumerate(cases):
            low = run_scenario(self.data, self.params, **low_args)
            high = run_scenario(self.data, self.params, **high_args)
            share_span = high["绿电消费占比"] - low["绿电消费占比"]
            revenue_span = high["综合收益"] - low["综合收益"]
            values = [name, value_range, f"{share_span:+.2f} 个百分点", f"{revenue_span:+.2f} 万元"]
            for column, text in enumerate(values):
                item = QTableWidgetItem(text)
                item.setTextAlignment(Qt.AlignCenter)
                self.sensitivity_table.setItem(row, column, item)

    def _refresh_advice(self, kpis: dict[str, float]) -> None:
        share = kpis["绿电消费占比"]
        storage_share = kpis["储能供能占比"]
        intensity = kpis["单位用电碳强度"]
        advice = [
            (
                "绿电消费占比较低，优先核查可再生能源出力与负荷时序匹配。"
                if share < 50
                else "绿电消费占比达到当前数据周期负荷的一半以上，继续关注高出力时段弃电。"
            ),
            (
                "当前未识别到绿色储能供电量，请核查储能充电时段是否存在光伏富余。"
                if storage_share <= 0
                else "已识别绿色储能供电贡献，可结合容量倍率结果评估扩容边际收益。"
            ),
            f"当前单位用电碳强度为 {intensity} kgCO2e/kWh，结果由电网购电量和排放因子共同决定。",
            f"当前排放因子来源说明：{self.params.emission_factor_source}",
        ]
        for label, text in zip(self.advice_labels, advice):
            label.setText(f"●  {text}")
