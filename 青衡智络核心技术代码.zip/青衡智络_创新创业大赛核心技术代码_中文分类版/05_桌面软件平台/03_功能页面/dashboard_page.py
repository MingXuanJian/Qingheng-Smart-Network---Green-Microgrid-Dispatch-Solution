from __future__ import annotations

import pandas as pd

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QButtonGroup,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from microgrid_app.calculator import compute_dashboard_kpis, compute_reduction_breakdown
from microgrid_app.models import CarbonParams, ProjectContext
from microgrid_app.report import export_dataset
from microgrid_app.reference_data import TABLE_COLUMNS

from ..cards import Card, default_kpi_cards
from ..icon_widgets import LineIcon
from ..charts import DonutChart, OperationalEnergyChart
from ..theme import BLUE, GOLD, PRIMARY


class DashboardPage(QWidget):
    def __init__(self, data, params: CarbonParams, data_source: str, project_name: str):
        super().__init__()
        self.data = data
        self.params = params
        self.data_source = data_source
        self.project = ProjectContext(project_name=project_name, data_source=data_source)
        self.kpi_cards = []
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 18, 24, 18)
        root.setSpacing(10)
        greeting = QLabel("项目分析工作台")
        greeting.setObjectName("Title")
        self.source_label = QLabel(self._source_text())
        self.source_label.setObjectName("Subtle")
        root.addWidget(greeting)
        root.addWidget(self.source_label)
        self.kpi_grid = QHBoxLayout()
        self.kpi_grid.setSpacing(10)
        root.addLayout(self.kpi_grid)
        self.refresh_kpis(compute_dashboard_kpis(self.data, self.params))
        middle = QHBoxLayout()
        middle.setSpacing(10)
        middle.addWidget(self._realtime_card(), 3)
        middle.addWidget(self._carbon_card(), 2)
        root.addLayout(middle, 3)
        bottom = QHBoxLayout()
        bottom.setSpacing(10)
        bottom.addWidget(self._table_card(), 8)
        bottom.addWidget(self._export_card(), 3)
        root.addLayout(bottom, 2)

    def refresh_kpis(self, values: dict[str, float]) -> None:
        while self.kpi_grid.count():
            item = self.kpi_grid.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.kpi_cards = default_kpi_cards(values)
        for card in self.kpi_cards:
            card.setMinimumHeight(116)
            card.setMaximumHeight(124)
            self.kpi_grid.addWidget(card)

    def _source_text(self) -> str:
        timestamps = pd.to_datetime(self.data.get("时间"), errors="coerce").dropna()
        coverage = "未提供"
        if not timestamps.empty:
            coverage = f"{timestamps.min():%Y-%m-%d %H:%M} 至 {timestamps.max():%Y-%m-%d %H:%M}"
        return f"数据来源：{self.data_source} ｜ 数据覆盖：{coverage} ｜ 记录数：{len(self.data)}"

    def set_data(self, data, data_source: str | None = None) -> None:
        self.data = data
        if data_source is not None:
            self.data_source = data_source
            self.project.data_source = data_source
        self.source_label.setText(self._source_text())
        self.refresh_kpis(compute_dashboard_kpis(self.data, self.params))
        self.chart.set_data(self.data)
        self.refresh_carbon()
        if hasattr(self, "table"):
            self.table.setRowCount(min(4, len(self.data)))
            self.table.setColumnCount(len(TABLE_COLUMNS))
            self._fill_table()
            self.page_label.setText(f"共 {len(self.data)} 条记录；首页显示前 {min(4, len(self.data))} 条")

    def set_params(self, params: CarbonParams) -> None:
        self.params = params
        self.refresh_kpis(compute_dashboard_kpis(self.data, self.params))
        self.refresh_carbon()

    def _segment_buttons(self, labels: list[str], active: int = 0) -> tuple[QButtonGroup, list[QPushButton]]:
        group = QButtonGroup(self)
        group.setExclusive(True)
        buttons = []
        for i, text in enumerate(labels):
            btn = QPushButton(text)
            btn.setCheckable(True)
            btn.setChecked(i == active)
            btn.clicked.connect(lambda checked=False, g=group: self._refresh_segment_style(g))
            group.addButton(btn, i)
            buttons.append(btn)
        self._refresh_segment_style(group)
        return group, buttons

    def _refresh_segment_style(self, group: QButtonGroup) -> None:
        for btn in group.buttons():
            if btn.isChecked():
                btn.setStyleSheet("background:#FFFFFF;color:#2FB463;border:1px solid #8ED8A4;border-radius:8px;font-weight:800;padding:7px 14px;")
            else:
                btn.setStyleSheet("background:#FFFFFF;color:#1F2937;border:1px solid #E5E7EB;border-radius:8px;padding:7px 14px;")

    def _realtime_card(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(14, 12, 14, 10)
        layout.setSpacing(6)
        head = QHBoxLayout()
        self.chart_title = QLabel("微电网运行数据曲线（最近24条）")
        self.chart_title.setObjectName("PageTitle")
        self.run_status = QLabel("  ● 离线数据  ")
        self.run_status.setStyleSheet("background:#E8F7EC;color:#2FB463;border-radius:8px;padding:5px 10px;font-weight:700;")
        head.addWidget(self.chart_title)
        head.addWidget(self.run_status)
        head.addStretch(1)
        self.range_group, range_buttons = self._segment_buttons(["最近24条", "全部数据"])
        for btn in range_buttons:
            head.addWidget(btn)
        self.range_group.idClicked.connect(self._change_range)
        self.chart = OperationalEnergyChart(self.data)
        self.chart.setMinimumHeight(275)
        layout.addLayout(head)
        layout.addWidget(self.chart, 1)
        return card

    def _change_range(self, index: int) -> None:
        names = ["最近24条", "全部数据"]
        mode = names[index]
        self.chart_title.setText(f"微电网运行数据曲线（{mode}）")
        self.run_status.setText(f"  ● {mode}  ")
        self.chart.set_range_mode(mode)

    def _carbon_card(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(14, 12, 14, 10)
        head = QHBoxLayout()
        title = QLabel("碳减排效益")
        title.setObjectName("PageTitle")
        more = QPushButton("更多 ›")
        more.setFlat(True)
        more.clicked.connect(lambda: QMessageBox.information(self, "碳减排详情", "可在分析报告页面查看趋势、方案对比和诊断建议。"))
        head.addWidget(title)
        head.addStretch(1)
        head.addWidget(more)
        layout.addLayout(head)
        body = QHBoxLayout()
        self.donut = DonutChart()
        body.addWidget(self.donut, 1)
        right = QVBoxLayout()
        right.setSpacing(8)
        self.breakdown_labels = []
        for _ in range(2):
            row = QLabel()
            row.setStyleSheet("background:transparent;color:#4B5563;padding:5px;")
            self.breakdown_labels.append(row)
            right.addWidget(row)
        body.addLayout(right, 1)
        layout.addLayout(body, 1)
        self.factor_note = QLabel()
        self.factor_note.setAlignment(Qt.AlignCenter)
        self.factor_note.setStyleSheet("background:#E8F7EC;color:#2F8A4E;border-radius:8px;padding:9px;font-weight:700;")
        layout.addWidget(self.factor_note)
        self.refresh_carbon()
        return card

    def refresh_carbon(self) -> None:
        if not hasattr(self, "donut"):
            return
        breakdown = compute_reduction_breakdown(self.data, self.params)
        self.donut.set_values(breakdown)
        total = max(sum(breakdown.values()), 1e-9)
        for label, (name, value) in zip(self.breakdown_labels, breakdown.items()):
            label.setText(f"●  {name}    {value:,.2f} tCO2e ({value / total * 100:.1f}%)")
        self.factor_note.setText(
            f"排放因子：{self.params.grid_emission_factor} kgCO2e/kWh ｜ 来源：{self.params.emission_factor_source}"
        )

    def _table_card(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(14, 12, 14, 10)
        layout.setSpacing(6)
        head = QHBoxLayout()
        title = QLabel("项目数据概览")
        title.setObjectName("PageTitle")
        head.addWidget(title)
        self.table_group, table_buttons = self._segment_buttons(["运行数据", "碳排数据", "经济数据", "设备数据"])
        for btn in table_buttons:
            head.addWidget(btn)
        head.addStretch(1)
        more = QPushButton("更多 ›")
        more.setFlat(True)
        more.clicked.connect(lambda: QMessageBox.information(self, "数据管理", "可在数据管理页面导入 CSV、编辑数据并执行质量检查。"))
        head.addWidget(more)
        layout.addLayout(head)
        self.table = QTableWidget(min(4, len(self.data)), len(TABLE_COLUMNS))
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(32)
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.table.setHorizontalHeaderLabels(
            [
                "时间",
                "光伏发电量\n(kWh)",
                "负荷用电量\n(kWh)",
                "储能充放电量\n(kWh)",
                "并网电量\n(kWh)",
                "绿电消费占比\n(%)",
                "碳减排量\n(kgCO2e)",
            ]
        )
        self._fill_table()
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignCenter)
        self.table.horizontalHeader().setFixedHeight(48)
        widths = [145, 105, 105, 126, 105, 112, 132]
        for i, width in enumerate(widths):
            self.table.setColumnWidth(i, width)
        layout.addWidget(self.table)
        self.table_group.idClicked.connect(self._change_table_tab)
        self.page_label = QLabel(f"共 {len(self.data)} 条记录；首页显示前 {min(4, len(self.data))} 条")
        self.page_label.setStyleSheet("background:transparent;color:#6B7280;padding:4px;")
        layout.addWidget(self.page_label)
        return card

    def _fill_table(self) -> None:
        for r, (_, row) in enumerate(self.data.head(self.table.rowCount()).iterrows()):
            for c, col in enumerate(TABLE_COLUMNS):
                item = QTableWidgetItem(str(row[col]))
                item.setTextAlignment(Qt.AlignCenter if c else Qt.AlignVCenter | Qt.AlignLeft)
                self.table.setItem(r, c, item)

    def _change_table_tab(self, index: int) -> None:
        labels = ["运行数据", "碳排数据", "经济数据", "设备数据"]
        self.table.setToolTip(f"当前查看：{labels[index]}")
        self.page_label.setText(f"当前查看：{labels[index]}")

    def _export_card(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(14, 12, 14, 10)
        layout.setSpacing(6)
        head = QHBoxLayout()
        title = QLabel("报告与导出")
        title.setObjectName("PageTitle")
        more = QPushButton("更多 ›")
        more.setFlat(True)
        more.clicked.connect(lambda: QMessageBox.information(self, "导出中心", "可在导出中心选择报告类型、时间范围和导出格式。"))
        head.addWidget(title)
        head.addStretch(1)
        head.addWidget(more)
        layout.addLayout(head)
        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(8)
        items = [
            ("月度报告", "月度运行与核算结果", PRIMARY, "html"),
            ("季度报告", "季度运行与效益分析", BLUE, "html"),
            ("年度报告", "年度减排与收益汇总", "#8A6DE9", "html"),
            ("自定义导出", "按需导出数据明细", GOLD, "excel"),
        ]
        for i, (title_text, desc, color, fmt) in enumerate(items):
            tile = self._compact_report_tile(title_text, desc, color, fmt)
            grid.addWidget(tile, i // 2, i % 2)
        layout.addLayout(grid, 1)
        btns = QHBoxLayout()
        gen = QPushButton("生成报告")
        gen.setObjectName("PrimaryButton")
        gen.clicked.connect(lambda: self._export_file("html"))
        out = QPushButton("导出数据")
        out.setObjectName("GhostButton")
        out.clicked.connect(lambda: self._export_file("excel"))
        btns.addWidget(gen)
        btns.addWidget(out)
        layout.addLayout(btns)
        layout.addWidget(QLabel("文件将保存至参数配置的输出目录"))
        return card

    def _compact_report_tile(self, title: str, desc: str, color: str, fmt: str) -> Card:
        tile = Card()
        tile.setMinimumHeight(88)
        layout = QHBoxLayout(tile)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(10)
        layout.addWidget(LineIcon("export" if "导出" in title else "report", color, f"{color}22", 38))
        text = QVBoxLayout()
        name = QLabel(title)
        name.setStyleSheet("font-weight:800;background:transparent;")
        detail = QLabel(desc)
        detail.setObjectName("Subtle")
        detail.setWordWrap(True)
        text.addWidget(name)
        text.addWidget(detail)
        layout.addLayout(text, 1)
        btn = QPushButton("导出" if fmt != "html" else "生成")
        btn.setObjectName("GhostButton")
        btn.clicked.connect(lambda checked=False, f=fmt: self._export_file(f))
        layout.addWidget(btn)
        return tile

    def _export_file(self, fmt: str) -> None:
        try:
            path = export_dataset(self.data, fmt, params=self.params, project=self.project)
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, "导出失败", str(error))
            return
        QMessageBox.information(self, "导出完成", f"文件已生成：{path}")
