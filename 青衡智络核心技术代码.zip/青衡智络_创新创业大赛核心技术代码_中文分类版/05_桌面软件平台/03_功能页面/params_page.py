from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from microgrid_app.config import PARAMETER_RANGES, REPORTS_DIR, ConfigError, save_params
from microgrid_app.models import CarbonParams

from ..cards import Card
from ..theme import PRIMARY


NUMERIC_FIELDS = {
    "grid_emission_factor": ("电网排放因子(kgCO2e/kWh)", 4, 0.0001, "用于计算绿电消费对应的碳减排量。"),
    "carbon_price": ("碳价(元/tCO2e)", 2, 1.0, "用于计算碳减排价值。"),
    "buy_price": ("购电电价(元/kWh)", 4, 0.01, "用于计算绿电替代购电的价值。"),
    "sell_price": ("售电电价(元/kWh)", 4, 0.01, "用于计算上网售电收入。"),
    "storage_capacity": ("储能容量(kWh)", 1, 10.0, "用于情景试算中的绿色储能容量约束。"),
    "wind_capacity": ("风电装机容量(kW)", 1, 10.0, "用于情景试算中的风电出力计算。"),
    "storage_roundtrip_efficiency": ("储能往返效率", 3, 0.01, "用于绿色储能台账充电量计算。"),
    "wind_capacity_factor": ("风电容量系数", 3, 0.01, "用于情景试算中的风电出力计算。"),
    "grid_export_limit_kw": ("上网功率限制(kW)", 1, 10.0, "0 表示不允许上网，超过上网能力的剩余电量计为弃电。"),
}


class ParamsPage(QWidget):
    params_saved = Signal(object)

    def __init__(self, params: CarbonParams):
        super().__init__()
        self.params = params
        self.inputs: dict[str, QDoubleSpinBox | QLineEdit] = {}
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 22, 26, 22)
        title = QLabel("参数配置")
        title.setObjectName("Title")
        subtitle = QLabel("配置核算因子、经济参数、设备约束和输出目录。")
        subtitle.setObjectName("Subtle")
        root.addWidget(title)
        root.addWidget(subtitle)
        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(12)
        grid.addWidget(self._group_card("碳排与价格参数", ["grid_emission_factor", "carbon_price", "buy_price", "sell_price"]), 0, 0)
        grid.addWidget(
            self._group_card(
                "设备与上网参数",
                [
                    "storage_capacity",
                    "wind_capacity",
                    "storage_roundtrip_efficiency",
                    "wind_capacity_factor",
                    "grid_export_limit_kw",
                ],
            ),
            0,
            1,
        )
        grid.addWidget(self._source_card(), 1, 0)
        grid.addWidget(self._output_card(), 1, 1)
        root.addLayout(grid, 1)

    def _spin_box(self, key: str) -> QDoubleSpinBox:
        label, decimals, step, tooltip = NUMERIC_FIELDS[key]
        minimum, maximum = PARAMETER_RANGES[key]
        box = QDoubleSpinBox()
        box.setRange(minimum, maximum)
        box.setDecimals(decimals)
        box.setSingleStep(step)
        box.setValue(float(getattr(self.params, key)))
        box.setToolTip(tooltip)
        box.setSuffix("" if key not in {"storage_roundtrip_efficiency", "wind_capacity_factor"} else "")
        self.inputs[key] = box
        return box

    def _group_card(self, title_text: str, keys: list[str]) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel(title_text)
        title.setObjectName("PageTitle")
        form = QFormLayout()
        for key in keys:
            label = NUMERIC_FIELDS[key][0]
            form.addRow(label, self._spin_box(key))
        layout.addWidget(title)
        layout.addLayout(form)
        layout.addStretch(1)
        return card

    def _source_card(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel("排放因子来源")
        title.setObjectName("PageTitle")
        source = QLineEdit(self.params.emission_factor_source)
        source.setPlaceholderText("请输入排放因子来源说明")
        source.setToolTip("报告将输出该说明。")
        self.inputs["emission_factor_source"] = source
        note = QLabel("排放因子统一用于首页、数据表、情景试算和报告的碳减排计算。")
        note.setWordWrap(True)
        note.setStyleSheet(f"background:#F0FAF3;border:1px solid #CFEBD8;border-radius:8px;padding:10px;color:{PRIMARY};")
        layout.addWidget(title)
        layout.addWidget(source)
        layout.addWidget(note)
        layout.addStretch(1)
        return card

    def _output_card(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel("保存与输出")
        title.setObjectName("PageTitle")
        output_dir = QLineEdit(self.params.report_output_dir or str(REPORTS_DIR))
        self.inputs["report_output_dir"] = output_dir
        choose = QPushButton("选择目录")
        choose.clicked.connect(self.choose_dir)
        row = QHBoxLayout()
        row.addWidget(output_dir, 1)
        row.addWidget(choose)
        note = QLabel("报告和数据文件将保存至所选目录。")
        note.setObjectName("Subtle")
        buttons = QHBoxLayout()
        save = QPushButton("保存参数")
        save.setObjectName("PrimaryButton")
        save.clicked.connect(self.save)
        reset = QPushButton("恢复默认")
        reset.setObjectName("GhostButton")
        reset.clicked.connect(self.reset)
        buttons.addWidget(save)
        buttons.addWidget(reset)
        layout.addWidget(title)
        layout.addWidget(QLabel("报告输出目录"))
        layout.addLayout(row)
        layout.addWidget(note)
        layout.addLayout(buttons)
        layout.addStretch(1)
        return card

    def choose_dir(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "选择报告输出目录")
        if path:
            box = self.inputs["report_output_dir"]
            if isinstance(box, QLineEdit):
                box.setText(path)

    def _collect_params(self) -> CarbonParams:
        values = {}
        for key in NUMERIC_FIELDS:
            box = self.inputs[key]
            if isinstance(box, QDoubleSpinBox):
                values[key] = box.value()
        source = self.inputs["emission_factor_source"]
        output_dir = self.inputs["report_output_dir"]
        values["emission_factor_source"] = source.text().strip() if isinstance(source, QLineEdit) else ""
        values["report_output_dir"] = output_dir.text().strip() if isinstance(output_dir, QLineEdit) else str(REPORTS_DIR)
        return CarbonParams(**values)

    def save(self) -> None:
        try:
            self.params = self._collect_params()
            path = save_params(self.params)
        except ConfigError as error:
            QMessageBox.warning(self, "保存失败", str(error))
            return
        self.params_saved.emit(self.params)
        QMessageBox.information(self, "保存成功", f"参数已保存到：{path}")

    def reset(self) -> None:
        self.params = CarbonParams(report_output_dir=str(REPORTS_DIR))
        for key in NUMERIC_FIELDS:
            box = self.inputs[key]
            if isinstance(box, QDoubleSpinBox):
                box.setValue(float(getattr(self.params, key)))
        source = self.inputs["emission_factor_source"]
        output_dir = self.inputs["report_output_dir"]
        if isinstance(source, QLineEdit):
            source.setText(self.params.emission_factor_source)
        if isinstance(output_dir, QLineEdit):
            output_dir.setText(self.params.report_output_dir)
        answer = QMessageBox.question(self, "已恢复默认", "默认参数已载入，是否立即保存？")
        if answer == QMessageBox.Yes:
            self.save()
