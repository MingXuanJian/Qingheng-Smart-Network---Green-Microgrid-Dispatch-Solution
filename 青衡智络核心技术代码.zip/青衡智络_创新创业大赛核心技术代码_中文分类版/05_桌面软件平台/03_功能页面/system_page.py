from __future__ import annotations

import platform
import shutil
from pathlib import Path

from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QLabel, QMessageBox, QPushButton, QVBoxLayout, QWidget

from microgrid_app.config import ASSETS_DIR, CONFIG_FILE, REPORTS_DIR, RESOURCE_DIR, USER_DATA_DIR, icon_ico_path
from microgrid_app.models import AppInfo

from ..cards import Card
from ..theme import BLUE, GOLD, PRIMARY


class SystemPage(QWidget):
    def __init__(self):
        super().__init__()
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 22, 26, 22)
        title = QLabel("系统信息")
        title.setObjectName("Title")
        subtitle = QLabel("查看软件名称、运行环境、依赖和数据目录状态。")
        subtitle.setObjectName("Subtle")
        root.addWidget(title)
        root.addWidget(subtitle)
        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(12)
        grid.addWidget(self._software_card(), 0, 0)
        grid.addWidget(self._resource_card(), 0, 1)
        grid.addWidget(self._dependency_card(), 1, 0)
        grid.addWidget(self._about_card(), 1, 1)
        root.addLayout(grid, 1)
        actions = QHBoxLayout()
        for text, handler, primary in [
            ("清理缓存", self.clear_cache, False),
            ("打开输出目录", self.open_dir, False),
            ("检查依赖", self.check_deps, False),
            ("关于软件", self.show_about, True),
        ]:
            btn = QPushButton(text)
            btn.setObjectName("PrimaryButton" if primary else "GhostButton")
            btn.clicked.connect(handler)
            actions.addWidget(btn)
        actions.addStretch(1)
        root.addLayout(actions)

    def _software_card(self) -> Card:
        info = AppInfo()
        return self._info_card(
            "软件信息",
            [
                ("软件名称", info.name),
                ("软件类型", "本地桌面应用"),
                ("运行环境", f"{platform.system()} {platform.release()}"),
                ("Python版本", platform.python_version()),
            ],
        )

    def _resource_card(self) -> Card:
        return self._info_card(
            "目录与资源",
            [
                ("资源目录", self._short(RESOURCE_DIR)),
                ("用户数据目录", self._short(USER_DATA_DIR)),
                ("报告目录", self._short(REPORTS_DIR)),
                ("配置文件", self._short(CONFIG_FILE)),
                ("图标状态", "已生成" if icon_ico_path().exists() else "未生成"),
                ("资源状态", "assets 已就绪" if ASSETS_DIR.exists() else "资源缺失"),
            ],
        )

    def _dependency_card(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel("依赖检查")
        title.setObjectName("PageTitle")
        layout.addWidget(title)
        for name, ok in self._dependency_status().items():
            color = PRIMARY if ok else GOLD
            label = QLabel(f"{name}    {'正常' if ok else '未安装'}")
            label.setStyleSheet(f"background:{color}14;border:1px solid #E5E7EB;border-radius:8px;padding:9px;color:#374151;")
            layout.addWidget(label)
        return card

    def _about_card(self) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel("软件说明")
        title.setObjectName("PageTitle")
        about = QLabel(
            "本软件用于工商业微电网的绿电消费、碳减排和经济效益评估，支持项目数据管理、"
            "参数配置、情景试算和报告导出。"
        )
        about.setWordWrap(True)
        about.setStyleSheet("line-height:1.6;background:transparent;color:#4B5563;")
        layout.addWidget(title)
        layout.addWidget(about)
        layout.addStretch(1)
        return card

    def _info_card(self, title_text: str, rows: list[tuple[str, str]]) -> Card:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel(title_text)
        title.setObjectName("PageTitle")
        layout.addWidget(title)
        for key, value in rows:
            row = QHBoxLayout()
            name = QLabel(key)
            name.setFixedWidth(92)
            name.setStyleSheet("color:#6B7280;background:transparent;")
            val = QLabel(value)
            val.setStyleSheet("font-weight:700;background:#F8FAF9;border-radius:6px;padding:7px;")
            row.addWidget(name)
            row.addWidget(val, 1)
            layout.addLayout(row)
        layout.addStretch(1)
        return card

    def _dependency_status(self) -> dict[str, bool]:
        modules = {"PySide6": "PySide6", "matplotlib": "matplotlib", "pandas": "pandas", "openpyxl": "openpyxl", "Pillow": "PIL"}
        status = {}
        for display, module in modules.items():
            try:
                __import__(module)
                status[display] = True
            except Exception:
                status[display] = False
        return status

    def _short(self, path: Path) -> str:
        resolved = path.resolve()
        try:
            relative = resolved.relative_to(USER_DATA_DIR.resolve())
            text = "用户数据目录" if str(relative) == "." else f"用户数据目录\\{relative}"
        except ValueError:
            text = str(resolved)
        return "..." + text[-58:] if len(text) > 62 else text

    def clear_cache(self) -> None:
        removed = 0
        for cache in USER_DATA_DIR.glob("**/__pycache__"):
            shutil.rmtree(cache, ignore_errors=True)
            removed += 1
        temp_dir = USER_DATA_DIR / "test_tmp"
        if temp_dir.exists():
            shutil.rmtree(temp_dir, ignore_errors=True)
            removed += 1
        QMessageBox.information(self, "清理完成", f"已清理临时缓存 {removed} 项，正式报告未删除。")

    def open_dir(self) -> None:
        REPORTS_DIR.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(REPORTS_DIR.resolve())))

    def check_deps(self) -> None:
        ok_count = sum(self._dependency_status().values())
        QMessageBox.information(self, "依赖检查", f"依赖检查完成：{ok_count}/5 项正常。")

    def show_about(self) -> None:
        info = AppInfo()
        QMessageBox.information(
            self,
            "关于软件",
            f"{info.short_name}\n\n"
            "运行方式：本地离线分析\n\n"
            "主要功能：\n"
            "1. 绿电消费与碳减排效益评估\n"
            "2. 运行数据管理与质量检查\n"
            "3. 参数配置与情景试算\n"
            "4. HTML、CSV、Excel 文件导出",
        )
