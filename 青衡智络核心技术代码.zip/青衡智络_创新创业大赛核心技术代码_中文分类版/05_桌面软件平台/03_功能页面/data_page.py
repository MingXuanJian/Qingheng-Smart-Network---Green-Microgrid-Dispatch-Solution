from __future__ import annotations

from pathlib import Path

import pandas as pd
from PySide6.QtCore import Signal, Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QFileDialog,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from microgrid_app.calculator import quality_summary
from microgrid_app.data_io import DataValidationError, load_csv, normalize_columns, save_csv, save_project_data
from microgrid_app.models import CarbonParams
from microgrid_app.reference_data import TABLE_COLUMNS

from ..cards import Card, MetricCard
from ..theme import BLUE, GOLD, PRIMARY


class DataPage(QWidget):
    data_changed = Signal(object, str)

    def __init__(self, data, params: CarbonParams, data_source: str):
        super().__init__()
        self.data = data.copy()
        self.params = params
        self.data_source = data_source
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 22, 26, 22)
        root.setSpacing(12)
        title = QLabel("数据管理")
        title.setObjectName("Title")
        subtitle = QLabel("导入、维护、校验并保存项目运行数据。")
        subtitle.setObjectName("Subtle")
        root.addWidget(title)
        root.addWidget(subtitle)
        actions_card = Card()
        actions = QHBoxLayout(actions_card)
        actions.setContentsMargins(16, 12, 16, 12)
        for text, handler, primary in [
            ("导入 CSV", self.import_csv, True),
            ("导出 CSV", self.export_csv, False),
            ("添加行", self.add_row, False),
            ("删除行", self.delete_row, False),
            ("保存数据", self.save_data, False),
        ]:
            button = QPushButton(text)
            if primary:
                button.setObjectName("PrimaryButton")
            button.clicked.connect(handler)
            actions.addWidget(button)
        actions.addStretch(1)
        root.addWidget(actions_card)
        self.quality_grid = QGridLayout()
        self.quality_grid.setHorizontalSpacing(10)
        self.quality_grid.setVerticalSpacing(10)
        root.addLayout(self.quality_grid)
        self.quality_note = QLabel()
        self.quality_note.setWordWrap(True)
        self.quality_note.setObjectName("Subtle")
        root.addWidget(self.quality_note)
        table_card = Card()
        table_layout = QVBoxLayout(table_card)
        table_layout.setContentsMargins(14, 14, 14, 14)
        table_title = QLabel("运行数据表")
        table_title.setObjectName("PageTitle")
        table_layout.addWidget(table_title)
        self.table = QTableWidget()
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(34)
        table_layout.addWidget(self.table)
        root.addWidget(table_card, 1)
        self.refresh_table()

    def refresh_table(self) -> None:
        display = self.data.reindex(columns=TABLE_COLUMNS)
        self.table.setRowCount(len(display))
        self.table.setColumnCount(len(TABLE_COLUMNS))
        self.table.setHorizontalHeaderLabels(TABLE_COLUMNS)
        for row_index, (_, row) in enumerate(display.iterrows()):
            for column_index, column in enumerate(TABLE_COLUMNS):
                item = QTableWidgetItem("" if pd.isna(row[column]) else str(row[column]))
                alignment = Qt.AlignLeft | Qt.AlignVCenter if column_index == 0 else Qt.AlignCenter
                item.setTextAlignment(alignment)
                self.table.setItem(row_index, column_index, item)
        widths = [150, 145, 145, 165, 130, 135, 165]
        for index, width in enumerate(widths):
            self.table.setColumnWidth(index, width)
        self.refresh_quality()

    def refresh_quality(self) -> None:
        while self.quality_grid.count():
            item = self.quality_grid.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        colors = [PRIMARY, GOLD, BLUE, PRIMARY]
        for index, (key, value) in enumerate(quality_summary(self.data).items()):
            self.quality_grid.addWidget(MetricCard(key, value, colors[index % len(colors)]), index // 4, index % 4)
        issues = self.data.attrs.get("quality_issues", [])
        if issues:
            self.quality_note.setText("数据校验提示：" + "；".join(issues))
        else:
            self.quality_note.setText("数据校验提示：未发现需要处理的问题。")

    def import_csv(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "导入 CSV", "", "CSV 文件 (*.csv)")
        if not path:
            return
        try:
            imported = load_csv(path, self.params)
        except (OSError, DataValidationError, ValueError) as error:
            QMessageBox.warning(self, "导入失败", str(error))
            return
        self.data = imported
        self.data_source = f"用户导入文件：{Path(path).name}"
        self.refresh_table()
        self.data_changed.emit(self.data.copy(), self.data_source)
        issues = imported.attrs.get("quality_issues", [])
        message = f"已导入：{Path(path).name}"
        if issues:
            message += "\n校验提示：" + "；".join(issues)
        QMessageBox.information(self, "导入完成", message)

    def export_csv(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "导出 CSV", "microgrid_data.csv", "CSV 文件 (*.csv)")
        if not path:
            return
        try:
            saved = save_csv(self._table_data(), path, self.params)
            QMessageBox.information(self, "导出完成", f"已导出到：{saved}")
        except DataValidationError as error:
            QMessageBox.warning(self, "导出失败", str(error))

    def add_row(self) -> None:
        row = {}
        for column in self.data.columns:
            row[column] = ""
        self.data = pd.concat([self.data, pd.DataFrame([row])], ignore_index=True)
        self.refresh_table()

    def delete_row(self) -> None:
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "请选择数据行", "请先在表格中选择需要删除的行。")
            return
        self.data = self.data.drop(self.data.index[row]).reset_index(drop=True)
        self.refresh_table()

    def _table_data(self) -> pd.DataFrame:
        rows = []
        for row in range(self.table.rowCount()):
            values = []
            for column in range(self.table.columnCount()):
                item = self.table.item(row, column)
                values.append(item.text() if item else "")
            rows.append(values)
        return pd.DataFrame(rows, columns=TABLE_COLUMNS)

    def save_data(self) -> None:
        try:
            self.data = normalize_columns(self._table_data(), self.params)
            path = save_project_data(self.data, self.params)
        except DataValidationError as error:
            QMessageBox.warning(self, "保存失败", str(error))
            return
        self.data_source = "已保存的项目数据"
        self.refresh_table()
        self.data_changed.emit(self.data.copy(), self.data_source)
        QMessageBox.information(self, "保存完成", f"项目数据已保存到：{path}")

    def set_params(self, params: CarbonParams) -> None:
        self.params = params
        try:
            self.data = normalize_columns(self.data, self.params)
        except DataValidationError:
            return
        self.refresh_table()
