@echo off
chcp 65001 >nul
cd /d "%~dp0\.."
python -B run.py
if errorlevel 1 (
  echo.
  echo Application failed to start. Please run scripts\check_env.bat first.
  pause
  exit /b 1
)
