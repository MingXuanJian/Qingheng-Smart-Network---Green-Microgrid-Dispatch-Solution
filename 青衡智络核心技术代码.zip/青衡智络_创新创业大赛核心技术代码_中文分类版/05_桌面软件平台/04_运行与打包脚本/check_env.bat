@echo off
chcp 65001 >nul
cd /d "%~dp0\.."
echo [1/3] Python version
python --version
if errorlevel 1 (
  echo Python is not available. Please install Python 3.10 or later.
  exit /b 1
)

echo.
echo [2/3] Dependency check
python -B -c "import PySide6, matplotlib, pandas, numpy, openpyxl, PIL, PyInstaller; print('Dependencies OK')"
if errorlevel 1 (
  echo Dependency check failed. Please run:
  echo python -m pip install -r requirements.txt
  exit /b 1
)

echo.
echo [3/3] Unit tests
python -B -m unittest discover tests -v
if errorlevel 1 (
  echo Unit tests failed.
  exit /b 1
)

echo.
echo Environment check passed.
