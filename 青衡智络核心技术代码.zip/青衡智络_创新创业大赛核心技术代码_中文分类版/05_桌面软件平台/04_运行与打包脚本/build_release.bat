@echo off
chcp 65001 >nul
cd /d "%~dp0\.."

echo Preparing release build for 微电网能碳数据分析与报告软件
echo.

call scripts\check_env.bat
if errorlevel 1 exit /b 1

call scripts\clean_project.bat
if errorlevel 1 exit /b 1

call scripts\build_exe.bat
if errorlevel 1 exit /b 1

echo.
echo Release build finished.
echo Executable output:
echo dist\qingheng_microgrid_app\qingheng_microgrid_app.exe
