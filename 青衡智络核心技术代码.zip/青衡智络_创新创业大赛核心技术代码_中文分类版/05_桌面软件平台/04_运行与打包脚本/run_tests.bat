@echo off
chcp 65001 >nul
cd /d "%~dp0\.."
python -B -m unittest discover tests -v
if errorlevel 1 (
  echo.
  echo Unit tests failed.
  pause
  exit /b 1
)
