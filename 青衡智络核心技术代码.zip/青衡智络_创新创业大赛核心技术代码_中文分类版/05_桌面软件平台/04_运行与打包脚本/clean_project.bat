@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0\.."

echo Cleaning temporary cache files...

for /d /r %%d in (__pycache__) do (
  if exist "%%d" rmdir /s /q "%%d"
)

for /r %%f in (*.pyc) do (
  if exist "%%f" del /f /q "%%f"
)

if exist ".pytest_cache" rmdir /s /q ".pytest_cache"

echo.
echo Clean finished. Source files, documents, assets, tests and release files are kept.
endlocal
