@echo off
chcp 65001 >nul
cd /d "%~dp0\.."
python -c "import PyInstaller" >nul 2>nul
if errorlevel 1 (
  echo 未检测到 PyInstaller，请先安装：
  echo python -m pip install pyinstaller
  exit /b 1
)

python -m PyInstaller --noconfirm --clean --windowed --name qingheng_microgrid_app --workpath build_pyinstaller --specpath build_spec --distpath dist --icon "%CD%\assets\icons\app_icon.ico" --add-data "%CD%\assets;assets" --add-data "%CD%\examples;examples" --exclude-module torch --exclude-module torchvision --exclude-module scipy --exclude-module streamlit --exclude-module sklearn run.py
if errorlevel 1 exit /b 1

echo.
echo 打包完成：dist\qingheng_microgrid_app\qingheng_microgrid_app.exe
