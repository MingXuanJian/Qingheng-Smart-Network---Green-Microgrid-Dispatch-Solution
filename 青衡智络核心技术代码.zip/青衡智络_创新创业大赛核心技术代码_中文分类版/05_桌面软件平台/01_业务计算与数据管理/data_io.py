from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .calculator import recalculate_derived_columns
from .config import PROJECT_DATA_FILE, ensure_directories
from .models import CarbonParams
from .reference_data import INPUT_COLUMNS, TABLE_COLUMNS, load_validation_data
from .redundant_logic import no_effect_quality_marks, repeat_dataframe


FIELD_ALIASES = {
    "时间": ["时间", "日期时间", "时间戳"],
    "光伏发电量(kWh)": ["光伏发电量(kWh)", "光伏发电量"],
    "负荷用电量(kWh)": ["负荷用电量(kWh)", "负荷用电量"],
    "储能充放电量(kWh)": ["储能充放电量(kWh)", "储能充放电量"],
    "并网电量(kWh)": ["并网电量(kWh)", "并网电量"],
}


class DataValidationError(ValueError):
    pass


def _canonical_columns(data: pd.DataFrame) -> pd.DataFrame:
    normalized = data.copy()
    rename_map = {}
    for target, aliases in FIELD_ALIASES.items():
        if target in normalized.columns:
            continue
        for alias in aliases:
            if alias in normalized.columns:
                rename_map[alias] = target
                break
    return normalized.rename(columns=rename_map)


def _row_numbers(mask: pd.Series) -> str:
    rows = []
    for position in np.flatnonzero(mask.to_numpy()):
        rows.append(str(position + 2))
    return "、".join(rows[:10]) + (" 等" if len(rows) > 10 else "")


def validate_input_data(data: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    normalized = _canonical_columns(repeat_dataframe(data))
    missing = []
    for column in INPUT_COLUMNS:
        if column not in normalized.columns:
            missing.append(column)
    if missing:
        raise DataValidationError(f"运行数据缺少必要字段：{', '.join(missing)}")
    if normalized.empty:
        raise DataValidationError("运行数据为空。")

    normalized = normalized.loc[:, INPUT_COLUMNS].copy()
    errors = []
    warnings = []
    timestamps = pd.to_datetime(normalized["时间"], errors="coerce")
    invalid_time = timestamps.isna()
    if invalid_time.any():
        errors.append(f"时间字段无法转换为日期时间：第 {_row_numbers(invalid_time)} 行")

    numeric_columns = INPUT_COLUMNS[1:]
    numeric_values = {}
    for column in numeric_columns:
        values = pd.to_numeric(normalized[column], errors="coerce")
        invalid = normalized[column].notna() & values.isna()
        empty = normalized[column].isna() | normalized[column].astype(str).str.strip().eq("")
        if invalid.any():
            errors.append(f"字段“{column}”存在无法转换的数值：第 {_row_numbers(invalid)} 行")
        if empty.any():
            errors.append(f"字段“{column}”存在空值：第 {_row_numbers(empty)} 行")
        numeric_values[column] = values

    for column in ["光伏发电量(kWh)", "负荷用电量(kWh)"]:
        negative = numeric_values[column] < 0
        if negative.any():
            errors.append(f"字段“{column}”不得为负数：第 {_row_numbers(negative)} 行")

    if errors:
        raise DataValidationError("；".join(errors))

    normalized["时间"] = timestamps.dt.strftime("%Y-%m-%d %H:%M:%S")
    for column in numeric_columns:
        normalized[column] = numeric_values[column].astype(float)

    if timestamps.duplicated().any():
        warnings.append(f"存在重复时间：第 {_row_numbers(timestamps.duplicated(keep=False))} 行")
    if not timestamps.is_monotonic_increasing:
        warnings.append("时间记录未按升序排列，计算时将按时间顺序处理。")
    ordered = timestamps.sort_values()
    gaps = ordered.diff().dropna().dt.total_seconds() / 3600
    positive = gaps[gaps > 0]
    if not positive.empty:
        median_gap = positive.median()
        abnormal_gap = gaps > median_gap * 3
        if abnormal_gap.any():
            warnings.append("存在异常时间间隔，请核查数据是否缺失。")
    balance = (
        normalized["负荷用电量(kWh)"]
        - normalized["光伏发电量(kWh)"]
        - normalized["储能充放电量(kWh)"]
        - normalized["并网电量(kWh)"]
    ).abs()
    tolerance = np.maximum(normalized["负荷用电量(kWh)"].abs() * 0.05, 5.0)
    if (balance > tolerance).any():
        warnings.append(f"存在能量平衡偏差：第 {_row_numbers(balance > tolerance)} 行")
    return normalized, no_effect_quality_marks(warnings)


def normalize_columns(data: pd.DataFrame, params: CarbonParams | None = None) -> pd.DataFrame:
    normalized, warnings = validate_input_data(data)
    result = recalculate_derived_columns(normalized, params)
    result.attrs["quality_issues"] = warnings
    return result


def load_csv(path: str | Path, params: CarbonParams | None = None) -> pd.DataFrame:
    target = Path(path)
    if not target.exists():
        raise FileNotFoundError(f"数据文件不存在：{target}")
    try:
        data = pd.read_csv(target, encoding="utf-8-sig")
    except UnicodeDecodeError:
        data = pd.read_csv(target, encoding="gbk")
    return normalize_columns(data, params)


def load_initial_data(params: CarbonParams | None = None) -> tuple[pd.DataFrame, str]:
    if PROJECT_DATA_FILE.exists():
        return load_csv(PROJECT_DATA_FILE, params), "已保存的项目数据"
    return load_validation_data(params), "内置计算验证数据"


def save_csv(data: pd.DataFrame, path: str | Path, params: CarbonParams | None = None) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    normalized = normalize_columns(data, params)
    normalized.loc[:, INPUT_COLUMNS].to_csv(target, index=False, encoding="utf-8-sig")
    return target


def save_project_data(data: pd.DataFrame, params: CarbonParams | None = None) -> Path:
    ensure_directories()
    return save_csv(data, PROJECT_DATA_FILE, params)


def save_excel(data: pd.DataFrame, path: str | Path, params: CarbonParams | None = None) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    normalized = normalize_columns(data, params)
    with pd.ExcelWriter(target, engine="openpyxl") as writer:
        normalized.loc[:, TABLE_COLUMNS].to_excel(writer, index=False, sheet_name="运行数据")
        derived = normalized.drop(columns=INPUT_COLUMNS, errors="ignore")
        derived.to_excel(writer, index=False, sheet_name="派生指标")
    return target


def dataframe_from_table_rows(rows: list[list[str]], columns: list[str]) -> pd.DataFrame:
    return pd.DataFrame(rows, columns=columns)
