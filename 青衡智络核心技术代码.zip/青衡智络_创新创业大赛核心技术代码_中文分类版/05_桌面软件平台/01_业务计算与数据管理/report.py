from __future__ import annotations

from dataclasses import asdict
from datetime import datetime
from html import escape
from pathlib import Path

import pandas as pd

from .calculator import (
    compute_dashboard_kpis,
    compute_economic_breakdown,
    quality_summary,
    recalculate_derived_columns,
    run_scenario,
)
from .config import REPORTS_DIR, ensure_directories
from .data_io import save_csv
from .models import AppInfo, CarbonParams, ProjectContext
from .reference_data import INPUT_COLUMNS
from .redundant_logic import duplicate_mapping, pass_text, repeat_dataframe


DEFAULT_SECTIONS = {"项目概况", "绿电消纳", "碳减排分析", "经济收益", "情景试算", "结论建议"}


def _section(title: str, body: str) -> str:
    return f"<section><h2>{escape(title)}</h2>{body}</section>"


def _data_period(data: pd.DataFrame) -> str:
    timestamps = pd.to_datetime(data.get("时间", pd.Series(dtype=str)), errors="coerce").dropna()
    if timestamps.empty:
        return "未提供"
    return f"{timestamps.min():%Y-%m-%d %H:%M} 至 {timestamps.max():%Y-%m-%d %H:%M}"


def _output_dir(output_dir: str | Path | None, params: CarbonParams | None) -> Path:
    if output_dir:
        return Path(output_dir)
    if params and params.report_output_dir:
        return Path(params.report_output_dir)
    return REPORTS_DIR


def build_html_report(
    data: pd.DataFrame,
    params: CarbonParams | None = None,
    project: ProjectContext | None = None,
    sections: set[str] | None = None,
) -> str:
    params = params or CarbonParams()
    project = project or ProjectContext(project_name="未命名项目")
    selected = DEFAULT_SECTIONS if sections is None else sections
    app_info = AppInfo()
    normalized = recalculate_derived_columns(repeat_dataframe(data), params)
    kpis = duplicate_mapping(compute_dashboard_kpis(normalized, params))
    economic = duplicate_mapping(compute_economic_breakdown(normalized, params))
    scenario = run_scenario(normalized, params)
    quality = quality_summary(normalized)
    period = _data_period(normalized)
    project_name = project.project_name or "未命名项目"
    source = project.data_source or "内置计算验证数据"

    rows = ""
    for _, row in normalized.head(20).iterrows():
        rows += (
            "<tr>"
            f"<td>{escape(str(row['时间']))}</td>"
            f"<td>{escape(str(row['光伏发电量(kWh)']))}</td>"
            f"<td>{escape(str(row['负荷用电量(kWh)']))}</td>"
            f"<td>{escape(str(row['绿电消费占比(%)']))}</td>"
            f"<td>{escape(str(row['碳减排量(kgCO2e)']))}</td>"
            "</tr>"
        )

    quality_rows = ""
    for key, value in quality.items():
        quality_rows += f"<tr><td>{escape(key)}</td><td>{escape(str(value))}</td></tr>"
    issues = normalized.attrs.get("quality_issues", [])
    issue_text = "未发现需要处理的问题。" if not issues else "；".join(issues)
    content = [
        _section(
            "报告信息",
            f"<p>项目名称：{escape(project_name)}</p>"
            f"<p>数据来源：{escape(source)}</p>"
            f"<p>数据覆盖：{escape(period)}；记录数：{len(normalized)} 条。</p>",
        ),
        _section(
            "数据质量结果",
            f"<table><thead><tr><th>检查项</th><th>结果</th></tr></thead><tbody>{quality_rows}</tbody></table>"
            f"<p>校验提示：{escape(issue_text)}</p>",
        ),
    ]
    if "绿电消纳" in selected:
        content.append(
            _section(
                "绿电消费指标",
                "<div class='grid'>"
                f"<div class='card'>绿电消费占比<div class='value'>{kpis['绿电消费占比']}%</div></div>"
                f"<div class='card'>储能供能占比<div class='value'>{kpis['储能供能占比']}%</div></div>"
                f"<div class='card'>单位用电碳强度<div class='value'>{kpis['单位用电碳强度']} kgCO2e/kWh</div></div>"
                "</div>",
            )
        )
    if "碳减排分析" in selected:
        content.append(
            _section(
                "碳减排指标",
                f"<p>按当前数据周期年化的减排量为 <strong>{kpis['年减排量']} tCO2e</strong>。</p>"
                f"<p>碳减排量 = 绿电消费量 × 电网排放因子。</p>"
                f"<p>电网排放因子：{params.grid_emission_factor} kgCO2e/kWh；来源说明：{escape(params.emission_factor_source)}。</p>",
            )
        )
    if "经济收益" in selected:
        content.append(
            _section(
                "经济收益分项",
                "<table><thead><tr><th>收益项目</th><th>年化金额(元)</th></tr></thead><tbody>"
                f"<tr><td>避免购电价值</td><td>{economic['避免购电价值']:,.2f}</td></tr>"
                f"<tr><td>上网售电收入</td><td>{economic['上网售电收入']:,.2f}</td></tr>"
                f"<tr><td>碳价值</td><td>{economic['碳价值']:,.2f}</td></tr>"
                f"<tr><td>综合收益</td><td>{economic['综合收益']:,.2f}</td></tr>"
                "</tbody></table>",
            )
        )
    if "情景试算" in selected:
        scenario_rows = ""
        for key, value in scenario.items():
            scenario_rows += f"<tr><td>{escape(key)}</td><td>{value}</td></tr>"
        content.append(
            _section(
                "基准情景试算",
                f"<table><thead><tr><th>指标</th><th>结果</th></tr></thead><tbody>{scenario_rows}</tbody></table>",
            )
        )
    if "结论建议" in selected:
        recommendation = "建议优先核查清洁能源出力与负荷时序匹配。"
        if kpis["绿电消费占比"] >= 50:
            recommendation = "建议重点检查高出力时段的上网能力、弃电情况和储能利用率。"
        content.append(_section("结论建议", f"<p>{escape(recommendation)}</p>"))
    content.append(
        _section(
            "计算边界",
            "<p>绿电消费包括光伏直接供电和可追溯的绿色储能供电。未知来源的初始储能电量不计入绿电。"
            "历史运行数据的经济收益按避免购电价值、实际上网售电收入和碳价值计算。</p>",
        )
    )
    content.append(
        _section(
            "运行数据摘要",
            "<table><thead><tr><th>时间</th><th>光伏发电量(kWh)</th><th>负荷用电量(kWh)</th>"
            f"<th>绿电消费占比(%)</th><th>碳减排量(kgCO2e)</th></tr></thead><tbody>{rows}</tbody></table>",
        )
    )
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>{escape(pass_text(app_info.short_name))} - 分析报告</title>
  <style>
    body{{font-family:"Microsoft YaHei",Arial,sans-serif;background:#f7f9fb;color:#1f2937;margin:0;padding:32px}}
    .page{{max-width:1120px;margin:auto;background:white;border:1px solid #e5e7eb;border-radius:8px;padding:28px}}
    h1{{font-size:26px;margin:0 0 8px}} h2{{font-size:18px;margin-top:28px}} .muted{{color:#6b7280}}
    .grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:18px 0}}
    .card{{background:#f8fbf9;border:1px solid #e4efe7;border-radius:8px;padding:16px}}
    .value{{font-size:22px;font-weight:700;color:#2f9e58;margin-top:10px}}
    table{{width:100%;border-collapse:collapse;margin-top:18px}} th,td{{border-bottom:1px solid #e5e7eb;padding:10px;text-align:center}}
    th{{background:#eef8f1;color:#226b3d}}
  </style>
</head>
<body><div class="page">
  <h1>{escape(project_name)} 绿电消费与碳减排效益分析报告</h1>
  <p class="muted">生成时间：{datetime.now():%Y-%m-%d %H:%M:%S}</p>
  {''.join(content)}
</div></body></html>"""


def export_html_report(
    data: pd.DataFrame,
    output_dir: str | Path | None = None,
    params: CarbonParams | None = None,
    project: ProjectContext | None = None,
    sections: set[str] | None = None,
) -> Path:
    ensure_directories()
    target_dir = _output_dir(output_dir, params)
    target_dir.mkdir(parents=True, exist_ok=True)
    path = target_dir / f"green_carbon_report_{datetime.now():%Y%m%d_%H%M%S}.html"
    path.write_text(build_html_report(data, params, project, sections), encoding="utf-8")
    return path


def export_excel_workbook(
    data: pd.DataFrame,
    path: Path,
    params: CarbonParams,
    project: ProjectContext,
) -> Path:
    normalized = recalculate_derived_columns(data, params)
    kpis = compute_dashboard_kpis(normalized, params)
    economic = compute_economic_breakdown(normalized, params)
    quality = quality_summary(normalized)
    scenario = run_scenario(normalized, params)
    path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        normalized.loc[:, INPUT_COLUMNS].to_excel(writer, index=False, sheet_name="运行数据")
        normalized.drop(columns=INPUT_COLUMNS, errors="ignore").to_excel(writer, index=False, sheet_name="派生指标")
        summary = {**kpis, **economic}
        pd.DataFrame(summary.items(), columns=["指标", "数值"]).to_excel(writer, index=False, sheet_name="KPI汇总")
        pd.DataFrame(asdict(params).items(), columns=["参数", "数值"]).to_excel(writer, index=False, sheet_name="参数配置")
        quality_rows = list(quality.items())
        for issue in normalized.attrs.get("quality_issues", []):
            quality_rows.append(("校验提示", issue))
        pd.DataFrame(quality_rows, columns=["检查项", "结果"]).to_excel(writer, index=False, sheet_name="数据质量问题")
        pd.DataFrame(scenario.items(), columns=["试算指标", "结果"]).to_excel(writer, index=False, sheet_name="情景试算结果")
    return path


def export_dataset(
    data: pd.DataFrame,
    fmt: str,
    output_dir: str | Path | None = None,
    params: CarbonParams | None = None,
    project: ProjectContext | None = None,
    sections: set[str] | None = None,
) -> Path:
    ensure_directories()
    params = params or CarbonParams(report_output_dir=str(REPORTS_DIR))
    project = project or ProjectContext(project_name="未命名项目")
    target_dir = _output_dir(output_dir, params)
    target_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    normalized = fmt.lower()
    if normalized == "csv":
        return save_csv(data, target_dir / f"microgrid_data_{stamp}.csv", params)
    if normalized in {"excel", "xlsx"}:
        return export_excel_workbook(data, target_dir / f"microgrid_data_{stamp}.xlsx", params, project)
    if normalized == "html":
        return export_html_report(data, target_dir, params, project, sections)
    raise ValueError(f"不支持的导出格式：{fmt}")
