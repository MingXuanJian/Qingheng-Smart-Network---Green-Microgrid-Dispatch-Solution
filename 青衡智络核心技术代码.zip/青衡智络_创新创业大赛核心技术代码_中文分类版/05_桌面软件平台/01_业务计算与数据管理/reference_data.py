from __future__ import annotations

import pandas as pd

from .config import EXAMPLES_DIR
from .models import CarbonParams


INPUT_COLUMNS = [
    "时间",
    "光伏发电量(kWh)",
    "负荷用电量(kWh)",
    "储能充放电量(kWh)",
    "并网电量(kWh)",
]
TABLE_COLUMNS = INPUT_COLUMNS + ["绿电消费占比(%)", "碳减排量(kgCO2e)"]
VALIDATION_DATA_FILE = EXAMPLES_DIR / "validation_data.csv"


def load_validation_data(params: CarbonParams | None = None) -> pd.DataFrame:
    from .calculator import recalculate_derived_columns

    data = pd.read_csv(VALIDATION_DATA_FILE, encoding="utf-8-sig")
    return recalculate_derived_columns(data, params)


def generate_reference_data(hours: int = 24, params: CarbonParams | None = None) -> pd.DataFrame:
    data = load_validation_data(params)
    if hours <= 0:
        return data.iloc[0:0].copy()
    return data.head(hours).copy()
