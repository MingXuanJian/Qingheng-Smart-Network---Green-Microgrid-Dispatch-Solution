from __future__ import annotations

import json
import os
import shutil
import sys
from dataclasses import asdict
from datetime import datetime
from pathlib import Path

from .models import CarbonParams, ProjectContext


APP_FOLDER_NAME = "QinghengMicrogridApp"
RESOURCE_DIR = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))
ASSETS_DIR = RESOURCE_DIR / "assets"
EXAMPLES_DIR = RESOURCE_DIR / "examples"
LOCAL_APP_DATA = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
USER_DATA_DIR = LOCAL_APP_DATA / APP_FOLDER_NAME
CONFIG_DIR = USER_DATA_DIR / "config"
DATA_DIR = USER_DATA_DIR / "data"
REPORTS_DIR = USER_DATA_DIR / "reports"
LOGS_DIR = USER_DATA_DIR / "logs"
CONFIG_FILE = CONFIG_DIR / "params.json"
PROJECT_FILE = CONFIG_DIR / "project.json"
PROJECT_DATA_FILE = DATA_DIR / "project_data.csv"
OUTPUTS_DIR = REPORTS_DIR
PARAMETER_RANGES = {
    "grid_emission_factor": (0.01, 2.0),
    "carbon_price": (0.0, 2000.0),
    "buy_price": (0.0, 10.0),
    "sell_price": (0.0, 10.0),
    "storage_capacity": (0.0, 100000.0),
    "wind_capacity": (0.0, 100000.0),
    "storage_roundtrip_efficiency": (0.01, 1.0),
    "wind_capacity_factor": (0.0, 1.0),
    "grid_export_limit_kw": (0.0, 100000.0),
}


class ConfigError(ValueError):
    pass


def ensure_directories() -> None:
    for path in [CONFIG_DIR, DATA_DIR, REPORTS_DIR, LOGS_DIR]:
        path.mkdir(parents=True, exist_ok=True)


def validate_params(params: CarbonParams) -> CarbonParams:
    for key, limits in PARAMETER_RANGES.items():
        value = getattr(params, key)
        minimum, maximum = limits
        if not isinstance(value, (int, float)) or not minimum <= value <= maximum:
            raise ConfigError(f"参数“{key}”应在 {minimum} 至 {maximum} 之间。")
    if not params.emission_factor_source.strip():
        raise ConfigError("请填写排放因子来源说明。")
    return params


def load_params(path: Path | None = None) -> CarbonParams:
    ensure_directories()
    target = path or CONFIG_FILE
    if not target.exists():
        params = CarbonParams(report_output_dir=str(REPORTS_DIR))
        return params
    try:
        values = json.loads(target.read_text(encoding="utf-8"))
        defaults = asdict(CarbonParams(report_output_dir=str(REPORTS_DIR)))
        defaults.update(values)
        params = CarbonParams(**defaults)
        if not params.report_output_dir:
            params.report_output_dir = str(REPORTS_DIR)
        return validate_params(params)
    except (json.JSONDecodeError, TypeError, ValueError) as error:
        raise ConfigError(f"配置文件无法读取：{target}。{error}") from error


def save_params(params: CarbonParams, path: Path | None = None) -> Path:
    ensure_directories()
    target = path or CONFIG_FILE
    target.parent.mkdir(parents=True, exist_ok=True)
    validate_params(params)
    target.write_text(json.dumps(asdict(params), ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def backup_broken_config(path: Path | None = None) -> Path | None:
    target = path or CONFIG_FILE
    if not target.exists():
        return None
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = target.with_name(f"{target.stem}.broken_{stamp}{target.suffix}")
    shutil.copy2(target, backup)
    return backup


def load_project_context() -> ProjectContext:
    ensure_directories()
    if not PROJECT_FILE.exists():
        return ProjectContext()
    try:
        values = json.loads(PROJECT_FILE.read_text(encoding="utf-8"))
        return ProjectContext(
            project_name=str(values.get("project_name", "")),
            data_source=str(values.get("data_source", "已保存的项目数据")),
        )
    except (json.JSONDecodeError, TypeError, ValueError):
        return ProjectContext()


def save_project_context(project: ProjectContext) -> Path:
    ensure_directories()
    values = {
        "project_name": project.project_name,
        "data_source": project.data_source,
    }
    PROJECT_FILE.write_text(json.dumps(values, ensure_ascii=False, indent=2), encoding="utf-8")
    return PROJECT_FILE


def icon_png_path() -> Path:
    return ASSETS_DIR / "icons" / "app_icon.png"


def icon_ico_path() -> Path:
    return ASSETS_DIR / "icons" / "app_icon.ico"
