from __future__ import annotations

import sys

from PySide6.QtGui import QIcon
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication, QMessageBox

from .config import ConfigError, REPORTS_DIR, backup_broken_config, ensure_directories, icon_ico_path, icon_png_path, load_params
from .models import CarbonParams
from .ui.icon_utils import generate_app_icon
from .ui.workspace_window import WorkspaceWindow
from .ui.main_window import MainWindow
from .ui.theme import app_stylesheet, setup_chinese_font


def ensure_icon_assets() -> None:
    ensure_directories()
    if getattr(sys, "frozen", False):
        return
    if not icon_png_path().exists() or not icon_ico_path().exists():
        generate_app_icon(icon_png_path(), icon_ico_path())


def main() -> int:
    ensure_icon_assets()
    app = QApplication(sys.argv)
    setup_chinese_font(app)
    app.setStyleSheet(app_stylesheet())
    if icon_ico_path().exists():
        app.setWindowIcon(QIcon(str(icon_ico_path())))
    config_warning = ""
    try:
        params = load_params()
    except ConfigError as error:
        backup = backup_broken_config()
        params = CarbonParams(report_output_dir=str(REPORTS_DIR))
        backup_text = "未找到可备份文件。" if backup is None else f"已保留副本：{backup}"
        config_warning = f"{error}\n已恢复默认配置，{backup_text}"
    workspace = WorkspaceWindow()
    windows: dict[str, MainWindow] = {}

    def open_main(project_name: str) -> None:
        main_window = MainWindow(project_name, params)
        if icon_ico_path().exists():
            main_window.setWindowIcon(QIcon(str(icon_ico_path())))
        windows["main"] = main_window
        main_window.show()
        workspace.close()
        if config_warning:
            QTimer.singleShot(0, lambda: QMessageBox.warning(main_window, "配置文件提示", config_warning))
        if main_window.data_warning:
            QTimer.singleShot(0, lambda: QMessageBox.warning(main_window, "项目数据提示", main_window.data_warning))

    workspace.workspace_opened.connect(open_main)
    workspace.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
