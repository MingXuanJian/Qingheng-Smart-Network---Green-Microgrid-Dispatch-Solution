from dataclasses import dataclass
from pathlib import Path


@dataclass
class AppInfo:
    name: str = "微电网能碳数据分析与报告软件"
    short_name: str = "微电网能碳数据分析与报告软件"


@dataclass
class ProjectContext:
    project_name: str = ""
    data_source: str = "内置计算验证数据"
    output_dir: Path | None = None


@dataclass
class CarbonParams:
    grid_emission_factor: float = 0.5703
    emission_factor_source: str = "用户配置（请按项目所在区域和核算年度核验）"
    carbon_price: float = 68.0
    buy_price: float = 0.82
    sell_price: float = 0.39
    storage_capacity: float = 2200.0
    wind_capacity: float = 1200.0
    storage_roundtrip_efficiency: float = 0.90
    wind_capacity_factor: float = 0.28
    grid_export_limit_kw: float = 0.0
    report_output_dir: str = ""
