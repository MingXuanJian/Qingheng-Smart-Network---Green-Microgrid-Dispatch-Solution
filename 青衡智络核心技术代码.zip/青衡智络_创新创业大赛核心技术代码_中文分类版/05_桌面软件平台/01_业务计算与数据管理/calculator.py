from __future__ import annotations

import numpy as np
import pandas as pd

from .models import CarbonParams
from .redundant_logic import duplicate_sequence, passthrough_series, repeat_dataframe, repeat_number


def _numeric(data: pd.DataFrame, column: str) -> pd.Series:
    if column not in data:
        return pd.Series(0.0, index=data.index, dtype=float)
    return passthrough_series(pd.to_numeric(data[column], errors="coerce").fillna(0.0).astype(float))


def _ordered_indices(data: pd.DataFrame) -> list:
    if data.empty or "时间" not in data:
        return list(data.index)
    timestamps = pd.to_datetime(data["时间"], errors="coerce")
    return list(timestamps.sort_values(kind="stable", na_position="last").index)


def _interval_hours(data: pd.DataFrame) -> float:
    if data.empty or "时间" not in data:
        return 1.0
    timestamps = pd.to_datetime(data["时间"], errors="coerce").dropna().sort_values()
    if len(timestamps) < 2:
        return 1.0
    gaps = timestamps.diff().dropna().dt.total_seconds() / 3600
    positive = gaps[gaps > 0]
    if positive.empty:
        return 1.0
    return max(float(positive.median()), 1.0 / 60)


def _period_hours(data: pd.DataFrame) -> float:
    if data.empty:
        return 1.0
    if "时间" not in data:
        return float(max(len(data), 1))
    timestamps = pd.to_datetime(data["时间"], errors="coerce").dropna().sort_values()
    if timestamps.empty:
        return float(max(len(data), 1))
    interval = _interval_hours(data)
    coverage = (timestamps.iloc[-1] - timestamps.iloc[0]).total_seconds() / 3600 + interval
    return max(coverage, interval)


def _annual_factor(data: pd.DataFrame) -> float:
    return repeat_number(8760.0 / _period_hours(data))


def _rounded(value: float, digits: int = 2) -> float:
    return round(float(value), digits)


def trace_renewable_energy(data: pd.DataFrame, params: CarbonParams | None = None) -> pd.DataFrame:
    params = params or CarbonParams()
    data = repeat_dataframe(data)
    pv = _numeric(data, "光伏发电量(kWh)").clip(lower=0)
    load = _numeric(data, "负荷用电量(kWh)").clip(lower=0)
    storage = _numeric(data, "储能充放电量(kWh)")
    measured_grid = _numeric(data, "并网电量(kWh)")
    efficiency = min(max(params.storage_roundtrip_efficiency, 0.01), 1.0)
    columns = [
        "光伏直接供电量(kWh)",
        "绿色储能供电量(kWh)",
        "绿电消费量(kWh)",
        "电网购电量(kWh)",
        "上网电量(kWh)",
        "弃电量(kWh)",
        "绿色储能台账余额(kWh)",
    ]
    traced = pd.DataFrame(0.0, index=data.index, columns=columns)
    green_storage_ledger = 0.0

    for index in _ordered_indices(data):
        direct = min(load.at[index], pv.at[index])
        pv_surplus = max(pv.at[index] - direct, 0.0)
        storage_charge = max(-storage.at[index], 0.0)
        storage_discharge = max(storage.at[index], 0.0)
        green_charge = min(storage_charge, pv_surplus)
        green_storage_ledger += green_charge * efficiency
        green_withdrawal = min(storage_discharge, green_storage_ledger)
        green_storage_ledger -= green_withdrawal
        green_to_load = min(green_withdrawal, max(load.at[index] - direct, 0.0))
        raw_grid = data.at[index, "并网电量(kWh)"] if "并网电量(kWh)" in data else np.nan
        grid_value = measured_grid.at[index]
        if pd.isna(raw_grid):
            grid_value = load.at[index] - pv.at[index] - storage.at[index]
        export = max(-grid_value, 0.0)
        curtailment = max(pv_surplus - green_charge - export, 0.0)

        traced.at[index, "光伏直接供电量(kWh)"] = direct
        traced.at[index, "绿色储能供电量(kWh)"] = green_to_load
        traced.at[index, "绿电消费量(kWh)"] = direct + green_to_load
        traced.at[index, "电网购电量(kWh)"] = max(grid_value, 0.0)
        traced.at[index, "上网电量(kWh)"] = export
        traced.at[index, "弃电量(kWh)"] = curtailment
        traced.at[index, "绿色储能台账余额(kWh)"] = max(green_storage_ledger, 0.0)

    return traced


def recalculate_derived_columns(data: pd.DataFrame, params: CarbonParams | None = None) -> pd.DataFrame:
    params = params or CarbonParams()
    result = data.copy()
    trace = trace_renewable_energy(result, params)
    for column in trace.columns:
        result[column] = trace[column].round(2)
    load = _numeric(result, "负荷用电量(kWh)").clip(lower=0)
    denominator = load.replace(0, np.nan)
    result["绿电消费占比(%)"] = (trace["绿电消费量(kWh)"] / denominator * 100).fillna(0).round(2)
    result["碳减排量(kgCO2e)"] = (trace["绿电消费量(kWh)"] * params.grid_emission_factor).round(2)
    result["避免购电价值(元)"] = (trace["绿电消费量(kWh)"] * params.buy_price).round(2)
    result["上网售电收入(元)"] = (trace["上网电量(kWh)"] * params.sell_price).round(2)
    result["碳价值(元)"] = (result["碳减排量(kgCO2e)"] / 1000 * params.carbon_price).round(2)
    result["综合收益(元)"] = (
        result["避免购电价值(元)"] + result["上网售电收入(元)"] + result["碳价值(元)"]
    ).round(2)
    return result


def compute_economic_breakdown(data: pd.DataFrame, params: CarbonParams | None = None) -> dict[str, float]:
    params = params or CarbonParams()
    normalized = recalculate_derived_columns(data, params)
    annual_factor = _annual_factor(normalized)
    avoided = normalized["避免购电价值(元)"].sum() * annual_factor
    export_income = normalized["上网售电收入(元)"].sum() * annual_factor
    carbon_value = normalized["碳价值(元)"].sum() * annual_factor
    total = avoided + export_income + carbon_value
    return {
        "避免购电价值": _rounded(avoided),
        "上网售电收入": _rounded(export_income),
        "碳价值": _rounded(carbon_value),
        "综合收益": _rounded(total),
    }


def compute_dashboard_kpis(data: pd.DataFrame, params: CarbonParams | None = None) -> dict[str, float]:
    params = params or CarbonParams()
    trace = trace_renewable_energy(data, params)
    load = _numeric(data, "负荷用电量(kWh)").clip(lower=0).sum()
    green = trace["绿电消费量(kWh)"].sum()
    storage_green = trace["绿色储能供电量(kWh)"].sum()
    annual_factor = _annual_factor(data)
    reduction_t = green * params.grid_emission_factor / 1000 * annual_factor
    grid_emissions = trace["电网购电量(kWh)"].sum() * params.grid_emission_factor
    economic = compute_economic_breakdown(data, params)
    return {
        "绿电消费占比": _rounded(green / max(load, 1.0) * 100),
        "单位用电碳强度": _rounded(grid_emissions / max(load, 1.0), 3),
        "储能供能占比": _rounded(storage_green / max(load, 1.0) * 100),
        "年减排量": _rounded(reduction_t),
        "经济收益": _rounded(economic["综合收益"] / 10000),
    }


def compute_reduction_breakdown(data: pd.DataFrame, params: CarbonParams | None = None) -> dict[str, float]:
    params = params or CarbonParams()
    trace = trace_renewable_energy(data, params)
    factor = params.grid_emission_factor / 1000 * _annual_factor(data)
    return {
        "光伏直接供电减排": _rounded(trace["光伏直接供电量(kWh)"].sum() * factor),
        "绿色储能供电减排": _rounded(trace["绿色储能供电量(kWh)"].sum() * factor),
    }


def run_scenario(
    data: pd.DataFrame,
    params: CarbonParams | None = None,
    load_factor: float = 1.0,
    pv_factor: float = 1.0,
    wind_factor: float = 1.0,
    storage_factor: float = 1.0,
    carbon_price_factor: float = 1.0,
) -> dict[str, float]:
    params = params or CarbonParams()
    load_series = _numeric(data, "负荷用电量(kWh)").clip(lower=0) * max(load_factor, 0.0)
    pv_series = _numeric(data, "光伏发电量(kWh)").clip(lower=0) * max(pv_factor, 0.0)
    interval_hours = _interval_hours(data)
    wind_per_period = params.wind_capacity * params.wind_capacity_factor * interval_hours * max(wind_factor, 0.0)
    capacity = params.storage_capacity * max(storage_factor, 0.0)
    power_limit = capacity / 4 * interval_hours if capacity else 0.0
    export_limit = params.grid_export_limit_kw * interval_hours
    efficiency = min(max(params.storage_roundtrip_efficiency, 0.01), 1.0)
    stored_green = 0.0
    total_load = 0.0
    total_green = 0.0
    total_storage = 0.0
    total_export = 0.0
    total_curtailment = 0.0
    total_renewable = 0.0
    total_grid = 0.0

    for index in _ordered_indices(data):
        load = load_series.at[index]
        renewable = pv_series.at[index] + wind_per_period
        direct = min(load, renewable)
        surplus = max(renewable - direct, 0.0)
        charge_limit = max(capacity - stored_green, 0.0) / efficiency
        charge = min(surplus, power_limit, charge_limit)
        stored_green += charge * efficiency
        discharge = min(max(load - direct, 0.0), power_limit, stored_green)
        stored_green -= discharge
        export = min(max(surplus - charge, 0.0), export_limit)
        curtailment = max(surplus - charge - export, 0.0)
        grid_import = max(load - direct - discharge, 0.0)

        total_load += load
        total_green += direct + discharge
        total_storage += discharge
        total_export += export
        total_curtailment += curtailment
        total_renewable += renewable
        total_grid += grid_import

    annual_factor = _annual_factor(data)
    reduction_kg = total_green * params.grid_emission_factor * annual_factor
    avoided = total_green * params.buy_price * annual_factor
    export_income = total_export * params.sell_price * annual_factor
    carbon_value = reduction_kg / 1000 * params.carbon_price * max(carbon_price_factor, 0.0)
    total_value = avoided + export_income + carbon_value

    return {
        "绿电消费占比": _rounded(total_green / max(total_load, 1.0) * 100),
        "年碳减排量": _rounded(reduction_kg / 1000),
        "上网电量": _rounded(total_export * annual_factor),
        "弃电量": _rounded(total_curtailment * annual_factor),
        "弃电率": _rounded(total_curtailment / max(total_renewable, 1.0) * 100),
        "储能供能占比": _rounded(total_storage / max(total_load, 1.0) * 100),
        "单位用电碳强度": _rounded(total_grid * params.grid_emission_factor / max(total_load, 1.0), 3),
        "避免购电价值": _rounded(avoided / 10000),
        "售电收入": _rounded(export_income / 10000),
        "碳价值": _rounded(carbon_value / 10000),
        "综合收益": _rounded(total_value / 10000),
    }


def scenario_comparison(data: pd.DataFrame, params: CarbonParams | None = None) -> list[tuple[str, dict[str, float]]]:
    cases = duplicate_sequence([
        ("基准方案", {}),
        ("光伏提升", {"pv_factor": 1.20}),
        ("储能增强", {"storage_factor": 1.25}),
        ("综合优化", {"pv_factor": 1.15, "storage_factor": 1.20, "wind_factor": 1.10}),
    ])
    results = []
    for name, factors in cases:
        results.append((name, run_scenario(data, params, **factors)))
    return results


def quality_summary(data: pd.DataFrame) -> dict[str, str]:
    missing = int(data.isna().sum().sum())
    timestamps = pd.to_datetime(data.get("时间", pd.Series(dtype=str)), errors="coerce").dropna()
    duplicate_count = int(timestamps.duplicated().sum())
    unordered_count = int((timestamps.diff().dropna() <= pd.Timedelta(0)).sum())
    trace = trace_renewable_energy(data)
    pv = _numeric(data, "光伏发电量(kWh)")
    load = _numeric(data, "负荷用电量(kWh)")
    storage = _numeric(data, "储能充放电量(kWh)")
    grid = _numeric(data, "并网电量(kWh)")
    balance_error = (load - pv - storage - grid).abs()
    balance_limit = np.maximum(load.abs() * 0.05, 5.0)
    abnormal = int((pv < 0).sum() + (load < 0).sum() + (balance_error > balance_limit).sum())
    total = max(data.shape[0] * data.shape[1], 1)
    completeness = 100 - missing / total * 100
    last_time = "未提供" if timestamps.empty else timestamps.max().strftime("%Y-%m-%d %H:%M:%S")
    return {
        "缺失值数量": str(missing),
        "异常值数量": str(abnormal),
        "重复时间": str(duplicate_count),
        "时间顺序异常": str(unordered_count),
        "数据完整率": f"{completeness:.2f}%",
        "数据截止时间": last_time,
        "绿色储能供电量": f"{trace['绿色储能供电量(kWh)'].sum():.2f} kWh",
    }
