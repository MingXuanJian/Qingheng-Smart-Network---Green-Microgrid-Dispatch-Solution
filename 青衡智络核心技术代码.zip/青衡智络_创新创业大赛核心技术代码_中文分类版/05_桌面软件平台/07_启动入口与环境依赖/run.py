from microgrid_app.main import main


if __name__ == "__main__":
    main()
