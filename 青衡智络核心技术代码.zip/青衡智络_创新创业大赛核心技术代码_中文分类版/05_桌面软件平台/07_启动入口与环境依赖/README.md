# 青衡智络｜微电网能碳数据分析与报告桌面端（iCAN 版）

## 软件说明

> **模块边界**：本目录是独立可运行的桌面数据管理与报告工具。它不会在界面内部直接训练 CNN–LSTM–Attention 或执行改进 WOA；正式预测、碳流与滚动调度由 `../algorithm_core/` 生成结果文件后，再按项目接口接入展示层。内置固定合成数据仅用于界面与计算流程自检。


本软件是 Windows 本地离线运行的工商业微电网能碳评估工具。用户输入项目名称后进入工作台，可导入 CSV 运行数据，完成绿电消费、绿色储能追踪、碳减排、经济收益、情景试算、数据质量检查和报告导出。

软件不连接远程设备、业务服务器或账号系统。首次运行使用“内置计算验证数据”；该数据为固定合成数据，仅用于验证计算流程，不代表真实项目。导入 CSV 后，页面和导出文件均使用用户数据。

## 功能范围

- 项目工作区创建与项目名称输入
- CSV 导入、字段校验、质量提示和项目数据保存
- 光伏直接供电与绿色储能台账追踪
- 绿电消费量、碳减排量和年化指标计算
- 避免购电价值、上网售电收入、碳价值和综合收益计算
- 参数配置、情景试算、上网功率限制和弃电计算
- HTML 报告、结构化 CSV、六工作表 Excel 导出
- 参数和项目数据持久化
- PyInstaller Windows EXE 打包脚本

## CSV 字段

| 字段 | 单位 | 约定 |
| --- | --- | --- |
| 时间 | 日期时间 | 可转换为日期时间 |
| 光伏发电量(kWh) | kWh | 不得为负数 |
| 负荷用电量(kWh) | kWh | 不得为负数 |
| 储能充放电量(kWh) | kWh | 正值为放电，负值为充电 |
| 并网电量(kWh) | kWh | 正值为购电，负值为上网 |

缺少字段、非法时间、空值、非数值、负光伏或负负荷会阻止导入。重复时间、时间顺序、异常时间间隔和能量平衡偏差会显示为数据质量提示。

## 安装与启动

```powershell
python -m pip install -r requirements.txt
python run.py
```

Windows 下也可以运行 `scripts\run_app.bat`。

## 数据目录

源码运行和 EXE 运行均使用以下用户数据目录，不向安装目录写入配置或报告：

```text
%LOCALAPPDATA%\QinghengMicrogridApp\
├─ config\
├─ data\
├─ reports\
└─ logs\
```

参数文件为 `config\params.json`，项目数据文件为 `data\project_data.csv`。配置文件损坏时，软件会保留损坏副本并提示使用默认配置，不会静默覆盖原文件。

## 测试与打包

```powershell
python -m compileall microgrid_app tests
python -m unittest discover tests -v
scripts\build_release.bat
```

`requirements-lock.txt` 记录本工程已验证的依赖版本。EXE 会生成在 `dist\qingheng_microgrid_app\qingheng_microgrid_app.exe`。

详细操作、公式、模块、运行环境和测试记录见 `docs/`。
