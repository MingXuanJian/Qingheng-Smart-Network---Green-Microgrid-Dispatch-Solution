from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict, dataclass
from numbers import Real
import numpy as np
import pandas as pd

from qingheng.carbon import (
    BranchFlow,
    CarbonMetrics,
    CarbonReservoir,
    ReservoirTransfer,
    SourceInjection,
    TraceResult,
    compute_carbon_metrics,
    trace_carbon,
)
from qingheng.config import CarbonConfig, DispatchConfig
from qingheng.dispatch import DispatchEvaluation, DispatchInputs
from qingheng.network import IEEE33ScheduleValidator, PowerFlowValidation


@dataclass(frozen=True)
class CarbonAccountingResult:
    snapshots: pd.DataFrame
    metrics: CarbonMetrics
    traces: tuple[TraceResult, ...]
    reservoir_transfers: tuple[ReservoirTransfer, ...]
    load_allocated_emissions_kg: float
    external_source_emissions_kg: float
    nonstorage_sink_emissions_kg: float
    opening_storage_carbon_kg: float
    closing_storage_carbon_kg: float
    carbon_balance_residual_kg: float
    direct_green_consumed_kwh: float
    opening_battery_green_inventory_kwh: float
    closing_battery_green_inventory_kwh: float
    opening_hydrogen_green_inventory_kwh: float
    closing_hydrogen_green_inventory_kwh: float
    battery_green_inventory_balance_residual_kwh: float
    hydrogen_green_inventory_balance_residual_kwh: float

    @property
    def opening_storage_green_inventory_kwh(self) -> float:
        return (
            self.opening_battery_green_inventory_kwh
            + self.opening_hydrogen_green_inventory_kwh
        )

    @property
    def closing_storage_green_inventory_kwh(self) -> float:
        return (
            self.closing_battery_green_inventory_kwh
            + self.closing_hydrogen_green_inventory_kwh
        )

    @property
    def green_inventory_balance_residual_kwh(self) -> float:
        return (
            self.battery_green_inventory_balance_residual_kwh
            + self.hydrogen_green_inventory_balance_residual_kwh
        )

    def metrics_dict(self) -> dict[str, object]:
        return {
            **asdict(self.metrics),
            "load_allocated_emissions_kg": self.load_allocated_emissions_kg,
            "external_source_emissions_kg": self.external_source_emissions_kg,
            "nonstorage_sink_emissions_kg": self.nonstorage_sink_emissions_kg,
            "opening_storage_carbon_kg": self.opening_storage_carbon_kg,
            "closing_storage_carbon_kg": self.closing_storage_carbon_kg,
            "carbon_balance_residual_kg": self.carbon_balance_residual_kg,
            "direct_green_consumed_kwh": self.direct_green_consumed_kwh,
            "opening_battery_green_inventory_kwh": (
                self.opening_battery_green_inventory_kwh
            ),
            "closing_battery_green_inventory_kwh": (
                self.closing_battery_green_inventory_kwh
            ),
            "opening_hydrogen_green_inventory_kwh": (
                self.opening_hydrogen_green_inventory_kwh
            ),
            "closing_hydrogen_green_inventory_kwh": (
                self.closing_hydrogen_green_inventory_kwh
            ),
            "opening_storage_green_inventory_kwh": (
                self.opening_storage_green_inventory_kwh
            ),
            "closing_storage_green_inventory_kwh": (
                self.closing_storage_green_inventory_kwh
            ),
            "battery_green_inventory_balance_residual_kwh": (
                self.battery_green_inventory_balance_residual_kwh
            ),
            "hydrogen_green_inventory_balance_residual_kwh": (
                self.hydrogen_green_inventory_balance_residual_kwh
            ),
            "green_inventory_balance_residual_kwh": (
                self.green_inventory_balance_residual_kwh
            ),
        }


def _validated_initial_green_inventory(
    name: str,
    value: float,
    *,
    initial_energy_kwh: float,
    tolerance_kwh: float,
) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be finite and non-negative")
    numeric = float(value)
    if not np.isfinite(numeric) or numeric < 0.0:
        raise ValueError(f"{name} must be finite and non-negative")
    if numeric > initial_energy_kwh + tolerance_kwh:
        raise ValueError(f"{name} cannot exceed the initial stored energy")
    return min(numeric, initial_energy_kwh)


def _green_inventory_balance_residual(
    *,
    carrier: str,
    opening_green_inventory_kwh: float,
    closing_green_inventory_kwh: float,
    charge_efficiency: float,
    discharge_efficiency: float,
    transfers: list[ReservoirTransfer],
) -> float:
    stored_green_charged = sum(
        transfer.green_energy_kwh * charge_efficiency
        for transfer in transfers
        if transfer.carrier == carrier and transfer.direction == "charge"
    )
    stored_green_withdrawn = sum(
        transfer.green_energy_kwh / discharge_efficiency
        for transfer in transfers
        if transfer.carrier == carrier and transfer.direction == "discharge"
    )
    return (
        opening_green_inventory_kwh
        + stored_green_charged
        - stored_green_withdrawn
        - closing_green_inventory_kwh
    )


def _expanded_loss_network(
    validation: PowerFlowValidation,
    step: int,
    *,
    tolerance_kw: float,
) -> tuple[list[BranchFlow], dict[object, float]]:
    """Represent each AC line loss as a load on an intermediate flow node."""

    branches: list[BranchFlow] = []
    loss_loads: dict[object, float] = {}
    from_end = validation.branch_flows_kw[step]
    to_end = validation.branch_to_end_flows_kw[step]
    for index, (u, v, p_from, p_to) in enumerate(
        zip(
            validation.branch_from_bus,
            validation.branch_to_bus,
            from_end,
            to_end,
            strict=True,
        )
    ):
        if not np.isfinite(p_from) or not np.isfinite(p_to):
            continue
        loss_node = ("line_loss", index)
        if p_from > tolerance_kw and p_to > tolerance_kw:
            # A reversal point can lie inside a resistive line: both ends then
            # supply the line loss and no active power crosses the whole branch.
            branches.append(BranchFlow(int(u), loss_node, float(p_from)))
            branches.append(BranchFlow(int(v), loss_node, float(p_to)))
            loss_loads[loss_node] = float(p_from + p_to)
            continue
        if p_from > tolerance_kw:
            source, target = int(u), int(v)
            sent, received = float(p_from), max(float(-p_to), 0.0)
        elif p_to > tolerance_kw:
            source, target = int(v), int(u)
            sent, received = float(p_to), max(float(-p_from), 0.0)
        else:
            continue
        received = min(received, sent)
        branches.append(BranchFlow(source, loss_node, sent))
        if received > tolerance_kw:
            branches.append(BranchFlow(loss_node, target, received))
        loss_loads[loss_node] = max(sent - received, 0.0)
    return branches, loss_loads


def run_carbon_accounting(
    *,
    inputs: DispatchInputs,
    dispatch: DispatchEvaluation,
    dispatch_config: DispatchConfig,
    carbon_config: CarbonConfig,
    validator: IEEE33ScheduleValidator,
    validation: PowerFlowValidation,
    initial_battery_factor_kg_per_kwh: float | None = None,
    initial_hydrogen_factor_kg_per_kwh: float | None = None,
    initial_battery_green_inventory_kwh: float = 0.0,
    initial_hydrogen_green_inventory_kwh: float = 0.0,
) -> CarbonAccountingResult:
    """Trace dispatch while carrying carbon and green-label inventories.

    Initial green inventories use the reservoirs' stored-energy basis and cannot
    exceed the corresponding initial dispatch energy. Their default of zero keeps
    single-horizon callers backward compatible.
    """

    current_feasible = (
        True if validation.current_feasible is None else validation.current_feasible
    )
    if not (
        validation.all_converged
        and validation.voltage_feasible
        and current_feasible
    ):
        raise ValueError(
            "carbon accounting requires a physically feasible AC power-flow schedule"
        )
    if inputs.horizon != dispatch_config.horizon_steps:
        raise ValueError("dispatch configuration horizon differs from inputs")
    dt = dispatch_config.step_hours
    trace_tolerance_kw = max(carbon_config.tolerance_kw, 1e-4)
    # State reconstruction accumulates tiny optimizer boundary corrections over
    # the horizon; keep that tolerance separate from the stricter carbon balance.
    state_power_tolerance_kw = max(trace_tolerance_kw, 1e-4)
    battery_state_tolerance_kwh = max(
        1e-6,
        inputs.horizon
        * state_power_tolerance_kw
        * dt
        / min(
            dispatch_config.battery_charge_efficiency,
            dispatch_config.battery_discharge_efficiency,
        ),
    )
    hydrogen_state_tolerance_kwh = max(
        1e-6,
        inputs.horizon
        * state_power_tolerance_kw
        * dt
        / min(dispatch_config.electrolyzer_efficiency, dispatch_config.fuel_cell_efficiency),
    )
    battery_factor = (
        inputs.battery_initial_stored_carbon_kg_per_kwh
        if initial_battery_factor_kg_per_kwh is None
        else initial_battery_factor_kg_per_kwh
    )
    hydrogen_factor = (
        inputs.hydrogen_initial_stored_carbon_kg_per_kwh
        if initial_hydrogen_factor_kg_per_kwh is None
        else initial_hydrogen_factor_kg_per_kwh
    )
    opening_battery_energy = float(dispatch.battery_energy_kwh[0])
    opening_hydrogen_energy = float(dispatch.hydrogen_energy_kwh[0])
    opening_battery_green = _validated_initial_green_inventory(
        "initial_battery_green_inventory_kwh",
        initial_battery_green_inventory_kwh,
        initial_energy_kwh=opening_battery_energy,
        tolerance_kwh=1e-9,
    )
    opening_hydrogen_green = _validated_initial_green_inventory(
        "initial_hydrogen_green_inventory_kwh",
        initial_hydrogen_green_inventory_kwh,
        initial_energy_kwh=opening_hydrogen_energy,
        tolerance_kwh=1e-9,
    )
    battery = CarbonReservoir(
        capacity_kwh=dispatch_config.battery_capacity_kwh,
        energy_kwh=opening_battery_energy,
        charge_efficiency=dispatch_config.battery_charge_efficiency,
        discharge_efficiency=dispatch_config.battery_discharge_efficiency,
        carrier="battery",
        carbon_inventory_kg=opening_battery_energy * battery_factor,
        green_inventory_kwh=opening_battery_green,
        minimum_energy_kwh=(dispatch_config.battery_min_soc * dispatch_config.battery_capacity_kwh),
        tolerance_kwh=battery_state_tolerance_kwh,
    )
    hydrogen = CarbonReservoir(
        capacity_kwh=dispatch_config.hydrogen_capacity_kwh,
        energy_kwh=opening_hydrogen_energy,
        charge_efficiency=dispatch_config.electrolyzer_efficiency,
        discharge_efficiency=dispatch_config.fuel_cell_efficiency,
        carrier="hydrogen",
        carbon_inventory_kg=opening_hydrogen_energy * hydrogen_factor,
        green_inventory_kwh=opening_hydrogen_green,
        minimum_energy_kwh=(
            dispatch_config.hydrogen_min_soc * dispatch_config.hydrogen_capacity_kwh
        ),
        tolerance_kwh=hydrogen_state_tolerance_kwh,
    )

    feeder = validator.feeder
    placement = validator.placement
    total_base_load = float(np.sum(feeder.load_p_kw))
    trace_results: list[TraceResult] = []
    transfers: list[ReservoirTransfer] = []
    rows: list[dict[str, float | int | bool | str]] = []
    load_allocated_emissions = 0.0
    external_source_emissions = 0.0
    nonstorage_sink_emissions = 0.0
    direct_green = 0.0
    green_generation = 0.0
    mediated_green_to_load: defaultdict[str, float] = defaultdict(float)
    low_carbon_to_load: defaultdict[str, float] = defaultdict(float)
    user_load_energy = float(np.sum(inputs.load_kw) * dt)
    opening_storage_carbon = battery.carbon_inventory_kg + hydrogen.carbon_inventory_kg

    for step in range(inputs.horizon):
        tolerance = trace_tolerance_kw
        branches, losses = _expanded_loss_network(validation, step, tolerance_kw=tolerance)
        load_scale = inputs.load_kw[step] / total_base_load
        user_loads = {
            external: float(feeder.load_p_kw[external - 1] * load_scale)
            for external in range(1, feeder.n_bus + 1)
            if feeder.load_p_kw[external - 1] * load_scale > tolerance
        }
        loads: dict[object, float] = dict(user_loads)
        loads.update(losses)
        battery_power = float(dispatch.battery_power_kw[step])
        hydrogen_power = float(dispatch.hydrogen_power_kw[step])
        if battery_power < -tolerance:
            loads[placement.battery_bus] = loads.get(placement.battery_bus, 0.0) - battery_power
        if hydrogen_power < -tolerance:
            loads[placement.hydrogen_bus] = loads.get(placement.hydrogen_bus, 0.0) - hydrogen_power

        slack_kw = float(validation.bus_injections_kw[step, feeder.slack_bus])
        if slack_kw < -tolerance:
            loads[1] = loads.get(1, 0.0) - slack_kw
        renewable_fraction = float(dispatch.renewable_fraction[step])
        pv_kw = float(inputs.pv_available_kw[step] * renewable_fraction)
        wind_kw = float(inputs.wind_available_kw[step] * renewable_fraction)
        fixed_kw = float(inputs.fixed_generation_kw[step])
        battery_source_factor = (
            battery.carbon_intensity_kg_per_kwh / battery.discharge_efficiency
            if battery_power > tolerance
            else 0.0
        )
        hydrogen_source_factor = (
            hydrogen.carbon_intensity_kg_per_kwh / hydrogen.discharge_efficiency
            if hydrogen_power > tolerance
            else 0.0
        )
        sources = [
            SourceInjection(
                "grid",
                1,
                max(slack_kw, 0.0),
                float(inputs.grid_carbon_kg_per_kwh[step]),
            ),
            SourceInjection(
                "pv",
                placement.pv_bus,
                pv_kw,
                float(inputs.pv_carbon_kg_per_kwh[step]),
                True,
                "pv",
            ),
            SourceInjection(
                "wind",
                placement.wind_bus,
                wind_kw,
                float(inputs.wind_carbon_kg_per_kwh[step]),
                True,
                "wind",
            ),
            SourceInjection(
                "fixed_fuel_cell",
                placement.fixed_generation_bus,
                fixed_kw,
                float(inputs.fixed_generation_carbon_kg_per_kwh[step]),
                False,
                "fuel_cell",
            ),
            SourceInjection(
                "battery",
                placement.battery_bus,
                max(battery_power, 0.0),
                battery_source_factor,
                False,
                "battery",
            ),
            SourceInjection(
                "hydrogen",
                placement.hydrogen_bus,
                max(hydrogen_power, 0.0),
                hydrogen_source_factor,
                False,
                "hydrogen",
            ),
        ]
        trace = trace_carbon(
            branches,
            sources,
            loads,
            tolerance_kw=tolerance,
            strict_balance=True,
            enumerate_paths=True,
        )
        trace_results.append(trace)

        source_green_fraction = {
            "grid": 0.0,
            "pv": 1.0,
            "wind": 1.0,
            "fixed_fuel_cell": 0.0,
            "battery": battery.green_fraction,
            "hydrogen": hydrogen.green_fraction,
        }
        step_user_emissions = (
            sum(
                power_kw * trace.node_intensity_kg_per_kwh[node]
                for node, power_kw in user_loads.items()
            )
            * dt
        )
        step_direct_green = (
            sum(
                power_kw * trace.source_share[node].get(source_id, 0.0)
                for node, power_kw in user_loads.items()
                for source_id in ("pv", "wind")
            )
            * dt
        )
        load_allocated_emissions += step_user_emissions
        direct_green += step_direct_green
        green_generation += (pv_kw + wind_kw) * dt
        external_source_emissions += sum(
            source.power_kw * source.carbon_factor_kg_per_kwh * dt
            for source in sources
            if source.source_id not in {"battery", "hydrogen"}
        )
        step_nonstorage_sink = step_user_emissions + sum(
            power_kw * trace.node_intensity_kg_per_kwh[node] * dt
            for node, power_kw in losses.items()
        )
        if slack_kw < -tolerance:
            step_nonstorage_sink += -slack_kw * trace.node_intensity_kg_per_kwh[1] * dt
        nonstorage_sink_emissions += step_nonstorage_sink
        for carrier, factor in (
            ("battery", battery_source_factor),
            ("hydrogen", hydrogen_source_factor),
        ):
            delivered_to_user_kw = sum(
                power_kw * trace.source_share[node].get(carrier, 0.0)
                for node, power_kw in user_loads.items()
            )
            mediated_green_to_load[carrier] += (
                delivered_to_user_kw * source_green_fraction[carrier] * dt
            )
            if factor < float(inputs.grid_carbon_kg_per_kwh[step]):
                low_carbon_to_load[carrier] += delivered_to_user_kw * dt

        if battery_power < -tolerance:
            node = placement.battery_bus
            share = trace.source_share[node]
            green_fraction = sum(
                share.get(source_id, 0.0) * fraction
                for source_id, fraction in source_green_fraction.items()
            )
            transfers.append(
                battery.charge(
                    -battery_power * dt,
                    trace.node_intensity_kg_per_kwh[node],
                    green_fraction=float(np.clip(green_fraction, 0.0, 1.0)),
                )
            )
        elif battery_power > tolerance:
            transfers.append(battery.discharge(battery_power * dt))
        if hydrogen_power < -tolerance:
            node = placement.hydrogen_bus
            share = trace.source_share[node]
            green_fraction = sum(
                share.get(source_id, 0.0) * fraction
                for source_id, fraction in source_green_fraction.items()
            )
            transfers.append(
                hydrogen.charge(
                    -hydrogen_power * dt,
                    trace.node_intensity_kg_per_kwh[node],
                    green_fraction=float(np.clip(green_fraction, 0.0, 1.0)),
                )
            )
        elif hydrogen_power > tolerance:
            transfers.append(hydrogen.discharge(hydrogen_power * dt))

        path_residual = max((abs(value) for value in trace.path_residual_kw.values()), default=0.0)
        rows.append(
            {
                "step": step,
                "method": trace.flow_order.method,
                "is_dag": trace.flow_order.is_dag,
                "load_allocated_emissions_kg": step_user_emissions,
                "all_sink_emissions_kg": trace.total_load_emissions_kg_per_h * dt,
                "direct_green_consumed_kwh": step_direct_green,
                "maximum_balance_residual_kw": trace.balance.max_abs_residual_kw,
                "maximum_path_residual_kw": path_residual,
                "paths": len(trace.paths),
                "paths_truncated": trace.paths_truncated,
                "battery_carbon_kg_end": battery.carbon_inventory_kg,
                "hydrogen_carbon_kg_end": hydrogen.carbon_inventory_kg,
                "battery_green_inventory_kwh_end": battery.green_inventory_kwh,
                "hydrogen_green_inventory_kwh_end": hydrogen.green_inventory_kwh,
            }
        )

    if not np.isclose(
        battery.energy_kwh,
        dispatch.battery_energy_kwh[-1],
        rtol=0.0,
        atol=battery_state_tolerance_kwh,
    ):
        raise RuntimeError("battery carbon reservoir diverged from dispatch energy state")
    if not np.isclose(
        hydrogen.energy_kwh,
        dispatch.hydrogen_energy_kwh[-1],
        rtol=0.0,
        atol=hydrogen_state_tolerance_kwh,
    ):
        raise RuntimeError("hydrogen carbon reservoir diverged from dispatch energy state")

    closing_storage_carbon = battery.carbon_inventory_kg + hydrogen.carbon_inventory_kg
    closing_battery_green = battery.green_inventory_kwh
    closing_hydrogen_green = hydrogen.green_inventory_kwh
    battery_green_balance_residual = _green_inventory_balance_residual(
        carrier="battery",
        opening_green_inventory_kwh=opening_battery_green,
        closing_green_inventory_kwh=closing_battery_green,
        charge_efficiency=dispatch_config.battery_charge_efficiency,
        discharge_efficiency=dispatch_config.battery_discharge_efficiency,
        transfers=transfers,
    )
    hydrogen_green_balance_residual = _green_inventory_balance_residual(
        carrier="hydrogen",
        opening_green_inventory_kwh=opening_hydrogen_green,
        closing_green_inventory_kwh=closing_hydrogen_green,
        charge_efficiency=dispatch_config.electrolyzer_efficiency,
        discharge_efficiency=dispatch_config.fuel_cell_efficiency,
        transfers=transfers,
    )
    green_balance_tolerance = 1e-8
    if (
        abs(battery_green_balance_residual) > green_balance_tolerance
        or abs(hydrogen_green_balance_residual) > green_balance_tolerance
    ):
        raise RuntimeError("horizon green inventory does not balance")
    carbon_balance_residual = external_source_emissions - (
        nonstorage_sink_emissions + closing_storage_carbon - opening_storage_carbon
    )
    balance_tolerance = max(1e-5, inputs.horizon * carbon_config.tolerance_kw)
    if abs(carbon_balance_residual) > balance_tolerance:
        raise RuntimeError(
            f"horizon carbon inventory does not balance: residual={carbon_balance_residual:.6g} kg"
        )

    baseline_emissions = float(np.sum(inputs.load_kw * inputs.grid_carbon_kg_per_kwh) * dt)
    effective_grid_factor = baseline_emissions / user_load_energy if user_load_energy else 0.0
    metrics = compute_carbon_metrics(
        load_energy_kwh=user_load_energy,
        actual_emissions_kg=load_allocated_emissions,
        grid_factor_kg_per_kwh=effective_grid_factor,
        green_generation_kwh=green_generation,
        direct_green_consumed_kwh=direct_green,
        reservoir_transfers=transfers,
        opening_green_inventory_kwh=(
            opening_battery_green + opening_hydrogen_green
        ),
        mediated_green_to_load_by_carrier_kwh=mediated_green_to_load,
        low_carbon_to_load_by_carrier_kwh=low_carbon_to_load,
    )
    return CarbonAccountingResult(
        snapshots=pd.DataFrame.from_records(rows),
        metrics=metrics,
        traces=tuple(trace_results),
        reservoir_transfers=tuple(transfers),
        load_allocated_emissions_kg=load_allocated_emissions,
        external_source_emissions_kg=external_source_emissions,
        nonstorage_sink_emissions_kg=nonstorage_sink_emissions,
        opening_storage_carbon_kg=opening_storage_carbon,
        closing_storage_carbon_kg=closing_storage_carbon,
        carbon_balance_residual_kg=carbon_balance_residual,
        direct_green_consumed_kwh=direct_green,
        opening_battery_green_inventory_kwh=opening_battery_green,
        closing_battery_green_inventory_kwh=closing_battery_green,
        opening_hydrogen_green_inventory_kwh=opening_hydrogen_green,
        closing_hydrogen_green_inventory_kwh=closing_hydrogen_green,
        battery_green_inventory_balance_residual_kwh=(
            battery_green_balance_residual
        ),
        hydrogen_green_inventory_balance_residual_kwh=(
            hydrogen_green_balance_residual
        ),
    )
