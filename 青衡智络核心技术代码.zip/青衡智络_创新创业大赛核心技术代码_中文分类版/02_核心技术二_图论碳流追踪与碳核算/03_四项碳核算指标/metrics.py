"""Horizon-level carbon and renewable-use metrics."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from math import isfinite
from typing import Iterable, Mapping

from .reservoir import ReservoirTransfer


@dataclass(frozen=True)
class CarbonMetrics:
    green_self_use_rate: float
    unit_supply_carbon_intensity_kg_per_kwh: float
    low_carbon_storage_contribution_kwh: float
    low_carbon_storage_share: float
    avoided_emissions_kg: float
    avoided_emissions_rate: float
    direct_green_consumed_kwh: float
    mediated_green_consumed_kwh: float
    mediated_green_by_carrier_kwh: Mapping[str, float]
    low_carbon_by_carrier_kwh: Mapping[str, float]


def compute_carbon_metrics(
    *,
    load_energy_kwh: float,
    actual_emissions_kg: float,
    grid_factor_kg_per_kwh: float,
    green_generation_kwh: float,
    direct_green_consumed_kwh: float,
    reservoir_transfers: Iterable[ReservoirTransfer] = (),
    opening_green_inventory_kwh: float = 0.0,
    mediated_green_to_load_by_carrier_kwh: Mapping[str, float] | None = None,
    low_carbon_to_load_by_carrier_kwh: Mapping[str, float] | None = None,
) -> CarbonMetrics:
    """Compute the four project carbon indicators over one accounting horizon.

    Green self-use includes green output delivered later by a battery or hydrogen
    reservoir.  ``opening_green_inventory_kwh`` keeps the ratio well defined when
    the horizon starts with previously stored renewable energy.  A reservoir
    discharge is counted as low-carbon when its delivered intensity is below the
    grid-only reference factor.
    """

    values = {
        "load_energy_kwh": load_energy_kwh,
        "actual_emissions_kg": actual_emissions_kg,
        "grid_factor_kg_per_kwh": grid_factor_kg_per_kwh,
        "green_generation_kwh": green_generation_kwh,
        "direct_green_consumed_kwh": direct_green_consumed_kwh,
        "opening_green_inventory_kwh": opening_green_inventory_kwh,
    }
    for name, value in values.items():
        if not isfinite(value) or value < 0:
            raise ValueError(f"{name} must be finite and non-negative")

    mediated: defaultdict[str, float] = defaultdict(float)
    low_carbon: defaultdict[str, float] = defaultdict(float)
    if mediated_green_to_load_by_carrier_kwh is None or low_carbon_to_load_by_carrier_kwh is None:
        for transfer in reservoir_transfers:
            if transfer.direction != "discharge":
                continue
            if mediated_green_to_load_by_carrier_kwh is None:
                mediated[transfer.carrier] += transfer.green_energy_kwh
            if (
                low_carbon_to_load_by_carrier_kwh is None
                and transfer.carbon_intensity_kg_per_kwh < grid_factor_kg_per_kwh
            ):
                low_carbon[transfer.carrier] += transfer.bus_energy_kwh
    if mediated_green_to_load_by_carrier_kwh is not None:
        mediated.update(_validated_carrier_mapping(mediated_green_to_load_by_carrier_kwh))
    if low_carbon_to_load_by_carrier_kwh is not None:
        low_carbon.update(_validated_carrier_mapping(low_carbon_to_load_by_carrier_kwh))

    mediated_total = float(sum(mediated.values()))
    low_carbon_total = float(sum(low_carbon.values()))
    green_available = green_generation_kwh + opening_green_inventory_kwh
    green_used = direct_green_consumed_kwh + mediated_total
    baseline_emissions = load_energy_kwh * grid_factor_kg_per_kwh
    avoided = baseline_emissions - actual_emissions_kg

    return CarbonMetrics(
        green_self_use_rate=_ratio(green_used, green_available),
        unit_supply_carbon_intensity_kg_per_kwh=_ratio(actual_emissions_kg, load_energy_kwh),
        low_carbon_storage_contribution_kwh=low_carbon_total,
        low_carbon_storage_share=_ratio(low_carbon_total, load_energy_kwh),
        avoided_emissions_kg=avoided,
        avoided_emissions_rate=_ratio(avoided, baseline_emissions),
        direct_green_consumed_kwh=direct_green_consumed_kwh,
        mediated_green_consumed_kwh=mediated_total,
        mediated_green_by_carrier_kwh=dict(mediated),
        low_carbon_by_carrier_kwh=dict(low_carbon),
    )


def _ratio(numerator: float, denominator: float) -> float:
    return numerator / denominator if denominator > 0 else 0.0


def _validated_carrier_mapping(values: Mapping[str, float]) -> dict[str, float]:
    checked: dict[str, float] = {}
    for carrier, value in values.items():
        numeric = float(value)
        if not carrier or not isfinite(numeric) or numeric < 0:
            raise ValueError(
                "carrier contributions must use non-empty names and non-negative values"
            )
        checked[str(carrier)] = numeric
    return checked
