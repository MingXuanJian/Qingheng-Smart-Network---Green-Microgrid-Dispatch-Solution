"""Nodal carbon-flow tracing and carbon inventory accounting.

The public API is deliberately small: :func:`trace_carbon` handles one power-flow
snapshot, :class:`CarbonReservoir` carries carbon through time, and
:func:`compute_carbon_metrics` aggregates an accounting horizon.
"""

from .metrics import CarbonMetrics, compute_carbon_metrics
from .reservoir import (
    CarbonReservoir,
    ReservoirConstraintError,
    ReservoirTransfer,
)
from .tracer import (
    BranchFlow,
    FlowOrder,
    NodeBalance,
    PathContribution,
    PowerBalanceDiagnostics,
    PowerBalanceError,
    SourceInjection,
    TraceResult,
    trace_carbon,
)

__all__ = [
    "BranchFlow",
    "CarbonMetrics",
    "CarbonReservoir",
    "FlowOrder",
    "NodeBalance",
    "PathContribution",
    "PowerBalanceDiagnostics",
    "PowerBalanceError",
    "ReservoirConstraintError",
    "ReservoirTransfer",
    "SourceInjection",
    "TraceResult",
    "compute_carbon_metrics",
    "trace_carbon",
]
