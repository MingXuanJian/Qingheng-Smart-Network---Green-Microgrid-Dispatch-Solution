"""Snapshot carbon-flow tracing based on proportional sharing.

For node ``i`` the nodal carbon intensity ``c_i`` is obtained from

``T_i c_i - sum_j(P_ji c_j) = sum_s(P_is e_s)``,

where ``T_i`` is load plus outgoing power, ``P_ji`` is power entering from
node ``j``, and a local source ``s`` injects power ``P_is`` with factor
``e_s``.  The same system with one source-power right-hand side at a time
gives source shares.  Acyclic flow graphs are evaluated in Kahn/BFS order;
meshed flow graphs are solved as a linear system.
"""

from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from math import isfinite
from typing import Hashable, Iterable, Mapping, TypeAlias

import numpy as np

Node: TypeAlias = Hashable


@dataclass(frozen=True)
class BranchFlow:
    """Active power on a branch.

    Positive ``power_kw`` means ``from_node -> to_node``.  A negative value is
    normalized to the reverse direction, so callers may pass signed power-flow
    results without first changing branch endpoints.
    """

    from_node: Node
    to_node: Node
    power_kw: float


@dataclass(frozen=True)
class SourceInjection:
    """A distinguishable source connected at one node."""

    source_id: str
    node: Node
    power_kw: float
    carbon_factor_kg_per_kwh: float
    is_green: bool = False
    carrier: str = "electricity"


@dataclass(frozen=True)
class NodeBalance:
    node: Node
    source_kw: float
    incoming_kw: float
    load_kw: float
    outgoing_kw: float
    residual_kw: float
    within_tolerance: bool


@dataclass(frozen=True)
class PowerBalanceDiagnostics:
    by_node: Mapping[Node, NodeBalance]
    tolerance_kw: float
    max_abs_residual_kw: float
    total_abs_residual_kw: float
    balanced: bool


class PowerBalanceError(ValueError):
    """Raised when a snapshot violates nodal active-power balance."""

    def __init__(self, diagnostics: PowerBalanceDiagnostics):
        self.diagnostics = diagnostics
        offenders = [
            f"{item.node!r}: {item.residual_kw:+.6g} kW"
            for item in diagnostics.by_node.values()
            if not item.within_tolerance
        ]
        preview = ", ".join(offenders[:5])
        if len(offenders) > 5:
            preview += f", ... ({len(offenders)} nodes)"
        super().__init__(
            f"Nodal active-power imbalance exceeds {diagnostics.tolerance_kw:g} kW ({preview})"
        )


@dataclass(frozen=True)
class FlowOrder:
    """Direction order of the normalized active-power graph.

    ``order`` is Kahn's breadth-first topological order when ``is_dag`` is
    true.  For a mesh, it contains the acyclic prefix and ``cyclic_nodes``
    identifies the part requiring a linear solve.
    """

    is_dag: bool
    order: tuple[Node, ...]
    cyclic_nodes: tuple[Node, ...]
    method: str


@dataclass(frozen=True)
class PathContribution:
    source_id: str
    load_node: Node
    nodes: tuple[Node, ...]
    power_kw: float
    carbon_flow_kg_per_h: float


@dataclass(frozen=True)
class TraceResult:
    """Complete carbon accounting for one power-flow snapshot."""

    node_intensity_kg_per_kwh: Mapping[Node, float]
    source_share: Mapping[Node, Mapping[str, float]]
    load_source_power_kw: Mapping[Node, Mapping[str, float]]
    load_emissions_kg_per_h: Mapping[Node, float]
    total_load_emissions_kg_per_h: float
    normalized_branches: tuple[BranchFlow, ...]
    flow_order: FlowOrder
    balance: PowerBalanceDiagnostics
    paths: tuple[PathContribution, ...]
    path_residual_kw: Mapping[tuple[str, Node], float]
    paths_truncated: bool
    linear_condition_number: float | None
    linear_residual_norm: float


def trace_carbon(
    branches: Iterable[BranchFlow],
    sources: Iterable[SourceInjection],
    loads_kw: Mapping[Node, float],
    *,
    tolerance_kw: float = 1e-6,
    strict_balance: bool = True,
    enumerate_paths: bool = True,
    max_paths: int = 100_000,
) -> TraceResult:
    """Trace power and carbon from named sources to loads.

    Parameters use kW and kg/kWh, so carbon-flow outputs are kg/h.  The
    snapshot must include the slack/grid injection as a source.  Set
    ``strict_balance=False`` to inspect an imperfect measurement snapshot;
    the returned balance diagnostics still report every residual.
    """

    if not isfinite(tolerance_kw) or tolerance_kw < 0:
        raise ValueError("tolerance_kw must be finite and non-negative")
    if max_paths < 1:
        raise ValueError("max_paths must be at least 1")

    branch_list = _normalize_branches(branches, tolerance_kw)
    source_list = _validate_sources(sources)
    load_map = _validate_loads(loads_kw)
    nodes = _collect_nodes(branch_list, source_list, load_map)
    if not nodes:
        return _empty_result(tolerance_kw)

    source_ids = [source.source_id for source in source_list]
    node_index = {node: idx for idx, node in enumerate(nodes)}
    incoming: dict[Node, list[tuple[Node, float]]] = defaultdict(list)
    outgoing: dict[Node, list[tuple[Node, float]]] = defaultdict(list)
    for branch in branch_list:
        outgoing[branch.from_node].append((branch.to_node, branch.power_kw))
        incoming[branch.to_node].append((branch.from_node, branch.power_kw))

    source_power = {node: 0.0 for node in nodes}
    for source in source_list:
        source_power[source.node] += source.power_kw

    balance = _power_balance(
        nodes,
        source_power,
        incoming,
        outgoing,
        load_map,
        tolerance_kw,
    )
    if strict_balance and not balance.balanced:
        raise PowerBalanceError(balance)

    order = _flow_order(nodes, branch_list, node_index)
    throughput = {
        node: load_map.get(node, 0.0) + sum(power for _, power in outgoing[node]) for node in nodes
    }
    carbon_rhs = np.zeros(len(nodes), dtype=float)
    source_rhs = np.zeros((len(nodes), len(source_list)), dtype=float)
    for source_idx, source in enumerate(source_list):
        idx = node_index[source.node]
        carbon_rhs[idx] += source.power_kw * source.carbon_factor_kg_per_kwh
        source_rhs[idx, source_idx] += source.power_kw

    matrix = _sharing_matrix(nodes, node_index, incoming, throughput, tolerance_kw)
    rhs = np.column_stack((carbon_rhs, source_rhs))
    if order.is_dag:
        solution = _solve_dag(
            nodes,
            node_index,
            incoming,
            throughput,
            rhs,
            order.order,
            tolerance_kw,
        )
        condition_number = None
    else:
        solution, condition_number = _solve_mesh(matrix, rhs)

    solution[np.abs(solution) < 1e-13] = 0.0
    linear_residual = float(np.linalg.norm(matrix @ solution - rhs, ord=np.inf))
    intensities = {node: float(solution[node_index[node], 0]) for node in nodes}
    shares: dict[Node, dict[str, float]] = {}
    load_attribution: dict[Node, dict[str, float]] = {}
    load_emissions: dict[Node, float] = {}
    for node in nodes:
        row = node_index[node]
        shares[node] = {
            source_id: float(solution[row, idx + 1]) for idx, source_id in enumerate(source_ids)
        }
        if node in load_map and load_map[node] > tolerance_kw:
            load_attribution[node] = {
                source_id: load_map[node] * shares[node][source_id] for source_id in source_ids
            }
            load_emissions[node] = load_map[node] * intensities[node]

    if enumerate_paths:
        paths, truncated = _enumerate_paths(
            nodes,
            outgoing,
            throughput,
            load_map,
            source_list,
            tolerance_kw,
            max_paths,
        )
    else:
        paths, truncated = (), False
    path_totals: dict[tuple[str, Node], float] = defaultdict(float)
    for path in paths:
        path_totals[(path.source_id, path.load_node)] += path.power_kw
    path_residual = {
        (source_id, node): load_attribution[node][source_id] - path_totals[(source_id, node)]
        for node in load_attribution
        for source_id in source_ids
    }

    return TraceResult(
        node_intensity_kg_per_kwh=intensities,
        source_share=shares,
        load_source_power_kw=load_attribution,
        load_emissions_kg_per_h=load_emissions,
        total_load_emissions_kg_per_h=float(sum(load_emissions.values())),
        normalized_branches=branch_list,
        flow_order=order,
        balance=balance,
        paths=paths,
        path_residual_kw=path_residual,
        paths_truncated=truncated,
        linear_condition_number=condition_number,
        linear_residual_norm=linear_residual,
    )


def _normalize_branches(
    branches: Iterable[BranchFlow], tolerance_kw: float
) -> tuple[BranchFlow, ...]:
    normalized: list[BranchFlow] = []
    for branch in branches:
        power = float(branch.power_kw)
        if not isfinite(power):
            raise ValueError("branch power must be finite")
        if abs(power) <= tolerance_kw:
            continue
        if power < 0:
            normalized.append(BranchFlow(branch.to_node, branch.from_node, -power))
        else:
            normalized.append(BranchFlow(branch.from_node, branch.to_node, power))
    return tuple(normalized)


def _validate_sources(sources: Iterable[SourceInjection]) -> tuple[SourceInjection, ...]:
    result = tuple(sources)
    ids: set[str] = set()
    for source in result:
        if not source.source_id or source.source_id in ids:
            raise ValueError("source_id values must be non-empty and unique")
        ids.add(source.source_id)
        if not isfinite(source.power_kw) or source.power_kw < 0:
            raise ValueError(f"source {source.source_id!r} power must be finite and non-negative")
        if not isfinite(source.carbon_factor_kg_per_kwh) or source.carbon_factor_kg_per_kwh < 0:
            raise ValueError(
                f"source {source.source_id!r} carbon factor must be finite and non-negative"
            )
    return result


def _validate_loads(loads_kw: Mapping[Node, float]) -> dict[Node, float]:
    result: dict[Node, float] = {}
    for node, value in loads_kw.items():
        load = float(value)
        if not isfinite(load) or load < 0:
            raise ValueError(f"load at node {node!r} must be finite and non-negative")
        result[node] = load
    return result


def _collect_nodes(
    branches: tuple[BranchFlow, ...],
    sources: tuple[SourceInjection, ...],
    loads: Mapping[Node, float],
) -> tuple[Node, ...]:
    ordered: dict[Node, None] = {}
    for branch in branches:
        ordered.setdefault(branch.from_node, None)
        ordered.setdefault(branch.to_node, None)
    for node in loads:
        ordered.setdefault(node, None)
    for source in sources:
        ordered.setdefault(source.node, None)
    return tuple(ordered)


def _power_balance(
    nodes: tuple[Node, ...],
    source_power: Mapping[Node, float],
    incoming: Mapping[Node, list[tuple[Node, float]]],
    outgoing: Mapping[Node, list[tuple[Node, float]]],
    loads: Mapping[Node, float],
    tolerance_kw: float,
) -> PowerBalanceDiagnostics:
    by_node: dict[Node, NodeBalance] = {}
    for node in nodes:
        inflow = sum(power for _, power in incoming[node])
        outflow = sum(power for _, power in outgoing[node])
        residual = source_power[node] + inflow - loads.get(node, 0.0) - outflow
        by_node[node] = NodeBalance(
            node=node,
            source_kw=source_power[node],
            incoming_kw=inflow,
            load_kw=loads.get(node, 0.0),
            outgoing_kw=outflow,
            residual_kw=residual,
            within_tolerance=abs(residual) <= tolerance_kw,
        )
    max_residual = max((abs(item.residual_kw) for item in by_node.values()), default=0.0)
    total_residual = sum(abs(item.residual_kw) for item in by_node.values())
    return PowerBalanceDiagnostics(
        by_node=by_node,
        tolerance_kw=tolerance_kw,
        max_abs_residual_kw=max_residual,
        total_abs_residual_kw=total_residual,
        balanced=max_residual <= tolerance_kw,
    )


def _flow_order(
    nodes: tuple[Node, ...],
    branches: tuple[BranchFlow, ...],
    node_index: Mapping[Node, int],
) -> FlowOrder:
    adjacency: dict[Node, list[Node]] = defaultdict(list)
    indegree = {node: 0 for node in nodes}
    seen_edges: set[tuple[Node, Node]] = set()
    for branch in branches:
        edge = (branch.from_node, branch.to_node)
        if edge in seen_edges:
            continue
        seen_edges.add(edge)
        adjacency[branch.from_node].append(branch.to_node)
        indegree[branch.to_node] += 1
    for children in adjacency.values():
        children.sort(key=node_index.__getitem__)
    queue = deque(node for node in nodes if indegree[node] == 0)
    order: list[Node] = []
    while queue:
        node = queue.popleft()
        order.append(node)
        for child in adjacency[node]:
            indegree[child] -= 1
            if indegree[child] == 0:
                queue.append(child)
    cyclic = tuple(node for node in nodes if indegree[node] > 0)
    is_dag = not cyclic
    return FlowOrder(
        is_dag=is_dag,
        order=tuple(order),
        cyclic_nodes=cyclic,
        method="dag-bfs-proportional-sharing" if is_dag else "mesh-linear-system",
    )


def _sharing_matrix(
    nodes: tuple[Node, ...],
    node_index: Mapping[Node, int],
    incoming: Mapping[Node, list[tuple[Node, float]]],
    throughput: Mapping[Node, float],
    tolerance_kw: float,
) -> np.ndarray:
    matrix = np.zeros((len(nodes), len(nodes)), dtype=float)
    for node in nodes:
        row = node_index[node]
        if throughput[node] <= tolerance_kw and not incoming[node]:
            matrix[row, row] = 1.0
            continue
        matrix[row, row] = throughput[node]
        for parent, power in incoming[node]:
            matrix[row, node_index[parent]] -= power
    return matrix


def _solve_dag(
    nodes: tuple[Node, ...],
    node_index: Mapping[Node, int],
    incoming: Mapping[Node, list[tuple[Node, float]]],
    throughput: Mapping[Node, float],
    rhs: np.ndarray,
    order: tuple[Node, ...],
    tolerance_kw: float,
) -> np.ndarray:
    result = np.zeros_like(rhs)
    for node in order:
        row = node_index[node]
        numerator = rhs[row].copy()
        for parent, power in incoming[node]:
            numerator += power * result[node_index[parent]]
        if throughput[node] > tolerance_kw:
            result[row] = numerator / throughput[node]
        elif np.linalg.norm(numerator, ord=np.inf) > tolerance_kw:
            # This is reachable only when strict balance is disabled.
            result[row] = 0.0
    return result


def _solve_mesh(matrix: np.ndarray, rhs: np.ndarray) -> tuple[np.ndarray, float]:
    condition = float(np.linalg.cond(matrix))
    rank = int(np.linalg.matrix_rank(matrix))
    if rank == matrix.shape[0] and isfinite(condition) and condition < 1.0 / np.finfo(float).eps:
        return np.linalg.solve(matrix, rhs), condition
    solution, *_ = np.linalg.lstsq(matrix, rhs, rcond=None)
    return solution, condition


def _enumerate_paths(
    nodes: tuple[Node, ...],
    outgoing: Mapping[Node, list[tuple[Node, float]]],
    throughput: Mapping[Node, float],
    loads: Mapping[Node, float],
    sources: tuple[SourceInjection, ...],
    tolerance_kw: float,
    max_paths: int,
) -> tuple[tuple[PathContribution, ...], bool]:
    del nodes  # Node order is already reflected in source and adjacency order.
    results: list[PathContribution] = []
    truncated = False

    def walk(
        source: SourceInjection,
        node: Node,
        power: float,
        path: tuple[Node, ...],
        visited: frozenset[Node],
    ) -> None:
        nonlocal truncated
        if truncated or power <= tolerance_kw:
            return
        total = throughput[node]
        if total <= tolerance_kw:
            return
        load = loads.get(node, 0.0)
        if load > tolerance_kw:
            delivered = power * load / total
            if delivered > tolerance_kw:
                if len(results) >= max_paths:
                    truncated = True
                    return
                results.append(
                    PathContribution(
                        source_id=source.source_id,
                        load_node=node,
                        nodes=path,
                        power_kw=delivered,
                        carbon_flow_kg_per_h=(delivered * source.carbon_factor_kg_per_kwh),
                    )
                )
        for child, branch_power in outgoing[node]:
            if child in visited:
                continue
            walk(
                source,
                child,
                power * branch_power / total,
                path + (child,),
                visited | {child},
            )

    for source in sources:
        if source.power_kw > tolerance_kw:
            walk(
                source,
                source.node,
                source.power_kw,
                (source.node,),
                frozenset({source.node}),
            )
        if truncated:
            break
    return tuple(results), truncated


def _empty_result(tolerance_kw: float) -> TraceResult:
    balance = PowerBalanceDiagnostics({}, tolerance_kw, 0.0, 0.0, True)
    return TraceResult(
        node_intensity_kg_per_kwh={},
        source_share={},
        load_source_power_kw={},
        load_emissions_kg_per_h={},
        total_load_emissions_kg_per_h=0.0,
        normalized_branches=(),
        flow_order=FlowOrder(True, (), (), "dag-bfs-proportional-sharing"),
        balance=balance,
        paths=(),
        path_residual_kw={},
        paths_truncated=False,
        linear_condition_number=None,
        linear_residual_norm=0.0,
    )
