"""Carbon and renewable-label inventory for batteries and hydrogen stores."""

from __future__ import annotations

from dataclasses import dataclass
from math import isfinite


class ReservoirConstraintError(ValueError):
    """Raised when a reservoir transfer violates an energy constraint."""


@dataclass(frozen=True)
class ReservoirTransfer:
    """One transfer measured at the electrical bus boundary."""

    carrier: str
    direction: str
    bus_energy_kwh: float
    reservoir_energy_delta_kwh: float
    carbon_kg: float
    green_energy_kwh: float
    carbon_intensity_kg_per_kwh: float


@dataclass
class CarbonReservoir:
    """A well-mixed energy store with carbon and green-energy inventories.

    ``charge_efficiency`` maps bus input to stored energy.  ``discharge_efficiency``
    maps withdrawn stored energy to bus output.  Carbon supplied while charging
    remains attached to the surviving stored energy, so the delivered intensity
    naturally reflects both conversion losses.
    """

    capacity_kwh: float
    energy_kwh: float
    charge_efficiency: float
    discharge_efficiency: float
    carrier: str = "battery"
    carbon_inventory_kg: float = 0.0
    green_inventory_kwh: float = 0.0
    minimum_energy_kwh: float = 0.0
    tolerance_kwh: float = 1e-9
    activity_tolerance_kwh: float = 1e-12

    def __post_init__(self) -> None:
        numeric = (
            self.capacity_kwh,
            self.energy_kwh,
            self.charge_efficiency,
            self.discharge_efficiency,
            self.carbon_inventory_kg,
            self.green_inventory_kwh,
            self.minimum_energy_kwh,
            self.tolerance_kwh,
            self.activity_tolerance_kwh,
        )
        if not all(isfinite(value) for value in numeric):
            raise ValueError("reservoir parameters must be finite")
        if self.capacity_kwh < 0:
            raise ValueError("capacity_kwh must be non-negative")
        if self.capacity_kwh == 0 and any(
            value != 0.0
            for value in (
                self.energy_kwh,
                self.carbon_inventory_kg,
                self.green_inventory_kwh,
                self.minimum_energy_kwh,
            )
        ):
            raise ValueError("a zero-capacity reservoir must have zero inventories")
        if not 0 < self.charge_efficiency <= 1:
            raise ValueError("charge_efficiency must be in (0, 1]")
        if not 0 < self.discharge_efficiency <= 1:
            raise ValueError("discharge_efficiency must be in (0, 1]")
        if self.minimum_energy_kwh < 0 or self.minimum_energy_kwh > self.capacity_kwh:
            raise ValueError("minimum_energy_kwh must be within reservoir capacity")
        if (
            self.energy_kwh < self.minimum_energy_kwh - self.tolerance_kwh
            or self.energy_kwh > self.capacity_kwh + self.tolerance_kwh
        ):
            raise ValueError("initial energy is outside reservoir bounds")
        if self.carbon_inventory_kg < 0:
            raise ValueError("carbon inventory cannot be negative")
        if (
            self.green_inventory_kwh < 0
            or self.green_inventory_kwh > self.energy_kwh + self.tolerance_kwh
        ):
            raise ValueError("green inventory must be between zero and stored energy")
        if self.tolerance_kwh < 0:
            raise ValueError("tolerance_kwh cannot be negative")
        if self.activity_tolerance_kwh < 0:
            raise ValueError("activity_tolerance_kwh cannot be negative")

    @property
    def carbon_intensity_kg_per_kwh(self) -> float:
        """Current carbon density per kWh of stored energy."""

        if self.energy_kwh <= self.activity_tolerance_kwh:
            return 0.0
        return self.carbon_inventory_kg / self.energy_kwh

    @property
    def green_fraction(self) -> float:
        if self.energy_kwh <= self.activity_tolerance_kwh:
            return 0.0
        return self.green_inventory_kwh / self.energy_kwh

    def charge(
        self,
        input_energy_kwh: float,
        carbon_intensity_kg_per_kwh: float,
        *,
        green_fraction: float = 0.0,
    ) -> ReservoirTransfer:
        """Charge from bus energy and update both inventories."""

        _require_nonnegative("input_energy_kwh", input_energy_kwh)
        _require_nonnegative("carbon_intensity_kg_per_kwh", carbon_intensity_kg_per_kwh)
        if not isfinite(green_fraction) or not 0 <= green_fraction <= 1:
            raise ValueError("green_fraction must be in [0, 1]")
        stored = input_energy_kwh * self.charge_efficiency
        if self.energy_kwh + stored > self.capacity_kwh + self.tolerance_kwh:
            available_input = max(0.0, self.capacity_kwh - self.energy_kwh) / self.charge_efficiency
            raise ReservoirConstraintError(
                f"charge exceeds capacity; at most {available_input:.6g} kWh bus input is feasible"
            )
        carbon = input_energy_kwh * carbon_intensity_kg_per_kwh
        green_stored = stored * green_fraction
        self.energy_kwh = min(self.capacity_kwh, self.energy_kwh + stored)
        self.carbon_inventory_kg += carbon
        self.green_inventory_kwh += green_stored
        stored_intensity = carbon / stored if stored > self.activity_tolerance_kwh else 0.0
        return ReservoirTransfer(
            carrier=self.carrier,
            direction="charge",
            bus_energy_kwh=input_energy_kwh,
            reservoir_energy_delta_kwh=stored,
            carbon_kg=carbon,
            green_energy_kwh=input_energy_kwh * green_fraction,
            carbon_intensity_kg_per_kwh=stored_intensity,
        )

    def discharge(self, output_energy_kwh: float) -> ReservoirTransfer:
        """Deliver bus energy while removing efficiency-adjusted inventory."""

        _require_nonnegative("output_energy_kwh", output_energy_kwh)
        withdrawn = output_energy_kwh / self.discharge_efficiency
        available = max(0.0, self.energy_kwh - self.minimum_energy_kwh)
        if withdrawn > available + self.tolerance_kwh:
            feasible_output = available * self.discharge_efficiency
            raise ReservoirConstraintError(
                f"discharge exceeds available energy; at most {feasible_output:.6g} kWh output is feasible"
            )
        if (
            self.energy_kwh <= self.activity_tolerance_kwh
            or withdrawn <= self.activity_tolerance_kwh
        ):
            return ReservoirTransfer(
                self.carrier, "discharge", output_energy_kwh, 0.0, 0.0, 0.0, 0.0
            )

        carbon_density = self.carbon_intensity_kg_per_kwh
        green_fraction = self.green_fraction
        carbon = withdrawn * carbon_density
        green_withdrawn = withdrawn * green_fraction
        green_delivered = green_withdrawn * self.discharge_efficiency
        self.energy_kwh -= withdrawn
        self.carbon_inventory_kg -= carbon
        self.green_inventory_kwh -= green_withdrawn
        self._clean_roundoff()
        delivered_intensity = carbon / output_energy_kwh if output_energy_kwh > 0 else 0.0
        return ReservoirTransfer(
            carrier=self.carrier,
            direction="discharge",
            bus_energy_kwh=output_energy_kwh,
            reservoir_energy_delta_kwh=-withdrawn,
            carbon_kg=carbon,
            green_energy_kwh=green_delivered,
            carbon_intensity_kg_per_kwh=delivered_intensity,
        )

    def step(
        self,
        *,
        charge_input_kwh: float = 0.0,
        discharge_output_kwh: float = 0.0,
        charge_carbon_intensity_kg_per_kwh: float = 0.0,
        charge_green_fraction: float = 0.0,
    ) -> ReservoirTransfer:
        """Apply one mutually exclusive charge or discharge decision."""

        _require_nonnegative("charge_input_kwh", charge_input_kwh)
        _require_nonnegative("discharge_output_kwh", discharge_output_kwh)
        if (
            charge_input_kwh > self.activity_tolerance_kwh
            and discharge_output_kwh > self.activity_tolerance_kwh
        ):
            raise ReservoirConstraintError("simultaneous charge and discharge is not permitted")
        if charge_input_kwh > self.activity_tolerance_kwh:
            return self.charge(
                charge_input_kwh,
                charge_carbon_intensity_kg_per_kwh,
                green_fraction=charge_green_fraction,
            )
        if discharge_output_kwh > self.activity_tolerance_kwh:
            return self.discharge(discharge_output_kwh)
        return ReservoirTransfer(self.carrier, "idle", 0.0, 0.0, 0.0, 0.0, 0.0)

    def _clean_roundoff(self) -> None:
        if abs(self.energy_kwh - self.minimum_energy_kwh) <= self.tolerance_kwh:
            self.energy_kwh = self.minimum_energy_kwh
        if abs(self.carbon_inventory_kg) <= self.activity_tolerance_kwh:
            self.carbon_inventory_kg = 0.0
        if abs(self.green_inventory_kwh) <= self.activity_tolerance_kwh:
            self.green_inventory_kwh = 0.0


def _require_nonnegative(name: str, value: float) -> None:
    if not isfinite(value) or value < 0:
        raise ValueError(f"{name} must be finite and non-negative")
