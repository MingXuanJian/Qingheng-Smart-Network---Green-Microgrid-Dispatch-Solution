# Demo 数据

运行 `python scripts/generate_demo_data.py` 后，本目录会生成：

- `microgrid_profile_15min.csv`：一个完整本地自然日的 15 分钟合成负荷、光伏与风电序列；
- `demo_data_manifest.json`：文件大小、时间范围和 SHA-256。

这些数据仅用于代码自检，不对应企业现场、SoCal 正式缓存或商业计划书中的正式指标。
