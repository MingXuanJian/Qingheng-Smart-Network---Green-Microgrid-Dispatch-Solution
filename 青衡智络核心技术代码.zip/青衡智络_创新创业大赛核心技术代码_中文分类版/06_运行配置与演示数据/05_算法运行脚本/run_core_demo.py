"""Run a self-contained dispatch and carbon-flow smoke demo.

The script deliberately avoids external SoCal and MPTE assets. It verifies that
core data, optimization, reporting and carbon-tracing interfaces work together.
"""

from __future__ import annotations

from dataclasses import replace
import json
from pathlib import Path
import shutil

import matplotlib
matplotlib.use("Agg")
import pandas as pd

from qingheng.carbon import BranchFlow, SourceInjection, trace_carbon
from qingheng.config import CarbonConfig, DispatchConfig
from qingheng.dispatch import MultiEnergyDispatchProblem, run_optimizer_benchmark
from qingheng.reporting import export_dispatch, plot_benchmark, plot_dispatch
from qingheng.scenario import make_profile_dispatch_inputs


ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / "data" / "demo" / "microgrid_profile_15min.csv"
OUTPUT = ROOT / "artifacts" / "demo"


def main() -> int:
    if not PROFILE.is_file():
        raise FileNotFoundError(
            "Demo profile is missing. Run: python scripts/generate_demo_data.py"
        )
    if OUTPUT.exists():
        shutil.rmtree(OUTPUT)
    OUTPUT.mkdir(parents=True)

    frame = pd.read_csv(PROFILE, parse_dates=["timestamp"]).set_index("timestamp")
    dispatch = replace(
        DispatchConfig(),
        population=8,
        iterations=8,
        seeds=(2026,),
        battery_capacity_kwh=420.0,
        battery_power_kw=110.0,
        hydrogen_capacity_kwh=520.0,
        hydrogen_power_kw=90.0,
        grid_import_limit_kw=900.0,
        grid_export_limit_kw=500.0,
    )
    carbon = CarbonConfig()
    inputs = make_profile_dispatch_inputs(frame, dispatch, carbon)
    problem = MultiEnergyDispatchProblem(inputs, dispatch)

    benchmark_dir = OUTPUT / "optimization"
    results, evaluations = run_optimizer_benchmark(
        problem,
        seeds=dispatch.seeds,
        population_size=dispatch.population,
        iterations=dispatch.iterations,
        output_dir=benchmark_dir,
    )
    candidates = results.loc[
        (results["algorithm"] != "zero_dispatch") & results["feasible"].astype(bool)
    ].sort_values("score")
    if candidates.empty:
        raise RuntimeError("The smoke benchmark produced no feasible optimizer run")
    selected = candidates.iloc[0]
    key = (str(selected["algorithm"]), int(selected["seed"]))
    best = evaluations[key]

    export_dispatch(benchmark_dir, inputs, best)
    plot_dispatch(benchmark_dir / "best_dispatch.png", inputs, best)
    plot_benchmark(results, benchmark_dir / "optimizer_comparison.png")

    # A transparent one-snapshot carbon-flow example. The four injections add
    # exactly to the 100 kW load, so both power and carbon balances are auditable.
    trace = trace_carbon(
        branches=[
            BranchFlow("grid", "load_bus", 55.0),
            BranchFlow("pv", "load_bus", 25.0),
            BranchFlow("wind", "load_bus", 15.0),
            BranchFlow("fuel_cell", "load_bus", 5.0),
        ],
        sources=[
            SourceInjection("grid", "grid", 55.0, carbon.grid_kg_per_kwh),
            SourceInjection("pv", "pv", 25.0, carbon.pv_kg_per_kwh, is_green=True),
            SourceInjection("wind", "wind", 15.0, carbon.wind_kg_per_kwh, is_green=True),
            SourceInjection(
                "fuel_cell", "fuel_cell", 5.0, carbon.fuel_cell_kg_per_kwh
            ),
        ],
        loads_kw={"load_bus": 100.0},
    )
    carbon_summary = {
        "schema_version": "qingheng.core-demo.v1",
        "balanced": trace.balance.balanced,
        "flow_method": trace.flow_order.method,
        "load_intensity_kg_per_kwh": trace.node_intensity_kg_per_kwh["load_bus"],
        "load_emissions_kg_per_h": trace.total_load_emissions_kg_per_h,
        "source_power_at_load_kw": trace.load_source_power_kw["load_bus"],
        "path_count": len(trace.paths),
    }
    (OUTPUT / "carbon_flow_demo.json").write_text(
        json.dumps(carbon_summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    summary = {
        "schema_version": "qingheng.demo-summary.v1",
        "formal_result": False,
        "selected_algorithm": key[0],
        "selected_seed": key[1],
        "selected_score": float(best.score),
        "dispatch_feasible": bool(best.feasible),
        "carbon_balance_passed": bool(trace.balance.balanced),
        "outputs": {
            "benchmark": str(benchmark_dir.relative_to(ROOT)),
            "carbon": str((OUTPUT / "carbon_flow_demo.json").relative_to(ROOT)),
        },
    }
    (OUTPUT / "demo_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
