"""Generate a deterministic, synthetic 15-minute microgrid profile."""

from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "data" / "demo"
CSV_PATH = OUTPUT_DIR / "microgrid_profile_15min.csv"
MANIFEST_PATH = OUTPUT_DIR / "demo_data_manifest.json"


def file_sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    index = pd.date_range(
        "2025-01-15 00:00",
        periods=96,
        freq="15min",
        tz="America/Los_Angeles",
    )
    hour = index.hour.to_numpy(dtype=float) + index.minute.to_numpy(dtype=float) / 60.0
    rng = np.random.default_rng(20260714)

    morning = 95.0 * np.exp(-0.5 * ((hour - 8.0) / 1.8) ** 2)
    evening = 165.0 * np.exp(-0.5 * ((hour - 19.0) / 2.4) ** 2)
    load = 360.0 + morning + evening + rng.normal(0.0, 4.0, len(index))

    solar = np.sin(np.pi * np.clip((hour - 6.0) / 12.0, 0.0, 1.0))
    pv = 310.0 * np.maximum(solar, 0.0) ** 1.7
    wind = 70.0 + 25.0 * np.sin(2.0 * np.pi * (hour + 2.0) / 24.0)
    wind += rng.normal(0.0, 3.0, len(index))
    wind = np.clip(wind, 20.0, None)

    frame = pd.DataFrame(
        {
            "timestamp": index,
            "load_kw": np.round(load, 6),
            "pv_kw": np.round(pv, 6),
            "wind_kw": np.round(wind, 6),
        }
    )
    frame.to_csv(CSV_PATH, index=False)
    manifest = {
        "schema_version": "qingheng.demo-data.v1",
        "synthetic": True,
        "rows": len(frame),
        "timezone": "America/Los_Angeles",
        "start": str(index[0]),
        "end_inclusive": str(index[-1]),
        "columns": list(frame.columns),
        "file": CSV_PATH.name,
        "size_bytes": CSV_PATH.stat().st_size,
        "sha256": file_sha256(CSV_PATH),
        "formal_result_warning": (
            "Synthetic demo data only; do not use its outputs as formal project evidence."
        ),
    }
    MANIFEST_PATH.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"Demo profile: {CSV_PATH}")
    print(f"Manifest: {MANIFEST_PATH}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
