"""Verify the repository files recorded in SOURCE_MANIFEST.csv."""

from __future__ import annotations

from hashlib import sha256
from pathlib import Path
import csv


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "SOURCE_MANIFEST.csv"


def digest(path: Path) -> str:
    value = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def main() -> int:
    if not MANIFEST.is_file():
        raise FileNotFoundError(f"Missing manifest: {MANIFEST}")
    failures: list[str] = []
    checked = 0
    with MANIFEST.open("r", encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            path = ROOT / row["path"]
            checked += 1
            if not path.is_file():
                failures.append(f"missing: {row['path']}")
                continue
            if path.stat().st_size != int(row["size_bytes"]):
                failures.append(f"size mismatch: {row['path']}")
                continue
            if digest(path) != row["sha256"]:
                failures.append(f"sha256 mismatch: {row['path']}")
    if failures:
        print("Package verification failed:")
        for item in failures:
            print(f"- {item}")
        return 1
    print(f"Package verification passed: {checked} files")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
