"""Qingheng carbon-aware microgrid simulation package."""

__version__ = "0.1.0"
