# iCAN 代码索引

| 模块 | 主要文件 | 作用 |
|---|---|---|
| 工程入口 | `src/qingheng/cli.py` | 数据准备、预测、单日调度、测试日导出和滚动调度 CLI |
| 配置 | `src/qingheng/config.py` | 路径、预测、碳因子、设备及优化参数校验 |
| 数据治理 | `src/qingheng/data/completeness.py`、`manifest.py`、`socal.py` | 下载完整性审计、文件指纹、SoCal 通道读取与 15 分钟缓存 |
| 网络数据 | `src/qingheng/data/ieee33.py` | 外部 MPTE IEEE 33 节点数据的只读适配 |
| 混合场景 | `src/qingheng/data/hybrid.py`、`scenario.py`、`scenario_sizing.py` | 实测时间序列与研究资产假设组合、训练期容量标定 |
| 预测模型 | `src/qingheng/forecast/model.py` | CNN–LSTM–Attention 残差预测结构 |
| 预测训练 | `src/qingheng/forecast/data.py`、`training.py`、`metrics.py`、`forecast_workflow.py` | 严格时序切分、强周期基线、训练与认证结果导出 |
| 碳流追踪 | `src/qingheng/carbon/tracer.py` | BFS 拓扑传播、环网线性求解、DFS 路径贡献 |
| 碳库存 | `src/qingheng/carbon/reservoir.py` | 电池/氢储能碳库存与绿色库存传递 |
| 碳指标 | `src/qingheng/carbon/metrics.py` | 强度、自用、储能贡献及守恒指标 |
| 调度问题 | `src/qingheng/dispatch/problem.py` | 电池、氢系统、PCC、终端状态和多目标函数 |
| 优化算法 | `src/qingheng/dispatch/optimizers.py` | 标准 WOA、改进 WOA、PSO、Logistic–Tent 与非线性惯性 |
| 统一预算实验 | `src/qingheng/dispatch/benchmark.py` | 多种子对比、收敛长表、协议与 artifact manifest |
| 网络校核 | `src/qingheng/network/ieee33.py` | IEEE 33 节点逐时潮流、节点电压与 PCC 约束校核 |
| 协同流水线 | `src/qingheng/pipeline.py` | 调度、网络和碳核算连接 |
| 滚动调度 | `src/qingheng/rolling_dispatch.py`、`rolling_optimization.py` | 48 h 预见、24 h 执行、因果校正和跨日状态传递 |
| 消融汇总 | `src/qingheng/ablation_summary.py` | 不同储能配置的预测/回放结果汇总与清单冻结 |
| 图表与结果 | `src/qingheng/reporting.py` | 调度表、指标、算法对比和图表输出 |
| 测试 | `tests/` | 数据、预测、碳流、调度、网络、滚动与清单校验 |
