from __future__ import annotations

import os
from dataclasses import dataclass, field
from math import isfinite
from numbers import Integral, Real
from pathlib import Path
from typing import Any, Mapping

import yaml


def _expand_path(value: str | Path, base_dir: Path) -> Path:
    expanded = os.path.expandvars(os.path.expanduser(str(value)))
    path = Path(expanded)
    return path if path.is_absolute() else (base_dir / path).resolve()


@dataclass(frozen=True)
class PathConfig:
    mpte_root: Path
    socal_root: Path
    evidence_root: Path
    cache_root: Path
    results_root: Path


@dataclass(frozen=True)
class ForecastConfig:
    resample_minutes: int = 15
    dispatch_minutes: int = 60
    input_steps: int = 96
    horizon_steps: int = 96
    hidden_size: int = 64
    conv_channels: int = 32
    kernel_size: int = 3
    dropout: float = 0.1
    batch_size: int = 64
    epochs: int = 30
    learning_rate: float = 1e-3
    seed: int = 20260714

    def __post_init__(self) -> None:
        for name in (
            "resample_minutes",
            "dispatch_minutes",
            "input_steps",
            "horizon_steps",
            "hidden_size",
            "conv_channels",
            "kernel_size",
            "batch_size",
            "epochs",
        ):
            _require_integer(name, getattr(self, name), minimum=1)
        if 24 * 60 % self.resample_minutes:
            raise ValueError("resample_minutes must divide one day")
        if self.dispatch_minutes % self.resample_minutes:
            raise ValueError("dispatch_minutes must be a multiple of resample_minutes")
        daily_steps = 24 * 60 // self.resample_minutes
        if self.input_steps < daily_steps or self.horizon_steps > daily_steps:
            raise ValueError("forecast history must cover a day and horizon cannot exceed a day")
        if self.kernel_size % 2 == 0:
            raise ValueError("kernel_size must be odd")
        if self.hidden_size % 4:
            raise ValueError("hidden_size must be divisible by the four attention heads")
        dropout = _require_finite_real("dropout", self.dropout)
        if not 0 <= dropout < 1:
            raise ValueError("dropout must be in [0, 1)")
        _require_positive_finite("learning_rate", self.learning_rate)
        if isinstance(self.seed, bool) or not isinstance(self.seed, Integral):
            raise ValueError("seed must be an integer")


@dataclass(frozen=True)
class CarbonConfig:
    grid_kg_per_kwh: float = 0.570
    wind_kg_per_kwh: float = 0.011
    pv_kg_per_kwh: float = 0.041
    fuel_cell_kg_per_kwh: float = 0.200
    battery_initial_stored_carbon_kg_per_kwh: float = 0.570
    hydrogen_initial_stored_carbon_kg_per_kwh: float = 0.570
    tolerance_kw: float = 1e-6

    def __post_init__(self) -> None:
        for name in (
            "grid_kg_per_kwh",
            "wind_kg_per_kwh",
            "pv_kg_per_kwh",
            "fuel_cell_kg_per_kwh",
            "battery_initial_stored_carbon_kg_per_kwh",
            "hydrogen_initial_stored_carbon_kg_per_kwh",
            "tolerance_kw",
        ):
            _require_nonnegative_finite(name, getattr(self, name))


@dataclass(frozen=True)
class DispatchConfig:
    horizon_steps: int = 24
    step_hours: float = 1.0
    population: int = 60
    iterations: int = 160
    seeds: tuple[int, ...] = (2026, 2027, 2028, 2029, 2030)
    objective_weights: dict[str, float] = field(
        default_factory=lambda: {"cost": 0.4, "curtailment": 0.3, "emissions": 0.3}
    )
    battery_enabled: bool = True
    battery_capacity_kwh: float = 1200.0
    battery_power_kw: float = 400.0
    battery_initial_soc: float = 0.50
    battery_min_soc: float = 0.10
    battery_max_soc: float = 0.90
    battery_charge_efficiency: float = 0.95
    battery_discharge_efficiency: float = 0.95
    hydrogen_enabled: bool = True
    hydrogen_capacity_kwh: float = 1800.0
    hydrogen_power_kw: float = 300.0
    hydrogen_initial_soc: float = 0.40
    hydrogen_min_soc: float = 0.05
    hydrogen_max_soc: float = 0.95
    electrolyzer_efficiency: float = 0.70
    fuel_cell_efficiency: float = 0.55
    grid_import_limit_kw: float = 2500.0
    grid_export_limit_kw: float = 1000.0
    grid_export_price_fraction: float = 0.0
    terminal_tolerance: float = 0.005
    terminal_repair_steps: int = 4
    battery_throughput_cost_per_kwh: float = 0.015
    hydrogen_throughput_cost_per_kwh: float = 0.025

    def __post_init__(self) -> None:
        _require_integer("horizon_steps", self.horizon_steps, minimum=1)
        _require_integer("population", self.population, minimum=4)
        _require_integer("iterations", self.iterations, minimum=1)
        _require_integer("terminal_repair_steps", self.terminal_repair_steps, minimum=1)
        _require_positive_finite("step_hours", self.step_hours)
        if not self.seeds or any(
            isinstance(seed, bool) or not isinstance(seed, Integral) for seed in self.seeds
        ):
            raise ValueError("seeds must be a non-empty sequence of integers")
        _validate_objective_weights(self.objective_weights)

        for device in ("battery", "hydrogen"):
            enabled = getattr(self, f"{device}_enabled")
            if not isinstance(enabled, bool):
                raise ValueError(f"{device}_enabled must be a boolean")
            for suffix in ("capacity_kwh", "power_kw"):
                name = f"{device}_{suffix}"
                if enabled:
                    _require_positive_finite(name, getattr(self, name))
                elif _require_nonnegative_finite(name, getattr(self, name)) != 0.0:
                    raise ValueError(f"{name} must be zero when {device} is disabled")
        for name in (
            "battery_charge_efficiency",
            "battery_discharge_efficiency",
            "electrolyzer_efficiency",
            "fuel_cell_efficiency",
        ):
            value = _require_finite_real(name, getattr(self, name))
            if not 0.0 < value <= 1.0:
                raise ValueError(f"{name} must be in (0, 1]")

        _validate_soc_bounds(
            "battery",
            self.battery_min_soc,
            self.battery_initial_soc,
            self.battery_max_soc,
        )
        _validate_soc_bounds(
            "hydrogen",
            self.hydrogen_min_soc,
            self.hydrogen_initial_soc,
            self.hydrogen_max_soc,
        )
        _require_nonnegative_finite("grid_import_limit_kw", self.grid_import_limit_kw)
        _require_nonnegative_finite("grid_export_limit_kw", self.grid_export_limit_kw)
        export_fraction = _require_nonnegative_finite(
            "grid_export_price_fraction", self.grid_export_price_fraction
        )
        if export_fraction > 1.0:
            raise ValueError("grid_export_price_fraction must be in [0, 1]")
        _require_nonnegative_finite(
            "battery_throughput_cost_per_kwh", self.battery_throughput_cost_per_kwh
        )
        _require_nonnegative_finite(
            "hydrogen_throughput_cost_per_kwh", self.hydrogen_throughput_cost_per_kwh
        )
        tolerance = _require_nonnegative_finite("terminal_tolerance", self.terminal_tolerance)
        if tolerance > 1.0:
            raise ValueError("terminal_tolerance must be in [0, 1]")


@dataclass(frozen=True)
class ProjectConfig:
    paths: PathConfig
    forecast: ForecastConfig = field(default_factory=ForecastConfig)
    carbon: CarbonConfig = field(default_factory=CarbonConfig)
    dispatch: DispatchConfig = field(default_factory=DispatchConfig)

    @classmethod
    def from_yaml(cls, path: str | Path) -> "ProjectConfig":
        config_path = Path(path).resolve()
        with config_path.open("r", encoding="utf-8") as stream:
            raw: dict[str, Any] = yaml.safe_load(stream) or {}

        paths_raw = raw.get("paths", {})
        required = ("mpte_root", "socal_root", "evidence_root", "cache_root", "results_root")
        missing = [name for name in required if name not in paths_raw]
        if missing:
            raise ValueError(f"Missing path configuration: {', '.join(missing)}")

        paths = PathConfig(
            **{name: _expand_path(paths_raw[name], config_path.parent) for name in required}
        )
        forecast = ForecastConfig(**raw.get("forecast", {}))
        carbon = CarbonConfig(**raw.get("carbon", {}))
        dispatch_raw = dict(raw.get("dispatch", {}))
        if "seeds" in dispatch_raw:
            dispatch_raw["seeds"] = tuple(dispatch_raw["seeds"])
        dispatch = DispatchConfig(**dispatch_raw)
        cls._validate_weights(dispatch.objective_weights)
        return cls(paths=paths, forecast=forecast, carbon=carbon, dispatch=dispatch)

    @staticmethod
    def _validate_weights(weights: dict[str, float]) -> None:
        _validate_objective_weights(weights)

    def prepare_output_dirs(self) -> None:
        self.paths.cache_root.mkdir(parents=True, exist_ok=True)
        self.paths.results_root.mkdir(parents=True, exist_ok=True)


def _require_finite_real(name: str, value: object) -> float:
    if isinstance(value, bool) or not isinstance(value, Real) or not isfinite(value):
        raise ValueError(f"{name} must be a finite real number")
    return float(value)


def _require_positive_finite(name: str, value: object) -> float:
    numeric = _require_finite_real(name, value)
    if numeric <= 0.0:
        raise ValueError(f"{name} must be positive")
    return numeric


def _require_nonnegative_finite(name: str, value: object) -> float:
    numeric = _require_finite_real(name, value)
    if numeric < 0.0:
        raise ValueError(f"{name} must be non-negative")
    return numeric


def _require_integer(name: str, value: object, *, minimum: int) -> None:
    if isinstance(value, bool) or not isinstance(value, Integral) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")


def _validate_soc_bounds(name: str, minimum: object, initial: object, maximum: object) -> None:
    low = _require_finite_real(f"{name}_min_soc", minimum)
    start = _require_finite_real(f"{name}_initial_soc", initial)
    high = _require_finite_real(f"{name}_max_soc", maximum)
    if not 0.0 <= low <= start <= high <= 1.0:
        raise ValueError(
            f"{name} SOC values must satisfy 0 <= min_soc <= initial_soc <= max_soc <= 1"
        )


def _validate_objective_weights(weights: Mapping[str, float]) -> None:
    expected = {"cost", "curtailment", "emissions"}
    if not isinstance(weights, Mapping) or set(weights) != expected:
        raise ValueError(f"objective_weights must contain exactly {sorted(expected)}")
    values = [
        _require_nonnegative_finite(f"objective_weights[{key}]", weights[key]) for key in expected
    ]
    if abs(sum(values) - 1.0) > 1e-9:
        raise ValueError("objective_weights must sum to 1")
