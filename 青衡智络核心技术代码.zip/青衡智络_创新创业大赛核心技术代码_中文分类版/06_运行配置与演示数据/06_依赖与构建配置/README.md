# 青衡智络：微电网碳流追踪与低碳协同调度（iCAN 完整代码整理版）

本仓库对应 **青衡智络 iCAN 创新赛道通用版本**，不混入其他赛事定制版本。代码由原始 `qingheng.zip` 工程清理、去缓存并重新编排，保留项目正式研发链中的全部 Python 源码、测试、Notebook、配置模板与技术审计文档。

核心能力包括：

- 15 分钟级时序数据完整性审计、连续异常门禁、来源哈希与 artifact manifest；
- Last-value、日周期、周周期强基线，以及 CNN–LSTM–Attention 残差预测；
- 基于有向功率网络的 BFS 拓扑传播、DFS 路径回溯、环网线性守恒求解；
- 电池与氢储能碳库存、绿电库存和跨日状态传递；
- Logistic–Tent 混沌初始化、非线性惯性权重、标准 WOA、改进 WOA 与 PSO；
- 单日多能协同调度、设备消融、实际轨迹回放和 48 h 预见/24 h 执行滚动调度；
- IEEE 33 节点潮流校核、PCC 限额检查、结果清单与哈希验证。

## 公开与归档边界

本代码包不包含：原始 SoCal 大体量数据、企业原始数据、账号密钥、个人信息、第三方证明、未公开专利全文、开发期虚拟环境、模型权重和数百组临时结果。正式缓存、结果表与证据文件已单独归入“商业计划书关键数据来源证据包”，不要把本仓库中的合成 demo 输出替代为正式实验结论。

初次上传 GitHub 建议将仓库设为 **Private**。完成数据授权、论文出版状态、专利披露范围与团队署名核验后，再决定是否公开。

推荐仓库名：

```text
qingheng-microgrid-carbon-dispatch
```

## 环境要求

- Python 3.10–3.13
- 基础依赖：NumPy、Pandas、PyYAML、PyArrow、Matplotlib、NetworkX
- 深度学习预测：PyTorch
- 测试：Pytest

Windows：

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -U pip
pip install -e ".[dev]"
```

macOS / Linux：

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
pip install -e ".[dev]"
```

需要训练 CNN–LSTM–Attention 或运行 Notebook 时：

```bash
pip install -e ".[all]"
```

## 无外部数据的快速自检

```bash
python scripts/generate_demo_data.py
python scripts/run_core_demo.py
python scripts/verify_package.py
pytest -q
```

输出位于 `artifacts/demo/`。该流程只验证代码链、接口和基本数值守恒，不复现正式 MAE、算法降幅或 43 天结果。

## 正式工程入口

先在 `configs/default.yaml` 中填写本机数据路径，再按需运行：

```bash
# 1. 原始量测审计与 15 分钟派生缓存
qingheng --config configs/default.yaml prepare-data \
  --start 2024-09-01T00:00:00Z \
  --end 2025-09-01T00:00:00Z

# 2. 预测模型训练与强基线比较
qingheng --config configs/default.yaml train-forecast

# 3. 单日 SoCal 混合场景调度
qingheng --config configs/default.yaml socal-dispatch \
  --forecast-csv results/forecast_socal/first_test_forecast.csv

# 4. 多日滚动调度
qingheng --config configs/default.yaml rolling-dispatch \
  --daily-forecast-csv results/forecast_socal/all_test_daily_forecasts.csv
```

完整 CLI 参数可查看：

```bash
qingheng --help
```

## 目录结构

```text
configs/                     可移植配置模板
data/demo/                   合成演示数据（脚本生成）
docs/                       技术依据、数据治理、实验边界与审计记录
notebooks/                  端到端研究 Notebook
scripts/                    demo、自检和包完整性核验
src/qingheng/data/          数据审计、SoCal 适配与来源清单
src/qingheng/forecast/      强基线、模型、训练与指标
src/qingheng/carbon/        碳流追踪、路径解释与碳库存
src/qingheng/dispatch/      调度问题、WOA/PSO 与统一预算实验
src/qingheng/network/       IEEE 33 节点网络校核适配
src/qingheng/               CLI、流水线、滚动调度、容量标定与报告
tests/                      17 组测试文件
SOURCE_MANIFEST.csv          文件级 SHA-256 清单
PACKAGE_REPORT.md            本次整理范围与剔除说明
```

## 结果解释守则

- 神经网络模型、强周期基线和运行组合必须分别报告，不能把组合 MAE 写成单一 CNN–LSTM–Attention 指标。
- 改进 WOA 可与标准 WOA比较，但当 PSO 的平均目标值更低时，不应表述为“改进 WOA 全面最优”。
- 43 天滚动结果属于研究场景仿真与实际数据回放，不等同于现场设备连续在线运行。
- SoCal 时间序列与 IEEE 33 固定拓扑组合属于“真实时间序列 + 固定网络”的混合实验，不是同步现场数字孪生。
- 配置中的储能、氢系统和 PCC 参数是研究标定或示例参数，不能直接解释为企业现场装机容量。

更详细的技术口径见 `docs/TECHNICAL_BASIS.md`、`docs/AUDIT_2026-07-16.md` 和各专题审计文档。

## 权利说明

当前代码包用于竞赛评审、团队协作与学术复核，未附加标准开源许可证。未经项目组书面许可，不默认授予商用、再许可或公开再发布权利。详见 `LICENSE_NOTICE.md`。
