# Rights and use notice

Copyright © Qingheng project team. All rights reserved unless the team issues a
separate written licence.

This repository package is supplied for iCAN competition review, internal team
collaboration, reproducibility inspection and academic evaluation. Possession of
the package does not by itself grant permission for commercial use, public
redistribution, sublicensing, patent-disclosure expansion or use of third-party
data beyond its original licence.

Before making the repository public, the team should separately confirm data
licences, paper publication status, patent disclosure scope, contributor names
and the final open-source licence, if any.
