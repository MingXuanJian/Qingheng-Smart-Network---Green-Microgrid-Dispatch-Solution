from __future__ import annotations

import argparse
from dataclasses import asdict, replace
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
import pandas as pd

from qingheng.config import DispatchConfig, ProjectConfig
from qingheng.data import (
    HybridAssetAssumptions,
    build_hybrid_profile,
    build_socal_15min_cache,
    verify_socal_cache_manifest,
)
from qingheng.dispatch import (
    DispatchEvaluation,
    DispatchInputs,
    MultiEnergyDispatchProblem,
    run_optimizer_benchmark,
    write_optimizer_artifact_manifest,
)
from qingheng.network import IEEE33ScheduleValidator, PowerFlowValidation
from qingheng.forecast_workflow import (
    export_socal_test_daily_forecasts,
    run_socal_forecast_experiment,
)
from qingheng.pipeline import run_carbon_accounting
from qingheng.reporting import (
    export_dispatch,
    plot_benchmark,
    plot_dispatch,
    plot_optimizer_algorithm_comparison,
)
from qingheng.rolling_dispatch import (
    RollingPCCPolicy,
    load_authenticated_daily_forecasts,
    run_rolling_dispatch_sensitivity,
)
from qingheng.scenario import make_builtin_scenario, make_profile_dispatch_inputs
from qingheng.scenario_sizing import calibrate_socal_dispatch


def _default_config_path() -> Path:
    return Path(__file__).resolve().parents[2] / "configs" / "default.yaml"


def _file_sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _new_result_directory(results_root: Path, name: str) -> Path:
    root = results_root.resolve()
    relative = Path(name)
    if not name.strip() or relative.is_absolute():
        raise ValueError("result name must be a non-empty relative path")
    output = (root / relative).resolve()
    if output == root or root not in output.parents:
        raise ValueError("result name must stay inside the configured results root")
    if output.exists():
        if not output.is_dir():
            raise ValueError(f"result path exists and is not a directory: {output}")
        if next(output.iterdir(), None) is not None:
            raise ValueError(
                f"result directory is not empty: {output}; use a new --name to avoid "
                "mixing artifacts from different runs"
            )
    output.mkdir(parents=True, exist_ok=True)
    return output


def _validate_complete_local_calendar_day(
    index: pd.DatetimeIndex,
    *,
    timezone: str = "America/Los_Angeles",
) -> None:
    if index.tz is None:
        raise ValueError("dispatch timestamps must be timezone-aware")
    if len(index) != 96:
        raise ValueError("dispatch profile must contain exactly one 96-step local calendar day")
    local = index.tz_convert(timezone)
    clock_minutes = (local.hour * 60 + local.minute).to_numpy(dtype=np.int64)
    expected = np.arange(0, 24 * 60, 15, dtype=np.int64)
    if local[0].date() != local[-1].date() or not np.array_equal(clock_minutes, expected):
        raise ValueError(
            "dispatch profile must span one complete local natural day from 00:00 to 23:45; "
            "DST transition days and shifted 24-hour windows are not supported"
        )


def _load_bound_forecast(
    forecast_path: Path,
    metrics_path: Path | None,
    *,
    cache_manifest: dict[str, object],
    cache_rows: int,
    expected_steps: int,
) -> tuple[pd.DataFrame, dict[str, object]]:
    csv_path = forecast_path.resolve()
    sidecar = (
        metrics_path.resolve()
        if metrics_path is not None
        else csv_path.with_name("forecast_metrics.json")
    )
    if not csv_path.is_file():
        raise FileNotFoundError(f"forecast CSV not found: {csv_path}")
    if not sidecar.is_file():
        raise FileNotFoundError(
            "forecast metrics sidecar is required to bind dispatch sizing and test provenance: "
            f"{sidecar}"
        )
    try:
        metrics = json.loads(sidecar.read_text(encoding="utf-8"))
    except (UnicodeError, json.JSONDecodeError) as error:
        raise ValueError(f"invalid forecast metrics sidecar: {sidecar}") from error
    if metrics.get("schema_version") != "qingheng.forecast-metrics.v5":
        raise ValueError("forecast metrics sidecar has an unsupported schema")
    provenance = metrics.get("data_provenance")
    if not isinstance(provenance, dict):
        raise ValueError("forecast metrics sidecar has no data_provenance")
    if provenance.get("cache_output_sha256") != cache_manifest.get("output_sha256"):
        raise ValueError("forecast and dispatch caches have different content hashes")
    selected = cache_manifest.get("derivation", {})
    selected_months = (
        selected.get("selected_complete_months") if isinstance(selected, dict) else None
    )
    if provenance.get("selected_complete_months") != selected_months:
        raise ValueError("forecast and dispatch caches have different complete-month selections")
    if provenance.get("source_cache_rows") != cache_rows:
        raise ValueError("forecast source row count differs from the dispatch cache")
    splits = provenance.get("target_split_intervals")
    if not isinstance(splits, dict) or not isinstance(splits.get("train"), dict):
        raise ValueError("forecast metrics sidecar has no target training interval")
    if not isinstance(splits.get("test"), dict):
        raise ValueError("forecast metrics sidecar has no held-out test interval")
    train = splits["train"]
    test = splits["test"]
    train_start = pd.Timestamp(train.get("target_start"))
    train_end = pd.Timestamp(train.get("target_end_exclusive"))
    test_start = pd.Timestamp(test.get("target_start"))
    test_end = pd.Timestamp(test.get("target_end_exclusive"))
    timestamps = (train_start, train_end, test_start, test_end)
    if any(timestamp.tzinfo is None for timestamp in timestamps):
        raise ValueError("forecast split timestamps must be timezone-aware")
    if not train_start < train_end <= test_start < test_end:
        raise ValueError("forecast train/test intervals are not strictly chronological")

    forecast = pd.read_csv(csv_path, parse_dates=["timestamp"]).set_index("timestamp")
    forecast.index = pd.to_datetime(forecast.index, utc=True)
    if len(forecast) != expected_steps:
        raise ValueError(f"forecast CSV must contain exactly {expected_steps} 15-minute steps")
    if forecast.index.has_duplicates or not forecast.index.is_monotonic_increasing:
        raise ValueError("forecast timestamps must be unique and sorted")
    if len(forecast) > 1 and not np.all(
        np.diff(forecast.index.asi8) == pd.Timedelta(minutes=15).value
    ):
        raise ValueError("forecast timestamps must form a continuous 15-minute grid")
    if expected_steps == 96:
        _validate_complete_local_calendar_day(forecast.index)
    if forecast.index[0] < test_start or forecast.index[-1] >= test_end:
        raise ValueError("forecast CSV is not wholly inside the declared held-out test interval")
    export = metrics.get("dispatch_export")
    if not isinstance(export, dict):
        raise ValueError("forecast metrics sidecar has no authenticated dispatch export")
    csv_sha256 = _file_sha256(csv_path)
    if export.get("sha256") != csv_sha256:
        raise ValueError("forecast CSV content does not match its metrics sidecar hash")
    if export.get("rows") != len(forecast):
        raise ValueError("forecast CSV row count does not match its metrics sidecar")
    if (
        pd.Timestamp(export.get("start")) != forecast.index[0]
        or pd.Timestamp(export.get("end_inclusive")) != forecast.index[-1]
    ):
        raise ValueError("forecast CSV interval does not match its metrics sidecar")
    if export.get("is_complete_local_calendar_day") is not True:
        raise ValueError("dispatch forecast must be a complete local calendar day")
    experiment = provenance.get("experiment_interval")
    quick = experiment.get("quick_truncation") if isinstance(experiment, dict) else None
    return forecast, {
        "metrics_path": str(sidecar),
        "metrics_schema_version": metrics["schema_version"],
        "forecast_csv_sha256": csv_sha256,
        "train_start": train_start.isoformat(),
        "train_end_exclusive": train_end.isoformat(),
        "test_start": test_start.isoformat(),
        "test_end_exclusive": test_end.isoformat(),
        "quick_truncation": quick,
    }


def _select_network_feasible_evaluation(
    frame: pd.DataFrame,
    evaluations: dict[tuple[str, int], DispatchEvaluation],
    network: IEEE33ScheduleValidator,
    inputs: DispatchInputs,
    config: ProjectConfig,
    audit_path: Path,
) -> tuple[tuple[str, int], DispatchEvaluation, PowerFlowValidation]:
    candidates = frame[
        (frame["algorithm"] != "zero_dispatch") & frame["feasible"].astype(bool)
    ].sort_values("score")
    if candidates.empty:
        raise ValueError("optimizer benchmark produced no dispatch-feasible run")

    records: list[dict[str, object]] = []
    accepted: list[tuple[tuple[str, int], DispatchEvaluation, PowerFlowValidation]] = []
    for row in candidates.itertuples(index=False):
        key = (str(row.algorithm), int(row.seed))
        evaluation = evaluations[key]
        validation = network.validate(
            inputs,
            evaluation,
            grid_import_limit_kw=config.dispatch.grid_import_limit_kw,
            grid_export_limit_kw=config.dispatch.grid_export_limit_kw,
        )
        slack = validation.timeseries["slack_power_kw"]
        records.append(
            {
                "algorithm": key[0],
                "seed": key[1],
                "score": evaluation.score,
                "dispatch_feasible": evaluation.feasible,
                "powerflow_converged": validation.all_converged,
                "voltage_feasible": validation.voltage_feasible,
                "current_feasible": validation.current_feasible,
                "pcc_limit_feasible": validation.grid_feasible,
                "network_feasible": validation.feasible,
                "maximum_pcc_import_kw": float(np.maximum(slack, 0.0).max()),
                "maximum_pcc_export_kw": float(np.maximum(-slack, 0.0).max()),
            }
        )
        if validation.feasible:
            accepted.append((key, evaluation, validation))
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame.from_records(records).to_csv(audit_path, index=False)
    if not accepted:
        raise ValueError(
            "no optimizer run satisfies dispatch, AC voltage/current, and loss-adjusted PCC limits"
        )
    return accepted[0]


def _network_adjusted_summary(
    inputs: DispatchInputs,
    evaluation: DispatchEvaluation,
    validation: PowerFlowValidation,
    config: ProjectConfig,
) -> dict[str, float | bool | None | str]:
    dt = config.dispatch.step_hours
    slack = validation.timeseries["slack_power_kw"].to_numpy(dtype=float)
    imported = np.maximum(slack, 0.0)
    exported = np.maximum(-slack, 0.0)
    cycling = config.dispatch.battery_throughput_cost_per_kwh * np.abs(
        evaluation.battery_power_kw
    ) + config.dispatch.hydrogen_throughput_cost_per_kwh * np.abs(evaluation.hydrogen_power_kw)
    network_cost = float(
        np.sum(imported * inputs.buy_price_per_kwh - exported * inputs.sell_price_per_kwh + cycling)
        * dt
        + evaluation.terminal_replenishment_cost
    )
    network_emissions = float(
        np.sum(
            imported * inputs.grid_carbon_kg_per_kwh
            + inputs.fixed_generation_kw * inputs.fixed_generation_carbon_kg_per_kwh
            + evaluation.pv_used_kw * inputs.pv_carbon_kg_per_kwh
            + evaluation.wind_used_kw * inputs.wind_carbon_kg_per_kwh
        )
        * dt
        + evaluation.terminal_replenishment_emissions_kg
    )
    return {
        "all_converged": validation.all_converged,
        "voltage_feasible": validation.voltage_feasible,
        "current_feasible": validation.current_feasible,
        "pcc_limit_feasible": validation.grid_feasible,
        "feasible": validation.feasible,
        "minimum_voltage_pu": float(validation.timeseries["min_voltage_pu"].min()),
        "maximum_voltage_pu": float(validation.timeseries["max_voltage_pu"].max()),
        "maximum_pcc_import_kw": float(np.max(imported)),
        "maximum_pcc_export_kw": float(np.max(exported)),
        "active_loss_energy_kwh": float(validation.timeseries["active_loss_kw"].sum() * dt),
        "lossless_dispatch_cost": evaluation.cost,
        "loss_adjusted_cost": network_cost,
        "lossless_dispatch_load_allocated_emissions_proxy_kg": (
            evaluation.load_allocated_emissions_proxy_kg
        ),
        "lossless_dispatch_source_emissions_kg": evaluation.external_source_emissions_kg,
        "loss_adjusted_source_emissions_kg": network_emissions,
        "terminal_replenishment_cost": evaluation.terminal_replenishment_cost,
        "terminal_replenishment_emissions_kg": (evaluation.terminal_replenishment_emissions_kg),
        "ampacity_note": "Canonical IEEE33 has no branch ratings; current is diagnostic only.",
    }


def _export_actual_replay(
    *,
    config: ProjectConfig,
    actual_inputs: DispatchInputs,
    forecast_evaluation: DispatchEvaluation,
    selected_key: tuple[str, int],
    network: IEEE33ScheduleValidator,
    output: Path,
) -> None:
    replay = _evaluate_actual_replay(actual_inputs, config.dispatch, forecast_evaluation)
    validation = network.validate(
        actual_inputs,
        replay,
        grid_import_limit_kw=config.dispatch.grid_import_limit_kw,
        grid_export_limit_kw=config.dispatch.grid_export_limit_kw,
    )
    export_dispatch(output, actual_inputs, replay, prefix="actual_replay")
    plot_dispatch(output / "actual_replay.png", actual_inputs, replay)
    validation.timeseries.to_csv(output / "actual_replay_powerflow_validation.csv", index=False)
    summary = _network_adjusted_summary(actual_inputs, replay, validation, config)
    summary.update(
        {
            "source_schedule_algorithm": selected_key[0],
            "source_schedule_seed": selected_key[1],
            "dispatch_feasible": replay.feasible,
            "interpretation": (
                "Fixed forecast-optimized device powers and renewable fractions replayed "
                "against the exported actual load and PV; no re-optimization."
            ),
        }
    )
    (output / "actual_replay_powerflow_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    if replay.feasible and validation.feasible:
        carbon = run_carbon_accounting(
            inputs=actual_inputs,
            dispatch=replay,
            dispatch_config=config.dispatch,
            carbon_config=config.carbon,
            validator=network,
            validation=validation,
        )
        carbon.snapshots.to_csv(output / "actual_replay_carbon_trace_timeseries.csv", index=False)
        carbon_payload: dict[str, object] = {
            "available": True,
            **carbon.metrics_dict(),
        }
    else:
        carbon_payload = {
            "available": False,
            "reason": "actual replay violates dispatch or AC network constraints",
            "dispatch_feasible": replay.feasible,
            "network_feasible": validation.feasible,
        }
    (output / "actual_replay_carbon_metrics.json").write_text(
        json.dumps(carbon_payload, indent=2, ensure_ascii=True), encoding="utf-8"
    )


def _evaluate_actual_replay(
    actual_inputs: DispatchInputs,
    dispatch_config: DispatchConfig,
    forecast_evaluation: DispatchEvaluation,
) -> DispatchEvaluation:
    decision = np.concatenate(
        [
            forecast_evaluation.battery_power_kw,
            forecast_evaluation.hydrogen_power_kw,
            forecast_evaluation.renewable_fraction,
        ]
    )
    return MultiEnergyDispatchProblem(actual_inputs, dispatch_config).evaluate(decision)


def _apply_optimizer_overrides(
    dispatch_config: DispatchConfig,
    args: argparse.Namespace,
) -> DispatchConfig:
    seeds = dispatch_config.seeds
    population = dispatch_config.population
    iterations = dispatch_config.iterations
    if args.quick:
        seeds = (dispatch_config.seeds[0],)
        population = min(population, 16)
        iterations = min(iterations, 24)
    if args.population is not None:
        population = args.population
    if args.iterations is not None:
        iterations = args.iterations
    if args.seed is not None:
        seeds = (args.seed,)
    return replace(
        dispatch_config,
        seeds=seeds,
        population=population,
        iterations=iterations,
    )


def _run_dispatch_experiment(
    config: ProjectConfig,
    inputs: DispatchInputs,
    args: argparse.Namespace,
    *,
    actual_inputs: DispatchInputs | None = None,
) -> int:
    dispatch_config = _apply_optimizer_overrides(config.dispatch, args)
    seeds = dispatch_config.seeds
    population = dispatch_config.population
    iterations = dispatch_config.iterations

    problem = MultiEnergyDispatchProblem(inputs, dispatch_config)
    output = config.paths.results_root / args.name
    frame, evaluations = run_optimizer_benchmark(
        problem,
        seeds=seeds,
        population_size=population,
        iterations=iterations,
        output_dir=output,
    )
    network = IEEE33ScheduleValidator(config.paths.mpte_root)
    key, best, validation = _select_network_feasible_evaluation(
        frame,
        evaluations,
        network,
        inputs,
        config,
        output / "network_candidate_audit.csv",
    )
    schedule_path, metrics_path = export_dispatch(output, inputs, best)
    plot_dispatch(output / "best_dispatch.png", inputs, best)
    plot_benchmark(frame, output / "optimizer_comparison.png")
    convergence = pd.read_csv(output / "optimizer_convergence.csv")
    plot_optimizer_algorithm_comparison(
        frame,
        convergence,
        output / "optimizer_algorithm_comparison.png",
    )
    plot_optimizer_algorithm_comparison(
        frame,
        convergence,
        output / "optimizer_algorithm_comparison.pdf",
    )
    write_optimizer_artifact_manifest(output)

    validation.timeseries.to_csv(output / "powerflow_validation.csv", index=False)
    network_summary = _network_adjusted_summary(inputs, best, validation, config)
    network_summary["selected_algorithm"] = key[0]
    network_summary["selected_seed"] = key[1]
    (output / "powerflow_summary.json").write_text(
        json.dumps(network_summary, indent=2), encoding="utf-8"
    )
    carbon = run_carbon_accounting(
        inputs=inputs,
        dispatch=best,
        dispatch_config=dispatch_config,
        carbon_config=config.carbon,
        validator=network,
        validation=validation,
    )
    carbon.snapshots.to_csv(output / "carbon_trace_timeseries.csv", index=False)
    (output / "carbon_metrics.json").write_text(
        json.dumps(carbon.metrics_dict(), indent=2, ensure_ascii=True), encoding="utf-8"
    )
    if actual_inputs is not None:
        _export_actual_replay(
            config=config,
            actual_inputs=actual_inputs,
            forecast_evaluation=best,
            selected_key=key,
            network=network,
            output=output,
        )
    print(f"Best run: {key[0]} seed={key[1]} score={best.score:.6f}")
    print(f"Dispatch feasible: {best.feasible}; IEEE33 network feasible: {validation.feasible}")
    print(f"Carbon intensity: {carbon.metrics.unit_supply_carbon_intensity_kg_per_kwh:.4f} kg/kWh")
    print(f"Schedule: {schedule_path}")
    print(f"Metrics: {metrics_path}")
    return 0


def _demo(args: argparse.Namespace) -> int:
    config = ProjectConfig.from_yaml(args.config)
    config.prepare_output_dirs()
    _new_result_directory(config.paths.results_root, args.name)
    inputs = make_builtin_scenario(config.dispatch, config.carbon)
    return _run_dispatch_experiment(config, inputs, args)


def _utc_timestamp(value: str | None, default: pd.Timestamp) -> pd.Timestamp:
    if value is None:
        return default
    timestamp = pd.Timestamp(value)
    return timestamp.tz_localize("UTC") if timestamp.tzinfo is None else timestamp.tz_convert("UTC")


def _scenario_plausibility(inputs: DispatchInputs) -> dict[str, object]:
    """Flag scale mismatches without inventing replacement asset capacities."""

    load_energy = float(np.sum(inputs.load_kw))
    wind_energy = float(np.sum(inputs.wind_available_kw))
    pv_energy = float(np.sum(inputs.pv_available_kw))
    renewable_energy = wind_energy + pv_energy
    warnings: list[str] = []
    if load_energy > 0.0:
        wind_ratio = wind_energy / load_energy
        renewable_ratio = renewable_energy / load_energy
        if wind_ratio > 1.0:
            warnings.append("synthetic wind energy exceeds load energy for the dispatch horizon")
        if renewable_ratio > 2.0:
            warnings.append(
                "available renewable energy exceeds twice the load; results may be "
                "export-dominated and storage/hydrogen dispatch may become degenerate"
            )
    else:
        wind_ratio = None
        renewable_ratio = None
        warnings.append("dispatch horizon has zero total load")
    return {
        "basis": "hourly pre-dispatch availability; one-hour steps",
        "load_energy_kwh": load_energy,
        "pv_available_energy_kwh": pv_energy,
        "synthetic_wind_available_energy_kwh": wind_energy,
        "wind_to_load_energy_ratio": wind_ratio,
        "renewable_to_load_energy_ratio": renewable_ratio,
        "renewable_surplus_hour_fraction": float(
            np.mean(inputs.renewable_available_kw > inputs.load_kw)
        ),
        "warnings": warnings,
    }


def _socal_dispatch(args: argparse.Namespace) -> int:
    config = ProjectConfig.from_yaml(args.config)
    config.prepare_output_dirs()
    cache_path = args.cache or (config.paths.cache_root / "socal_15min.parquet")
    cache_manifest = verify_socal_cache_manifest(cache_path)
    real = pd.read_parquet(cache_path)
    selected_months = tuple(cache_manifest["derivation"]["selected_complete_months"])
    actual_months = tuple(dict.fromkeys(real.index.strftime("%Y-%m")))
    if actual_months != selected_months:
        raise ValueError(
            f"cache months {actual_months} do not match manifest selection {selected_months}"
        )
    forecast: pd.DataFrame | None = None
    forecast_binding: dict[str, object] | None = None
    if args.forecast_csv is not None:
        forecast, forecast_binding = _load_bound_forecast(
            args.forecast_csv,
            args.forecast_metrics,
            cache_manifest=cache_manifest,
            cache_rows=len(real),
            expected_steps=config.forecast.horizon_steps,
        )
    sizing_manifest: dict[str, object] | None = None
    if args.asset_sizing == "train-calibrated":
        sizing = calibrate_socal_dispatch(
            real,
            config.dispatch,
            cache_manifest=cache_manifest,
            wind_capacity_kw=args.synthetic_wind_capacity_kw,
            input_steps=config.forecast.input_steps,
            train_start=(None if forecast_binding is None else forecast_binding["train_start"]),
            train_end_exclusive=(
                None if forecast_binding is None else forecast_binding["train_end_exclusive"]
            ),
        )
        config = replace(config, dispatch=sizing.dispatch)
        sizing_manifest = sizing.manifest
    disabled_devices: list[str] = []
    if args.disable_battery:
        config = replace(
            config,
            dispatch=replace(
                config.dispatch,
                battery_enabled=False,
                battery_capacity_kwh=0.0,
                battery_power_kw=0.0,
            ),
        )
        disabled_devices.append("battery")
    if args.disable_hydrogen:
        config = replace(
            config,
            dispatch=replace(
                config.dispatch,
                hydrogen_enabled=False,
                hydrogen_capacity_kwh=0.0,
                hydrogen_power_kw=0.0,
            ),
        )
        disabled_devices.append("hydrogen")
    config = replace(
        config,
        dispatch=_apply_optimizer_overrides(config.dispatch, args),
    )
    applied_scenario_sha256: str | None = None
    if sizing_manifest is not None:
        sizing_manifest["post_sizing_application"] = {
            "disabled_devices": disabled_devices,
            "applied_dispatch": asdict(config.dispatch),
        }
        canonical_application = json.dumps(sizing_manifest, sort_keys=True, separators=(",", ":"))
        applied_scenario_sha256 = sha256(canonical_application.encode("utf-8")).hexdigest()
        sizing_manifest["applied_scenario_sha256"] = applied_scenario_sha256
    hybrid = build_hybrid_profile(
        real,
        HybridAssetAssumptions.from_dispatch_config(
            config.dispatch,
            wind_capacity_kw=args.synthetic_wind_capacity_kw,
        ),
    )
    wind_enabled = args.synthetic_wind_capacity_kw > 0.0
    provenance: dict[str, object] = {
        "profile_kind": hybrid.metadata["profile_kind"],
        "hybrid_asset_assumptions": hybrid.metadata["asset_assumptions"],
        "cache_path": str(Path(cache_path).resolve()),
        "selected_complete_months": list(selected_months),
        "wind_source": (
            "synthetic bounded trace"
            if wind_enabled
            else "disabled because no confirmed SoCal wind measurement is available"
        ),
        "battery_source": (
            (
                "training-calibrated research device parameters; schedule optimized"
                if args.asset_sizing == "train-calibrated"
                else "configured synthetic research device parameters; schedule optimized"
            )
            if config.dispatch.battery_enabled
            else "disabled for device ablation"
        ),
        "hydrogen_source": (
            (
                "training-calibrated research device parameters; schedule optimized"
                if args.asset_sizing == "train-calibrated"
                else "configured synthetic research device parameters; schedule optimized"
            )
            if config.dispatch.hydrogen_enabled
            else "disabled for device ablation"
        ),
        "asset_sizing_policy": args.asset_sizing,
        "disabled_devices": disabled_devices,
        "carbon_assumptions": asdict(config.carbon),
        "dispatch_carbon_objective": "lossless copper-plate load-allocated inventory proxy",
        "optimizer_benchmark": {
            "quick": bool(args.quick),
            "population": config.dispatch.population,
            "iterations": config.dispatch.iterations,
            "seeds": list(config.dispatch.seeds),
        },
        "sizing_sha256": (None if sizing_manifest is None else sizing_manifest["sizing_sha256"]),
        "applied_scenario_sha256": applied_scenario_sha256,
        "fuel_cell_source": (
            "SoCal eGauge22 auxiliary observation; excluded from the default dispatch "
            "balance because it is outside the eGauge16 load boundary"
        ),
    }
    actual_profile: pd.DataFrame | None = None
    if forecast is not None:
        operational_columns = {"load_operational_kw", "pv_operational_kw"}
        neural_columns = {"load_model_kw", "pv_model_kw"}
        if operational_columns & set(forecast.columns) and not (
            operational_columns <= set(forecast.columns)
        ):
            raise ValueError("forecast CSV contains only one operational forecast column")
        if operational_columns <= set(forecast.columns):
            load_forecast_column = "load_operational_kw"
            pv_forecast_column = "pv_operational_kw"
            forecast_source = (
                "validation-selected operational forecast (CNN-LSTM-Attention residual "
                "model blended with daily/weekly seasonal persistence)"
            )
        elif neural_columns <= set(forecast.columns):
            load_forecast_column = "load_model_kw"
            pv_forecast_column = "pv_model_kw"
            forecast_source = "CNN-LSTM-Attention physical forecast"
        else:
            raise ValueError(
                "forecast CSV must contain both operational forecast columns or both "
                "model forecast columns"
            )
        profile = hybrid.frame.reindex(forecast.index).copy()
        if profile[["wind_kw", "fuel_cell_kw"]].isna().any().any():
            raise ValueError("forecast timestamps are outside the prepared SoCal cache")
        profile["load_kw"] = forecast[load_forecast_column].to_numpy()
        profile["pv_kw"] = forecast[pv_forecast_column].to_numpy()
        actual_columns = {"load_actual_kw", "pv_actual_kw"}
        if not actual_columns <= set(forecast.columns):
            raise ValueError(
                "authenticated forecast CSV must contain load_actual_kw and pv_actual_kw"
            )
        actual_profile = hybrid.frame.reindex(forecast.index).copy()
        actual_profile["load_kw"] = forecast["load_actual_kw"].to_numpy()
        actual_profile["pv_kw"] = forecast["pv_actual_kw"].to_numpy()
        provenance.update(
            {
                "load_source": forecast_source,
                "pv_source": forecast_source,
                "load_forecast_column": load_forecast_column,
                "pv_forecast_column": pv_forecast_column,
                "forecast_csv": str(args.forecast_csv.resolve()),
                "forecast_binding": forecast_binding,
            }
        )
    else:
        if args.start is not None:
            start = _utc_timestamp(args.start, hybrid.frame.index[0])
        elif sizing_manifest is not None:
            calibration_end = pd.Timestamp(sizing_manifest["training_interval"]["end_exclusive"])
            local_end = calibration_end.tz_convert("America/Los_Angeles")
            local_midnight = local_end.normalize()
            if local_midnight < local_end:
                local_midnight += pd.DateOffset(days=1)
            start = local_midnight.tz_convert("UTC")
        else:
            start = hybrid.frame.index[0]
        if start.minute != 0 or start.second != 0:
            raise ValueError("SoCal dispatch start must align to an exact UTC hour")
        if sizing_manifest is not None:
            calibration_end = pd.Timestamp(sizing_manifest["training_interval"]["end_exclusive"])
            if start < calibration_end:
                raise ValueError(
                    "measured-profile dispatch cannot start before sizing training ends"
                )
        end = start + pd.Timedelta(hours=config.dispatch.horizon_steps)
        profile = hybrid.frame.loc[(hybrid.frame.index >= start) & (hybrid.frame.index < end)]
        _validate_complete_local_calendar_day(profile.index)
        provenance.update(
            {
                "load_source": "SoCal held-out/selected measured profile",
                "pv_source": "SoCal measured profile",
            }
        )
    inputs = make_profile_dispatch_inputs(profile, config.dispatch, config.carbon)
    actual_inputs = (
        None
        if actual_profile is None
        else make_profile_dispatch_inputs(actual_profile, config.dispatch, config.carbon)
    )
    plausibility = _scenario_plausibility(inputs)
    provenance["scenario_plausibility"] = plausibility
    provenance["start"] = str(profile.index.min())
    provenance["end"] = str(profile.index.max())
    provenance["local_start"] = str(profile.index.min().tz_convert("America/Los_Angeles"))
    provenance["local_end"] = str(profile.index.max().tz_convert("America/Los_Angeles"))
    output = _new_result_directory(config.paths.results_root, args.name)
    (output / "scenario_provenance.json").write_text(
        json.dumps(provenance, indent=2, ensure_ascii=True), encoding="utf-8"
    )
    if sizing_manifest is not None:
        (output / "sizing_manifest.json").write_text(
            json.dumps(sizing_manifest, indent=2, ensure_ascii=True), encoding="utf-8"
        )
    for warning in plausibility["warnings"]:
        print(f"Scenario warning: {warning}")
    return _run_dispatch_experiment(config, inputs, args, actual_inputs=actual_inputs)


def _prepare_data(args: argparse.Namespace) -> int:
    config = ProjectConfig.from_yaml(args.config)
    config.prepare_output_dirs()
    cache = build_socal_15min_cache(
        config.paths.socal_root,
        config.paths.cache_root,
        hash_mode=args.hash_mode,
        start=args.start,
        end=args.end,
        unit_policy=args.unit_policy,
        source_resolution_seconds=args.source_resolution_seconds,
        download_plan_path=args.download_plan,
    )
    print(f"Rows: {cache.rows}")
    print(f"Selected complete months: {', '.join(cache.selected_months)}")
    print(f"Parquet: {cache.parquet_path}")
    print(f"Manifest: {cache.manifest_path}")
    return 0


def _train_forecast(args: argparse.Namespace) -> int:
    config = ProjectConfig.from_yaml(args.config)
    config.prepare_output_dirs()
    cache_path = args.cache or (config.paths.cache_root / "socal_15min.parquet")
    verify_socal_cache_manifest(cache_path)
    output = _new_result_directory(config.paths.results_root, args.name)
    result = run_socal_forecast_experiment(
        cache_path,
        output,
        config.forecast,
        quick=args.quick,
        epochs=args.epochs,
    )
    model_overall = result.model_metrics["overall"]
    operational_overall = result.operational_metrics["overall"]
    persistence_overall = result.persistence_metrics["overall"]
    print(
        f"Rows/windows: {result.rows}/"
        f"{result.train_windows}/{result.validation_windows}/{result.test_windows}"
    )
    print(
        f"Test MAE neural={model_overall['mae']:.3f}, "
        f"operational={operational_overall['mae']:.3f}, "
        f"daily persistence={persistence_overall['mae']:.3f}"
    )
    print(f"Artifact: {result.artifact_path}")
    print(f"Metrics: {result.metrics_path}")
    return 0


def _export_test_days(args: argparse.Namespace) -> int:
    config = ProjectConfig.from_yaml(args.config)
    cache_path = args.cache or (config.paths.cache_root / "socal_15min.parquet")
    metrics_path = args.forecast_metrics.resolve()
    artifact_path = (
        args.artifact.resolve()
        if args.artifact is not None
        else metrics_path.with_name("cnn_lstm_attention.pt")
    )
    output_dir = args.output_dir.resolve() if args.output_dir is not None else metrics_path.parent
    result = export_socal_test_daily_forecasts(
        cache_path,
        artifact_path,
        metrics_path,
        output_dir,
        config.forecast,
    )
    print(f"Complete local days: {result.days}; rows: {result.rows}")
    print(f"Daily forecasts: {result.csv_path}")
    print(f"Manifest: {result.manifest_path}")
    return 0


def _socal_rolling(args: argparse.Namespace) -> int:
    config = ProjectConfig.from_yaml(args.config)
    config.prepare_output_dirs()
    cache_path = (args.cache or (config.paths.cache_root / "socal_15min.parquet")).resolve()
    cache_manifest = verify_socal_cache_manifest(cache_path)
    real = pd.read_parquet(cache_path)

    daily_csv = args.daily_forecast_csv.resolve()
    daily_manifest_path = (
        args.daily_forecast_manifest.resolve()
        if args.daily_forecast_manifest is not None
        else daily_csv.with_name("all_test_daily_forecasts_manifest.json")
    )
    daily_forecasts, daily_manifest = load_authenticated_daily_forecasts(
        daily_csv,
        daily_manifest_path,
        expected_cache_sha256=str(cache_manifest["output_sha256"]),
    )
    daily_source = daily_manifest["source"]
    metrics_path = (
        args.forecast_metrics.resolve()
        if args.forecast_metrics is not None
        else Path(str(daily_source["forecast_metrics"])).resolve()
    )
    if Path(str(daily_source["forecast_metrics"])).resolve() != metrics_path:
        raise ValueError("daily forecast manifest is bound to a different metrics sidecar")
    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    export = metrics.get("dispatch_export")
    if not isinstance(export, dict):
        raise ValueError("forecast metrics sidecar has no authenticated dispatch export")
    authenticated_csv = metrics_path.parent / str(export.get("filename", ""))
    _, forecast_binding = _load_bound_forecast(
        authenticated_csv,
        metrics_path,
        cache_manifest=cache_manifest,
        cache_rows=len(real),
        expected_steps=config.forecast.horizon_steps,
    )
    if daily_source.get("target_split_intervals") != metrics["data_provenance"].get(
        "target_split_intervals"
    ):
        raise ValueError("daily forecast export and v5 sidecar use different splits")

    sizing = calibrate_socal_dispatch(
        real,
        config.dispatch,
        cache_manifest=cache_manifest,
        wind_capacity_kw=0.0,
        input_steps=config.forecast.input_steps,
        train_start=str(forecast_binding["train_start"]),
        train_end_exclusive=str(forecast_binding["train_end_exclusive"]),
    )
    base_dispatch = sizing.dispatch
    hybrid = build_hybrid_profile(
        real,
        HybridAssetAssumptions.from_dispatch_config(base_dispatch, wind_capacity_kw=0.0),
    )
    population = base_dispatch.population if args.population is None else args.population
    iterations = base_dispatch.iterations if args.iterations is None else args.iterations
    max_days = args.max_days
    if args.quick:
        population = min(population, 16)
        iterations = min(iterations, 24)
        max_days = 2 if max_days is None else max_days

    output = _new_result_directory(config.paths.results_root, args.name)
    rolling_seeds = (
        tuple(args.seeds)
        if args.seeds is not None
        else (
            (args.seed, args.seed + 10_000, args.seed + 20_000)
            if args.pcc_policy == "robust-v2"
            else (args.seed,)
        )
    )
    provenance = {
        "cache": str(cache_path),
        "cache_output_sha256": cache_manifest["output_sha256"],
        "selected_complete_months": cache_manifest["derivation"]["selected_complete_months"],
        "daily_forecast_csv": str(daily_csv),
        "daily_forecast_csv_sha256": daily_manifest["output"]["sha256"],
        "daily_forecast_manifest": str(daily_manifest_path),
        "daily_forecast_manifest_sha256": _file_sha256(daily_manifest_path),
        "forecast_metrics_sha256": _file_sha256(metrics_path),
        "forecast_binding": forecast_binding,
        "sizing_sha256": sizing.manifest["sizing_sha256"],
        "wind_source": "disabled because no confirmed SoCal wind measurement is available",
        "grid_export_price_fraction": base_dispatch.grid_export_price_fraction,
    }
    result = run_rolling_dispatch_sensitivity(
        forecasts=daily_forecasts,
        hybrid_profile=hybrid.frame,
        base_dispatch=base_dispatch,
        carbon_config=config.carbon,
        mpte_root=config.paths.mpte_root,
        output_dir=output,
        initial_carbon_factors=tuple(args.initial_carbon_factors),
        population=population,
        iterations=iterations,
        base_seed=args.seed,
        base_seeds=rolling_seeds,
        max_days=max_days,
        pcc_policy=(
            RollingPCCPolicy.robust_v2() if args.pcc_policy == "robust-v2" else RollingPCCPolicy()
        ),
        provenance=provenance,
        sizing_manifest=sizing.manifest,
    )
    print(f"Rolling sensitivity: {result.comparison_csv}")
    print(f"Rolling provenance: {result.provenance_path}")
    print(f"Rolling artifact manifest: {result.artifact_manifest_path}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="qingheng", description="Carbon-flow-aware microgrid simulation"
    )
    parser.add_argument(
        "--config", type=Path, default=_default_config_path(), help="YAML configuration"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    demo = subparsers.add_parser("demo", help="Run the built-in 24-hour benchmark")
    demo.add_argument("--name", default="builtin_demo", help="Result directory name")
    demo.add_argument("--quick", action="store_true", help="Use a short smoke benchmark")
    demo.add_argument("--population", type=int)
    demo.add_argument("--iterations", type=int)
    demo.add_argument("--seed", type=int)
    demo.set_defaults(handler=_demo)

    socal_dispatch = subparsers.add_parser(
        "socal-dispatch",
        help="Dispatch a SoCal day with explicit measured/synthetic asset provenance",
    )
    socal_dispatch.add_argument("--cache", type=Path, help="Prepared SoCal Parquet path")
    socal_dispatch.add_argument(
        "--asset-sizing",
        choices=("train-calibrated", "config"),
        default="train-calibrated",
        help="Use training-only SoCal sizing or literal dispatch config capacities",
    )
    socal_dispatch.add_argument(
        "--disable-battery", action="store_true", help="Disable battery for an ablation run"
    )
    socal_dispatch.add_argument(
        "--disable-hydrogen", action="store_true", help="Disable hydrogen for an ablation run"
    )
    socal_dispatch.add_argument(
        "--synthetic-wind-capacity-kw",
        type=float,
        default=0.0,
        help="Opt-in synthetic wind nameplate; defaults to zero for the SoCal evidence path",
    )
    socal_dispatch.add_argument("--start", help="UTC start for measured-profile dispatch")
    socal_dispatch.add_argument(
        "--forecast-csv", type=Path, help="Forecast CSV produced by train-forecast"
    )
    socal_dispatch.add_argument(
        "--forecast-metrics",
        type=Path,
        help="Forecast metrics sidecar; defaults to forecast_metrics.json beside the CSV",
    )
    socal_dispatch.add_argument("--name", default="socal_dispatch")
    socal_dispatch.add_argument("--quick", action="store_true")
    socal_dispatch.add_argument("--population", type=int)
    socal_dispatch.add_argument("--iterations", type=int)
    socal_dispatch.add_argument("--seed", type=int)
    socal_dispatch.set_defaults(handler=_socal_dispatch)

    prepare = subparsers.add_parser(
        "prepare-data", help="Build a read-only-derived SoCal 15-minute cache"
    )
    prepare.add_argument("--start", help="Inclusive UTC start timestamp")
    prepare.add_argument("--end", help="Exclusive UTC end timestamp")
    prepare.add_argument("--hash-mode", choices=("metadata", "full"), default="metadata")
    prepare.add_argument(
        "--source-resolution-seconds",
        type=int,
        default=60,
        help="Raw magnitude cadence to isolate and completeness-check (default: 60)",
    )
    prepare.add_argument(
        "--download-plan",
        type=Path,
        help="Versioned download plan to pin instead of the mutable top-level plan",
    )
    prepare.add_argument(
        "--unit-policy",
        choices=("socal_calibrated_kw", "metadata_w", "auto"),
        default="socal_calibrated_kw",
    )
    prepare.set_defaults(handler=_prepare_data)

    forecast = subparsers.add_parser(
        "train-forecast", help="Train residual CNN-LSTM-Attention with seasonal baselines"
    )
    forecast.add_argument("--cache", type=Path, help="Prepared SoCal Parquet path")
    forecast.add_argument("--name", default="forecast_socal", help="Result directory name")
    forecast.add_argument("--quick", action="store_true", help="One-epoch smoke run")
    forecast.add_argument("--epochs", type=int)
    forecast.set_defaults(handler=_train_forecast)

    export_days = subparsers.add_parser(
        "export-test-days",
        help="Export every complete held-out Los Angeles local day without retraining",
    )
    export_days.add_argument("--cache", type=Path, help="Prepared SoCal Parquet path")
    export_days.add_argument(
        "--forecast-metrics", type=Path, required=True, help="Authenticated v5 sidecar"
    )
    export_days.add_argument(
        "--artifact", type=Path, help="Saved model; defaults beside the metrics sidecar"
    )
    export_days.add_argument(
        "--output-dir", type=Path, help="Output directory; defaults beside the sidecar"
    )
    export_days.set_defaults(handler=_export_test_days)

    rolling = subparsers.add_parser(
        "rolling-dispatch",
        help="Run causal 48-hour/24-hour SoCal rolling dispatch with state carry",
    )
    rolling.add_argument("--cache", type=Path, help="Prepared SoCal Parquet path")
    rolling.add_argument("--daily-forecast-csv", type=Path, required=True)
    rolling.add_argument("--daily-forecast-manifest", type=Path)
    rolling.add_argument("--forecast-metrics", type=Path)
    rolling.add_argument("--name", default="socal_rolling_dispatch")
    rolling.add_argument(
        "--initial-carbon-factors",
        type=float,
        nargs="+",
        default=(0.0, 0.041, 0.570),
        help="Initial battery and hydrogen stored-carbon factors in kg/kWh",
    )
    rolling.add_argument("--population", type=int)
    rolling.add_argument("--iterations", type=int)
    rolling.add_argument("--seed", type=int, default=2029)
    rolling.add_argument(
        "--seeds",
        type=int,
        nargs="+",
        help=(
            "Base seeds for daily forecast-only optimizer restarts. Robust v2 defaults "
            "to seed, seed+10000, and seed+20000; legacy v1 defaults to --seed only."
        ),
    )
    rolling.add_argument("--max-days", type=int)
    rolling.add_argument(
        "--pcc-policy",
        choices=("legacy-v1", "robust-v2"),
        default="legacy-v1",
        help="Use legacy open-loop replay or causal reserve plus hourly PCC correction",
    )
    rolling.add_argument("--quick", action="store_true")
    rolling.set_defaults(handler=_socal_rolling)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    return int(args.handler(args))


if __name__ == "__main__":
    raise SystemExit(main())
