# 优化算法对比与收敛记录（2026-07-18）

## 正式派生结果

论文级算法图位于 `results/algorithm_comparison_final_v1/`。该目录使用与
`results/socal_dispatch_ablation_final_v4/full/` 完全相同的 v3 operational
预测、训练期容量标定、零风电、零上网收益和 `2025-06-17` 洛杉矶自然日。

三种算法统一采用：

- 个体数：`60`
- 迭代数：`160`
- 随机种子：`2026-2030`
- 每个 seed 的目标函数评价次数：`9,660`

新结果中 15 个优化运行的 score、cost 和 emissions 与 v4 full 逐项完全一致；
runtime 不作为可重复数值约束。

## 对比结果

| 算法 | 5-seed 目标均值 | 标准差 |
|---|---:|---:|
| PSO | 0.073564 | 0.002501 |
| 改进 WOA | 0.084412 | 0.002939 |
| 标准 WOA | 0.110048 | 0.004524 |

改进 WOA 相对标准 WOA 的均值下降为 `23.295%`，可以作为同族算法改进结果。
但 PSO 均值又比改进 WOA 低 `12.852%`，所以不能写成“改进 WOA 在所有传统
算法中整体最优”。样本量只有 5 个 seed，图中不添加显著性星号。

`optimizer_algorithm_comparison.png` 和同名 PDF 是双面板图：左图为 5 个 seed
的 best-so-far 中位数与四分位区间，右图为最终目标箱线图并叠加全部原始点。
原始长表为 `optimizer_convergence.csv`，不是从图片反推的数据。

## 结果治理

`optimizer_protocol.json` 记录实际生效的 population、iterations、seeds 和
history 语义，避免 CLI 的 `--quick` 或 override 与基础配置混淆。协议哈希为：

`10014ca8e95997325259ef02c05a3509a0a7f1cb89d470f42991becabd15cd86`

`optimizer_artifact_manifest.json` 固定 7 个算法表格/图形文件，其 manifest
哈希为：

`99ec780ade4a82c868d6a3f259ee0a261a43eb61b6814a912fc0b2eb951440ab`

审计还发现冻结的 v4 `no_storage` case 的 sizing manifest 继承了基础
`60/160/5-seed` 配置，但实际 `optimizer_runs.csv` 是 quick
`16/24/1-seed`。无储能日的三个优化器与确定性全量利用方案数值相同，因此
主表的确定性基线值不受影响；该 case 的旧算法分布不得用于收敛或随机性结论。
代码现以独立 applied protocol 记录真实预算，且新的消融 manifest 同时兼容
旧 82 文件集和带收敛证据的新文件集，不修改冻结 v4。
