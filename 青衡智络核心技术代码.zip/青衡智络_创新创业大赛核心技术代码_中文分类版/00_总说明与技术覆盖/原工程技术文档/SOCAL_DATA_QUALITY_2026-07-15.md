# SoCal data-quality audit (2026-07-15)

> Superseded for current decisions by
> [SOCAL_DATA_QUALITY_2026-07-16.md](SOCAL_DATA_QUALITY_2026-07-16.md). This file
> is retained only as the prior audit snapshot.

## Decision

The authenticated v3 cache remains unchanged. Its output SHA-256 is
`ee9f04399ee0a52d83308a45aa54af238ca1a64bb8bd3b51e341ed6ffbbda0e1`, and it
still verifies against its manifest. No actively downloaded 10-second file was
allowed to enter that cache.

The recovered 60-second August data is usable for the four selected forecasting
channels, but it is not yet promoted to the formal cache. Its batch marker still
declares server gaps in seven other magnitude channels, and the original 60-second
download plan was overwritten when the new 10-second plan started.

## Selected-channel audit

The audit isolates the exact `r60s` directories and reads only:

- `egauge_16-Mains_Power`
- `egauge_16-NorthPV_Power`
- `egauge_16-SouthPV_Power`
- `egauge_22-es1_Power`

The 15-minute quality thresholds are a usable-bin fraction of at least `0.999`, a
strict-complete-bin fraction of at least `0.999`, and no joint all-zero run longer
than 16 bins.

| UTC month | Rows | Usable fraction | Strict fraction | Maximum joint-zero run | Decision |
|---|---:|---:|---:|---:|---|
| 2024-09 | 2,880 / 2,880 | 1.000000 | 0.999653 | 424 | Reject |
| 2024-10 to 2025-07 | Complete calendar months | 1.000000 | 0.999628 to 0.999664 | 0 | Accept |
| 2025-08 | 2,976 / 2,976 | 1.000000 | 0.999664 | 0 | Selected channels pass; full batch evidence does not |

September contains 424 consecutive all-zero 15-minute bins from
`2024-09-01 00:00 UTC` through `2024-09-05 09:45 UTC`. This is not an aggregation
artifact: the newly completed 10-second September batches reproduce exactly the
same zero flags and interval, so September remains rejected.

Each selected August channel contains 44,639 unique valid minute samples instead
of 44,640. The only absent timestamp is `2025-08-31 23:59 UTC`; consequently only
the final 15-minute bin has 14 rather than 15 samples. There are no NaNs, duplicate
timestamps, invalid load-balance bins, missing usable bins, or joint-zero bins.

## Download state

The active plan was generated at `2026-07-15T02:36:54Z` and contains 96 magnitude
batches: eight channel groups for each of 12 months at 10-second resolution. At
the final audit checkpoint, all eight September and October groups were complete
and November had started. September fails the data-quality gate described above;
October passes with 2,976 rows, a usable fraction of `1.0`, a strict fraction of
`0.999664`, and no joint-zero or invalid-balance bins. Later months must not be
assessed until all eight groups for that month have success markers.

Disk capacity is not the current blocker: the plan estimates approximately
23.57 GiB and the D: drive had approximately 139 GiB free at the checkpoint.

Phasor status is separate from the forecasting path. A marker inventory finds
clean coverage for `2024-09` through `2024-11` and `2025-01` through `2025-05`.
December 2024 and June through August 2025 still contain gap markers. Because the
top-level plan now describes magnitudes only, this phasor inventory is diagnostic,
not a plan-authenticated completeness certificate.

## Pipeline fixes

The SoCal reader now filters source files by the requested raw cadence and ignores
`.partial` directories. The completeness gate applies the same cadence, so a
10-second plan can no longer certify a cache that actually reads 60-second files.
`prepare-data` accepts `--source-resolution-seconds` and an optional versioned
`--download-plan`.

The downloader now writes future plans to a versioned `plans/` archive before
updating the top-level `download_plan.json`. This prevents a later retry or cadence
change from destroying the plan lineage needed to rebuild an older cache.
The currently running 10-second plan was also archived explicitly as
`plans/download_plan_20260715T0236541436190000_eb0cd200b5d6.json` and was verified
through the cadence-scoped completeness API.
