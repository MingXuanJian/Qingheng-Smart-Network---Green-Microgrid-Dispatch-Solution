# 模块衔接现状

## 已具备

- 算法核心能够输出 CSV、JSON、PNG/PDF 图表和 artifact manifest；
- 桌面端能够导入结构化 CSV，保存项目数据并导出 HTML、CSV 和 Excel；
- 两端均采用 Python，便于后续以文件适配器或本地 API 连接。

## 尚未宣称完成

- 桌面端尚未直接调用算法核心的训练、优化和滚动调度 CLI；
- 桌面端当前核算器与算法核心的正式结果口径不是同一套实现；
- 尚未形成统一用户身份、实时采集协议、数据库或服务化部署。

因此，答辩和材料中可表述为“算法层与展示层均已形成可运行代码，具备接口化集成条件”，不宜写成“前后端已完成现场实时闭环部署”。

## 后续推荐接口

建议以只读结果适配器连接：

- `forecast_metrics.json` / `first_test_forecast.csv`：预测页；
- `dispatch_schedule.csv` / `metrics.json`：调度与 KPI 页；
- 碳流节点、路径和储能库存 JSON：碳流页；
- artifact manifest：来源与版本追溯页。
