# Multi-day rolling dispatch (2026-07-15, audited 2026-07-16)

> Superseded diagnostic: the corrected 209-day, robust-PCC, multi-restart and
> cross-day-green-inventory result is documented in
> `docs/ROLLING_DISPATCH_2026-07-16_V2.md` and stored in
> `results/socal_rolling_final_v2d/`. The numbers below remain the immutable v1
> failure record and must not be cited as the current rolling result.

## Status after the DST sizing fix

These artifacts were generated before the complete-local-day rule was tightened.
Their sizing manifest counts 211 training days and has SHA-256
`71e2354a413200a9fa0ff1a5fe87b00b308cddfc60e0f96f0531cfcd9456275c`.
The corrected rule excludes the 23-hour and 25-hour Los Angeles DST transition
days, leaving 209 training days and producing a new sizing hash. The discrete
battery, hydrogen, and PCC capacities are unchanged, but this rolling directory
is nevertheless a **pre-DST-fix diagnostic artifact** and is excluded from the
paper's formal result table. A formal rolling result must be rerun under the
corrected sizing manifest
`3c0a5cb04698beb7e89652b8d0964675d3a058fe3a9deaeecdba0f0b0fbe9688`
rather than relabeling this directory.

## Scope

The extension exports 44 complete held-out Los Angeles local days from the
authenticated v5 forecast artifact. It then executes 43 rolling decisions from
`2025-06-17` through `2025-07-29`: optimize a 48-hour horizon and apply only the
first 24 hours. The second forecast day uses causal seven-day persistence; future
actual measurements are not used during optimization.

Battery energy, hydrogen energy, and both carbon inventories carry across day
boundaries. The optimizer is PSO with 60 particles and 160 iterations because PSO
was best in the single-day benchmark; the corrected v4 rerun preserves that
ranking. This does not broaden the improved WOA claim beyond its comparison with
standard WOA.

Each day currently uses one deterministic PSO realization (`2029 + day index`).
The same seed sequence is reused across the three carbon-factor cases, but no
multi-seed uncertainty interval is available. The 48-hour plan also returns both
energy stores to their opening energy at the end of its lookahead. This cyclic
terminal boundary is useful against end effects but can suppress longer-duration
hydrogen value, so factor rankings are not treated as comparative evidence.

Energy and carbon inventories are carried exactly. Green-label inventory is not:
the daily AC carbon-accounting call currently reinitializes that auxiliary
inventory. Rolling green-self-use metrics are therefore deliberately omitted
rather than presented as cross-day results.

## Carbon-factor sensitivity

| Initial factor (kg/kWh) | Actual cost | Copper-plate load carbon (kg) | AC load allocation (kg) | Proxy deviation | Actual PCC feasible |
|---:|---:|---:|---:|---:|---|
| 0.000 | 2,646.05 | 3,091.13 | 3,270.66 | 5.49% | No |
| 0.041 | 2,930.15 | 3,251.59 | 3,482.16 | 6.62% | No |
| 0.570 | 2,832.18 | 3,269.16 | 3,452.78 | 5.32% | No |

All energy-carry residuals are exactly zero. The maximum carbon-carry residual is
`7.11e-15 kg`; copper-plate and AC carbon conservation residuals remain below
`2e-13 kg`.

## Feasibility finding

Every planned 48-hour schedule passed the forecast-condition network screen, and
every actual replay converged physically on the IEEE33 model. Across the three
sensitivity runs, voltage extrema remain between `0.99307` and `1.03701 pu`.

However, forecast error causes actual loss-adjusted PCC-limit violations:

- factor `0.000`: `2025-06-28`, `2025-07-19`
- factor `0.041`: `2025-06-20`
- factor `0.570`: `2025-06-28`, `2025-07-04`, `2025-07-27`

Therefore the rolling result does not pass the operational acceptance criterion.
Together with its pre-DST-fix sizing provenance, this makes it a diagnostic
sensitivity study, not evidence that the multi-day policy is deployable or that
one initial carbon factor is superior. The next formal rerun needs the corrected
209-day sizing manifest plus a forecast-error reserve margin or an intraday
corrective re-optimization that enforces the loss-adjusted PCC constraint during
actual replay.

The canonical IEEE33 data still has no branch ampacity ratings, so branch current
is diagnostic only and cannot support a thermal-feasibility claim.

## Artifacts

- `results/forecast_rebuilt_full_final_v3/all_test_daily_forecasts.csv`
- `results/forecast_rebuilt_full_final_v3/all_test_daily_forecasts_manifest.json`
- `results/socal_rolling_final_v1/rolling_carbon_sensitivity.csv`
- `results/socal_rolling_final_v1/rolling_carbon_sensitivity.json`
- `results/socal_rolling_final_v1/rolling_provenance.json`
- `results/socal_rolling_final_v1/rolling_artifact_manifest.json`

Every case summary and the combined JSON now contain an explicit `acceptance`
object. It requires both the dispatch-model lossless PCC constraint and the AC
loss-adjusted slack/PCC check. All three cases are marked `failed`. The artifact
manifest hashes every result file so post-run edits or stale extra files are
detectable without rerunning the 43-day optimization. These integrity checks
authenticate the diagnostic artifact as generated; they do not upgrade its old
211-day sizing provenance to the corrected formal basis.

The completed v1 run predates the new carbon-config and IEEE33 structural fields
in rolling provenance, so its original scenario hash alone is not a complete
configuration fingerprint. The new artifact manifest freezes the current v1
bytes; future rolling runs additionally bind the carbon configuration, network
structure, forecast-manifest hash, and forecast-metrics hash in provenance.
