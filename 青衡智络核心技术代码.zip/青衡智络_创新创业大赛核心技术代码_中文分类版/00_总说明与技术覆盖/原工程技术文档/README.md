# 青衡智络 iCAN 完整代码包

本代码包将项目组现有 **iCAN 通用版代码**整理为两个边界清晰、可分别运行的工程：

1. `algorithm_core/`：数据质量审计、预测、BFS/DFS 碳流追踪、储能碳库存、改进 WOA/PSO、单日与 43 天滚动调度、网络校核及测试；
2. `desktop_app/`：微电网运行数据导入、能碳核算、情景试算、图表展示、HTML/CSV/Excel 报告导出和 Windows 桌面界面。

## 重要说明

两个工程当前是**独立可运行模块**。桌面端没有在内部直接调用深度预测与滚动调度训练流程，也不能把桌面端内置合成数据的结果当作项目正式实验指标。正式数据、模型权重、企业材料和关键结果表继续由证据包单独保管，不建议提交到公开 GitHub。

本包仅保留 iCAN 通用版代码，不混入其他赛事定制内容或无关论文材料。

## 快速运行算法核心

```bash
cd algorithm_core
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -e ".[dev]"
python scripts/generate_demo_data.py
python scripts/run_core_demo.py
pytest -q
```

需要深度学习模型时安装：

```bash
pip install -e ".[all]"
```

## 快速运行桌面端

```bash
cd desktop_app
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python run.py
```

## GitHub 上传建议

- 作为一个完整仓库：直接上传本目录；根目录工作流会分别检查两个工程。
- 拆成两个仓库：分别上传 `algorithm_core/` 与 `desktop_app/`；算法仓库建议命名为 `qingheng-microgrid-carbon-dispatch`。
- 初次上传建议设为 **Private**，先核对数据许可、论文公开状态、专利披露范围和团队署名。

## 完整性核验

```bash
python tools/verify_all.py
```

该命令按 `PACKAGE_MANIFEST.csv` 核验文件大小与 SHA-256。各子工程也有自己的 `SOURCE_MANIFEST.csv` 和核验脚本。

## 核验结果

- 算法核心：32 个原始源文件全部保留且与原工程哈希一致；147 项测试通过，10 项因外部数据/PyArrow 条件按设计跳过；核心 demo 调度可行、碳守恒通过。
- 桌面端：32 个原始 Python 文件全部保留；21 项测试通过，5 项因当前环境未安装 PySide6 按设计跳过；Python 编译通过。

详见 `PACKAGE_INVENTORY.md`、两个子工程的 `PACKAGE_REPORT.md` 和 `INTEGRATION_STATUS.md`。
