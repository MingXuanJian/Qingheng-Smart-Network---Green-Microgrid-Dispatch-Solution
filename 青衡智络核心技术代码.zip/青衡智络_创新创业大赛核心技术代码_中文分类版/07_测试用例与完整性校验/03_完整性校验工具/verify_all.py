"""Verify all static files in the complete iCAN code package."""
from __future__ import annotations
from pathlib import Path
from hashlib import sha256
import csv

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "PACKAGE_MANIFEST.csv"

def digest(path: Path) -> str:
    h = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> int:
    failures = []
    checked = 0
    with MANIFEST.open("r", encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            checked += 1
            path = ROOT / row["path"]
            if not path.is_file():
                failures.append(f"missing: {row['path']}")
            elif path.stat().st_size != int(row["size_bytes"]):
                failures.append(f"size mismatch: {row['path']}")
            elif digest(path) != row["sha256"]:
                failures.append(f"sha256 mismatch: {row['path']}")
    if failures:
        print("Complete package verification failed:")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print(f"Complete package verification passed: {checked} files")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
