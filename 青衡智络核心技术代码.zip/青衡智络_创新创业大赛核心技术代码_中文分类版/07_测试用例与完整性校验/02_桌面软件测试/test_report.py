import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from openpyxl import load_workbook

from microgrid_app.models import CarbonParams, ProjectContext
from microgrid_app.reference_data import generate_reference_data
from microgrid_app.report import build_html_report, export_dataset


class ReportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.params = CarbonParams(report_output_dir=str(self.base), grid_export_limit_kw=50)
        self.project = ProjectContext(project_name="测试项目", data_source="内置计算验证数据")

    def tearDown(self):
        self.tmp.cleanup()

    def test_html_report_contains_required_context(self):
        html = build_html_report(generate_reference_data(), self.params, self.project)
        for text in [
            "测试项目",
            "内置计算验证数据",
            "数据质量结果",
            "经济收益分项",
            "上网售电收入",
            "电网排放因子",
            "计算边界",
        ]:
            self.assertIn(text, html)

    def test_export_html_csv_and_excel(self):
        data = generate_reference_data()
        html = export_dataset(data, "html", self.base, self.params, self.project)
        csv = export_dataset(data, "csv", self.base, self.params, self.project)
        xlsx = export_dataset(data, "excel", self.base, self.params, self.project)
        self.assertTrue(html.exists())
        self.assertTrue(csv.exists())
        self.assertTrue(xlsx.exists())
        workbook = load_workbook(xlsx, read_only=True)
        for sheet in ["运行数据", "派生指标", "KPI汇总", "参数配置", "数据质量问题", "情景试算结果"]:
            self.assertIn(sheet, workbook.sheetnames)
        workbook.close()

    def test_empty_data_can_build_html_but_not_date_filtered_export_is_ui_guard(self):
        html = build_html_report(generate_reference_data(0), self.params, self.project)
        self.assertIn("记录数：0 条", html)


if __name__ == "__main__":
    unittest.main()
