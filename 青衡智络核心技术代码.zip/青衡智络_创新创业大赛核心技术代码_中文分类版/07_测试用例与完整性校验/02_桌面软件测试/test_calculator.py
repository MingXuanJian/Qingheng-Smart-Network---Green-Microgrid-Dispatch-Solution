import unittest

import pandas as pd

from microgrid_app.calculator import (
    compute_dashboard_kpis,
    compute_economic_breakdown,
    recalculate_derived_columns,
    run_scenario,
    trace_renewable_energy,
)
from microgrid_app.models import CarbonParams
from microgrid_app.reference_data import INPUT_COLUMNS, generate_reference_data


def sample_data(rows):
    return pd.DataFrame(rows, columns=INPUT_COLUMNS)


class CalculatorTests(unittest.TestCase):
    def test_dashboard_kpis_have_expected_keys(self):
        kpis = compute_dashboard_kpis(generate_reference_data(), CarbonParams())
        for key in ["绿电消费占比", "单位用电碳强度", "储能供能占比", "年减排量", "经济收益"]:
            self.assertIn(key, kpis)
        self.assertGreater(kpis["年减排量"], 0)

    def test_reduction_uses_configured_factor(self):
        data = generate_reference_data()
        base = recalculate_derived_columns(data, CarbonParams(grid_emission_factor=0.5))
        doubled = recalculate_derived_columns(data, CarbonParams(grid_emission_factor=1.0))
        self.assertAlmostEqual(
            doubled["碳减排量(kgCO2e)"].sum(),
            base["碳减排量(kgCO2e)"].sum() * 2,
            delta=0.01,
        )

    def test_green_storage_requires_renewable_charge(self):
        data = sample_data(
            [
                ["2025-01-01 10:00", 20, 10, -10, 0],
                ["2025-01-01 11:00", 0, 5, 5, 0],
            ]
        )
        trace = trace_renewable_energy(data, CarbonParams(storage_roundtrip_efficiency=0.9))
        self.assertEqual(trace.iloc[0]["绿色储能供电量(kWh)"], 0)
        self.assertEqual(trace.iloc[1]["绿色储能供电量(kWh)"], 5)
        self.assertGreaterEqual(trace["绿色储能台账余额(kWh)"].min(), 0)

    def test_unknown_initial_storage_is_not_green(self):
        data = sample_data([["2025-01-01 10:00", 0, 5, 5, 0]])
        trace = trace_renewable_energy(data)
        self.assertEqual(trace.iloc[0]["绿色储能供电量(kWh)"], 0)
        self.assertEqual(trace.iloc[0]["绿电消费量(kWh)"], 0)

    def test_green_supply_does_not_exceed_load(self):
        data = sample_data(
            [
                ["2025-01-01 10:00", 30, 10, -20, 0],
                ["2025-01-01 11:00", 0, 5, 20, -15],
            ]
        )
        trace = trace_renewable_energy(data)
        self.assertTrue((trace["绿电消费量(kWh)"] <= data["负荷用电量(kWh)"]).all())

    def test_sell_price_changes_economic_breakdown(self):
        data = sample_data([["2025-01-01 10:00", 30, 10, 0, -20]])
        low = compute_economic_breakdown(data, CarbonParams(sell_price=0.2))
        high = compute_economic_breakdown(data, CarbonParams(sell_price=0.8))
        self.assertGreater(high["上网售电收入"], low["上网售电收入"])
        self.assertGreater(high["综合收益"], low["综合收益"])

    def test_grid_export_limit_controls_export_and_curtailment(self):
        data = sample_data([["2025-01-01 10:00", 100, 0, 0, -100]])
        blocked = run_scenario(data, CarbonParams(storage_capacity=0, wind_capacity=0, grid_export_limit_kw=0))
        allowed = run_scenario(data, CarbonParams(storage_capacity=0, wind_capacity=0, grid_export_limit_kw=30))
        self.assertEqual(blocked["上网电量"], 0)
        self.assertGreater(allowed["上网电量"], 0)
        self.assertLess(allowed["弃电量"], blocked["弃电量"])

    def test_scenario_returns_complete_result(self):
        result = run_scenario(generate_reference_data(), CarbonParams(grid_export_limit_kw=200))
        keys = [
            "绿电消费占比",
            "年碳减排量",
            "上网电量",
            "弃电量",
            "弃电率",
            "储能供能占比",
            "单位用电碳强度",
            "避免购电价值",
            "售电收入",
            "碳价值",
            "综合收益",
        ]
        for key in keys:
            self.assertIn(key, result)

    def test_empty_and_single_record_data_are_supported(self):
        empty = sample_data([])
        single = sample_data([["2025-01-01 10:00", 10, 10, 0, 0]])
        self.assertEqual(run_scenario(empty)["绿电消费占比"], 0)
        self.assertGreaterEqual(run_scenario(single)["绿电消费占比"], 0)


if __name__ == "__main__":
    unittest.main()
