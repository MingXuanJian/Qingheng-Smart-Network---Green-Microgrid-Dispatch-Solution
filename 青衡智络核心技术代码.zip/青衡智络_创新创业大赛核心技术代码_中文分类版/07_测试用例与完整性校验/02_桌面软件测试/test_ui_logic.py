import os
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from microgrid_app.config import ConfigError, backup_broken_config, load_params, save_params
from microgrid_app.models import CarbonParams
from microgrid_app.reference_data import generate_reference_data

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

try:
    from PySide6.QtWidgets import QApplication
    from microgrid_app.ui.icon_utils import generate_app_icon
    from microgrid_app.ui.main_window import MainWindow
    from microgrid_app.ui.theme import format_unit
    from microgrid_app.ui.workspace_window import WorkspaceWindow
except ImportError:
    QApplication = None


class ConfigTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.base = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_config_roundtrip(self):
        path = self.base / "params.json"
        params = CarbonParams(carbon_price=88.0, emission_factor_source="测试来源", report_output_dir=str(self.base))
        save_params(params, path)
        loaded = load_params(path)
        self.assertEqual(loaded.carbon_price, 88.0)
        self.assertEqual(loaded.emission_factor_source, "测试来源")

    def test_broken_config_is_reported_and_can_be_backed_up(self):
        path = self.base / "params.json"
        path.write_text("{broken", encoding="utf-8")
        with self.assertRaises(ConfigError):
            load_params(path)
        backup = backup_broken_config(path)
        self.assertIsNotNone(backup)
        self.assertTrue(backup.exists())


@unittest.skipIf(QApplication is None, "PySide6 is not installed")
class UiLogicTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.app = QApplication.instance() or QApplication([])

    def tearDown(self):
        self.tmp.cleanup()

    def test_icon_generation(self):
        png, ico = generate_app_icon(self.base / "app_icon.png", self.base / "app_icon.ico", size=128)
        self.assertTrue(png.exists())
        self.assertTrue(ico.exists())

    def test_kpi_unit_format(self):
        self.assertEqual(format_unit("绿电消费占比"), "%")
        self.assertIn("万元", format_unit("经济收益"))

    def test_clean_project_script_is_scoped(self):
        script = Path.cwd() / "scripts" / "clean_project.bat"
        content = script.read_text(encoding="utf-8")
        self.assertIn(".pytest_cache", content)
        self.assertNotIn("rmdir /s /q outputs", content.lower())

    def test_workspace_requires_user_input_and_emits_project_name(self):
        window = WorkspaceWindow()
        self.assertEqual(window.project.placeholderText(), "请输入项目名称")
        received = []
        window.workspace_opened.connect(received.append)
        window.project.setText("测试项目")
        window._submit()
        self.assertEqual(received, ["测试项目"])
        window.close()

    def test_main_window_initializes_and_syncs_data(self):
        data = generate_reference_data()
        params = CarbonParams(report_output_dir=str(self.base))
        with patch("microgrid_app.ui.main_window.load_initial_data", return_value=(data, "内置计算验证数据")), patch(
            "microgrid_app.ui.main_window.save_project_context"
        ):
            window = MainWindow("测试项目", params)
            self.assertEqual(len(window.pages), 7)
            changed = generate_reference_data(3)
            window._set_data(changed, "用户导入文件：test.csv")
            self.assertEqual(window.dashboard.data_source, "用户导入文件：test.csv")
            self.assertEqual(len(window.analysis_page.data), 3)
            window.close()


if __name__ == "__main__":
    unittest.main()
