import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

import pandas as pd

from microgrid_app.data_io import DataValidationError, load_csv, load_initial_data, save_csv, save_project_data
from microgrid_app.models import CarbonParams
from microgrid_app.reference_data import INPUT_COLUMNS, generate_reference_data


class DataIoTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.base = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def _write(self, name, rows, columns=INPUT_COLUMNS):
        path = self.base / name
        pd.DataFrame(rows, columns=columns).to_csv(path, index=False, encoding="utf-8-sig")
        return path

    def test_csv_roundtrip(self):
        path = self.base / "data.csv"
        save_csv(generate_reference_data(), path)
        loaded = load_csv(path)
        self.assertEqual(len(loaded), len(generate_reference_data()))
        self.assertIn("绿电消费占比(%)", loaded.columns)

    def test_missing_fields_are_reported(self):
        path = self._write("missing.csv", [["2025-01-01 00:00", 1]], ["时间", "光伏发电量(kWh)"])
        with self.assertRaisesRegex(DataValidationError, "负荷用电量"):
            load_csv(path)

    def test_invalid_time_and_numeric_values_are_reported(self):
        path = self._write("invalid.csv", [["bad-time", "x", 2, 0, 0]])
        with self.assertRaisesRegex(DataValidationError, "时间字段"):
            load_csv(path)
        path = self._write("invalid-number.csv", [["2025-01-01 00:00", "x", 2, 0, 0]])
        with self.assertRaisesRegex(DataValidationError, "第 2 行"):
            load_csv(path)

    def test_negative_pv_and_load_are_rejected(self):
        path = self._write("negative.csv", [["2025-01-01 00:00", -1, 2, 0, 0]])
        with self.assertRaisesRegex(DataValidationError, "不得为负数"):
            load_csv(path)

    def test_time_and_balance_issues_are_kept_as_quality_warnings(self):
        path = self._write(
            "quality.csv",
            [
                ["2025-01-01 03:00", 10, 20, 0, 0],
                ["2025-01-01 00:00", 0, 20, 0, 20],
                ["2025-01-01 00:00", 0, 20, 0, 20],
            ],
        )
        data = load_csv(path)
        issues = data.attrs["quality_issues"]
        self.assertTrue(any("重复时间" in issue for issue in issues))
        self.assertTrue(any("未按升序" in issue for issue in issues))
        self.assertTrue(any("能量平衡" in issue for issue in issues))

    def test_saved_project_data_is_loaded_on_restart(self):
        project_path = self.base / "project_data.csv"
        with patch("microgrid_app.data_io.PROJECT_DATA_FILE", project_path):
            save_project_data(generate_reference_data(), CarbonParams())
            data, source = load_initial_data(CarbonParams())
        self.assertEqual(source, "已保存的项目数据")
        self.assertEqual(len(data), len(generate_reference_data()))

    def test_missing_file_is_reported(self):
        with self.assertRaises(FileNotFoundError):
            load_csv(self.base / "missing.csv")


if __name__ == "__main__":
    unittest.main()
