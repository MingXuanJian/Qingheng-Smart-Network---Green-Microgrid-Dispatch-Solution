from pathlib import Path

import pytest

from qingheng.config import CarbonConfig, DispatchConfig, ForecastConfig, ProjectConfig


def test_default_config_loads() -> None:
    project = Path(__file__).resolve().parents[1]
    config = ProjectConfig.from_yaml(project / "configs" / "default.yaml")
    assert config.dispatch.horizon_steps == 24
    assert sum(config.dispatch.objective_weights.values()) == pytest.approx(1.0)
    assert config.dispatch.terminal_tolerance == pytest.approx(0.005)
    assert config.dispatch.grid_export_price_fraction == 0.0
    assert config.paths.socal_root.is_absolute()


@pytest.mark.parametrize(
    "overrides",
    [
        {"horizon_steps": 0},
        {"population": 3},
        {"battery_charge_efficiency": 0.0},
        {"battery_min_soc": 0.6, "battery_initial_soc": 0.5},
        {"hydrogen_initial_soc": 1.1},
        {"grid_import_limit_kw": -1.0},
        {"grid_export_price_fraction": 1.01},
        {"terminal_tolerance": 1.01},
        {"terminal_repair_steps": 0},
        {"battery_throughput_cost_per_kwh": -0.1},
        {"battery_enabled": False},
        {"hydrogen_enabled": False},
        {"objective_weights": {"cost": float("nan"), "curtailment": 0.5, "emissions": 0.5}},
    ],
)
def test_dispatch_config_rejects_nonphysical_parameters(overrides: dict[str, object]) -> None:
    with pytest.raises(ValueError):
        DispatchConfig(**overrides)


def test_carbon_config_rejects_negative_or_nonfinite_values() -> None:
    with pytest.raises(ValueError):
        CarbonConfig(grid_kg_per_kwh=-0.1)
    with pytest.raises(ValueError):
        CarbonConfig(tolerance_kw=float("inf"))
    with pytest.raises(ValueError):
        CarbonConfig(battery_initial_stored_carbon_kg_per_kwh=-0.1)


def test_dispatch_config_accepts_explicitly_disabled_devices() -> None:
    config = DispatchConfig(
        battery_enabled=False,
        battery_capacity_kwh=0.0,
        battery_power_kw=0.0,
        hydrogen_enabled=False,
        hydrogen_capacity_kwh=0.0,
        hydrogen_power_kw=0.0,
    )

    assert not config.battery_enabled
    assert not config.hydrogen_enabled


@pytest.mark.parametrize(
    "overrides",
    [
        {"resample_minutes": 17},
        {"dispatch_minutes": 50},
        {"input_steps": 95},
        {"horizon_steps": 97},
        {"hidden_size": 62},
        {"kernel_size": 4},
        {"dropout": 1.0},
        {"learning_rate": float("nan")},
    ],
)
def test_forecast_config_rejects_incompatible_parameters(overrides: dict[str, object]) -> None:
    with pytest.raises(ValueError):
        ForecastConfig(**overrides)
