from __future__ import annotations

import json
from pathlib import Path

from qingheng.data import audit_download_completeness


def _write_marker(root: Path, data_type: str, batch_id: str, **payload: object) -> None:
    path = root / data_type / batch_id / "_SUCCESS.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


def test_completeness_requires_every_planned_batch_for_each_modality(tmp_path: Path) -> None:
    batches = [
        {"batch_id": "mag_sep", "data_type": "magnitudes", "start": "2024-09-01"},
        {"batch_id": "pha_sep_1", "data_type": "phasors", "start": "2024-09-01"},
        {"batch_id": "pha_sep_2", "data_type": "phasors", "start": "2024-09-02"},
        {"batch_id": "mag_oct", "data_type": "magnitudes", "start": "2024-10-01"},
        {"batch_id": "pha_oct", "data_type": "phasors", "start": "2024-10-01"},
        {"batch_id": "mag_nov", "data_type": "magnitudes", "start": "2024-11-01"},
        {"batch_id": "pha_nov", "data_type": "phasors", "start": "2024-11-01"},
    ]
    (tmp_path / "download_plan.json").write_text(json.dumps({"batches": batches}), encoding="utf-8")
    for data_type, batch_id in (
        ("magnitudes", "mag_sep"),
        ("phasors", "pha_sep_1"),
        ("phasors", "pha_sep_2"),
        ("magnitudes", "mag_oct"),
        ("phasors", "pha_oct"),
        ("magnitudes", "mag_nov"),
        ("phasors", "pha_nov"),
    ):
        _write_marker(tmp_path, data_type, batch_id, status="completed")

    report = audit_download_completeness(tmp_path)

    assert report.complete_months == ("2024-09", "2024-10", "2024-11")
    assert report.longest_contiguous_run == report.complete_months


def test_server_gaps_and_missing_markers_fail_closed(tmp_path: Path) -> None:
    batches = [
        {"batch_id": "mag_sep", "data_type": "magnitudes", "start": "2024-09-01"},
        {"batch_id": "mag_oct", "data_type": "magnitudes", "start": "2024-10-01"},
        {"batch_id": "mag_nov", "data_type": "magnitudes", "start": "2024-11-01"},
        {"batch_id": "mag_dec", "data_type": "magnitudes", "start": "2024-12-01"},
    ]
    (tmp_path / "download_plan.json").write_text(json.dumps({"batches": batches}), encoding="utf-8")
    _write_marker(tmp_path, "magnitudes", "mag_sep", status="completed")
    _write_marker(
        tmp_path,
        "magnitudes",
        "mag_oct",
        status="completed_with_server_gaps",
        server_gaps=["channel-x"],
    )
    _write_marker(tmp_path, "magnitudes", "mag_dec", status="completed")

    report = audit_download_completeness(tmp_path, required_data_types=("magnitudes",))

    assert report.complete_months == ("2024-09", "2024-12")
    assert report.contiguous_complete_runs == (("2024-09",), ("2024-12",))
    by_month = {month.month: month for month in report.months}
    assert not by_month["2024-10"].complete
    assert by_month["2024-10"].status_counts == {"completed_with_server_gaps": 1}
    assert by_month["2024-11"].status_counts == {"missing_marker": 1}


def test_completeness_is_scoped_to_source_resolution(tmp_path: Path) -> None:
    batches = [
        {
            "batch_id": "mag_sep_r60s",
            "data_type": "magnitudes",
            "start": "2024-09-01",
            "resolution_seconds": 60,
        },
        {
            "batch_id": "mag_sep_r10s_g01-of-02",
            "data_type": "magnitudes",
            "start": "2024-09-01",
            "resolution_seconds": 10,
        },
        {
            "batch_id": "mag_sep_r10s_g02-of-02",
            "data_type": "magnitudes",
            "start": "2024-09-01",
            "resolution_seconds": 10,
        },
    ]
    (tmp_path / "download_plan.json").write_text(
        json.dumps({"batches": batches}), encoding="utf-8"
    )
    _write_marker(tmp_path, "magnitudes", "mag_sep_r60s", status="completed")
    _write_marker(tmp_path, "magnitudes", "mag_sep_r10s_g01-of-02", status="completed")

    report_60s = audit_download_completeness(
        tmp_path,
        required_data_types=("magnitudes",),
        resolution_seconds=60,
    )
    report_10s = audit_download_completeness(
        tmp_path,
        required_data_types=("magnitudes",),
        resolution_seconds=10,
    )

    assert report_60s.complete_months == ("2024-09",)
    assert report_60s.resolution_seconds == 60
    assert report_10s.complete_months == ()
    assert report_10s.months[0].planned_by_type == {"magnitudes": 2}


def test_completeness_can_pin_a_versioned_plan(tmp_path: Path) -> None:
    current = {
        "batches": [
            {
                "batch_id": "current_r10s",
                "data_type": "magnitudes",
                "start": "2025-01-01",
                "resolution_seconds": 10,
            }
        ]
    }
    archived = {
        "batches": [
            {
                "batch_id": "archived_r60s",
                "data_type": "magnitudes",
                "start": "2024-12-01",
                "resolution_seconds": 60,
            }
        ]
    }
    current_path = tmp_path / "download_plan.json"
    archived_path = tmp_path / "plans" / "download_plan_legacy.json"
    current_path.write_text(json.dumps(current), encoding="utf-8")
    archived_path.parent.mkdir()
    archived_path.write_text(json.dumps(archived), encoding="utf-8")
    _write_marker(tmp_path, "magnitudes", "archived_r60s", status="completed")

    report = audit_download_completeness(
        tmp_path,
        required_data_types=("magnitudes",),
        resolution_seconds=60,
        download_plan_path=archived_path,
    )

    assert report.plan_path == archived_path.resolve()
    assert report.complete_months == ("2024-12",)
