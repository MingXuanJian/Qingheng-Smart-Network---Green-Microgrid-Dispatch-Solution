from dataclasses import replace

import numpy as np
import pandas as pd
import pytest

from qingheng.config import DispatchConfig
from qingheng.scenario import make_builtin_scenario, make_profile_dispatch_inputs


def test_builtin_scenario_is_reproducible_and_nonnegative() -> None:
    config = replace(DispatchConfig(), horizon_steps=24)
    first = make_builtin_scenario(config, seed=3)
    second = make_builtin_scenario(config, seed=3)
    np.testing.assert_allclose(first.load_kw, second.load_kw)
    assert np.all(first.load_kw >= 0)
    assert np.max(first.pv_available_kw) > 0


def test_profile_dispatch_inputs_aggregate_15min_power_as_hourly_mean() -> None:
    index = pd.date_range("2025-01-01", periods=96, freq="15min", tz="UTC")
    frame = pd.DataFrame(
        {
            "load_kw": np.full(96, 100.0),
            "pv_kw": np.arange(96, dtype=float),
            "wind_kw": np.full(96, 20.0),
            "fuel_cell_kw": np.full(96, 10.0),
        },
        index=index,
    )
    inputs = make_profile_dispatch_inputs(
        frame, DispatchConfig(), fixed_generation_column="fuel_cell_kw"
    )
    assert inputs.horizon == 24
    assert inputs.load_kw[0] == 100.0
    assert np.all(inputs.sell_price_per_kwh == 0.0)
    assert inputs.pv_available_kw[0] == 1.5


def test_profile_dispatch_inputs_reject_incomplete_or_duplicate_timestamps() -> None:
    complete = pd.date_range("2025-01-01", periods=96, freq="15min", tz="UTC")
    frame = pd.DataFrame(
        {"load_kw": 100.0, "pv_kw": 20.0, "wind_kw": 10.0},
        index=complete,
    )

    with pytest.raises(ValueError, match="exactly 96"):
        make_profile_dispatch_inputs(frame.iloc[:-1], DispatchConfig())

    duplicate = complete.to_list()
    duplicate[1] = duplicate[0]
    duplicate_frame = frame.copy()
    duplicate_frame.index = pd.DatetimeIndex(duplicate)
    with pytest.raises(ValueError, match="duplicate"):
        make_profile_dispatch_inputs(duplicate_frame, DispatchConfig())

    gap_index = pd.date_range("2025-01-01", periods=97, freq="15min", tz="UTC").delete(40)
    gap_frame = frame.copy()
    gap_frame.index = gap_index
    with pytest.raises(ValueError, match="continuous"):
        make_profile_dispatch_inputs(gap_frame, DispatchConfig())


def test_profile_dispatch_inputs_require_four_samples_per_clock_hour() -> None:
    index = pd.date_range("2025-01-01 00:15", periods=96, freq="15min", tz="UTC")
    frame = pd.DataFrame(
        {"load_kw": 100.0, "pv_kw": 20.0, "wind_kw": 10.0},
        index=index,
    )
    with pytest.raises(ValueError, match="exactly four"):
        make_profile_dispatch_inputs(frame, DispatchConfig())


def test_profile_tariff_uses_california_local_hour() -> None:
    # 02:00 UTC in January is 18:00 PST on the previous day, an evening peak hour.
    index = pd.date_range("2025-01-02 02:00", periods=96, freq="15min", tz="UTC")
    frame = pd.DataFrame(
        {"load_kw": 100.0, "pv_kw": 20.0, "wind_kw": 10.0},
        index=index,
    )
    inputs = make_profile_dispatch_inputs(frame, DispatchConfig())
    assert inputs.buy_price_per_kwh[0] == pytest.approx(1.18)


def test_profile_dispatch_inputs_reject_negative_power_instead_of_clipping() -> None:
    index = pd.date_range("2025-01-01", periods=96, freq="15min", tz="UTC")
    frame = pd.DataFrame(
        {"load_kw": 100.0, "pv_kw": 20.0, "wind_kw": 10.0},
        index=index,
    )
    frame.iloc[5, frame.columns.get_loc("pv_kw")] = -1.0

    with pytest.raises(ValueError, match="non-negative"):
        make_profile_dispatch_inputs(frame, DispatchConfig())


def test_profile_dispatch_inputs_reject_duplicate_or_reused_role_columns() -> None:
    index = pd.date_range("2025-01-01", periods=96, freq="15min", tz="UTC")
    duplicate_columns = pd.DataFrame(
        np.column_stack(
            [
                np.full(96, 100.0),
                np.full(96, 20.0),
                np.full(96, 10.0),
                np.full(96, 11.0),
            ]
        ),
        index=index,
        columns=["load_kw", "pv_kw", "wind_kw", "wind_kw"],
    )
    with pytest.raises(ValueError, match="unique"):
        make_profile_dispatch_inputs(duplicate_columns, DispatchConfig())

    frame = pd.DataFrame(
        {"load_kw": 100.0, "pv_kw": 20.0, "wind_kw": 10.0},
        index=index,
    )
    with pytest.raises(ValueError, match="distinct"):
        make_profile_dispatch_inputs(
            frame,
            DispatchConfig(),
            load_column="load_kw",
            pv_column="load_kw",
        )
