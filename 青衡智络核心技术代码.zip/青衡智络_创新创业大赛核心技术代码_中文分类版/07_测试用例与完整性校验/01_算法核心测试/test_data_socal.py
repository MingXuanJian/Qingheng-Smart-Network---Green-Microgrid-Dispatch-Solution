from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from qingheng.data import (
    ChannelCatalog,
    HybridAssetAssumptions,
    build_hybrid_profile,
    build_socal_15min_cache,
    fingerprint_file,
    load_socal_15min_profile,
    read_magnitude_channel_15min,
    verify_socal_cache_manifest,
)


CHANNELS = (
    "egauge_16-NorthPV_Power",
    "egauge_16-SouthPV_Power",
    "egauge_16-Mains_Power",
    "egauge_22-es1_Power",
)


def _write_channel(
    path: Path,
    timestamps: pd.DatetimeIndex,
    values: np.ndarray,
    headers: tuple[str, str],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({headers[0]: timestamps.strftime("%Y-%m-%d %H:%M:%S"), headers[1]: values}).to_csv(
        path, index=False
    )


@pytest.fixture
def tiny_socal(tmp_path: Path) -> Path:
    root = tmp_path / "socal"
    catalog = {"generated_at": "test", "magnitudes": list(CHANNELS), "phasors": []}
    root.mkdir()
    (root / "channel_catalog.json").write_text(json.dumps(catalog), encoding="utf-8")
    folder = root / "magnitudes" / "2025-01_r60s" / "magnitudes"
    timestamps = pd.date_range("2025-01-01", periods=30, freq="1min")
    _write_channel(folder / f"{CHANNELS[0]}.csv", timestamps, np.full(30, 100.0), ("t", "v"))
    _write_channel(
        folder / f"{CHANNELS[1]}.csv",
        timestamps[:15],
        np.full(15, 50.0),
        ("timestamp", "value"),
    )
    _write_channel(
        folder / f"{CHANNELS[2]}.csv", timestamps, np.full(30, 20.0), ("time", "reading")
    )
    _write_channel(
        folder / f"{CHANNELS[3]}.csv", timestamps, np.full(30, 30.0), ("date_time", "power")
    )
    return root


def test_catalog_and_profile_streaming_with_missing_flags(tiny_socal: Path) -> None:
    catalog = ChannelCatalog.from_root(tiny_socal)
    assert catalog.magnitude_files(CHANNELS[0])[0].name == f"{CHANNELS[0]}.csv"

    profile = load_socal_15min_profile(
        tiny_socal,
        start="2025-01-01T00:00:00Z",
        end="2025-01-01T00:30:00Z",
        chunksize=7,
    )
    assert list(profile.frame.columns[:4]) == ["pv_kw", "grid_kw", "fuel_cell_kw", "load_kw"]
    assert len(profile.frame) == 2
    first = profile.frame.iloc[0]
    assert first["pv_kw"] == pytest.approx(150.0)
    assert first["grid_kw"] == pytest.approx(20.0)
    assert first["fuel_cell_kw"] == pytest.approx(30.0)
    assert first["load_kw"] == pytest.approx(170.0)
    assert profile.metadata["load_kw_derivation"].startswith("max(0, egauge16")
    assert not bool(first["load_missing"])
    assert bool(profile.frame.iloc[1]["pv_missing"])
    assert bool(profile.frame.iloc[1]["load_missing"])
    assert profile.unit_decisions[CHANNELS[0]].metadata_unit == "W"
    assert profile.unit_decisions[CHANNELS[0]].scale_to_kw == 1.0
    assert "nameplates" in profile.unit_decisions[CHANNELS[0]].reason


def test_auto_unit_policy_uses_nameplate_to_recognise_watts(tiny_socal: Path) -> None:
    path = next((tiny_socal / "magnitudes").rglob(f"{CHANNELS[0]}.csv"))
    data = pd.read_csv(path)
    data["v"] = 500_000.0
    data.to_csv(path, index=False)
    reading = read_magnitude_channel_15min(
        ChannelCatalog.from_root(tiny_socal),
        CHANNELS[0],
        start="2025-01-01",
        end="2025-01-01T00:30:00",
        unit_policy="auto",
    )
    assert reading.unit_decision.scale_to_kw == pytest.approx(0.001)
    assert reading.values_kw.iloc[0] == pytest.approx(500.0)


def test_duplicate_timestamps_across_chunks_do_not_inflate_coverage(tiny_socal: Path) -> None:
    path = next((tiny_socal / "magnitudes").rglob(f"{CHANNELS[0]}.csv"))
    data = pd.read_csv(path)
    data = pd.concat([data, data.iloc[[0]]], ignore_index=True)
    data.to_csv(path, index=False)

    reading = read_magnitude_channel_15min(
        ChannelCatalog.from_root(tiny_socal),
        CHANNELS[0],
        start="2025-01-01",
        end="2025-01-01T00:15:00",
        chunksize=7,
    )

    assert reading.sample_count.iloc[0] == 15
    assert reading.values_kw.iloc[0] == pytest.approx(100.0)


def test_channel_reader_isolates_resolution_and_ignores_partial_batches(
    tiny_socal: Path,
) -> None:
    timestamps = pd.date_range("2025-01-01", periods=180, freq="10s")
    complete_10s = tiny_socal / "magnitudes" / "2025-01_r10s_g01-of-01" / "magnitudes"
    partial_60s = tiny_socal / "magnitudes" / "2025-01-extra_r60s.partial" / "magnitudes"
    _write_channel(
        complete_10s / f"{CHANNELS[0]}.csv",
        timestamps,
        np.full(len(timestamps), 999.0),
        ("t", "v"),
    )
    _write_channel(
        partial_60s / f"{CHANNELS[0]}.csv",
        timestamps[::6],
        np.full(30, 777.0),
        ("t", "v"),
    )

    catalog = ChannelCatalog.from_root(tiny_socal)
    files_60s = catalog.magnitude_files(CHANNELS[0], resolution_seconds=60)
    files_10s = catalog.magnitude_files(CHANNELS[0], resolution_seconds=10)
    assert len(files_60s) == 1
    assert len(files_10s) == 1
    assert "r60s" in files_60s[0].as_posix()
    assert "r10s" in files_10s[0].as_posix()

    reading = read_magnitude_channel_15min(
        catalog,
        CHANNELS[0],
        start="2025-01-01",
        end="2025-01-01T00:30:00",
        source_resolution_seconds=60,
    )
    assert reading.values_kw.iloc[0] == pytest.approx(100.0)


def test_fingerprints_distinguish_full_and_metadata_modes(tiny_socal: Path) -> None:
    source = tiny_socal / "channel_catalog.json"
    full = fingerprint_file(source, "full")
    metadata = fingerprint_file(source, "metadata")
    assert full["sha256"] == hashlib.sha256(source.read_bytes()).hexdigest()
    assert metadata["hash_mode"] == "metadata"
    assert metadata["sha256"] != full["sha256"]


def test_hybrid_builder_is_reproducible_and_labels_synthetic_assets(tiny_socal: Path) -> None:
    profile = load_socal_15min_profile(tiny_socal, start="2025-01-01", end="2025-01-01T00:30:00")
    assumptions = HybridAssetAssumptions(seed=17, wind_capacity_kw=120.0)
    first = build_hybrid_profile(profile, assumptions)
    second = build_hybrid_profile(profile, assumptions)
    np.testing.assert_allclose(first.frame["wind_kw"], second.frame["wind_kw"])
    assert first.frame["wind_is_synthetic"].all()
    assert first.frame["battery_is_synthetic"].all()
    assert first.frame["hydrogen_is_synthetic"].all()
    assert "battery and hydrogen operating powers" in first.metadata["storage_schedule_policy"]


def test_hybrid_asset_assumptions_can_follow_dispatch_configuration() -> None:
    from qingheng.config import DispatchConfig

    dispatch = DispatchConfig(
        battery_capacity_kwh=900.0,
        battery_power_kw=250.0,
        hydrogen_capacity_kwh=1400.0,
        hydrogen_power_kw=220.0,
    )

    assumptions = HybridAssetAssumptions.from_dispatch_config(dispatch, seed=7)

    assert assumptions.seed == 7
    assert assumptions.wind_capacity_kw == 0.0
    assert assumptions.battery_capacity_kwh == 900.0
    assert assumptions.hydrogen_capacity_kwh == 1400.0
    assert assumptions.electrolyzer_power_limit_kw == 220.0


def test_parquet_cache_references_raw_files_without_copying(
    tiny_socal: Path, tmp_path: Path
) -> None:
    pytest.importorskip("pyarrow")
    cache = build_socal_15min_cache(
        tiny_socal,
        tmp_path / "cache",
        start="2025-01-01",
        end="2025-01-01T00:30:00",
        hash_mode="metadata",
        complete_months_only=False,
    )
    assert cache.parquet_path.is_file()
    assert cache.manifest_path.is_file()
    assert cache.rows == 2
    assert cache.manifest["raw_data_policy"].startswith("read_only_references")
    assert all(
        entry["path"].startswith(str(tiny_socal.resolve()))
        for entry in cache.manifest["source_files"]
    )
    assert not any(path.suffix == ".csv" for path in cache.parquet_path.parent.iterdir())
    with pytest.raises(ValueError, match="complete calendar months"):
        verify_socal_cache_manifest(cache.parquet_path)


def test_cache_verifier_can_strictly_audit_source_fingerprints(tmp_path: Path) -> None:
    cache = tmp_path / "cache.parquet"
    source = tmp_path / "versioned_plan.json"
    cache.write_bytes(b"derived-cache")
    source.write_text('{"batches": []}', encoding="utf-8")
    manifest = {
        "dataset": "Caltech_SoCal28_15min_derivative",
        "output_file": str(cache.resolve()),
        "output_sha256": hashlib.sha256(cache.read_bytes()).hexdigest(),
        "source_files": [fingerprint_file(source, "full")],
        "derivation": {
            "selected_complete_months": ["2025-01"],
            "source_resolution_seconds": 60,
            "download_completeness": {
                "required_data_types": ["magnitudes"],
                "resolution_seconds": 60,
            },
            "month_quality": {"2025-01": {"accepted": True}},
        },
    }
    manifest_path = tmp_path / "cache.manifest.json"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

    verify_socal_cache_manifest(cache, manifest_path, verify_source_files=True)
    source.write_text('{"batches": ["changed"]}', encoding="utf-8")

    verify_socal_cache_manifest(cache, manifest_path)
    with pytest.raises(ValueError, match="source lineage"):
        verify_socal_cache_manifest(cache, manifest_path, verify_source_files=True)
