from dataclasses import replace
import json

import numpy as np
import pandas as pd
import pytest

from qingheng.config import DispatchConfig
from qingheng.dispatch.optimizers import (
    logistic_tent_sequence,
    nonlinear_inertia,
    particle_swarm_optimization,
    whale_optimization,
)
from qingheng.dispatch.benchmark import (
    run_optimizer_benchmark,
    verify_optimizer_artifact_manifest,
    write_optimizer_artifact_manifest,
)
from qingheng.dispatch.problem import DispatchInputs, MultiEnergyDispatchProblem


def _problem() -> MultiEnergyDispatchProblem:
    horizon = 4
    inputs = DispatchInputs.from_arrays(
        load_kw=[100, 120, 110, 90],
        pv_available_kw=[0, 80, 50, 0],
        wind_available_kw=[20, 20, 20, 20],
        buy_price_per_kwh=[0.5, 0.6, 1.0, 0.8],
        sell_price_per_kwh=[0.2] * horizon,
        grid_carbon_kg_per_kwh=[0.6] * horizon,
    )
    config = replace(
        DispatchConfig(),
        horizon_steps=horizon,
        battery_capacity_kwh=200,
        battery_power_kw=50,
        hydrogen_capacity_kwh=300,
        hydrogen_power_kw=40,
        grid_import_limit_kw=300,
    )
    return MultiEnergyDispatchProblem(inputs, config)


def test_zero_dispatch_is_balanced_and_feasible() -> None:
    problem = _problem()
    evaluation = problem.zero_dispatch()
    expected = problem.inputs.load_kw - problem.inputs.renewable_available_kw
    np.testing.assert_allclose(evaluation.grid_power_kw, expected)
    assert evaluation.feasible
    assert evaluation.penalty == 0


def test_dispatch_inputs_detach_and_freeze_caller_arrays() -> None:
    load = np.array([100.0, 120.0])
    inputs = DispatchInputs.from_arrays(
        load_kw=load,
        pv_available_kw=[0.0, 0.0],
        wind_available_kw=[0.0, 0.0],
        buy_price_per_kwh=[1.0, 1.0],
        grid_carbon_kg_per_kwh=[0.5, 0.5],
    )

    load[0] = 999.0

    assert inputs.load_kw[0] == 100.0
    assert not inputs.load_kw.flags.writeable
    with pytest.raises(ValueError):
        inputs.load_kw[0] = 1.0


def test_dispatch_evaluation_rejects_nonfinite_and_penalizes_bound_violations() -> None:
    problem = _problem()
    decision = problem.zero_decision()
    decision[0] = np.nan
    with pytest.raises(ValueError, match="finite"):
        problem.evaluate(decision)

    out_of_bounds = problem.zero_decision()
    out_of_bounds[0] = problem.config.battery_power_kw + 1.0
    out_of_bounds[-1] = 1.1
    evaluation = problem.evaluate(out_of_bounds)

    assert not evaluation.feasible
    assert evaluation.violation["battery_power"] > 0.0
    assert evaluation.violation["renewable_fraction"] > 0.0


def test_cost_reference_scale_does_not_cancel_negative_price_intervals() -> None:
    inputs = DispatchInputs.from_arrays(
        load_kw=[10.0, 10.0],
        pv_available_kw=[0.0, 0.0],
        wind_available_kw=[0.0, 0.0],
        buy_price_per_kwh=[-2.0, 2.0],
        grid_carbon_kg_per_kwh=[0.5, 0.5],
    )
    problem = MultiEnergyDispatchProblem(inputs, replace(DispatchConfig(), horizon_steps=2))

    assert problem._scales["cost"] == pytest.approx(40.0)


def test_benchmark_rejects_empty_or_duplicate_seed_sets() -> None:
    problem = _problem()

    with pytest.raises(ValueError, match="non-empty"):
        run_optimizer_benchmark(problem, seeds=())
    with pytest.raises(ValueError, match="unique"):
        run_optimizer_benchmark(problem, seeds=(7, 7))


def test_benchmark_exports_complete_best_so_far_histories(tmp_path) -> None:
    frame, _ = run_optimizer_benchmark(
        _problem(),
        seeds=(7, 11),
        population_size=4,
        iterations=3,
        output_dir=tmp_path,
    )

    convergence = pd.read_csv(tmp_path / "optimizer_convergence.csv")
    protocol = json.loads((tmp_path / "optimizer_protocol.json").read_text(encoding="utf-8"))
    assert len(convergence) == 3 * 2 * 3
    assert set(convergence["iteration"]) == {1, 2, 3}
    assert protocol["population_size"] == 4
    assert protocol["iterations"] == 3
    assert protocol["seeds"] == [7, 11]
    assert protocol["expected_function_evaluations_per_run"] == 16
    for (algorithm, seed), history in convergence.groupby(["algorithm", "seed"]):
        scores = history.sort_values("iteration")["best_score"].to_numpy()
        assert np.all(np.diff(scores) <= 1e-12)
        final = frame.loc[
            (frame["algorithm"] == algorithm) & (frame["seed"] == seed), "score"
        ].iloc[0]
        assert scores[-1] == pytest.approx(final)

    for filename in (
        "optimizer_comparison.png",
        "optimizer_algorithm_comparison.png",
        "optimizer_algorithm_comparison.pdf",
    ):
        (tmp_path / filename).write_bytes(filename.encode())
    manifest_path = write_optimizer_artifact_manifest(tmp_path)
    manifest = verify_optimizer_artifact_manifest(manifest_path)
    assert manifest["best_algorithm_by_mean"] in {"improved_woa", "standard_woa", "pso"}


def test_signed_device_state_updates_are_physical() -> None:
    problem = _problem()
    horizon = problem.inputs.horizon
    decision = np.concatenate([np.array([-10, 0, 0, 9.025]), np.zeros(horizon), np.ones(horizon)])
    evaluation = problem.evaluate(decision)
    assert evaluation.battery_energy_kwh[1] > evaluation.battery_energy_kwh[0]
    np.testing.assert_allclose(evaluation.battery_energy_kwh[-1], evaluation.battery_energy_kwh[0])


def test_optimizer_repair_enforces_state_and_exact_terminal_inventory() -> None:
    problem = _problem()
    horizon = problem.inputs.horizon
    raw = np.concatenate(
        [
            np.full(horizon, problem.config.battery_power_kw),
            np.full(horizon, -problem.config.hydrogen_power_kw),
            np.ones(horizon),
        ]
    )

    repaired = problem.repair_decision(raw)
    evaluation = problem.evaluate(repaired)

    assert np.all(repaired >= problem.lower_bounds)
    assert np.all(repaired <= problem.upper_bounds)
    np.testing.assert_allclose(
        evaluation.battery_energy_kwh[-1], evaluation.battery_energy_kwh[0], atol=1e-8
    )
    np.testing.assert_allclose(
        evaluation.hydrogen_energy_kwh[-1], evaluation.hydrogen_energy_kwh[0], atol=1e-8
    )
    assert evaluation.violation["battery_state"] == 0.0
    assert evaluation.violation["hydrogen_state"] == 0.0
    assert evaluation.violation["battery_terminal"] == 0.0
    assert evaluation.violation["hydrogen_terminal"] == 0.0


def test_corrected_chaos_and_nonlinear_schedule() -> None:
    first = logistic_tent_sequence(20, seed=7)
    second = logistic_tent_sequence(20, seed=7)
    np.testing.assert_allclose(first, second)
    assert np.all((first > 0) & (first < 1))
    assert nonlinear_inertia(0, 10) > nonlinear_inertia(9, 10)


@pytest.mark.parametrize("optimizer", [whale_optimization, particle_swarm_optimization])
def test_optimizers_reject_invalid_inputs_and_nonfinite_objectives(optimizer) -> None:
    lower = np.zeros(2)
    upper = np.ones(2)

    with pytest.raises(ValueError, match="population_size"):
        optimizer(lambda candidate: float(candidate.sum()), lower, upper, population_size=3)
    with pytest.raises(ValueError, match="finite"):
        optimizer(
            lambda candidate: float(candidate.sum()),
            np.array([0.0, np.nan]),
            upper,
            population_size=4,
            iterations=1,
        )
    with pytest.raises(ValueError, match="finite score"):
        optimizer(
            lambda candidate: np.nan,
            lower,
            upper,
            population_size=4,
            iterations=1,
        )


def test_dispatch_emissions_include_used_renewable_lifecycle_factors() -> None:
    horizon = 1
    inputs = DispatchInputs.from_arrays(
        load_kw=[100.0],
        pv_available_kw=[40.0],
        wind_available_kw=[20.0],
        buy_price_per_kwh=[1.0],
        grid_carbon_kg_per_kwh=[0.6],
        pv_carbon_kg_per_kwh=[0.04],
        wind_carbon_kg_per_kwh=[0.01],
    )
    config = replace(DispatchConfig(), horizon_steps=horizon)

    evaluation = MultiEnergyDispatchProblem(inputs, config).zero_dispatch()

    assert evaluation.emissions_kg == 40.0 * 0.6 + 40.0 * 0.04 + 20.0 * 0.01


def test_carbon_objective_tracks_dirty_opening_storage_at_the_load() -> None:
    inputs = DispatchInputs.from_arrays(
        load_kw=[100.0, 100.0],
        pv_available_kw=[0.0, 150.0],
        wind_available_kw=[0.0, 0.0],
        buy_price_per_kwh=[1.0, 1.0],
        grid_carbon_kg_per_kwh=[0.1, 0.1],
        pv_carbon_kg_per_kwh=[0.0, 0.0],
        battery_initial_stored_carbon_kg_per_kwh=1.0,
        hydrogen_initial_stored_carbon_kg_per_kwh=0.0,
    )
    config = replace(
        DispatchConfig(),
        horizon_steps=2,
        battery_capacity_kwh=200.0,
        battery_power_kw=50.0,
        battery_min_soc=0.0,
        battery_initial_soc=0.5,
        battery_charge_efficiency=1.0,
        battery_discharge_efficiency=1.0,
        hydrogen_enabled=False,
        hydrogen_capacity_kwh=0.0,
        hydrogen_power_kw=0.0,
        terminal_tolerance=0.0,
    )
    problem = MultiEnergyDispatchProblem(inputs, config)
    decision = np.concatenate([np.array([50.0, -50.0]), np.zeros(2), np.ones(2)])

    evaluation = problem.evaluate(decision)

    assert evaluation.external_source_emissions_kg == pytest.approx(5.0)
    assert evaluation.load_allocated_emissions_proxy_kg == pytest.approx(55.0)
    assert evaluation.emissions_kg == pytest.approx(55.0)
    assert evaluation.opening_storage_carbon_kg == pytest.approx(100.0)
    assert evaluation.closing_storage_carbon_proxy_kg == pytest.approx(50.0)
    assert abs(evaluation.carbon_balance_residual_proxy_kg) < 1e-9


def test_terminal_inventory_depletion_has_replenishment_cost_and_carbon() -> None:
    inputs = DispatchInputs.from_arrays(
        load_kw=[100.0],
        pv_available_kw=[0.0],
        wind_available_kw=[0.0],
        buy_price_per_kwh=[1.0],
        grid_carbon_kg_per_kwh=[0.6],
    )
    problem = MultiEnergyDispatchProblem(inputs, replace(DispatchConfig(), horizon_steps=1))
    decision = np.array([1.0, 0.0, 1.0])

    evaluation = problem.evaluate(decision)

    assert evaluation.feasible
    assert evaluation.terminal_replenishment_cost > 0.0
    assert evaluation.terminal_replenishment_emissions_kg > 0.0


def test_rolling_execution_can_leave_terminal_inventory_without_replenishment() -> None:
    inputs = DispatchInputs.from_arrays(
        load_kw=np.full(4, 100.0),
        pv_available_kw=np.zeros(4),
        wind_available_kw=np.zeros(4),
        buy_price_per_kwh=np.ones(4),
        grid_carbon_kg_per_kwh=np.full(4, 0.5),
    )
    config = replace(
        DispatchConfig(),
        horizon_steps=4,
        battery_capacity_kwh=100.0,
        battery_power_kw=20.0,
        battery_initial_soc=0.5,
        hydrogen_enabled=False,
        hydrogen_capacity_kwh=0.0,
        hydrogen_power_kw=0.0,
        grid_import_limit_kw=1_000.0,
        grid_export_limit_kw=1_000.0,
        terminal_tolerance=0.0,
    )
    problem = MultiEnergyDispatchProblem(inputs, config)
    decision = np.concatenate([np.full(4, 5.0), np.zeros(4), np.ones(4)])

    evaluation = problem.evaluate(decision, enforce_terminal_inventory=False)

    assert evaluation.battery_energy_kwh[-1] < evaluation.battery_energy_kwh[0]
    assert evaluation.terminal_replenishment_cost == 0.0
    assert evaluation.terminal_replenishment_emissions_kg == 0.0
    assert evaluation.violation["battery_terminal"] == 0.0
    assert evaluation.feasible


def test_disabled_hydrogen_has_fixed_zero_schedule_and_state() -> None:
    problem = _problem()
    config = replace(
        problem.config,
        hydrogen_enabled=False,
        hydrogen_capacity_kwh=0.0,
        hydrogen_power_kw=0.0,
    )
    disabled = MultiEnergyDispatchProblem(problem.inputs, config)

    repaired = disabled.repair_decision(np.ones(disabled.dimension))
    evaluation = disabled.evaluate(repaired)

    np.testing.assert_allclose(evaluation.hydrogen_power_kw, 0.0)
    np.testing.assert_allclose(evaluation.hydrogen_energy_kwh, 0.0)
    assert evaluation.violation["hydrogen_state"] == 0.0
    assert evaluation.violation["hydrogen_terminal"] == 0.0


def test_terminal_repair_is_distributed_across_configured_tail() -> None:
    horizon = 8
    inputs = DispatchInputs.from_arrays(
        load_kw=np.full(horizon, 100.0),
        pv_available_kw=np.zeros(horizon),
        wind_available_kw=np.zeros(horizon),
        buy_price_per_kwh=np.ones(horizon),
        grid_carbon_kg_per_kwh=np.full(horizon, 0.5),
    )
    config = replace(
        DispatchConfig(),
        horizon_steps=horizon,
        terminal_repair_steps=4,
        battery_capacity_kwh=200.0,
        battery_power_kw=50.0,
    )
    problem = MultiEnergyDispatchProblem(inputs, config)
    raw = np.concatenate([np.full(horizon, -20.0), np.zeros(horizon), np.ones(horizon)])

    repaired = problem.repair_decision(raw)
    battery, _, _ = problem.decode(repaired)
    evaluation = problem.evaluate(repaired)

    np.testing.assert_allclose(battery[-4:], battery[-1])
    assert battery[-1] > 0.0
    np.testing.assert_allclose(evaluation.battery_energy_kwh[-1], 100.0, atol=1e-8)
