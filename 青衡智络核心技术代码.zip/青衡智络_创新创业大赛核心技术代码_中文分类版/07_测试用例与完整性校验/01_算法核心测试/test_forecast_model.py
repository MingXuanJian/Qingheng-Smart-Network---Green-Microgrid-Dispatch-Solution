from __future__ import annotations

import importlib.util

import numpy as np
import pandas as pd
import pytest

from qingheng.forecast import (
    CNNLSTMAttention,
    ModelSpec,
    TrainingConfig,
    load_forecast_artifact,
    predict_dataset,
    prepare_windowed_data,
    train_forecaster,
)


TORCH_AVAILABLE = importlib.util.find_spec("torch") is not None
pytestmark = pytest.mark.skipif(
    not TORCH_AVAILABLE,
    reason="forecast optional dependency is absent",
)


def test_model_returns_multi_horizon_output_and_attention() -> None:
    import torch

    spec = ModelSpec(
        input_features=3,
        target_count=2,
        horizon_steps=4,
        conv_channels=4,
        hidden_size=8,
        attention_heads=2,
        dropout=0.0,
    )
    model = CNNLSTMAttention(spec)
    forecast, attention = model(torch.randn(5, 12, 3), return_attention=True)

    assert forecast.shape == (5, 4, 2)
    assert attention.shape == (5, 12)
    torch.testing.assert_close(attention.sum(dim=1), torch.ones(5))


def test_residual_model_starts_at_aligned_history_baseline() -> None:
    import torch

    spec = ModelSpec(
        input_features=3,
        target_count=2,
        horizon_steps=4,
        conv_channels=4,
        hidden_size=8,
        attention_heads=2,
        dropout=0.0,
    )
    model = CNNLSTMAttention(spec)
    inputs = torch.randn(5, 12, 3)

    forecast = model(inputs)

    torch.testing.assert_close(forecast, inputs[:, -4:, :2])
    with pytest.raises(ValueError, match="cover residual_period_steps"):
        model(torch.randn(2, 3, 3))


def test_residual_model_uses_explicit_seasonal_period() -> None:
    import torch

    spec = ModelSpec(
        input_features=2,
        target_count=1,
        horizon_steps=2,
        residual_period_steps=4,
        conv_channels=4,
        hidden_size=8,
        attention_heads=2,
        dropout=0.0,
    )
    model = CNNLSTMAttention(spec)
    inputs = torch.arange(12, dtype=torch.float32).reshape(1, 6, 2)

    forecast = model(inputs)

    torch.testing.assert_close(forecast, inputs[:, 2:4, :1])


def test_legacy_model_spec_keeps_direct_forecast_semantics() -> None:
    legacy = ModelSpec.from_dict(
        {
            "input_features": 3,
            "target_count": 2,
            "horizon_steps": 4,
        }
    )

    assert legacy.residual_baseline == "none"


def test_validation_calibration_can_disable_harmful_target_corrections() -> None:
    import torch
    from torch.utils.data import DataLoader, TensorDataset

    from qingheng.forecast.training import _calibrate_residual_gains

    model = CNNLSTMAttention(
        ModelSpec(
            input_features=2,
            target_count=2,
            horizon_steps=2,
            conv_channels=4,
            hidden_size=4,
            attention_heads=1,
            dropout=0.0,
        )
    )
    inputs = torch.randn(6, 4, 2)
    targets = inputs[:, -2:, :].clone()
    with torch.no_grad():
        model.output[-1].bias.copy_(torch.tensor([1.0, -0.5, 1.0, -0.5]))

    gains, calibrated_mae = _calibrate_residual_gains(
        model,
        DataLoader(TensorDataset(inputs, targets), batch_size=3),
        torch.device("cpu"),
    )

    assert gains == [0.0, 0.0]
    assert calibrated_mae == pytest.approx(0.0)
    torch.testing.assert_close(model(inputs), targets)


def test_validation_calibration_uses_the_configured_seasonal_reference() -> None:
    import torch
    from torch.utils.data import DataLoader, TensorDataset

    from qingheng.forecast.training import _calibrate_residual_gains

    model = CNNLSTMAttention(
        ModelSpec(
            input_features=1,
            target_count=1,
            horizon_steps=2,
            residual_period_steps=4,
            conv_channels=4,
            hidden_size=4,
            attention_heads=1,
            dropout=0.0,
        )
    )
    inputs = torch.tensor([[[0.0], [0.0], [10.0], [20.0], [30.0], [40.0]]]).repeat(
        4, 1, 1
    )
    targets = inputs[:, 2:4, :].clone()
    with torch.no_grad():
        model.output[-1].bias.fill_(1.0)

    gains, calibrated_mae = _calibrate_residual_gains(
        model,
        DataLoader(TensorDataset(inputs, targets), batch_size=2),
        torch.device("cpu"),
    )

    assert gains == [0.0]
    assert calibrated_mae == pytest.approx(0.0)
    torch.testing.assert_close(model(inputs), targets)


def test_artifact_loader_rejects_inconsistent_column_metadata(tmp_path) -> None:
    import torch

    from qingheng.forecast import StandardScaler
    from qingheng.forecast.training import TrainingHistory, save_forecast_artifact

    spec = ModelSpec(
        input_features=2,
        target_count=1,
        horizon_steps=2,
        conv_channels=4,
        hidden_size=4,
        attention_heads=1,
        dropout=0.0,
        target_feature_indices=(0,),
    )
    artifact_path = tmp_path / "corrupt.pt"
    save_forecast_artifact(
        artifact_path,
        model=CNNLSTMAttention(spec),
        feature_scaler=StandardScaler(
            mean=np.array([1.0, 0.0]),
            scale=np.array([2.0, 1.0]),
        ),
        target_scaler=StandardScaler(mean=np.array([1.0]), scale=np.array([2.0])),
        feature_columns=("load_kw", "hour_sin"),
        target_columns=("load_kw",),
        history=TrainingHistory(),
    )
    payload = torch.load(artifact_path, map_location="cpu", weights_only=True)
    payload["feature_columns"] = ["load_kw"]
    torch.save(payload, artifact_path)

    with pytest.raises(ValueError, match="feature_columns do not match"):
        load_forecast_artifact(artifact_path)


def test_tiny_training_round_trip_artifact(tmp_path) -> None:
    rows = 96
    t = np.arange(rows, dtype=np.float64)
    frame = pd.DataFrame(
        {
            "pv_kw": np.maximum(0.0, np.sin(t / 8.0)),
            "load_kw": 1.5 + 0.2 * np.cos(t / 7.0),
            "hour_sin": np.sin(2.0 * np.pi * t / 24.0),
        },
        index=pd.date_range("2025-01-01", periods=rows, freq="h", tz="UTC"),
    )
    splits = prepare_windowed_data(
        frame,
        feature_columns=("pv_kw", "load_kw", "hour_sin"),
        target_columns=("pv_kw", "load_kw"),
        input_steps=6,
        horizon_steps=2,
        train_fraction=0.60,
        validation_fraction=0.20,
    )
    artifact_path = tmp_path / "forecast.pt"
    result = train_forecaster(
        splits,
        spec=ModelSpec(
            input_features=3,
            target_count=2,
            horizon_steps=2,
            conv_channels=4,
            hidden_size=4,
            attention_heads=1,
            dropout=0.0,
        ),
        training=TrainingConfig(
            epochs=2,
            patience=1,
            learning_rate=1e-2,
            seed=42,
            device="cpu",
        ),
        artifact_path=artifact_path,
        batch_size=16,
        metadata={"dataset": "tiny-test"},
    )
    loaded = load_forecast_artifact(artifact_path)
    predictions = predict_dataset(
        loaded.model,
        splits.test,
        target_scaler=loaded.target_scaler,
        device="cpu",
    )

    assert artifact_path.is_file()
    assert result.history.best_epoch in {0, 1, 2}
    assert result.history.best_validation_loss <= result.history.initial_validation_loss
    assert len(result.history.residual_gains) == 2
    assert all(0.0 <= gain <= 1.0 for gain in result.history.residual_gains)
    assert loaded.metadata == {"dataset": "tiny-test"}
    assert loaded.model.spec.residual_baseline == "aligned_history"
    assert loaded.history.residual_gains == result.history.residual_gains
    assert predictions.predicted.shape == predictions.actual.shape
    assert predictions.predicted.shape[1:] == (2, 2)
    assert set(predictions.metrics()) == {"mae", "rmse", "smape_percent"}
