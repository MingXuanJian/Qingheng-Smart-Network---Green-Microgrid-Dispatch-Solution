from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import pytest

from qingheng.ablation_summary import (
    AblationSummaryError,
    CONVERGENCE_CASE_FILES,
    EXPECTED_ABLATION_CASES,
    FORMAL_CASE_FILES,
    summarize_dispatch_ablation,
    verify_ablation_artifact_manifest,
    write_ablation_artifact_manifest,
)


def _write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value), encoding="utf-8")


def _write_case(
    root: Path,
    name: str,
    *,
    sizing_sha: str = "shared-sizing",
    ac_load_carbon: float = 80.0,
    replay: bool = True,
) -> Path:
    directory = root / name
    directory.mkdir()
    metrics = {
        "score": 0.2,
        "cost": 50.0,
        "feasible": True,
        "load_allocated_emissions_proxy_kg": 100.0,
        "external_source_emissions_kg": 70.0,
        "curtailment_kwh": 3.0,
        "carbon_balance_residual_proxy_kg": 1e-12,
    }
    schedule = pd.DataFrame(
        {
            "grid_power_kw": [10.0, -4.0],
            "battery_power_kw": [2.0, -2.0],
            "hydrogen_power_kw": [1.0, -1.0],
            "battery_energy_kwh_end": [3.0, 5.0],
            "hydrogen_energy_kwh_end": [4.0, 5.0],
        }
    )
    carbon = {
        "load_allocated_emissions_kg": ac_load_carbon,
        "external_source_emissions_kg": 71.0,
        "carbon_balance_residual_kg": 2e-12,
    }
    powerflow = {
        "feasible": True,
        "all_converged": True,
        "voltage_feasible": True,
        "current_feasible": None,
        "pcc_limit_feasible": True,
        "minimum_voltage_pu": 0.97,
        "maximum_voltage_pu": 1.03,
        "maximum_pcc_import_kw": 10.1,
        "maximum_pcc_export_kw": 4.1,
        "active_loss_energy_kwh": 0.2,
        "loss_adjusted_cost": 50.1,
        "loss_adjusted_source_emissions_kg": 71.1,
        "selected_algorithm": "pso",
        "selected_seed": 2026,
    }
    applied_sha = f"applied-{name}"
    provenance = {
        "sizing_sha256": sizing_sha,
        "applied_scenario_sha256": applied_sha,
    }
    sizing = {
        "sizing_sha256": sizing_sha,
        "applied_scenario_sha256": applied_sha,
        "post_sizing_application": {
            "applied_dispatch": {
                "step_hours": 1.0,
                "battery_capacity_kwh": 10.0,
                "battery_initial_soc": 0.5,
                "hydrogen_capacity_kwh": 10.0,
                "hydrogen_initial_soc": 0.5,
            }
        },
    }
    optimizer = pd.DataFrame(
        [
            {"algorithm": "pso", "runs": 5, "score_mean": 0.2, "score_std": 0.01},
            {"algorithm": "zero_dispatch", "runs": 1, "score_mean": 0.4, "score_std": None},
        ]
    )

    _write_json(directory / "best_dispatch_metrics.json", metrics)
    schedule.to_csv(directory / "best_dispatch_schedule.csv", index=False)
    _write_json(directory / "carbon_metrics.json", carbon)
    _write_json(directory / "powerflow_summary.json", powerflow)
    _write_json(directory / "scenario_provenance.json", provenance)
    _write_json(directory / "sizing_manifest.json", sizing)
    optimizer.to_csv(directory / "optimizer_summary.csv", index=False)

    if replay:
        _write_json(directory / "actual_replay_metrics.json", metrics)
        schedule.to_csv(directory / "actual_replay_schedule.csv", index=False)
        _write_json(
            directory / "actual_replay_carbon_metrics.json",
            {"available": True, **carbon},
        )
        _write_json(directory / "actual_replay_powerflow_summary.json", powerflow)
    return directory


def _four_cases(root: Path) -> dict[str, Path]:
    return {
        name: _write_case(root, name, ac_load_carbon=80.0 if name == "full" else 98.0)
        for name in ("full", "battery_only", "hydrogen_only", "no_storage")
    }


def _formal_result_set(root: Path) -> Path:
    root.mkdir()
    cases = _four_cases(root)
    for index, case in enumerate(cases.values(), start=1):
        for filename in ("sizing_manifest.json", "scenario_provenance.json"):
            path = case / filename
            value = json.loads(path.read_text(encoding="utf-8"))
            value["sizing_sha256"] = "0" * 64
            value["applied_scenario_sha256"] = str(index) * 64
            _write_json(path, value)
    summarize_dispatch_ablation(cases, root)
    existing = {
        "best_dispatch_metrics.json",
        "best_dispatch_schedule.csv",
        "carbon_metrics.json",
        "powerflow_summary.json",
        "scenario_provenance.json",
        "sizing_manifest.json",
        "optimizer_summary.csv",
        "actual_replay_metrics.json",
        "actual_replay_schedule.csv",
        "actual_replay_carbon_metrics.json",
        "actual_replay_powerflow_summary.json",
    }
    for case in cases.values():
        for filename in set(FORMAL_CASE_FILES) - existing:
            (case / filename).write_bytes(f"{case.name}:{filename}".encode())
    return root


def test_summarize_dispatch_ablation_writes_flat_and_structured_outputs(tmp_path: Path) -> None:
    cases = _four_cases(tmp_path)

    csv_path, json_path = summarize_dispatch_ablation(cases, tmp_path / "summary")

    frame = pd.read_csv(csv_path).set_index("case")
    assert frame.loc["full", "grid_import_kwh"] == pytest.approx(10.0)
    assert frame.loc["full", "grid_export_kwh"] == pytest.approx(4.0)
    assert frame.loc["full", "battery_absolute_throughput_kwh"] == pytest.approx(4.0)
    assert frame.loc["full", "hydrogen_absolute_throughput_kwh"] == pytest.approx(2.0)
    assert frame.loc["full", "battery_terminal_error_kwh"] == pytest.approx(0.0)
    assert frame.loc["full", "actual_replay_network_feasible"]
    assert frame.loc["full", "pcc_limit_feasible"]
    assert frame.loc["full", "minimum_voltage_pu"] == pytest.approx(0.97)
    assert pd.isna(frame.loc["full", "current_feasible"])
    assert frame.loc["full", "carbon_proxy_relative_deviation_fraction"] == pytest.approx(0.25)

    document = json.loads(json_path.read_text(encoding="utf-8"))
    assert document["schema_version"] == "qingheng.dispatch-ablation.v2"
    assert document["sizing_sha256"] == "shared-sizing"
    assert {warning["scope"] for warning in document["warnings"]} == {
        "forecast_dispatch",
        "actual_replay",
    }
    full = next(case for case in document["cases"] if case["metrics"]["case"] == "full")
    assert full["optimizer_summary"][0]["score_std"] == pytest.approx(0.01)
    assert full["optimizer_summary"][1]["score_std"] is None
    assert document["ranking"]["consistent"]
    assert document["acceptance"]["passed"]
    assert not document["acceptance"]["branch_ampacity_ratings_available"]


def test_summarize_dispatch_ablation_keeps_unavailable_replay_reason(tmp_path: Path) -> None:
    cases = _four_cases(tmp_path)
    _write_json(
        cases["hydrogen_only"] / "actual_replay_carbon_metrics.json",
        {"available": False, "reason": "AC replay did not converge"},
    )

    csv_path, _ = summarize_dispatch_ablation(cases, tmp_path / "summary")

    frame = pd.read_csv(csv_path).set_index("case")
    row = frame.loc["hydrogen_only"]
    assert not row["actual_replay_carbon_available"]
    assert row["actual_replay_carbon_unavailable_reason"] == "AC replay did not converge"
    assert pd.isna(row["actual_replay_ac_load_allocated_emissions_kg"])


def test_summarize_dispatch_ablation_marks_absent_replay_unavailable(
    tmp_path: Path,
) -> None:
    cases = _four_cases(tmp_path)
    missing_case = cases["hydrogen_only"]
    for filename in (
        "actual_replay_metrics.json",
        "actual_replay_schedule.csv",
        "actual_replay_carbon_metrics.json",
        "actual_replay_powerflow_summary.json",
    ):
        (missing_case / filename).unlink()

    csv_path, json_path = summarize_dispatch_ablation(cases, tmp_path / "summary")

    frame = pd.read_csv(csv_path).set_index("case")
    row = frame.loc["hydrogen_only"]
    assert not row["actual_replay_available"]
    assert row["actual_replay_unavailable_reason"] == (
        "Actual replay artifacts are absent for this case."
    )
    assert pd.isna(row["actual_replay_score"])
    assert pd.isna(row["actual_replay_battery_terminal_error_kwh"])
    assert not row["actual_replay_carbon_available"]

    document = json.loads(json_path.read_text(encoding="utf-8"))
    metrics = next(
        case["metrics"] for case in document["cases"] if case["metrics"]["case"] == "hydrogen_only"
    )
    assert metrics["actual_replay_score"] is None
    assert not document["acceptance"]["all_actual_replays_available"]
    assert not document["acceptance"]["terminal_energy_results_complete"]
    assert not document["acceptance"]["terminal_energy_passed"]
    assert not document["acceptance"]["copperplate_carbon_results_complete"]
    assert not document["acceptance"]["copperplate_carbon_passed"]
    assert not document["acceptance"]["passed"]
    assert document["ranking"]["actual_replay_by_score"] is None
    assert not document["ranking"]["device_gain_conclusion_permitted"]
    assert document["ranking"]["conclusion_scope"] == "selected_natural_day_only"
    assert not document["ranking"]["general_device_gain_conclusion_permitted"]


def test_summarize_dispatch_ablation_rejects_partial_replay_artifacts(
    tmp_path: Path,
) -> None:
    cases = _four_cases(tmp_path)
    (cases["hydrogen_only"] / "actual_replay_carbon_metrics.json").unlink()

    with pytest.raises(AblationSummaryError, match="incomplete actual replay"):
        summarize_dispatch_ablation(cases, tmp_path / "summary")


def test_summarize_dispatch_ablation_rejects_mismatched_sizing_hashes(tmp_path: Path) -> None:
    cases = _four_cases(tmp_path)
    case = cases["no_storage"]
    for filename in ("sizing_manifest.json", "scenario_provenance.json"):
        path = case / filename
        value = json.loads(path.read_text(encoding="utf-8"))
        value["sizing_sha256"] = "different-sizing"
        _write_json(path, value)

    with pytest.raises(AblationSummaryError, match="do not share one sizing_sha256"):
        summarize_dispatch_ablation(cases, tmp_path / "summary")


def test_summarize_dispatch_ablation_reports_missing_field_and_source(tmp_path: Path) -> None:
    cases = _four_cases(tmp_path)
    metrics_path = cases["battery_only"] / "best_dispatch_metrics.json"
    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    del metrics["cost"]
    _write_json(metrics_path, metrics)

    with pytest.raises(AblationSummaryError, match=r"missing required field 'cost'.*best_dispatch"):
        summarize_dispatch_ablation(cases, tmp_path / "summary")


def test_summarize_dispatch_ablation_rejects_reused_applied_hash(tmp_path: Path) -> None:
    cases = _four_cases(tmp_path)
    reused = "same-applied-scenario"
    for case in cases.values():
        for filename in ("sizing_manifest.json", "scenario_provenance.json"):
            path = case / filename
            value = json.loads(path.read_text(encoding="utf-8"))
            value["applied_scenario_sha256"] = reused
            _write_json(path, value)

    with pytest.raises(AblationSummaryError, match="distinct applied_scenario_sha256"):
        summarize_dispatch_ablation(cases, tmp_path / "summary")


def test_ablation_artifact_manifest_detects_tampering_and_unrecorded_files(
    tmp_path: Path,
) -> None:
    output = _formal_result_set(tmp_path / "formal")

    manifest_path = write_ablation_artifact_manifest(output)
    verified = verify_ablation_artifact_manifest(manifest_path)

    assert verified["result_complete"]
    assert verified["file_count"] == 82
    assert verified["required_file_count"] == 82

    stale = output / "full" / "stale.json"
    stale.write_text("{}", encoding="utf-8")
    with pytest.raises(AblationSummaryError, match="unexpected=.*stale.json"):
        verify_ablation_artifact_manifest(manifest_path)
    stale.unlink()

    schedule = output / "battery_only" / "best_dispatch_schedule.csv"
    schedule.write_text("tampered", encoding="utf-8")
    with pytest.raises(AblationSummaryError, match="does not match its manifest"):
        verify_ablation_artifact_manifest(manifest_path)


def test_ablation_artifact_manifest_accepts_complete_convergence_file_set(
    tmp_path: Path,
) -> None:
    output = _formal_result_set(tmp_path / "formal")
    for case in EXPECTED_ABLATION_CASES:
        for filename in CONVERGENCE_CASE_FILES:
            (output / case / filename).write_text(f"{case}:{filename}", encoding="utf-8")

    manifest_path = write_ablation_artifact_manifest(output)
    verified = verify_ablation_artifact_manifest(manifest_path)

    assert verified["case_file_set"] == "convergence-v2"
    assert verified["file_count"] == 102
    assert verified["required_file_count"] == 102


def test_ablation_artifact_manifest_rejects_stale_files_before_freezing(
    tmp_path: Path,
) -> None:
    output = _formal_result_set(tmp_path / "formal")
    (output / "unexpected.txt").write_text("stale", encoding="utf-8")

    with pytest.raises(AblationSummaryError, match="unexpected=.*unexpected.txt"):
        write_ablation_artifact_manifest(output)
