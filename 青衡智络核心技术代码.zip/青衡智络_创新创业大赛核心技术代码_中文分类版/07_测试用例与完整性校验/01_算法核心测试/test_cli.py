import json
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

from qingheng.cli import (
    _apply_optimizer_overrides,
    _evaluate_actual_replay,
    _file_sha256,
    _load_bound_forecast,
    _new_result_directory,
    _scenario_plausibility,
    _validate_complete_local_calendar_day,
)
from qingheng.config import DispatchConfig
from qingheng.dispatch import DispatchInputs, MultiEnergyDispatchProblem


def test_optimizer_overrides_are_materialized_before_provenance() -> None:
    base = DispatchConfig()
    quick = _apply_optimizer_overrides(
        base,
        SimpleNamespace(
            quick=True,
            population=None,
            iterations=None,
            seed=None,
        ),
    )
    explicit = _apply_optimizer_overrides(
        base,
        SimpleNamespace(
            quick=True,
            population=20,
            iterations=30,
            seed=99,
        ),
    )

    assert quick.population == 16
    assert quick.iterations == 24
    assert quick.seeds == (base.seeds[0],)
    assert explicit.population == 20
    assert explicit.iterations == 30
    assert explicit.seeds == (99,)


def test_scenario_plausibility_flags_export_dominated_synthetic_wind() -> None:
    inputs = DispatchInputs.from_arrays(
        load_kw=[10.0, 10.0],
        pv_available_kw=[10.0, 10.0],
        wind_available_kw=[30.0, 30.0],
        buy_price_per_kwh=[1.0, 1.0],
        grid_carbon_kg_per_kwh=[0.5, 0.5],
    )

    audit = _scenario_plausibility(inputs)

    assert audit["wind_to_load_energy_ratio"] == pytest.approx(3.0)
    assert audit["renewable_to_load_energy_ratio"] == pytest.approx(4.0)
    assert audit["renewable_surplus_hour_fraction"] == pytest.approx(1.0)
    assert len(audit["warnings"]) == 2


def test_forecast_dispatch_binding_verifies_cache_split_and_csv_hash(tmp_path) -> None:
    index = pd.date_range("2025-06-17T07:00:00Z", periods=4, freq="15min", tz="UTC")
    csv_path = tmp_path / "first_test_forecast.csv"
    pd.DataFrame(
        {
            "timestamp": index,
            "load_operational_kw": [1.0] * 4,
            "pv_operational_kw": [0.0] * 4,
        }
    ).to_csv(csv_path, index=False)
    metrics_path = tmp_path / "forecast_metrics.json"
    metrics = {
        "schema_version": "qingheng.forecast-metrics.v5",
        "data_provenance": {
            "cache_output_sha256": "cache-hash",
            "selected_complete_months": ["2024-10"],
            "source_cache_rows": 100,
            "experiment_interval": {"quick_truncation": False},
            "target_split_intervals": {
                "train": {
                    "target_start": "2024-10-02T00:00:00Z",
                    "target_end_exclusive": "2025-05-01T00:00:00Z",
                },
                "test": {
                    "target_start": "2025-06-17T07:00:00Z",
                    "target_end_exclusive": "2025-06-18T07:00:00Z",
                },
            },
        },
        "dispatch_export": {
            "sha256": _file_sha256(csv_path),
            "rows": 4,
            "start": index[0].isoformat(),
            "end_inclusive": index[-1].isoformat(),
            "is_complete_local_calendar_day": True,
        },
    }
    metrics_path.write_text(json.dumps(metrics), encoding="utf-8")
    cache_manifest = {
        "output_sha256": "cache-hash",
        "derivation": {"selected_complete_months": ["2024-10"]},
    }

    forecast, binding = _load_bound_forecast(
        csv_path,
        None,
        cache_manifest=cache_manifest,
        cache_rows=100,
        expected_steps=4,
    )

    assert len(forecast) == 4
    assert binding["forecast_csv_sha256"] == metrics["dispatch_export"]["sha256"]
    csv_path.write_text(csv_path.read_text(encoding="utf-8") + "\n", encoding="utf-8")
    with pytest.raises(ValueError, match="sidecar hash"):
        _load_bound_forecast(
            csv_path,
            None,
            cache_manifest=cache_manifest,
            cache_rows=100,
            expected_steps=4,
        )


def test_actual_replay_keeps_decisions_and_recomputes_grid_balance() -> None:
    config = DispatchConfig(horizon_steps=2)
    forecast_inputs = DispatchInputs.from_arrays(
        load_kw=[100.0, 100.0],
        pv_available_kw=[50.0, 50.0],
        wind_available_kw=[0.0, 0.0],
        buy_price_per_kwh=[1.0, 1.0],
        grid_carbon_kg_per_kwh=[0.5, 0.5],
    )
    actual_inputs = DispatchInputs.from_arrays(
        load_kw=[120.0, 120.0],
        pv_available_kw=[30.0, 30.0],
        wind_available_kw=[0.0, 0.0],
        buy_price_per_kwh=[1.0, 1.0],
        grid_carbon_kg_per_kwh=[0.5, 0.5],
    )
    forecast = MultiEnergyDispatchProblem(forecast_inputs, config).zero_dispatch()

    replay = _evaluate_actual_replay(actual_inputs, config, forecast)

    np.testing.assert_allclose(replay.battery_power_kw, forecast.battery_power_kw)
    np.testing.assert_allclose(replay.hydrogen_power_kw, forecast.hydrogen_power_kw)
    np.testing.assert_allclose(replay.renewable_fraction, forecast.renewable_fraction)
    np.testing.assert_allclose(forecast.grid_power_kw, 50.0)
    np.testing.assert_allclose(replay.grid_power_kw, 90.0)


def test_dispatch_day_validator_rejects_shifted_and_dst_windows() -> None:
    natural = pd.date_range("2025-06-17T07:00:00Z", periods=96, freq="15min")
    _validate_complete_local_calendar_day(natural)

    shifted = pd.date_range("2025-06-17T08:00:00Z", periods=96, freq="15min")
    with pytest.raises(ValueError, match="local natural day"):
        _validate_complete_local_calendar_day(shifted)

    spring_dst = pd.date_range("2025-03-09T08:00:00Z", periods=96, freq="15min")
    with pytest.raises(ValueError, match="DST transition"):
        _validate_complete_local_calendar_day(spring_dst)


def test_result_directory_guard_prevents_path_escape_and_stale_artifact_mixing(
    tmp_path,
) -> None:
    root = tmp_path / "results"
    output = _new_result_directory(root, "ablation/full")
    assert output == (root / "ablation" / "full").resolve()

    (output / "stale.json").write_text("{}", encoding="utf-8")
    with pytest.raises(ValueError, match="not empty"):
        _new_result_directory(root, "ablation/full")
    with pytest.raises(ValueError, match="stay inside"):
        _new_result_directory(root, "../outside")
