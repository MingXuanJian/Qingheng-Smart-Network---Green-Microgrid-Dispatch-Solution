from dataclasses import asdict, replace

import numpy as np
import pandas as pd
import pytest

from qingheng.config import DispatchConfig
from qingheng.data.hybrid import synthetic_wind_availability
from qingheng.scenario_sizing import calibrate_socal_dispatch


def _sizing_frame() -> pd.DataFrame:
    index = pd.date_range("2024-10-01", periods=96 * 40, freq="15min", tz="UTC")
    local = index.tz_convert("America/Los_Angeles")
    solar = np.sin(np.pi * np.clip((local.hour.to_numpy() - 6.0) / 12.0, 0.0, 1.0))
    return pd.DataFrame(
        {"load_kw": np.full(len(index), 100.0), "pv_kw": 180.0 * solar},
        index=index,
    )


def test_socal_sizing_uses_training_rows_only_and_records_formula() -> None:
    frame = _sizing_frame()
    base = replace(DispatchConfig(), grid_export_price_fraction=0.35)
    first = calibrate_socal_dispatch(frame, base, wind_capacity_kw=0.0)
    modified = frame.copy()
    modified.iloc[int(len(frame) * 0.70) :, :] = 10_000.0
    second = calibrate_socal_dispatch(modified, base, wind_capacity_kw=0.0)

    assert asdict(first.dispatch) == asdict(second.dispatch)
    assert first.dispatch.grid_export_price_fraction == 0.0
    assert first.dispatch.battery_initial_soc == 0.5
    assert first.dispatch.hydrogen_initial_soc == 0.5
    assert first.dispatch.battery_capacity_kwh % 25.0 == 0.0
    assert first.dispatch.battery_power_kw % 5.0 == 0.0
    assert first.manifest["training_interval"]["rows_15min"] < len(frame)
    assert "not economic capacity optimization" in first.manifest["interpretation"]
    assert len(first.manifest["sizing_sha256"]) == 64


def test_synthetic_wind_is_stable_when_requesting_a_subset() -> None:
    full_index = pd.date_range("2024-10-01", periods=200, freq="15min", tz="UTC")
    full = synthetic_wind_availability(full_index, 15.0, 7)
    subset = synthetic_wind_availability(full_index[80:140], 15.0, 7)

    np.testing.assert_allclose(subset, full[80:140])


def test_socal_sizing_can_bind_to_an_explicit_forecast_train_interval() -> None:
    frame = _sizing_frame()
    start = frame.index[96]
    end = frame.index[96 * 25]

    result = calibrate_socal_dispatch(
        frame,
        DispatchConfig(),
        train_start=start,
        train_end_exclusive=end,
    )

    interval = result.manifest["training_interval"]
    assert interval["selection"] == "forecast artifact target train interval"
    assert interval["start"] == start.isoformat()
    assert interval["end_exclusive"] == end.isoformat()
    assert interval["train_fraction"] is None


def test_socal_sizing_disables_devices_when_training_has_no_shiftable_surplus() -> None:
    frame = _sizing_frame()
    frame["pv_kw"] = 0.0

    result = calibrate_socal_dispatch(frame, DispatchConfig())

    assert not result.dispatch.battery_enabled
    assert result.dispatch.battery_capacity_kwh == 0.0
    assert not result.dispatch.hydrogen_enabled
    assert result.dispatch.hydrogen_capacity_kwh == 0.0


@pytest.mark.parametrize(
    ("start", "end", "hourly_rows"),
    [
        ("2024-11-02T07:00:00Z", "2024-11-05T08:00:00Z", 73),
        ("2025-03-08T08:00:00Z", "2025-03-11T07:00:00Z", 71),
    ],
)
def test_socal_sizing_excludes_dst_transition_days(
    start: str,
    end: str,
    hourly_rows: int,
) -> None:
    index = pd.date_range(start, end, freq="15min", inclusive="left")
    frame = pd.DataFrame(
        {"load_kw": np.full(len(index), 100.0), "pv_kw": np.zeros(len(index))},
        index=index,
    )

    result = calibrate_socal_dispatch(
        frame,
        DispatchConfig(),
        train_start=index[0],
        train_end_exclusive=pd.Timestamp(end),
    )

    interval = result.manifest["training_interval"]
    assert interval["rows_hourly"] == hourly_rows
    assert interval["complete_local_days"] == 2
    assert "DST transition days are excluded" in interval["complete_local_day_policy"]


@pytest.mark.parametrize("bad_value", [np.nan, -1.0])
def test_socal_sizing_rejects_invalid_training_power_values(bad_value: float) -> None:
    frame = _sizing_frame()
    frame.iloc[200, frame.columns.get_loc("load_kw")] = bad_value

    with pytest.raises(ValueError, match="non-finite|non-negative"):
        calibrate_socal_dispatch(frame, DispatchConfig())


def test_socal_sizing_rejects_off_grid_training_timestamps() -> None:
    frame = _sizing_frame()
    shifted = frame.copy()
    shifted.index = shifted.index + pd.Timedelta(minutes=1)

    with pytest.raises(ValueError, match="15-minute boundaries"):
        calibrate_socal_dispatch(shifted, DispatchConfig())
