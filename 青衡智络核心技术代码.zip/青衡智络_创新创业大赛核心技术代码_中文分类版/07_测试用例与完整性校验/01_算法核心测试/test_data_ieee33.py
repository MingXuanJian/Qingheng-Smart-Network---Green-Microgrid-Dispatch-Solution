import os
from pathlib import Path

import pytest

from qingheng.data import load_ieee33_from_mpte


MPTE_ROOT = Path(os.environ.get("QINGHENG_MPTE_ROOT", "external/mpte_topology_reconstruction"))


def test_ieee33_adapter_rejects_incomplete_checkout(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError, match="incomplete MPTE checkout"):
        load_ieee33_from_mpte(tmp_path)


@pytest.mark.skipif(not MPTE_ROOT.is_dir(), reason="local MPTE evidence checkout is unavailable")
def test_ieee33_adapter_loads_read_only_canonical_arrays() -> None:
    network = load_ieee33_from_mpte(MPTE_ROOT)
    assert network.n_bus == 33
    assert network.n_branch == 37
    assert network.base_switch_state.sum() == 32
    assert network.load_p_kw.sum() == pytest.approx(3715.0)
    assert len(network.topology_hash) == 64
    assert not network.load_p_kw.flags.writeable
    assert not network.branch_from.flags.writeable
    with pytest.raises(ValueError):
        network.load_p_kw[0] = 1.0
