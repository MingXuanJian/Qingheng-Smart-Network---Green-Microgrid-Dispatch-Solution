from __future__ import annotations

import importlib.util

import numpy as np
import pandas as pd
import pytest

from qingheng.forecast import (
    StandardScaler,
    clip_nonnegative_predictions,
    persistence_forecast,
    prepare_windowed_data,
    regression_metrics,
)


TORCH_AVAILABLE = importlib.util.find_spec("torch") is not None


@pytest.mark.skipif(not TORCH_AVAILABLE, reason="forecast optional dependency is absent")
def test_chronological_windows_and_train_only_scaling() -> None:
    rows = 120
    index = pd.date_range("2025-01-01", periods=rows, freq="15min", tz="UTC")
    frame = pd.DataFrame(
        {
            "pv_kw": np.arange(rows, dtype=float),
            "load_kw": 2.0 * np.arange(rows, dtype=float) + 10.0,
            "hour_sin": np.sin(np.arange(rows) / 4.0),
        },
        index=index,
    )
    splits = prepare_windowed_data(
        frame,
        feature_columns=("pv_kw", "load_kw", "hour_sin"),
        target_columns=("pv_kw", "load_kw"),
        input_steps=8,
        horizon_steps=4,
        train_fraction=0.60,
        validation_fraction=0.20,
    )

    assert splits.boundaries.train_end == 72
    np.testing.assert_allclose(
        splits.feature_scaler.mean,
        frame.iloc[:72][["pv_kw", "load_kw", "hour_sin"]].mean().to_numpy(),
    )
    assert splits.train.target_row_ranges[:, 1].max() <= 72
    assert splits.validation.target_row_ranges[:, 0].min() >= 72
    assert splits.validation.target_row_ranges[:, 1].max() <= 96
    assert splits.test.target_row_ranges[:, 0].min() >= 96
    # Prior observations are valid context, while validation targets begin at row 72.
    assert splits.validation.starts[0] == 72 - 8

    seasonal = splits.test.seasonal_persistence_predictions(period_steps=8)
    reference_starts = splits.test.target_row_ranges[:, 0] - 8
    reference_rows = reference_starts[:, None] + np.arange(4)[None, :]
    np.testing.assert_array_equal(seasonal, splits.test.targets[reference_rows])
    with pytest.raises(ValueError, match="input history"):
        splits.test.seasonal_persistence_predictions(period_steps=9)
    with pytest.raises(ValueError, match="horizon_steps"):
        splits.test.seasonal_persistence_predictions(period_steps=3)


def test_persistence_and_metrics_have_expected_values() -> None:
    history = np.array([[1.0, 3.0], [2.0, 5.0]])
    expected = np.array([[2.0, 5.0], [2.0, 5.0], [2.0, 5.0]])
    np.testing.assert_array_equal(persistence_forecast(history, 3), expected)

    actual = np.array([1.0, 2.0, 3.0])
    predicted = np.array([1.0, 3.0, 2.0])
    metrics = regression_metrics(actual, predicted)
    assert metrics["mae"] == pytest.approx(2.0 / 3.0)
    assert metrics["rmse"] == pytest.approx(np.sqrt(2.0 / 3.0))
    assert 0.0 < metrics["smape_percent"] < 200.0


def test_nonnegative_power_projection_reports_every_clipped_value() -> None:
    raw = np.array([[[-1.0, 2.0], [3.0, -4.0]], [[0.0, -0.5], [5.0, 6.0]]])
    physical, audit = clip_nonnegative_predictions(raw, ("load_kw", "pv_kw"))

    np.testing.assert_array_equal(
        physical,
        np.array([[[0.0, 2.0], [3.0, 0.0]], [[0.0, 0.0], [5.0, 6.0]]]),
    )
    assert audit["clipped_value_count"] == 3
    assert audit["total_value_count"] == 8
    assert audit["clipped_fraction"] == pytest.approx(3.0 / 8.0)
    assert audit["per_target_clipped_value_count"] == {"load_kw": 1, "pv_kw": 2}


def test_standard_scaler_rejects_corrupt_serialized_state_and_nonfinite_values() -> None:
    with pytest.raises(ValueError, match="one-dimensional"):
        StandardScaler.from_dict({"mean": [[1.0]], "scale": [[1.0]]})
    with pytest.raises(ValueError, match="positive"):
        StandardScaler.from_dict({"mean": [1.0], "scale": [0.0]})
    with pytest.raises(ValueError, match="finite"):
        StandardScaler.from_dict({"mean": [np.nan], "scale": [1.0]})

    scaler = StandardScaler.from_dict({"mean": [1.0], "scale": [2.0]})
    with pytest.raises(ValueError, match="NaN"):
        scaler.transform(np.array([[np.nan]]))
