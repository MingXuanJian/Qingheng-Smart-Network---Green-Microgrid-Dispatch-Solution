from dataclasses import replace
import os
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

from qingheng.config import CarbonConfig, DispatchConfig
from qingheng.dispatch import DispatchInputs, MultiEnergyDispatchProblem
from qingheng.network import DevicePlacement, IEEE33ScheduleValidator, PowerFlowValidation
from qingheng.pipeline import run_carbon_accounting


MPTE_ROOT = Path(os.environ.get("QINGHENG_MPTE_ROOT", "external/mpte_topology_reconstruction"))


def _single_bus_network(
    slack_power_kw: np.ndarray,
) -> tuple[SimpleNamespace, PowerFlowValidation]:
    horizon = slack_power_kw.size
    validator = SimpleNamespace(
        feeder=SimpleNamespace(
            load_p_kw=np.array([1.0]),
            n_bus=1,
            slack_bus=0,
        ),
        placement=DevicePlacement(
            pv_bus=1,
            wind_bus=1,
            battery_bus=1,
            hydrogen_bus=1,
            fixed_generation_bus=1,
        ),
    )
    validation = PowerFlowValidation(
        timeseries=pd.DataFrame({"step": np.arange(horizon)}),
        branch_flows_kw=np.empty((horizon, 0)),
        branch_to_end_flows_kw=np.empty((horizon, 0)),
        bus_injections_kw=slack_power_kw.reshape(-1, 1),
        branch_from_bus=np.empty(0, dtype=np.int64),
        branch_to_bus=np.empty(0, dtype=np.int64),
        all_converged=True,
        voltage_feasible=True,
        current_feasible=True,
        grid_feasible=True,
    )
    return validator, validation


def test_carbon_accounting_uses_time_varying_input_renewable_factors() -> None:
    horizon = 2
    inputs = DispatchInputs.from_arrays(
        load_kw=np.full(horizon, 100.0),
        pv_available_kw=np.full(horizon, 20.0),
        wind_available_kw=np.full(horizon, 10.0),
        buy_price_per_kwh=np.ones(horizon),
        grid_carbon_kg_per_kwh=np.full(horizon, 0.5),
        pv_carbon_kg_per_kwh=np.array([0.01, 0.11]),
        wind_carbon_kg_per_kwh=np.array([0.02, 0.22]),
    )
    config = replace(DispatchConfig(), horizon_steps=horizon)
    dispatch = MultiEnergyDispatchProblem(inputs, config).zero_dispatch()
    assert np.allclose(dispatch.grid_power_kw, 70.0)

    feeder = SimpleNamespace(
        load_p_kw=np.array([100.0]),
        n_bus=1,
        slack_bus=0,
    )
    validator = SimpleNamespace(
        feeder=feeder,
        placement=DevicePlacement(
            pv_bus=1,
            wind_bus=1,
            battery_bus=1,
            hydrogen_bus=1,
            fixed_generation_bus=1,
        ),
    )
    validation = PowerFlowValidation(
        timeseries=pd.DataFrame({"step": np.arange(horizon)}),
        branch_flows_kw=np.empty((horizon, 0)),
        branch_to_end_flows_kw=np.empty((horizon, 0)),
        bus_injections_kw=np.full((horizon, 1), 70.0),
        branch_from_bus=np.empty(0, dtype=np.int64),
        branch_to_bus=np.empty(0, dtype=np.int64),
        all_converged=True,
        voltage_feasible=True,
        current_feasible=True,
        grid_feasible=True,
    )

    accounting = run_carbon_accounting(
        inputs=inputs,
        dispatch=dispatch,
        dispatch_config=config,
        # Deliberately different defaults prove tracing follows DispatchInputs.
        carbon_config=CarbonConfig(pv_kg_per_kwh=9.0, wind_kg_per_kwh=8.0),
        validator=validator,
        validation=validation,
    )

    expected_by_step = np.array(
        [
            70.0 * 0.5 + 20.0 * 0.01 + 10.0 * 0.02,
            70.0 * 0.5 + 20.0 * 0.11 + 10.0 * 0.22,
        ]
    )
    assert [
        trace.node_intensity_kg_per_kwh[1] for trace in accounting.traces
    ] == pytest.approx(expected_by_step / 100.0)
    assert accounting.external_source_emissions_kg == pytest.approx(expected_by_step.sum())
    assert accounting.load_allocated_emissions_kg == pytest.approx(expected_by_step.sum())
    assert abs(accounting.carbon_balance_residual_kg) < 1e-8


def test_carbon_accounting_allows_a_physical_ac_flow_with_a_pcc_violation() -> None:
    inputs = DispatchInputs.from_arrays(
        load_kw=np.full(1, 100.0),
        pv_available_kw=np.zeros(1),
        wind_available_kw=np.zeros(1),
        buy_price_per_kwh=np.ones(1),
        grid_carbon_kg_per_kwh=np.full(1, 0.5),
    )
    config = replace(DispatchConfig(), horizon_steps=1)
    dispatch = MultiEnergyDispatchProblem(inputs, config).zero_dispatch()
    validator, validation = _single_bus_network(dispatch.grid_power_kw)
    validation = replace(validation, grid_feasible=False)

    accounting = run_carbon_accounting(
        inputs=inputs,
        dispatch=dispatch,
        dispatch_config=config,
        carbon_config=CarbonConfig(),
        validator=validator,
        validation=validation,
    )

    assert not validation.feasible
    assert accounting.external_source_emissions_kg == pytest.approx(50.0)
    assert accounting.load_allocated_emissions_kg == pytest.approx(50.0)
    assert abs(accounting.carbon_balance_residual_kg) < 1e-8


def test_carbon_accounting_carries_green_inventory_across_horizons() -> None:
    first_config = replace(
        DispatchConfig(),
        horizon_steps=1,
        battery_capacity_kwh=100.0,
        battery_power_kw=50.0,
        battery_initial_soc=0.1,
        battery_min_soc=0.0,
        battery_max_soc=1.0,
        battery_charge_efficiency=1.0,
        battery_discharge_efficiency=1.0,
        hydrogen_capacity_kwh=100.0,
        hydrogen_power_kw=50.0,
        hydrogen_initial_soc=0.1,
        hydrogen_min_soc=0.0,
        hydrogen_max_soc=1.0,
        electrolyzer_efficiency=1.0,
        fuel_cell_efficiency=1.0,
    )
    charge_inputs = DispatchInputs.from_arrays(
        load_kw=np.zeros(1),
        pv_available_kw=np.full(1, 20.0),
        wind_available_kw=np.zeros(1),
        buy_price_per_kwh=np.ones(1),
        grid_carbon_kg_per_kwh=np.full(1, 0.57),
    )
    charge_dispatch = MultiEnergyDispatchProblem(charge_inputs, first_config).evaluate(
        np.array([-10.0, -10.0, 1.0]),
        enforce_terminal_inventory=False,
    )
    assert charge_dispatch.feasible
    charge_validator, charge_validation = _single_bus_network(
        charge_dispatch.grid_power_kw
    )
    charged = run_carbon_accounting(
        inputs=charge_inputs,
        dispatch=charge_dispatch,
        dispatch_config=first_config,
        carbon_config=CarbonConfig(),
        validator=charge_validator,
        validation=charge_validation,
    )

    assert charged.opening_storage_green_inventory_kwh == pytest.approx(0.0)
    assert charged.closing_battery_green_inventory_kwh == pytest.approx(10.0)
    assert charged.closing_hydrogen_green_inventory_kwh == pytest.approx(10.0)
    assert charged.closing_storage_green_inventory_kwh == pytest.approx(20.0)
    assert abs(charged.green_inventory_balance_residual_kwh) < 1e-12

    second_config = replace(
        first_config,
        battery_initial_soc=0.2,
        hydrogen_initial_soc=0.2,
    )
    discharge_inputs = DispatchInputs.from_arrays(
        load_kw=np.full(1, 20.0),
        pv_available_kw=np.zeros(1),
        wind_available_kw=np.zeros(1),
        buy_price_per_kwh=np.ones(1),
        grid_carbon_kg_per_kwh=np.full(1, 0.57),
    )
    discharge_dispatch = MultiEnergyDispatchProblem(
        discharge_inputs, second_config
    ).evaluate(
        np.array([10.0, 10.0, 1.0]),
        enforce_terminal_inventory=False,
    )
    assert discharge_dispatch.feasible
    discharge_validator, discharge_validation = _single_bus_network(
        discharge_dispatch.grid_power_kw
    )
    battery_factor = (
        charged.snapshots["battery_carbon_kg_end"].iloc[-1]
        / charge_dispatch.battery_energy_kwh[-1]
    )
    hydrogen_factor = (
        charged.snapshots["hydrogen_carbon_kg_end"].iloc[-1]
        / charge_dispatch.hydrogen_energy_kwh[-1]
    )
    discharged = run_carbon_accounting(
        inputs=discharge_inputs,
        dispatch=discharge_dispatch,
        dispatch_config=second_config,
        carbon_config=CarbonConfig(),
        validator=discharge_validator,
        validation=discharge_validation,
        initial_battery_factor_kg_per_kwh=battery_factor,
        initial_hydrogen_factor_kg_per_kwh=hydrogen_factor,
        initial_battery_green_inventory_kwh=(
            charged.closing_battery_green_inventory_kwh
        ),
        initial_hydrogen_green_inventory_kwh=(
            charged.closing_hydrogen_green_inventory_kwh
        ),
    )

    assert discharged.opening_storage_green_inventory_kwh == pytest.approx(20.0)
    assert discharged.closing_battery_green_inventory_kwh == pytest.approx(5.0)
    assert discharged.closing_hydrogen_green_inventory_kwh == pytest.approx(5.0)
    assert discharged.closing_storage_green_inventory_kwh == pytest.approx(10.0)
    assert discharged.snapshots["battery_green_inventory_kwh_end"].iloc[-1] == (
        pytest.approx(5.0)
    )
    assert discharged.snapshots["hydrogen_green_inventory_kwh_end"].iloc[-1] == (
        pytest.approx(5.0)
    )
    assert discharged.metrics.mediated_green_consumed_kwh == pytest.approx(10.0)
    assert discharged.metrics.green_self_use_rate == pytest.approx(0.5)
    assert abs(discharged.battery_green_inventory_balance_residual_kwh) < 1e-12
    assert abs(discharged.hydrogen_green_inventory_balance_residual_kwh) < 1e-12
    assert abs(discharged.green_inventory_balance_residual_kwh) < 1e-12
    assert discharged.metrics_dict()["closing_storage_green_inventory_kwh"] == (
        pytest.approx(10.0)
    )


@pytest.mark.parametrize(
    ("argument", "value"),
    [
        ("initial_battery_green_inventory_kwh", -1.0),
        ("initial_battery_green_inventory_kwh", np.nan),
        ("initial_battery_green_inventory_kwh", True),
        ("initial_battery_green_inventory_kwh", 10.1),
        ("initial_hydrogen_green_inventory_kwh", "1.0"),
        ("initial_hydrogen_green_inventory_kwh", np.inf),
        ("initial_hydrogen_green_inventory_kwh", 10.1),
    ],
)
def test_carbon_accounting_rejects_invalid_initial_green_inventory(
    argument: str,
    value: object,
) -> None:
    config = replace(
        DispatchConfig(),
        horizon_steps=1,
        battery_capacity_kwh=100.0,
        battery_power_kw=50.0,
        battery_initial_soc=0.1,
        battery_min_soc=0.0,
        battery_max_soc=1.0,
        hydrogen_capacity_kwh=100.0,
        hydrogen_power_kw=50.0,
        hydrogen_initial_soc=0.1,
        hydrogen_min_soc=0.0,
        hydrogen_max_soc=1.0,
    )
    inputs = DispatchInputs.from_arrays(
        load_kw=np.ones(1),
        pv_available_kw=np.zeros(1),
        wind_available_kw=np.zeros(1),
        buy_price_per_kwh=np.ones(1),
        grid_carbon_kg_per_kwh=np.full(1, 0.57),
    )
    dispatch = MultiEnergyDispatchProblem(inputs, config).zero_dispatch()
    validator, validation = _single_bus_network(dispatch.grid_power_kw)

    with pytest.raises(ValueError, match=argument):
        run_carbon_accounting(
            inputs=inputs,
            dispatch=dispatch,
            dispatch_config=config,
            carbon_config=CarbonConfig(),
            validator=validator,
            validation=validation,
            **{argument: value},
        )


@pytest.mark.skipif(not MPTE_ROOT.exists(), reason="external MPTE repository unavailable")
def test_network_dispatch_carbon_pipeline_balances() -> None:
    horizon = 2
    inputs = DispatchInputs.from_arrays(
        load_kw=np.array([1000.0, 1100.0]),
        pv_available_kw=np.array([100.0, 200.0]),
        wind_available_kw=np.array([80.0, 80.0]),
        buy_price_per_kwh=np.ones(horizon),
        grid_carbon_kg_per_kwh=np.full(horizon, 0.57),
        fixed_generation_kw=np.full(horizon, 50.0),
        fixed_generation_carbon_kg_per_kwh=np.full(horizon, 0.2),
    )
    dispatch_config = replace(DispatchConfig(), horizon_steps=horizon)
    dispatch = MultiEnergyDispatchProblem(inputs, dispatch_config).zero_dispatch()
    validator = IEEE33ScheduleValidator(MPTE_ROOT)
    validation = validator.validate(inputs, dispatch)
    accounting = run_carbon_accounting(
        inputs=inputs,
        dispatch=dispatch,
        dispatch_config=dispatch_config,
        carbon_config=CarbonConfig(),
        validator=validator,
        validation=validation,
    )
    assert len(accounting.traces) == horizon
    assert accounting.snapshots["maximum_balance_residual_kw"].max() < 1e-3
    assert accounting.metrics.unit_supply_carbon_intensity_kg_per_kwh > 0
    assert abs(accounting.carbon_balance_residual_kg) < 1e-6


@pytest.mark.skipif(not MPTE_ROOT.exists(), reason="external MPTE repository unavailable")
def test_storage_export_is_not_reported_as_green_self_use_or_new_emissions() -> None:
    horizon = 2
    inputs = DispatchInputs.from_arrays(
        load_kw=np.zeros(horizon),
        pv_available_kw=np.array([100.0, 0.0]),
        wind_available_kw=np.zeros(horizon),
        buy_price_per_kwh=np.ones(horizon),
        sell_price_per_kwh=np.zeros(horizon),
        grid_carbon_kg_per_kwh=np.full(horizon, 0.57),
        pv_carbon_kg_per_kwh=np.full(horizon, 0.041),
    )
    dispatch_config = replace(
        DispatchConfig(),
        horizon_steps=horizon,
        battery_capacity_kwh=100.0,
        battery_power_kw=60.0,
        battery_initial_soc=0.1,
        battery_min_soc=0.1,
        battery_max_soc=0.9,
        battery_charge_efficiency=1.0,
        battery_discharge_efficiency=1.0,
        terminal_tolerance=0.0,
    )
    problem = MultiEnergyDispatchProblem(inputs, dispatch_config)
    decision = np.concatenate([np.array([-50.0, 50.0]), np.zeros(horizon), np.array([1.0, 0.0])])
    dispatch = problem.evaluate(decision)
    assert dispatch.feasible
    validator = IEEE33ScheduleValidator(MPTE_ROOT)
    validation = validator.validate(inputs, dispatch)

    accounting = run_carbon_accounting(
        inputs=inputs,
        dispatch=dispatch,
        dispatch_config=dispatch_config,
        carbon_config=CarbonConfig(),
        validator=validator,
        validation=validation,
    )

    assert accounting.metrics.mediated_green_consumed_kwh == pytest.approx(0.0)
    assert accounting.metrics.green_self_use_rate == pytest.approx(0.0)
    assert accounting.external_source_emissions_kg == pytest.approx(4.1)


@pytest.mark.skipif(not MPTE_ROOT.exists(), reason="external MPTE repository unavailable")
def test_storage_charging_at_a_load_bus_is_not_counted_as_user_consumption() -> None:
    inputs = DispatchInputs.from_arrays(
        load_kw=np.array([1000.0, 1000.0]),
        pv_available_kw=np.array([800.0, 0.0]),
        wind_available_kw=np.zeros(2),
        buy_price_per_kwh=np.ones(2),
        grid_carbon_kg_per_kwh=np.full(2, 0.57),
        pv_carbon_kg_per_kwh=np.full(2, 0.041),
    )
    config = replace(DispatchConfig(), horizon_steps=2, terminal_tolerance=0.0)
    problem = MultiEnergyDispatchProblem(inputs, config)
    decision = np.concatenate([np.array([-100.0, 90.25]), np.zeros(2), np.ones(2)])
    dispatch = problem.evaluate(decision)
    assert dispatch.feasible
    validator = IEEE33ScheduleValidator(MPTE_ROOT)
    validation = validator.validate(inputs, dispatch)

    accounting = run_carbon_accounting(
        inputs=inputs,
        dispatch=dispatch,
        dispatch_config=config,
        carbon_config=CarbonConfig(),
        validator=validator,
        validation=validation,
    )
    total_base_load = float(validator.feeder.load_p_kw.sum())
    expected = 0.0
    for step, trace in enumerate(accounting.traces):
        scale = inputs.load_kw[step] / total_base_load
        expected += sum(
            float(base_kw * scale) * trace.node_intensity_kg_per_kwh[bus]
            for bus, base_kw in enumerate(validator.feeder.load_p_kw, start=1)
            if base_kw > 0.0
        )

    assert accounting.load_allocated_emissions_kg == pytest.approx(expected)
    assert abs(accounting.carbon_balance_residual_kg) < 1e-6


@pytest.mark.skipif(not MPTE_ROOT.exists(), reason="external MPTE repository unavailable")
def test_carbon_accounting_tolerates_sub_trace_threshold_storage_power() -> None:
    horizon = 3
    inputs = DispatchInputs.from_arrays(
        load_kw=np.full(horizon, 1000.0),
        pv_available_kw=np.zeros(horizon),
        wind_available_kw=np.zeros(horizon),
        buy_price_per_kwh=np.ones(horizon),
        grid_carbon_kg_per_kwh=np.full(horizon, 0.57),
    )
    config = replace(
        DispatchConfig(),
        horizon_steps=horizon,
        battery_charge_efficiency=0.95,
        battery_discharge_efficiency=0.95,
        terminal_tolerance=0.0,
    )
    problem = MultiEnergyDispatchProblem(inputs, config)
    battery = np.array([10.0, 2.6e-5, -(10.0 + 2.6e-5) / 0.95**2])
    decision = np.concatenate([battery, np.zeros(horizon), np.ones(horizon)])
    dispatch = problem.evaluate(decision)
    assert dispatch.feasible
    validator = IEEE33ScheduleValidator(MPTE_ROOT)
    validation = validator.validate(inputs, dispatch)

    accounting = run_carbon_accounting(
        inputs=inputs,
        dispatch=dispatch,
        dispatch_config=config,
        carbon_config=CarbonConfig(),
        validator=validator,
        validation=validation,
    )

    assert len(accounting.snapshots) == horizon


@pytest.mark.skipif(not MPTE_ROOT.exists(), reason="external MPTE repository unavailable")
def test_carbon_reservoir_uses_the_trace_state_tolerance_at_soc_boundary() -> None:
    horizon = 24
    inputs = DispatchInputs.from_arrays(
        load_kw=np.full(horizon, 1000.0),
        pv_available_kw=np.zeros(horizon),
        wind_available_kw=np.zeros(horizon),
        buy_price_per_kwh=np.ones(horizon),
        grid_carbon_kg_per_kwh=np.full(horizon, 0.57),
    )
    config = replace(
        DispatchConfig(),
        horizon_steps=horizon,
        battery_capacity_kwh=525.0,
        battery_power_kw=135.0,
        battery_initial_soc=0.1,
        battery_min_soc=0.1,
        terminal_tolerance=0.0,
    )
    battery = np.zeros(horizon)
    battery[0] = 1.4e-4
    decision = np.concatenate([battery, np.zeros(horizon), np.ones(horizon)])
    dispatch = MultiEnergyDispatchProblem(inputs, config).evaluate(
        decision,
        enforce_terminal_inventory=False,
    )
    assert dispatch.feasible
    validator = IEEE33ScheduleValidator(MPTE_ROOT)
    validation = validator.validate(inputs, dispatch)

    accounting = run_carbon_accounting(
        inputs=inputs,
        dispatch=dispatch,
        dispatch_config=config,
        carbon_config=CarbonConfig(),
        validator=validator,
        validation=validation,
    )

    assert abs(accounting.carbon_balance_residual_kg) < 1e-6
