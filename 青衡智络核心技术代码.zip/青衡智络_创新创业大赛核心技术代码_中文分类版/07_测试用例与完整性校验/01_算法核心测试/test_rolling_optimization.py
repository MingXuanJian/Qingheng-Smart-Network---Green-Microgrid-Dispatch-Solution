from __future__ import annotations

from dataclasses import replace

import numpy as np
import pandas as pd
import pytest

from qingheng.config import DispatchConfig
from qingheng.dispatch import DispatchInputs, MultiEnergyDispatchProblem
from qingheng.dispatch.optimizers import OptimizationResult
from qingheng.network import PowerFlowValidation
from qingheng.rolling_optimization import (
    ForecastSeedSelectionError,
    rolling_day_seeds,
    select_forecast_feasible_seed,
)


def _problem() -> MultiEnergyDispatchProblem:
    horizon = 2
    inputs = DispatchInputs.from_arrays(
        load_kw=np.full(horizon, 10.0),
        pv_available_kw=np.full(horizon, 5.0),
        wind_available_kw=np.zeros(horizon),
        buy_price_per_kwh=np.ones(horizon),
        grid_carbon_kg_per_kwh=np.full(horizon, 0.5),
    )
    config = replace(
        DispatchConfig(),
        horizon_steps=horizon,
        battery_enabled=False,
        battery_capacity_kwh=0.0,
        battery_power_kw=0.0,
        hydrogen_enabled=False,
        hydrogen_capacity_kwh=0.0,
        hydrogen_power_kw=0.0,
    )
    return MultiEnergyDispatchProblem(inputs, config)


class _Network:
    def __init__(self, *, grid_feasible: bool = True) -> None:
        self.grid_feasible = grid_feasible
        self.limit_calls: list[tuple[float | None, float | None]] = []

    def validate(self, inputs, dispatch, **kwargs) -> PowerFlowValidation:
        self.limit_calls.append(
            (
                kwargs.get("grid_import_limit_kw"),
                kwargs.get("grid_export_limit_kw"),
            )
        )
        horizon = inputs.horizon
        return PowerFlowValidation(
            timeseries=pd.DataFrame(
                {
                    "slack_power_kw": dispatch.grid_power_kw,
                    "min_voltage_pu": np.full(horizon, 0.99),
                    "max_voltage_pu": np.full(horizon, 1.01),
                    "active_loss_kw": np.zeros(horizon),
                }
            ),
            branch_flows_kw=np.zeros((horizon, 1)),
            branch_to_end_flows_kw=np.zeros((horizon, 1)),
            bus_injections_kw=np.zeros((horizon, 2)),
            branch_from_bus=np.array([1]),
            branch_to_bus=np.array([2]),
            all_converged=True,
            voltage_feasible=True,
            current_feasible=None,
            grid_feasible=self.grid_feasible,
        )


def test_rolling_day_seeds_are_common_and_shifted() -> None:
    assert rolling_day_seeds((100, 200, 300), 4) == (104, 204, 304)
    with pytest.raises(ValueError, match="unique"):
        rolling_day_seeds((1, 1), 0)
    with pytest.raises(ValueError, match="non-negative"):
        rolling_day_seeds((-1, 2), 0)


def test_multiseed_selection_uses_forecast_score_only(monkeypatch: pytest.MonkeyPatch) -> None:
    problem = _problem()

    def fake_optimizer(
        objective,
        lower_bounds,
        upper_bounds,
        *,
        seed,
        **kwargs,
    ) -> OptimizationResult:
        del objective, upper_bounds, kwargs
        position = problem.zero_decision()
        position[-problem.inputs.horizon :] = 1.0 if seed == 20 else 0.5
        score = problem.evaluate(position).score
        return OptimizationResult(
            algorithm="pso",
            seed=seed,
            best_position=position,
            best_score=score,
            history=np.array([score]),
            evaluations=1,
        )

    monkeypatch.setattr(
        "qingheng.rolling_optimization.particle_swarm_optimization",
        fake_optimizer,
    )
    network = _Network()
    selected = select_forecast_feasible_seed(
        problem,
        network,  # type: ignore[arg-type]
        seeds=(10, 20, 30),
        population=4,
        iterations=1,
        terminal_tolerance_kwh=1e-8,
        carbon_tolerance_kg=1e-8,
        physical_grid_import_limit_kw=123.0,
        physical_grid_export_limit_kw=456.0,
    )

    assert selected.seed == 20
    assert selected.audit["eligible"].all()
    assert selected.audit.loc[selected.audit["selected"], "seed"].item() == 20
    assert selected.audit["seed"].tolist() == [10, 20, 30]
    assert selected.audit["restart_index"].tolist() == [0, 1, 2]
    assert network.limit_calls == [(123.0, 456.0)] * 3
    assert selected.audit["optimizer_score_consistent"].all()


def test_multiseed_failure_has_runtime_exception_and_complete_audit(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    problem = _problem()

    def fake_optimizer(
        objective,
        lower_bounds,
        upper_bounds,
        *,
        seed,
        **kwargs,
    ) -> OptimizationResult:
        del objective, upper_bounds, kwargs
        position = problem.zero_decision()
        score = problem.evaluate(position).score
        return OptimizationResult(
            algorithm="pso",
            seed=seed,
            best_position=position,
            best_score=score,
            history=np.array([score]),
            evaluations=1,
        )

    monkeypatch.setattr(
        "qingheng.rolling_optimization.particle_swarm_optimization",
        fake_optimizer,
    )
    with pytest.raises(ForecastSeedSelectionError) as captured:
        select_forecast_feasible_seed(
            problem,
            _Network(grid_feasible=False),  # type: ignore[arg-type]
            seeds=(10, 20),
            population=4,
            iterations=1,
            terminal_tolerance_kwh=1e-8,
            carbon_tolerance_kg=1e-8,
            physical_grid_import_limit_kw=123.0,
            physical_grid_export_limit_kw=456.0,
        )

    audit = captured.value.audit
    assert audit["seed"].tolist() == [10, 20]
    assert not audit["eligible"].any()
    assert not audit["selected"].any()
    assert not audit["forecast_pcc_limit_feasible"].any()


@pytest.mark.parametrize(
    ("overrides", "message"),
    [
        ({"seeds": (-1,)}, "non-negative"),
        ({"population": 4.5}, "population"),
        ({"iterations": True}, "population"),
        ({"terminal_tolerance_kwh": True}, "terminal_tolerance"),
        ({"physical_grid_import_limit_kw": -1.0}, "physical_grid_import"),
    ],
)
def test_multiseed_rejects_invalid_controls(
    overrides: dict[str, object], message: str
) -> None:
    arguments: dict[str, object] = {
        "seeds": (10,),
        "population": 4,
        "iterations": 1,
        "terminal_tolerance_kwh": 1e-8,
        "carbon_tolerance_kg": 1e-8,
        "physical_grid_import_limit_kw": 123.0,
        "physical_grid_export_limit_kw": 456.0,
    }
    arguments.update(overrides)
    with pytest.raises(ValueError, match=message):
        select_forecast_feasible_seed(
            _problem(),
            _Network(),  # type: ignore[arg-type]
            **arguments,  # type: ignore[arg-type]
        )
