from __future__ import annotations

from hashlib import sha256

import numpy as np
import pandas as pd
import pytest

from qingheng.forecast_workflow import (
    _apply_target_blend,
    _complete_local_day_sample_indices,
    _non_overlapping_metric_bundle,
    _pv_conditioned_metrics,
    _seasonal_lag_predictions,
    _seasonal_reference_audit,
    _target_values_from_frame,
    _validation_selected_blend,
    _verify_optional_artifact_binding,
    _window_overlap_audit,
)


def test_complete_local_day_samples_select_local_midnight_only() -> None:
    index = pd.date_range("2025-06-17 06:45", periods=194, freq="15min", tz="UTC")
    ranges = np.column_stack((np.arange(99), np.arange(99) + 96))

    selected = _complete_local_day_sample_indices(
        index,
        ranges,
        horizon_steps=96,
    )

    assert selected.tolist() == [1, 97]


def test_optional_sidecar_artifact_hash_is_backward_compatible_and_enforced(tmp_path) -> None:
    artifact = tmp_path / "forecast.pt"
    artifact.write_bytes(b"authenticated forecast model")

    _verify_optional_artifact_binding({}, artifact)
    _verify_optional_artifact_binding(
        {
            "forecast_artifact": {
                "filename": artifact.name,
                "sha256": sha256(artifact.read_bytes()).hexdigest(),
            }
        },
        artifact,
    )
    with pytest.raises(ValueError, match="hash does not match"):
        _verify_optional_artifact_binding(
            {
                "forecast_artifact": {
                    "filename": artifact.name,
                    "sha256": "0" * 64,
                }
            },
            artifact,
        )


def test_seasonal_lag_predictions_use_only_prior_rows() -> None:
    frame = pd.DataFrame(
        {
            "load_kw": np.arange(16, dtype=float),
            "pv_kw": np.arange(100, 116, dtype=float),
        },
        index=pd.date_range("2025-01-01", periods=16, freq="15min", tz="UTC"),
    )
    ranges = np.asarray([[8, 10], [9, 11]])

    predicted = _seasonal_lag_predictions(
        frame,
        target_columns=("load_kw", "pv_kw"),
        target_row_ranges=ranges,
        period_steps=4,
    )

    np.testing.assert_array_equal(predicted[0], frame.iloc[4:6].to_numpy())
    np.testing.assert_array_equal(predicted[1], frame.iloc[5:7].to_numpy())
    np.testing.assert_array_equal(
        _target_values_from_frame(
            frame,
            target_columns=("load_kw", "pv_kw"),
            target_row_ranges=ranges,
        )[0],
        frame.iloc[8:10].to_numpy(),
    )
    with pytest.raises(ValueError, match="outside the frame"):
        _seasonal_lag_predictions(
            frame,
            target_columns=("load_kw", "pv_kw"),
            target_row_ranges=np.asarray([[2, 4]]),
            period_steps=4,
        )


def test_fixed_step_seasonal_audit_flags_dst_wall_clock_shift() -> None:
    frame = pd.DataFrame(
        index=pd.date_range("2025-03-08 08:00", periods=193, freq="15min", tz="UTC")
    )

    audit = _seasonal_reference_audit(
        frame,
        target_row_ranges=np.asarray([[96, 192]]),
        period_steps=96,
    )

    assert audit["fixed_elapsed_hours"] == pytest.approx(24.0)
    assert audit["local_wall_clock_mismatch_value_count"] > 0
    assert audit["same_local_wall_clock_for_all_scored_values"] is False


def test_validation_blend_selects_each_target_independently() -> None:
    actual = np.asarray([[[1.0, 9.0], [2.0, 8.0]]])
    left = np.asarray([[[1.0, 0.0], [2.0, 0.0]]])
    right = np.asarray([[[0.0, 9.0], [0.0, 8.0]]])
    columns = ("load_kw", "pv_kw")

    blended, weights = _validation_selected_blend(actual, left, right, columns)

    assert weights == {"load_kw": 1.0, "pv_kw": 0.0}
    np.testing.assert_allclose(blended, actual)
    np.testing.assert_allclose(_apply_target_blend(left, right, weights, columns), actual)


def test_diagnostics_separate_non_overlapping_and_daylight_values() -> None:
    index = pd.date_range("2025-06-01 14:00", periods=12, freq="1h", tz="UTC")
    frame = pd.DataFrame(index=index)
    actual = np.asarray([[[0.0], [2.0], [4.0]], [[2.0], [4.0], [0.0]]])
    predicted = np.asarray([[[1.0], [3.0], [5.0]], [[3.0], [5.0], [1.0]]])
    ranges = np.asarray([[0, 3], [1, 4]])

    non_overlapping = _non_overlapping_metric_bundle(actual, predicted, ranges, ("pv_kw",))
    conditioned = _pv_conditioned_metrics(
        frame,
        actual,
        predicted,
        ranges,
        pv_target_index=0,
    )

    assert non_overlapping["window_count"] == 1
    assert non_overlapping["basis"].startswith("chronological greedy non-overlapping")
    assert non_overlapping["overall"]["mae"] == pytest.approx(1.0)
    assert conditioned["actual_zero_fraction"] == pytest.approx(2 / 6)
    assert conditioned["positive_actual"]["mae"] == pytest.approx(1.0)
    assert "saturate at 200%" in conditioned["smape_caution"]

    weighting = _window_overlap_audit(ranges)
    assert weighting["scored_window_value_count"] == 6
    assert weighting["unique_target_row_count"] == 4
    assert weighting["mean_target_row_multiplicity"] == pytest.approx(1.5)
    assert weighting["maximum_target_row_multiplicity"] == 2
