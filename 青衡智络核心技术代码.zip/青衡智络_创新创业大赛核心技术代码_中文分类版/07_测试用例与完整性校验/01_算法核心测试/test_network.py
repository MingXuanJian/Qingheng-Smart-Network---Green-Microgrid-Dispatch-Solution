import os
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from qingheng.config import DispatchConfig
from qingheng.dispatch.problem import DispatchInputs, MultiEnergyDispatchProblem
from qingheng.network.ieee33 import (
    DevicePlacement,
    IEEE33ScheduleValidator,
    PowerFlowValidation,
    directed_branch_records,
)


MPTE_ROOT = Path(os.environ.get("QINGHENG_MPTE_ROOT", "external/mpte_topology_reconstruction"))


@pytest.mark.skipif(not MPTE_ROOT.exists(), reason="external MPTE repository unavailable")
def test_ieee33_schedule_validation_uses_external_engine_read_only() -> None:
    horizon = 2
    inputs = DispatchInputs.from_arrays(
        load_kw=np.full(horizon, 1200.0),
        pv_available_kw=np.array([200.0, 0.0]),
        wind_available_kw=np.array([100.0, 100.0]),
        buy_price_per_kwh=np.ones(horizon),
        grid_carbon_kg_per_kwh=np.full(horizon, 0.57),
    )
    cfg = DispatchConfig(horizon_steps=horizon)
    problem = MultiEnergyDispatchProblem(inputs, cfg)
    validator = IEEE33ScheduleValidator(MPTE_ROOT)
    result = validator.validate(inputs, problem.zero_dispatch())
    assert result.all_converged
    assert result.branch_flows_kw.shape == (horizon, 37)
    assert directed_branch_records(result, 0)


def test_directed_branch_records_use_sending_end_for_reverse_flow() -> None:
    validation = PowerFlowValidation(
        timeseries=pd.DataFrame(),
        branch_flows_kw=np.array([[10.0, -9.0]]),
        branch_to_end_flows_kw=np.array([[-9.5, 10.0]]),
        bus_injections_kw=np.zeros((1, 3)),
        branch_from_bus=np.array([1, 2], dtype=np.int64),
        branch_to_bus=np.array([2, 3], dtype=np.int64),
        all_converged=True,
        voltage_feasible=True,
        current_feasible=None,
        grid_feasible=None,
    )

    assert directed_branch_records(validation, 0) == [(1, 2, 10.0), (3, 2, 10.0)]
    with pytest.raises(IndexError, match="outside"):
        directed_branch_records(validation, -1)
    with pytest.raises(ValueError, match="tolerance"):
        directed_branch_records(validation, 0, tolerance_kw=-1.0)


@pytest.mark.skipif(not MPTE_ROOT.exists(), reason="external MPTE repository unavailable")
def test_ieee33_validator_rejects_slack_placement_and_invalid_limits() -> None:
    with pytest.raises(ValueError, match="slack bus"):
        IEEE33ScheduleValidator(MPTE_ROOT, placement=DevicePlacement(pv_bus=1))
    with pytest.raises(ValueError, match="integer"):
        IEEE33ScheduleValidator(MPTE_ROOT, placement=DevicePlacement(pv_bus=18.5))
    with pytest.raises(ValueError, match="max_current_pu"):
        IEEE33ScheduleValidator(MPTE_ROOT, max_current_pu=np.inf)


@pytest.mark.skipif(not MPTE_ROOT.exists(), reason="external MPTE repository unavailable")
def test_grid_limit_uses_loss_adjusted_slack_power() -> None:
    inputs = DispatchInputs.from_arrays(
        load_kw=[2500.0],
        pv_available_kw=[0.0],
        wind_available_kw=[0.0],
        buy_price_per_kwh=[1.0],
        grid_carbon_kg_per_kwh=[0.57],
    )
    config = DispatchConfig(horizon_steps=1, grid_import_limit_kw=3000.0)
    dispatch = MultiEnergyDispatchProblem(inputs, config).zero_dispatch()

    result = IEEE33ScheduleValidator(MPTE_ROOT).validate(
        inputs,
        dispatch,
        grid_import_limit_kw=2500.0,
        grid_export_limit_kw=1000.0,
    )

    assert dispatch.feasible
    assert result.timeseries.loc[0, "slack_power_kw"] > 2500.0
    assert result.grid_feasible is False
    assert not result.feasible
