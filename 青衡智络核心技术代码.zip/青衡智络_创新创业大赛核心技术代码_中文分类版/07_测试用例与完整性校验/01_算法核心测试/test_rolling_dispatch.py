from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

from qingheng.config import DispatchConfig
from qingheng.dispatch.problem import DispatchInputs
from qingheng.network import PowerFlowValidation
from qingheng.rolling_dispatch import (
    RollingPCCPolicy,
    RollingDispatchError,
    _build_acceptance,
    _bounded_storage_energy,
    _causal_project_execution,
    _implementation_provenance,
    _lossless_pcc_feasible,
    _maximum_adjacent_carry_residual,
    _method_scope,
    _planning_pcc_limits,
    compose_rolling_lookahead,
    load_authenticated_daily_forecasts,
    rolling_execution_dates,
    verify_rolling_artifact_manifest,
    write_rolling_artifact_manifest,
)


class _FixedLossValidator:
    def __init__(self, loss_kw: float) -> None:
        self.loss_kw = loss_kw

    def validate(
        self,
        inputs: DispatchInputs,
        dispatch: object,
        *,
        grid_import_limit_kw: float | None = None,
        grid_export_limit_kw: float | None = None,
    ) -> PowerFlowValidation:
        grid = np.asarray(getattr(dispatch, "grid_power_kw"), dtype=float)
        slack = grid + self.loss_kw
        import_limit = np.inf if grid_import_limit_kw is None else grid_import_limit_kw
        export_limit = np.inf if grid_export_limit_kw is None else grid_export_limit_kw
        grid_feasible = bool(
            np.all(slack <= import_limit + 1e-6)
            and np.all(slack >= -export_limit - 1e-6)
        )
        rows = len(slack)
        timeseries = pd.DataFrame(
            {
                "step": np.arange(rows),
                "converged": True,
                "iterations": 1,
                "min_voltage_pu": 1.0,
                "max_voltage_pu": 1.0,
                "max_branch_current_pu": 0.0,
                "active_loss_kw": self.loss_kw,
                "slack_power_kw": slack,
            }
        )
        return PowerFlowValidation(
            timeseries=timeseries,
            branch_flows_kw=np.empty((rows, 0)),
            branch_to_end_flows_kw=np.empty((rows, 0)),
            bus_injections_kw=np.zeros((rows, 1)),
            branch_from_bus=np.empty(0, dtype=np.int64),
            branch_to_bus=np.empty(0, dtype=np.int64),
            all_converged=True,
            voltage_feasible=True,
            current_feasible=None,
            grid_feasible=grid_feasible,
        )


def _projection_config(*, battery_enabled: bool = True) -> DispatchConfig:
    return DispatchConfig(
        horizon_steps=2,
        population=4,
        iterations=1,
        seeds=(1,),
        battery_enabled=battery_enabled,
        battery_capacity_kwh=100.0 if battery_enabled else 0.0,
        battery_power_kw=20.0 if battery_enabled else 0.0,
        battery_initial_soc=0.5,
        battery_min_soc=0.1,
        battery_max_soc=0.9,
        hydrogen_enabled=False,
        hydrogen_capacity_kwh=0.0,
        hydrogen_power_kw=0.0,
        grid_import_limit_kw=10.0,
        grid_export_limit_kw=10.0,
        terminal_repair_steps=1,
    )


def _projection_inputs(load_kw: list[float]) -> DispatchInputs:
    rows = len(load_kw)
    return DispatchInputs.from_arrays(
        load_kw=load_kw,
        pv_available_kw=np.zeros(rows),
        wind_available_kw=np.zeros(rows),
        buy_price_per_kwh=np.ones(rows),
        grid_carbon_kg_per_kwh=np.full(rows, 0.5),
    )


def _daily_frame() -> pd.DataFrame:
    index = pd.date_range("2025-06-17 07:00", periods=192, freq="15min", tz="UTC")
    local = index.tz_convert("America/Los_Angeles")
    dates = np.asarray([value.date().isoformat() for value in local])
    horizon = np.tile(np.arange(1, 97), 2)
    origins = np.repeat([index[0], index[96]], 96)
    second = dates == "2025-06-18"
    return pd.DataFrame(
        {
            "forecast_origin": origins,
            "local_date": dates,
            "horizon_step": horizon,
            "load_actual_kw": np.where(second, 22.0, 12.0),
            "pv_actual_kw": np.where(second, 8.0, 4.0),
            "load_operational_kw": np.where(second, 20.0, 10.0),
            "pv_operational_kw": np.where(second, 7.0, 3.0),
            "load_weekly_persistence_kw": np.where(second, 30.0, 15.0),
            "pv_weekly_persistence_kw": np.where(second, 9.0, 5.0),
        },
        index=index,
    )


def test_compose_rolling_lookahead_uses_causal_second_day_policy() -> None:
    frame = _daily_frame()

    planning, actual = compose_rolling_lookahead(frame, "2025-06-17")

    assert rolling_execution_dates(frame) == ("2025-06-17",)
    np.testing.assert_allclose(planning["load_dispatch_forecast_kw"].iloc[:96], 10.0)
    np.testing.assert_allclose(planning["load_dispatch_forecast_kw"].iloc[96:], 30.0)
    np.testing.assert_allclose(planning["pv_dispatch_forecast_kw"].iloc[96:], 9.0)
    np.testing.assert_allclose(actual["load_dispatch_actual_kw"], 12.0)
    assert set(planning["rolling_source"].iloc[96:]) == {"weekly_persistence_day_2"}


def test_authenticated_daily_forecast_loader_checks_hash_and_days(tmp_path: Path) -> None:
    frame = _daily_frame().reset_index(names="timestamp")
    csv_path = tmp_path / "all_test_daily_forecasts.csv"
    frame.to_csv(csv_path, index=False)
    digest = sha256(csv_path.read_bytes()).hexdigest()
    manifest = {
        "schema_version": "qingheng.daily-forecast-export.v1",
        "source": {"cache_output_sha256": "cache-hash"},
        "output": {
            "filename": csv_path.name,
            "sha256": digest,
            "rows": 192,
            "complete_local_days": 2,
            "first_local_date": "2025-06-17",
            "last_local_date": "2025-06-18",
        },
        "rolling_forecast_policy": {"future_actual_inputs_used": False},
    }
    manifest_path = tmp_path / "all_test_daily_forecasts_manifest.json"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

    loaded, _ = load_authenticated_daily_forecasts(
        csv_path,
        manifest_path,
        expected_cache_sha256="cache-hash",
    )

    assert len(loaded) == 192
    with pytest.raises(RollingDispatchError, match="cache hashes differ"):
        load_authenticated_daily_forecasts(
            csv_path,
            manifest_path,
            expected_cache_sha256="different",
        )

    irregular = frame.copy()
    irregular.loc[10, "timestamp"] = irregular.loc[10, "timestamp"] + pd.Timedelta(minutes=1)
    irregular.to_csv(csv_path, index=False)
    manifest["output"]["sha256"] = sha256(csv_path.read_bytes()).hexdigest()
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(RollingDispatchError, match="not one fixed 24-hour day"):
        load_authenticated_daily_forecasts(
            csv_path,
            manifest_path,
            expected_cache_sha256="cache-hash",
        )


def test_rolling_acceptance_fails_explicitly_on_actual_pcc_violation() -> None:
    daily = pd.DataFrame(
        {
            "plan_network_feasible": [True],
            "plan_terminal_error_kwh": [0.0],
            "actual_device_state_feasible": [True],
            "actual_lossless_pcc_feasible": [False],
            "actual_physical_network_feasible": [True],
            "actual_pcc_limit_feasible": [False],
            "actual_proxy_carbon_residual_kg": [0.0],
            "actual_ac_carbon_residual_kg": [0.0],
        }
    )

    acceptance = _build_acceptance(
        daily,
        maximum_energy_carry_residual_kwh=0.0,
        maximum_carbon_carry_residual_kg=0.0,
    )

    assert acceptance["status"] == "failed"
    assert not acceptance["passed"]
    assert "all_actual_lossless_pcc_feasible" in acceptance["failure_reasons"]
    assert "all_actual_loss_adjusted_ac_pcc_feasible" in acceptance["failure_reasons"]
    assert not acceptance["green_inventory_carry_implemented"]


def test_rolling_acceptance_requires_green_carry_and_conservation() -> None:
    daily = pd.DataFrame(
        {
            "plan_network_feasible": [True],
            "plan_terminal_error_kwh": [0.0],
            "actual_device_state_feasible": [True],
            "actual_lossless_pcc_feasible": [True],
            "actual_physical_network_feasible": [True],
            "actual_pcc_limit_feasible": [True],
            "actual_proxy_carbon_residual_kg": [0.0],
            "actual_ac_carbon_residual_kg": [0.0],
        }
    )

    acceptance = _build_acceptance(
        daily,
        maximum_energy_carry_residual_kwh=0.0,
        maximum_carbon_carry_residual_kg=0.0,
        maximum_green_inventory_carry_residual_kwh=0.0,
        maximum_daily_green_inventory_balance_residual_kwh=1e-12,
        green_inventory_carry_implemented=True,
    )

    assert acceptance["passed"]
    assert acceptance["green_inventory_carry_passed"]
    assert acceptance["green_inventory_conservation_passed"]
    assert acceptance["green_metrics_reportable_across_days"]

    failed_green = _build_acceptance(
        daily,
        maximum_energy_carry_residual_kwh=0.0,
        maximum_carbon_carry_residual_kg=0.0,
        maximum_green_inventory_carry_residual_kwh=0.0,
        maximum_daily_green_inventory_balance_residual_kwh=1e-7,
        green_inventory_carry_implemented=True,
    )
    assert not failed_green["green_metrics_reportable_across_days"]


def test_multiseed_scope_does_not_overclaim_full_trajectory_uncertainty() -> None:
    scope = _method_scope((2029, 12029, 22029))["stochastic_robustness"]

    assert scope["multi_seed_validation"]
    assert scope["optimizer_restart_spread_reported"]
    assert not scope["ranking_uncertainty_quantified"]
    assert not scope["comparative_ranking_conclusion_permitted"]


def test_implementation_bundle_includes_data_construction_and_network_loading() -> None:
    paths = {
        record["path"]
        for record in _implementation_provenance()["source_files"]
    }

    assert "src/qingheng/data/hybrid.py" in paths
    assert "src/qingheng/data/ieee33.py" in paths
    assert "src/qingheng/data/socal.py" in paths


def test_carry_residual_is_recomputed_from_adjacent_output_days() -> None:
    daily = pd.DataFrame(
        {
            "open": [1.0, 2.25, 4.0],
            "close": [2.0, 4.5, 5.0],
        }
    )

    assert _maximum_adjacent_carry_residual(
        daily, (("open", "close"),)
    ) == pytest.approx(0.5)


def test_robust_planning_limits_use_only_supplied_prior_history() -> None:
    config = _projection_config()
    policy = RollingPCCPolicy.robust_v2(
        forecast_error_quantile=1.0,
        loss_quantile=1.0,
        minimum_forecast_reserve_fraction=0.0,
        minimum_import_loss_reserve_fraction=0.0,
    )

    first_day = _planning_pcc_limits(
        config,
        policy,
        prior_net_forecast_errors_kw=[],
        prior_ac_loss_deltas_kw=[],
    )
    later_day = _planning_pcc_limits(
        config,
        policy,
        prior_net_forecast_errors_kw=[2.0, -3.0],
        prior_ac_loss_deltas_kw=[1.0],
    )

    assert first_day.tightened_import_limit_kw == 10.0
    assert later_day.tightened_import_limit_kw == 7.0
    assert later_day.tightened_export_limit_kw == 7.0
    assert later_day.prior_forecast_error_observations == 2


def test_lossless_pcc_check_ignores_milliwatt_numerical_noise() -> None:
    assert _lossless_pcc_feasible(
        SimpleNamespace(
            violation={"grid_import": 0.0, "grid_export": 2e-10}
        )
    )
    assert not _lossless_pcc_feasible(
        SimpleNamespace(
            violation={"grid_import": 0.0, "grid_export": 2e-5}
        )
    )


def test_storage_energy_snaps_only_numerical_boundary_noise() -> None:
    assert _bounded_storage_energy(
        carrier="hydrogen",
        energy_kwh=9.9999999999,
        capacity_kwh=100.0,
        minimum_soc=0.1,
        maximum_soc=0.9,
    ) == pytest.approx(10.0)
    with pytest.raises(RollingDispatchError, match="state bound"):
        _bounded_storage_energy(
            carrier="hydrogen",
            energy_kwh=9.999,
            capacity_kwh=100.0,
            minimum_soc=0.1,
            maximum_soc=0.9,
        )


def test_robust_projection_is_hourly_causal_and_enforces_loss_adjusted_pcc() -> None:
    config = _projection_config()
    policy = RollingPCCPolicy.robust_v2(projection_bisection_iterations=24)
    validator = _FixedLossValidator(loss_kw=2.0)
    common = {
        "execution_config": config,
        "network": validator,
        "planned_battery_power_kw": [0.0, 0.0],
        "planned_hydrogen_power_kw": [0.0, 0.0],
        "planned_renewable_fraction": [1.0, 1.0],
        "policy": policy,
    }

    normal_future = _causal_project_execution(
        actual_inputs=_projection_inputs([15.0, 15.0]),
        **common,
    )
    changed_future = _causal_project_execution(
        actual_inputs=_projection_inputs([15.0, 20.0]),
        **common,
    )

    assert normal_future.decision[0] == pytest.approx(changed_future.decision[0])
    assert normal_future.decision[0] > 6.9
    assert bool(normal_future.records.loc[0, "pcc_projection_applied"])
    assert normal_future.records.loc[0, "pcc_slack_after_projection_kw"] <= 9.99 + 1e-8


def test_robust_projection_hard_fails_without_current_hour_headroom() -> None:
    config = _projection_config(battery_enabled=False)
    with pytest.raises(RollingDispatchError, match="insufficient"):
        _causal_project_execution(
            actual_inputs=_projection_inputs([15.0, 15.0]),
            execution_config=config,
            network=_FixedLossValidator(loss_kw=2.0),
            planned_battery_power_kw=[0.0, 0.0],
            planned_hydrogen_power_kw=[0.0, 0.0],
            planned_renewable_fraction=[1.0, 1.0],
            policy=RollingPCCPolicy.robust_v2(),
        )


def test_legacy_projection_keeps_open_loop_action_despite_pcc_violation() -> None:
    result = _causal_project_execution(
        actual_inputs=_projection_inputs([15.0, 15.0]),
        execution_config=_projection_config(),
        network=_FixedLossValidator(loss_kw=2.0),
        planned_battery_power_kw=[0.0, 0.0],
        planned_hydrogen_power_kw=[0.0, 0.0],
        planned_renewable_fraction=[1.0, 1.0],
        policy=RollingPCCPolicy(),
    )

    np.testing.assert_allclose(result.decision[:2], 0.0)
    assert not result.records["pcc_projection_applied"].any()


def test_rolling_artifact_manifest_detects_post_run_tampering(tmp_path: Path) -> None:
    provenance = {
        "schema_version": "qingheng.rolling-provenance.v1",
        "rolling_scenario_sha256": "a" * 64,
        "rolling_configuration": {
            "initial_carbon_factors_kg_per_kwh": [0.0],
        },
    }
    (tmp_path / "rolling_provenance.json").write_text(
        json.dumps(provenance), encoding="utf-8"
    )
    result_file = tmp_path / "rolling_carbon_sensitivity.csv"
    result_file.write_text("value\n1\n", encoding="utf-8")
    (tmp_path / "rolling_carbon_sensitivity.json").write_text("{}", encoding="utf-8")
    case = tmp_path / "initial_carbon_0p000"
    case.mkdir()
    for name in (
        "rolling_actual_schedule.csv",
        "rolling_daily_metrics.csv",
        "rolling_summary.json",
    ):
        (case / name).write_text("{}\n", encoding="utf-8")

    manifest = write_rolling_artifact_manifest(tmp_path)
    verified = verify_rolling_artifact_manifest(manifest)

    assert verified["file_count"] == 6
    result_file.write_text("value\n2\n", encoding="utf-8")
    with pytest.raises(RollingDispatchError, match="does not match its manifest"):
        verify_rolling_artifact_manifest(manifest)


def test_v3_rolling_artifact_manifest_requires_seed_audit(tmp_path: Path) -> None:
    provenance = {
        "schema_version": "qingheng.rolling-provenance.v3",
        "rolling_scenario_sha256": "b" * 64,
        "source": {"sizing_sha256": "c" * 64},
        "rolling_configuration": {
            "initial_carbon_factors_kg_per_kwh": [0.0],
            "base_seeds": [2029, 12029, 22029],
        },
    }
    (tmp_path / "rolling_provenance.json").write_text(
        json.dumps(provenance), encoding="utf-8"
    )
    (tmp_path / "rolling_carbon_sensitivity.csv").write_text(
        "value\n1\n", encoding="utf-8"
    )
    (tmp_path / "rolling_carbon_sensitivity.json").write_text(
        "{}", encoding="utf-8"
    )
    case = tmp_path / "initial_carbon_0p000"
    case.mkdir()
    for name in (
        "rolling_actual_schedule.csv",
        "rolling_daily_metrics.csv",
        "rolling_summary.json",
    ):
        (case / name).write_text("{}\n", encoding="utf-8")

    with pytest.raises(RollingDispatchError, match="rolling_seed_audit.csv"):
        write_rolling_artifact_manifest(tmp_path)

    (case / "rolling_seed_audit.csv").write_text("seed\n2029\n", encoding="utf-8")
    with pytest.raises(RollingDispatchError, match="sizing_manifest.json"):
        write_rolling_artifact_manifest(tmp_path)

    (tmp_path / "sizing_manifest.json").write_text(
        json.dumps({"sizing_sha256": "c" * 64}), encoding="utf-8"
    )
    manifest = write_rolling_artifact_manifest(tmp_path)
    assert verify_rolling_artifact_manifest(manifest)["result_complete"]
