from __future__ import annotations

import pytest

from qingheng.carbon import (
    BranchFlow,
    CarbonReservoir,
    PowerBalanceError,
    ReservoirConstraintError,
    SourceInjection,
    compute_carbon_metrics,
    trace_carbon,
)


def test_single_source_radial_trace_and_path_agree() -> None:
    result = trace_carbon(
        [BranchFlow("grid", "load", 100.0)],
        [SourceInjection("grid", "grid", 100.0, 0.5)],
        {"load": 100.0},
    )

    assert result.flow_order.is_dag
    assert result.flow_order.order == ("grid", "load")
    assert result.node_intensity_kg_per_kwh == {"grid": 0.5, "load": 0.5}
    assert result.load_source_power_kw["load"]["grid"] == pytest.approx(100.0)
    assert result.paths[0].nodes == ("grid", "load")
    assert result.paths[0].power_kw == pytest.approx(100.0)
    assert result.path_residual_kw[("grid", "load")] == pytest.approx(0.0)
    assert result.total_load_emissions_kg_per_h == pytest.approx(50.0)


def test_two_sources_mix_by_power_share() -> None:
    result = trace_carbon(
        [BranchFlow(0, 1, 60.0)],
        [
            SourceInjection("grid", 0, 60.0, 0.6),
            SourceInjection("pv", 1, 40.0, 0.0, is_green=True),
        ],
        {1: 100.0},
    )

    assert result.node_intensity_kg_per_kwh[1] == pytest.approx(0.36)
    assert result.source_share[1]["grid"] == pytest.approx(0.6)
    assert result.source_share[1]["pv"] == pytest.approx(0.4)
    assert result.load_source_power_kw[1] == pytest.approx({"grid": 60.0, "pv": 40.0})
    assert all(abs(value) < 1e-9 for value in result.path_residual_kw.values())


def test_negative_branch_power_reverses_flow_direction() -> None:
    result = trace_carbon(
        [BranchFlow("load", "source", -30.0)],
        [SourceInjection("fc", "source", 30.0, 0.2)],
        {"load": 30.0},
    )

    assert result.normalized_branches == (BranchFlow("source", "load", 30.0),)
    assert result.flow_order.order == ("source", "load")
    assert result.node_intensity_kg_per_kwh["load"] == pytest.approx(0.2)


def test_mesh_uses_linear_system_and_reports_simple_path_residual() -> None:
    # A 20 kW circulation overlays a 100 kW transfer from A to the load at B.
    result = trace_carbon(
        [
            BranchFlow("A", "B", 120.0),
            BranchFlow("B", "C", 20.0),
            BranchFlow("C", "A", 20.0),
        ],
        [SourceInjection("grid", "A", 100.0, 0.5)],
        {"B": 100.0},
    )

    assert not result.flow_order.is_dag
    assert result.flow_order.method == "mesh-linear-system"
    assert result.node_intensity_kg_per_kwh["A"] == pytest.approx(0.5)
    assert result.node_intensity_kg_per_kwh["B"] == pytest.approx(0.5)
    assert result.load_source_power_kw["B"]["grid"] == pytest.approx(100.0)
    assert result.paths[0].power_kw == pytest.approx(100.0 * 100.0 / 120.0)
    assert result.path_residual_kw[("grid", "B")] == pytest.approx(100.0 / 6.0)
    assert result.linear_residual_norm < 1e-9


def test_power_imbalance_has_diagnostics_and_configurable_tolerance() -> None:
    with pytest.raises(PowerBalanceError) as raised:
        trace_carbon(
            [BranchFlow(0, 1, 99.0)],
            [SourceInjection("grid", 0, 99.0, 0.5)],
            {1: 100.0},
        )
    assert raised.value.diagnostics.by_node[1].residual_kw == pytest.approx(-1.0)

    result = trace_carbon(
        [BranchFlow(0, 1, 99.0)],
        [SourceInjection("grid", 0, 99.0, 0.5)],
        {1: 100.0},
        strict_balance=False,
    )
    assert not result.balance.balanced


def test_reservoir_tracks_charge_and_discharge_efficiencies() -> None:
    reservoir = CarbonReservoir(
        capacity_kwh=100.0,
        energy_kwh=0.0,
        charge_efficiency=0.8,
        discharge_efficiency=0.9,
        carrier="hydrogen",
    )
    charged = reservoir.charge(50.0, 0.5, green_fraction=0.5)
    assert charged.reservoir_energy_delta_kwh == pytest.approx(40.0)
    assert reservoir.energy_kwh == pytest.approx(40.0)
    assert reservoir.carbon_inventory_kg == pytest.approx(25.0)
    assert reservoir.green_inventory_kwh == pytest.approx(20.0)

    discharged = reservoir.discharge(18.0)
    assert discharged.reservoir_energy_delta_kwh == pytest.approx(-20.0)
    assert discharged.carbon_kg == pytest.approx(12.5)
    assert discharged.green_energy_kwh == pytest.approx(9.0)
    assert discharged.carbon_intensity_kg_per_kwh == pytest.approx(0.5 / (0.8 * 0.9))
    assert reservoir.energy_kwh == pytest.approx(20.0)
    assert reservoir.carbon_inventory_kg == pytest.approx(12.5)
    assert reservoir.green_inventory_kwh == pytest.approx(10.0)

    with pytest.raises(ReservoirConstraintError):
        reservoir.step(charge_input_kwh=1.0, discharge_output_kwh=1.0)


def test_zero_capacity_reservoir_supports_disabled_device() -> None:
    reservoir = CarbonReservoir(0.0, 0.0, 1.0, 1.0, carrier="hydrogen")

    assert reservoir.step().direction == "idle"
    with pytest.raises(ReservoirConstraintError):
        reservoir.charge(1.0, 0.0)


def test_metrics_include_battery_and_hydrogen_labels() -> None:
    battery = CarbonReservoir(100.0, 0.0, 1.0, 1.0, carrier="battery")
    hydrogen = CarbonReservoir(100.0, 0.0, 1.0, 1.0, carrier="hydrogen")
    battery.charge(20.0, 0.1, green_fraction=1.0)
    hydrogen.charge(10.0, 0.2, green_fraction=0.5)
    transfers = [battery.discharge(20.0), hydrogen.discharge(10.0)]

    metrics = compute_carbon_metrics(
        load_energy_kwh=100.0,
        actual_emissions_kg=30.0,
        grid_factor_kg_per_kwh=0.6,
        green_generation_kwh=80.0,
        direct_green_consumed_kwh=35.0,
        reservoir_transfers=transfers,
    )

    assert metrics.mediated_green_by_carrier_kwh == pytest.approx(
        {"battery": 20.0, "hydrogen": 5.0}
    )
    assert metrics.green_self_use_rate == pytest.approx(60.0 / 80.0)
    assert metrics.low_carbon_storage_contribution_kwh == pytest.approx(30.0)
    assert metrics.low_carbon_storage_share == pytest.approx(0.3)
    assert metrics.unit_supply_carbon_intensity_kg_per_kwh == pytest.approx(0.3)
    assert metrics.avoided_emissions_kg == pytest.approx(30.0)
    assert metrics.avoided_emissions_rate == pytest.approx(0.5)


def test_explicit_load_allocations_do_not_count_exported_storage_energy() -> None:
    battery = CarbonReservoir(100.0, 0.0, 1.0, 1.0, carrier="battery")
    battery.charge(20.0, 0.0, green_fraction=1.0)
    transfers = [battery.discharge(20.0)]

    metrics = compute_carbon_metrics(
        load_energy_kwh=0.0,
        actual_emissions_kg=0.0,
        grid_factor_kg_per_kwh=0.6,
        green_generation_kwh=20.0,
        direct_green_consumed_kwh=0.0,
        reservoir_transfers=transfers,
        mediated_green_to_load_by_carrier_kwh={"battery": 0.0},
        low_carbon_to_load_by_carrier_kwh={"battery": 0.0},
    )

    assert metrics.mediated_green_consumed_kwh == 0.0
    assert metrics.low_carbon_storage_contribution_kwh == 0.0
    assert metrics.green_self_use_rate == 0.0
