from __future__ import annotations

import json
from pathlib import Path

import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from qingheng.dispatch.problem import DispatchEvaluation, DispatchInputs


def export_dispatch(
    output_dir: str | Path,
    inputs: DispatchInputs,
    evaluation: DispatchEvaluation,
    *,
    prefix: str = "best_dispatch",
) -> tuple[Path, Path]:
    directory = Path(output_dir)
    directory.mkdir(parents=True, exist_ok=True)
    schedule_path = directory / f"{prefix}_schedule.csv"
    metrics_path = directory / f"{prefix}_metrics.json"
    frame = pd.DataFrame(
        {
            "step": np.arange(inputs.horizon),
            "load_kw": inputs.load_kw,
            "pv_available_kw": inputs.pv_available_kw,
            "wind_available_kw": inputs.wind_available_kw,
            "fixed_generation_kw": inputs.fixed_generation_kw,
            "pv_used_kw": evaluation.pv_used_kw,
            "wind_used_kw": evaluation.wind_used_kw,
            "renewable_used_kw": evaluation.renewable_used_kw,
            "renewable_fraction": evaluation.renewable_fraction,
            "battery_power_kw": evaluation.battery_power_kw,
            "hydrogen_power_kw": evaluation.hydrogen_power_kw,
            "grid_power_kw": evaluation.grid_power_kw,
            "battery_energy_kwh_end": evaluation.battery_energy_kwh[1:],
            "hydrogen_energy_kwh_end": evaluation.hydrogen_energy_kwh[1:],
            "buy_price_per_kwh": inputs.buy_price_per_kwh,
            "grid_carbon_kg_per_kwh": inputs.grid_carbon_kg_per_kwh,
            "load_carbon_intensity_proxy_kg_per_kwh": (
                evaluation.carbon_intensity_proxy_kg_per_kwh
            ),
        }
    )
    frame.to_csv(schedule_path, index=False)
    metrics_path.write_text(
        json.dumps(evaluation.as_summary(), indent=2, ensure_ascii=True),
        encoding="utf-8",
    )
    return schedule_path, metrics_path


def plot_dispatch(
    output_path: str | Path,
    inputs: DispatchInputs,
    evaluation: DispatchEvaluation,
) -> Path:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    step = np.arange(inputs.horizon)
    figure, axes = plt.subplots(3, 1, figsize=(11, 9), sharex=True, constrained_layout=True)

    axes[0].plot(step, inputs.load_kw, color="#222222", linewidth=2.0, label="Load")
    axes[0].plot(step, evaluation.renewable_used_kw, color="#2a9d5b", label="Renewables")
    axes[0].plot(step, evaluation.grid_power_kw, color="#3977b8", label="Grid (+import)")
    axes[0].plot(step, inputs.fixed_generation_kw, color="#d08a20", label="Fuel cell")
    axes[0].set_ylabel("Power (kW)")
    axes[0].legend(ncol=4, fontsize=8)
    axes[0].grid(alpha=0.25)

    axes[1].plot(step, evaluation.battery_power_kw, color="#6b4ca5", label="Battery")
    axes[1].plot(step, evaluation.hydrogen_power_kw, color="#c84b52", label="Hydrogen")
    axes[1].axhline(0.0, color="#777777", linewidth=0.8)
    axes[1].set_ylabel("Bus injection (kW)")
    axes[1].legend(fontsize=8)
    axes[1].grid(alpha=0.25)

    axes[2].plot(step, evaluation.battery_energy_kwh[1:], color="#6b4ca5", label="Battery")
    axes[2].plot(step, evaluation.hydrogen_energy_kwh[1:], color="#c84b52", label="Hydrogen")
    axes[2].set_ylabel("Stored energy (kWh)")
    axes[2].set_xlabel("Dispatch step")
    axes[2].legend(fontsize=8)
    axes[2].grid(alpha=0.25)

    figure.savefig(path, dpi=160)
    plt.close(figure)
    return path


def plot_benchmark(frame: pd.DataFrame, output_path: str | Path) -> Path:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    algorithms = [name for name in frame["algorithm"].unique() if name != "zero_dispatch"]
    values = [frame.loc[frame["algorithm"] == name, "score"].to_numpy() for name in algorithms]
    figure, axis = plt.subplots(figsize=(8, 4.8), constrained_layout=True)
    axis.boxplot(values, tick_labels=algorithms, showmeans=True)
    axis.set_ylabel("Penalized normalized objective")
    axis.grid(axis="y", alpha=0.25)
    figure.savefig(path, dpi=160)
    plt.close(figure)
    return path


def plot_optimizer_algorithm_comparison(
    frame: pd.DataFrame,
    convergence: pd.DataFrame,
    output_path: str | Path,
) -> Path:
    """Plot seed-level final scores beside median best-so-far convergence."""

    required_runs = {"algorithm", "seed", "score"}
    required_history = {"algorithm", "seed", "iteration", "best_score"}
    missing_runs = required_runs - set(frame.columns)
    missing_history = required_history - set(convergence.columns)
    if missing_runs:
        raise ValueError(f"optimizer run table is missing columns: {sorted(missing_runs)}")
    if missing_history:
        raise ValueError(
            f"optimizer convergence table is missing columns: {sorted(missing_history)}"
        )

    preferred_order = ("improved_woa", "standard_woa", "pso")
    available = set(frame["algorithm"]) & set(convergence["algorithm"])
    algorithms = [name for name in preferred_order if name in available]
    algorithms.extend(sorted(available - set(algorithms) - {"zero_dispatch"}))
    if not algorithms:
        raise ValueError("optimizer comparison contains no shared algorithm runs")

    labels = {
        "improved_woa": "Improved WOA",
        "standard_woa": "Standard WOA",
        "pso": "PSO",
    }
    colors = {
        "improved_woa": "#14866d",
        "standard_woa": "#c54f4f",
        "pso": "#356eb3",
    }
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    figure, axes = plt.subplots(
        1,
        2,
        figsize=(12, 4.8),
        gridspec_kw={"width_ratios": (1.55, 1.0)},
        constrained_layout=True,
    )

    for algorithm in algorithms:
        subset = convergence.loc[convergence["algorithm"] == algorithm]
        pivot = subset.pivot(index="iteration", columns="seed", values="best_score").sort_index()
        if pivot.empty or pivot.isna().any().any():
            raise ValueError(f"{algorithm} convergence history is incomplete")
        median = pivot.median(axis=1)
        lower = pivot.quantile(0.25, axis=1)
        upper = pivot.quantile(0.75, axis=1)
        color = colors.get(algorithm, "#555555")
        axes[0].plot(
            median.index,
            median.to_numpy(),
            color=color,
            linewidth=2.0,
            label=labels.get(algorithm, algorithm),
        )
        axes[0].fill_between(
            median.index,
            lower.to_numpy(),
            upper.to_numpy(),
            color=color,
            alpha=0.16,
            linewidth=0,
        )

    baseline = frame.loc[frame["algorithm"] == "zero_dispatch", "score"]
    if not baseline.empty:
        axes[0].axhline(
            float(baseline.iloc[0]),
            color="#666666",
            linestyle="--",
            linewidth=1.0,
            label="Zero-dispatch baseline",
        )
    axes[0].set_xlabel("Iteration")
    axes[0].set_ylabel("Best-so-far normalized objective")
    axes[0].grid(alpha=0.2)
    axes[0].legend(frameon=False, fontsize=8)
    axes[0].text(
        0.99,
        0.98,
        "Median and interquartile range",
        transform=axes[0].transAxes,
        ha="right",
        va="top",
        fontsize=8,
        color="#555555",
    )

    values = [
        frame.loc[frame["algorithm"] == algorithm, "score"].to_numpy(dtype=np.float64)
        for algorithm in algorithms
    ]
    boxes = axes[1].boxplot(
        values,
        tick_labels=[labels.get(name, name) for name in algorithms],
        showmeans=True,
        patch_artist=True,
        widths=0.55,
        meanprops={
            "marker": "D",
            "markerfacecolor": "white",
            "markeredgecolor": "#222222",
            "markersize": 4,
        },
    )
    for patch, algorithm in zip(boxes["boxes"], algorithms, strict=True):
        patch.set_facecolor(colors.get(algorithm, "#777777"))
        patch.set_alpha(0.55)
    for position, (algorithm, scores) in enumerate(zip(algorithms, values, strict=True), start=1):
        offsets = np.linspace(-0.08, 0.08, len(scores)) if len(scores) > 1 else np.zeros(1)
        axes[1].scatter(
            position + offsets,
            scores,
            color=colors.get(algorithm, "#555555"),
            edgecolor="white",
            linewidth=0.5,
            s=24,
            zorder=3,
        )
    axes[1].set_ylabel("Final normalized objective")
    axes[1].tick_params(axis="x", labelrotation=15)
    axes[1].grid(axis="y", alpha=0.2)
    axes[1].text(
        0.99,
        0.98,
        "Lower is better",
        transform=axes[1].transAxes,
        ha="right",
        va="top",
        fontsize=8,
        color="#555555",
    )

    figure.savefig(path, dpi=300)
    plt.close(figure)
    return path
