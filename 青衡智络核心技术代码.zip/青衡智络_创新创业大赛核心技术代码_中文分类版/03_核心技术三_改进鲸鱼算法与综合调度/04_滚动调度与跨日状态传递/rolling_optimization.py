"""Multi-seed forecast-condition selection for rolling dispatch."""

from __future__ import annotations

from dataclasses import dataclass
from numbers import Integral, Real
from time import perf_counter
from typing import Sequence

import numpy as np
import pandas as pd

from qingheng.dispatch import DispatchEvaluation, MultiEnergyDispatchProblem
from qingheng.dispatch.optimizers import particle_swarm_optimization
from qingheng.network import IEEE33ScheduleValidator, PowerFlowValidation


class ForecastSeedSelectionError(RuntimeError):
    """Raised when every optimizer restart fails forecast-only acceptance."""

    def __init__(self, message: str, audit: pd.DataFrame) -> None:
        super().__init__(message)
        self.audit = audit.copy(deep=True)


@dataclass(frozen=True)
class RollingSeedSelection:
    seed: int
    evaluation: DispatchEvaluation
    validation: PowerFlowValidation
    audit: pd.DataFrame


def rolling_day_seeds(base_seeds: Sequence[int], day_index: int) -> tuple[int, ...]:
    """Return common-random-number seeds for one execution day.

    Applying the same base seeds and day index to every sensitivity case gives
    paired optimizer restarts. Base seeds used in a run should be spaced by more
    than the number of execution days so that restarts do not repeat across days.
    """

    if isinstance(day_index, bool) or not isinstance(day_index, Integral) or day_index < 0:
        raise ValueError("day_index must be a non-negative integer")
    try:
        seeds = tuple(base_seeds)
    except TypeError as exc:
        raise ValueError("base_seeds must be a non-empty sequence of integers") from exc
    if not seeds or any(
        isinstance(seed, bool) or not isinstance(seed, Integral) or seed < 0 for seed in seeds
    ):
        raise ValueError("base_seeds must be a non-empty sequence of non-negative integers")
    if len(set(seeds)) != len(seeds):
        raise ValueError("base_seeds must be unique")
    daily = tuple(int(seed) + int(day_index) for seed in seeds)
    if len(set(daily)) != len(daily):
        raise ValueError("daily rolling seeds must remain unique")
    return daily


def select_forecast_feasible_seed(
    problem: MultiEnergyDispatchProblem,
    network: IEEE33ScheduleValidator,
    *,
    seeds: Sequence[int],
    population: int,
    iterations: int,
    terminal_tolerance_kwh: float,
    carbon_tolerance_kg: float,
    physical_grid_import_limit_kw: float,
    physical_grid_export_limit_kw: float,
) -> RollingSeedSelection:
    """Choose the lowest-score seed using forecast information only.

    Every candidate is evaluated against dispatch, cyclic-terminal, copper-plate
    carbon, AC voltage/convergence, and loss-adjusted PCC constraints. The
    dispatch problem may contain tighter lossless planning limits, while the two
    explicit physical limits are applied to the AC slack power. Actual
    measurements are deliberately absent from this interface.
    """

    try:
        run_seeds = tuple(seeds)
    except TypeError as exc:
        raise ValueError("seeds must be a non-empty sequence of integers") from exc
    if not run_seeds or any(
        isinstance(seed, bool) or not isinstance(seed, Integral) or seed < 0
        for seed in run_seeds
    ):
        raise ValueError("seeds must be a non-empty sequence of non-negative integers")
    run_seeds = tuple(int(seed) for seed in run_seeds)
    if len(set(run_seeds)) != len(run_seeds):
        raise ValueError("seeds must be unique")
    if (
        isinstance(population, bool)
        or not isinstance(population, Integral)
        or isinstance(iterations, bool)
        or not isinstance(iterations, Integral)
        or population < 4
        or iterations < 1
    ):
        raise ValueError("population must be >=4 and iterations must be positive")
    if (
        isinstance(terminal_tolerance_kwh, bool)
        or not isinstance(terminal_tolerance_kwh, Real)
        or not np.isfinite(terminal_tolerance_kwh)
        or terminal_tolerance_kwh <= 0.0
    ):
        raise ValueError("terminal_tolerance_kwh must be finite and positive")
    if (
        isinstance(carbon_tolerance_kg, bool)
        or not isinstance(carbon_tolerance_kg, Real)
        or not np.isfinite(carbon_tolerance_kg)
        or carbon_tolerance_kg <= 0.0
    ):
        raise ValueError("carbon_tolerance_kg must be finite and positive")
    for name, value in (
        ("physical_grid_import_limit_kw", physical_grid_import_limit_kw),
        ("physical_grid_export_limit_kw", physical_grid_export_limit_kw),
    ):
        if (
            isinstance(value, bool)
            or not isinstance(value, Real)
            or not np.isfinite(value)
            or value < 0.0
        ):
            raise ValueError(f"{name} must be finite and non-negative")

    candidates: list[
        tuple[float, int, DispatchEvaluation, PowerFlowValidation]
    ] = []
    records: list[dict[str, object]] = []
    for restart_index, seed in enumerate(run_seeds):
        started = perf_counter()
        optimized = particle_swarm_optimization(
            problem.objective,
            problem.lower_bounds,
            problem.upper_bounds,
            population_size=population,
            iterations=iterations,
            seed=seed,
            initial_candidate=problem.zero_decision(),
            repair=problem.repair_decision,
        )
        runtime = perf_counter() - started
        evaluation = problem.evaluate(optimized.best_position)
        battery_terminal_error = abs(
            evaluation.battery_energy_kwh[-1] - evaluation.battery_energy_kwh[0]
        )
        hydrogen_terminal_error = abs(
            evaluation.hydrogen_energy_kwh[-1] - evaluation.hydrogen_energy_kwh[0]
        )
        terminal_error = max(battery_terminal_error, hydrogen_terminal_error)
        dispatch_ok = bool(evaluation.feasible)
        terminal_ok = terminal_error < terminal_tolerance_kwh
        carbon_ok = abs(evaluation.carbon_balance_residual_proxy_kg) < carbon_tolerance_kg
        score_consistent = bool(
            np.isfinite(optimized.best_score)
            and np.isfinite(evaluation.score)
            and np.isclose(
                optimized.best_score,
                evaluation.score,
                rtol=1e-12,
                atol=1e-10,
            )
        )
        validation = network.validate(
            problem.inputs,
            evaluation,
            grid_import_limit_kw=float(physical_grid_import_limit_kw),
            grid_export_limit_kw=float(physical_grid_export_limit_kw),
        )
        ac_ok = bool(
            validation.all_converged
            and validation.voltage_feasible
            and (
                validation.current_feasible is None
                or validation.current_feasible
            )
        )
        pcc_ok = bool(validation.grid_feasible)
        network_ok = bool(validation.feasible)
        eligible = (
            dispatch_ok
            and terminal_ok
            and carbon_ok
            and score_consistent
            and network_ok
        )
        slack_power = pd.to_numeric(
            validation.timeseries.get("slack_power_kw", pd.Series(dtype=float)),
            errors="coerce",
        ).to_numpy(dtype=float)
        finite_slack = slack_power[np.isfinite(slack_power)]
        voltage_min = pd.to_numeric(
            validation.timeseries.get("min_voltage_pu", pd.Series(dtype=float)),
            errors="coerce",
        ).to_numpy(dtype=float)
        voltage_max = pd.to_numeric(
            validation.timeseries.get("max_voltage_pu", pd.Series(dtype=float)),
            errors="coerce",
        ).to_numpy(dtype=float)
        active_loss = pd.to_numeric(
            validation.timeseries.get("active_loss_kw", pd.Series(dtype=float)),
            errors="coerce",
        ).to_numpy(dtype=float)
        finite_voltage_min = voltage_min[np.isfinite(voltage_min)]
        finite_voltage_max = voltage_max[np.isfinite(voltage_max)]
        finite_loss = active_loss[np.isfinite(active_loss)]
        records.append(
            {
                "restart_index": restart_index,
                "seed": seed,
                "optimizer_best_score": optimized.best_score,
                "forecast_score": evaluation.score,
                "score": evaluation.score,
                "optimizer_score_consistent": score_consistent,
                "dispatch_feasible": dispatch_ok,
                "battery_terminal_error_kwh": battery_terminal_error,
                "hydrogen_terminal_error_kwh": hydrogen_terminal_error,
                "terminal_error_kwh": terminal_error,
                "terminal_feasible": terminal_ok,
                "carbon_balance_residual_proxy_kg": (
                    evaluation.carbon_balance_residual_proxy_kg
                ),
                "carbon_proxy_feasible": carbon_ok,
                "forecast_ac_converged": bool(validation.all_converged),
                "forecast_voltage_feasible": bool(validation.voltage_feasible),
                "forecast_current_feasible": validation.current_feasible,
                "forecast_ac_feasible": ac_ok,
                "forecast_network_feasible": network_ok,
                "forecast_pcc_limit_feasible": pcc_ok,
                "forecast_lossless_pcc_max_import_kw": float(
                    max(0.0, np.max(evaluation.grid_power_kw))
                ),
                "forecast_lossless_pcc_max_export_kw": float(
                    max(0.0, np.max(-evaluation.grid_power_kw))
                ),
                "forecast_ac_pcc_max_import_kw": (
                    float(max(0.0, np.max(finite_slack)))
                    if finite_slack.size
                    else np.nan
                ),
                "forecast_ac_pcc_max_export_kw": (
                    float(max(0.0, np.max(-finite_slack)))
                    if finite_slack.size
                    else np.nan
                ),
                "forecast_min_voltage_pu": (
                    float(np.min(finite_voltage_min))
                    if finite_voltage_min.size
                    else np.nan
                ),
                "forecast_max_voltage_pu": (
                    float(np.max(finite_voltage_max))
                    if finite_voltage_max.size
                    else np.nan
                ),
                "forecast_max_active_loss_kw": (
                    float(np.max(finite_loss)) if finite_loss.size else np.nan
                ),
                "lossless_planning_import_limit_kw": (
                    problem.config.grid_import_limit_kw
                ),
                "lossless_planning_export_limit_kw": (
                    problem.config.grid_export_limit_kw
                ),
                "physical_ac_import_limit_kw": physical_grid_import_limit_kw,
                "physical_ac_export_limit_kw": physical_grid_export_limit_kw,
                "runtime_seconds": runtime,
                "evaluations": optimized.evaluations,
                "eligible": eligible,
                "selected": False,
            }
        )
        if eligible:
            candidates.append((float(evaluation.score), seed, evaluation, validation))

    audit = pd.DataFrame.from_records(records)
    if not candidates:
        failed_checks = {
            column: int((~audit[column].astype(bool)).sum())
            for column in (
                "dispatch_feasible",
                "terminal_feasible",
                "carbon_proxy_feasible",
                "optimizer_score_consistent",
                "forecast_ac_feasible",
                "forecast_pcc_limit_feasible",
            )
        }
        raise ForecastSeedSelectionError(
            "no forecast-condition feasible rolling seed; failed checks: "
            f"{failed_checks}",
            audit,
        )
    _, selected_seed, selected_evaluation, selected_validation = min(
        candidates, key=lambda item: (item[0], item[1])
    )
    audit["selected"] = audit["seed"].eq(selected_seed)
    return RollingSeedSelection(
        seed=selected_seed,
        evaluation=selected_evaluation,
        validation=selected_validation,
        audit=audit,
    )


__all__ = [
    "ForecastSeedSelectionError",
    "RollingSeedSelection",
    "rolling_day_seeds",
    "select_forecast_feasible_seed",
]
