from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from hashlib import sha256
import inspect
import json
import math
from numbers import Integral, Real
from pathlib import Path
import sys
from typing import Any, Literal, Mapping, Sequence

import numpy as np
import pandas as pd

from qingheng.config import CarbonConfig, DispatchConfig
from qingheng.dispatch.problem import DispatchInputs, MultiEnergyDispatchProblem
from qingheng.network import IEEE33ScheduleValidator, PowerFlowValidation
from qingheng.pipeline import run_carbon_accounting
from qingheng.rolling_optimization import (
    ForecastSeedSelectionError,
    rolling_day_seeds,
    select_forecast_feasible_seed,
)
from qingheng.scenario import make_profile_dispatch_inputs


LOCAL_TIMEZONE = "America/Los_Angeles"
DAILY_STEPS_15MIN = 96
EXECUTION_HOURS = 24
LOOKAHEAD_HOURS = 48
TERMINAL_ENERGY_TOLERANCE_KWH = 1e-8
PROXY_CARBON_TOLERANCE_KG = 1e-8
AC_CARBON_TOLERANCE_KG = 1e-6
STATE_CARRY_TOLERANCE = 1e-8
GREEN_INVENTORY_TOLERANCE_KWH = 1e-8
ARTIFACT_MANIFEST_FILENAME = "rolling_artifact_manifest.json"
PCC_POLICY_LEGACY_V1 = "legacy_v1"
PCC_POLICY_ROBUST_V2 = "causal_reserve_projection_v2"
PCC_LIMIT_TOLERANCE_KW = 1e-6
LOSSLESS_PCC_NUMERICAL_TOLERANCE_KW = 1e-5

REQUIRED_FORECAST_COLUMNS = {
    "local_date",
    "horizon_step",
    "load_actual_kw",
    "pv_actual_kw",
    "load_operational_kw",
    "pv_operational_kw",
    "load_weekly_persistence_kw",
    "pv_weekly_persistence_kw",
}


class RollingDispatchError(RuntimeError):
    """Raised when a rolling schedule cannot preserve its declared invariants."""


@dataclass(frozen=True)
class RollingSensitivityResult:
    comparison_csv: Path
    comparison_json: Path
    provenance_path: Path
    artifact_manifest_path: Path
    cases: tuple[Path, ...]


@dataclass(frozen=True)
class RollingPCCPolicy:
    """Auditable planning reserve and causal execution policy for rolling PCC limits."""

    strategy: Literal["legacy_v1", "causal_reserve_projection_v2"] = PCC_POLICY_LEGACY_V1
    forecast_error_quantile: float = 0.95
    minimum_forecast_reserve_fraction: float = 0.02
    loss_quantile: float = 0.95
    minimum_import_loss_reserve_fraction: float = 0.01
    execution_headroom_kw: float = 0.01
    projection_bisection_iterations: int = 40

    def __post_init__(self) -> None:
        if self.strategy not in {PCC_POLICY_LEGACY_V1, PCC_POLICY_ROBUST_V2}:
            raise ValueError(
                "PCC strategy must be legacy_v1 or causal_reserve_projection_v2"
            )
        for name in ("forecast_error_quantile", "loss_quantile"):
            value = getattr(self, name)
            if (
                isinstance(value, bool)
                or not isinstance(value, Real)
                or not math.isfinite(value)
                or not 0.0 <= value <= 1.0
            ):
                raise ValueError(f"{name} must be finite and in [0, 1]")
        for name in (
            "minimum_forecast_reserve_fraction",
            "minimum_import_loss_reserve_fraction",
        ):
            value = getattr(self, name)
            if (
                isinstance(value, bool)
                or not isinstance(value, Real)
                or not math.isfinite(value)
                or not 0.0 <= value < 1.0
            ):
                raise ValueError(f"{name} must be finite and in [0, 1)")
        if (
            isinstance(self.execution_headroom_kw, bool)
            or not isinstance(self.execution_headroom_kw, Real)
            or not math.isfinite(self.execution_headroom_kw)
            or self.execution_headroom_kw < 0.0
        ):
            raise ValueError("execution_headroom_kw must be finite and non-negative")
        if (
            isinstance(self.projection_bisection_iterations, bool)
            or not isinstance(self.projection_bisection_iterations, Integral)
            or self.projection_bisection_iterations < 1
        ):
            raise ValueError("projection_bisection_iterations must be a positive integer")

    @classmethod
    def robust_v2(cls, **overrides: Any) -> "RollingPCCPolicy":
        return cls(strategy=PCC_POLICY_ROBUST_V2, **overrides)

    @property
    def robust(self) -> bool:
        return self.strategy == PCC_POLICY_ROBUST_V2


@dataclass(frozen=True)
class _PlanningPCCLimits:
    physical_import_limit_kw: float
    physical_export_limit_kw: float
    tightened_import_limit_kw: float
    tightened_export_limit_kw: float
    import_forecast_error_reserve_kw: float
    export_forecast_error_reserve_kw: float
    import_loss_reserve_kw: float
    prior_forecast_error_observations: int
    prior_loss_observations: int


@dataclass(frozen=True)
class _CausalProjectionResult:
    decision: np.ndarray
    records: pd.DataFrame


def _file_sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RollingDispatchError(f"cannot read valid JSON from {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise RollingDispatchError(f"expected a JSON object in {path}")
    return value


def load_authenticated_daily_forecasts(
    csv_path: str | Path,
    manifest_path: str | Path,
    *,
    expected_cache_sha256: str | None = None,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Load the all-day forecast export and verify its v1 manifest."""

    csv = Path(csv_path).resolve()
    manifest_file = Path(manifest_path).resolve()
    if not csv.is_file():
        raise FileNotFoundError(f"daily forecast CSV not found: {csv}")
    if not manifest_file.is_file():
        raise FileNotFoundError(f"daily forecast manifest not found: {manifest_file}")
    manifest = _read_json(manifest_file)
    if manifest.get("schema_version") != "qingheng.daily-forecast-export.v1":
        raise RollingDispatchError("unsupported daily forecast manifest schema")
    source = manifest.get("source")
    output = manifest.get("output")
    policy = manifest.get("rolling_forecast_policy")
    if not isinstance(source, dict) or not isinstance(output, dict) or not isinstance(policy, dict):
        raise RollingDispatchError("daily forecast manifest is missing source/output/policy")
    if output.get("filename") != csv.name or output.get("sha256") != _file_sha256(csv):
        raise RollingDispatchError("daily forecast CSV does not match its manifest")
    if expected_cache_sha256 is not None and source.get("cache_output_sha256") != expected_cache_sha256:
        raise RollingDispatchError("daily forecast export and dispatch cache hashes differ")
    if policy.get("future_actual_inputs_used") is not False:
        raise RollingDispatchError("rolling forecast policy does not exclude future actual inputs")

    frame = pd.read_csv(csv, parse_dates=["timestamp", "forecast_origin"])
    missing = sorted(REQUIRED_FORECAST_COLUMNS - set(frame.columns))
    if missing:
        raise RollingDispatchError(f"daily forecast CSV is missing columns: {missing}")
    frame["timestamp"] = pd.to_datetime(frame["timestamp"], utc=True)
    frame["forecast_origin"] = pd.to_datetime(frame["forecast_origin"], utc=True)
    frame = frame.set_index("timestamp").sort_index()
    if frame.empty or frame.index.has_duplicates:
        raise RollingDispatchError("daily forecast timestamps must be non-empty and unique")
    numeric_columns = sorted(
        (REQUIRED_FORECAST_COLUMNS - {"local_date"}) | {"forecast_origin"}
    )
    numeric_columns = [column for column in numeric_columns if column != "forecast_origin"]
    values = frame.loc[:, numeric_columns].apply(pd.to_numeric, errors="coerce")
    if values.isna().any().any() or not np.isfinite(values.to_numpy(dtype=float)).all():
        raise RollingDispatchError("daily forecast numeric columns must be finite")
    power_columns = [column for column in numeric_columns if column != "horizon_step"]
    if (values.loc[:, power_columns] < 0.0).any().any():
        raise RollingDispatchError("daily forecast power columns cannot be negative")

    dates: list[str] = []
    expected_clock_minutes = np.arange(0, 24 * 60, 15, dtype=np.int64)
    for local_date, day in frame.groupby("local_date", sort=False):
        if len(day) != DAILY_STEPS_15MIN:
            raise RollingDispatchError(f"local date {local_date} does not contain 96 rows")
        if day["horizon_step"].astype(int).tolist() != list(range(1, 97)):
            raise RollingDispatchError(f"local date {local_date} has invalid horizon steps")
        local = day.index.tz_convert(LOCAL_TIMEZONE)
        clock_minutes = (local.hour * 60 + local.minute).to_numpy(dtype=np.int64)
        if not (
            np.array_equal(clock_minutes, expected_clock_minutes)
            and all(value.date() == local[0].date() for value in local)
            and local[0].date().isoformat() == str(local_date)
        ):
            raise RollingDispatchError(f"local date {local_date} is not one fixed 24-hour day")
        if not (day["forecast_origin"] == day.index[0]).all():
            raise RollingDispatchError(f"local date {local_date} has inconsistent issue origins")
        dates.append(str(local_date))
    if output.get("rows") != len(frame) or output.get("complete_local_days") != len(dates):
        raise RollingDispatchError("daily forecast row/day counts differ from the manifest")
    if output.get("first_local_date") != dates[0] or output.get("last_local_date") != dates[-1]:
        raise RollingDispatchError("daily forecast date range differs from the manifest")
    return frame, manifest


def rolling_execution_dates(forecasts: pd.DataFrame) -> tuple[str, ...]:
    """Return days that have a complete consecutive next day for 48-hour planning."""

    dates = [pd.Timestamp(value) for value in forecasts["local_date"].drop_duplicates()]
    selected = [
        first.date().isoformat()
        for first, second in zip(dates, dates[1:], strict=False)
        if second - first == pd.Timedelta(days=1)
    ]
    if not selected:
        raise RollingDispatchError("daily forecast export has no consecutive 48-hour window")
    return tuple(selected)


def compose_rolling_lookahead(
    forecasts: pd.DataFrame,
    local_date: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Compose a causal 48-hour forecast and the first day's actual replay inputs."""

    current_date = pd.Timestamp(local_date)
    next_date = (current_date + pd.Timedelta(days=1)).date().isoformat()
    first = forecasts.loc[forecasts["local_date"] == local_date].copy()
    second = forecasts.loc[forecasts["local_date"] == next_date].copy()
    if len(first) != DAILY_STEPS_15MIN or len(second) != DAILY_STEPS_15MIN:
        raise RollingDispatchError(f"{local_date} does not have two complete consecutive days")

    planning = pd.concat([first, second]).copy()
    planning["load_dispatch_forecast_kw"] = np.concatenate(
        [
            first["load_operational_kw"].to_numpy(dtype=float),
            second["load_weekly_persistence_kw"].to_numpy(dtype=float),
        ]
    )
    planning["pv_dispatch_forecast_kw"] = np.concatenate(
        [
            first["pv_operational_kw"].to_numpy(dtype=float),
            second["pv_weekly_persistence_kw"].to_numpy(dtype=float),
        ]
    )
    planning["rolling_source"] = np.repeat(
        ["operational_day_1", "weekly_persistence_day_2"],
        DAILY_STEPS_15MIN,
    )
    actual = first.copy()
    actual["load_dispatch_actual_kw"] = actual["load_actual_kw"].to_numpy(dtype=float)
    actual["pv_dispatch_actual_kw"] = actual["pv_actual_kw"].to_numpy(dtype=float)
    return planning, actual


def _profile_with_power(
    hybrid_profile: pd.DataFrame,
    source: pd.DataFrame,
    *,
    load_column: str,
    pv_column: str,
) -> pd.DataFrame:
    profile = hybrid_profile.reindex(source.index).copy()
    required = {"wind_kw", "fuel_cell_kw"}
    missing = sorted(required - set(profile.columns))
    if missing or profile.loc[:, sorted(required)].isna().any().any():
        raise RollingDispatchError(
            f"rolling timestamps are outside the hybrid profile or missing columns: {missing}"
        )
    profile["load_kw"] = source[load_column].to_numpy(dtype=float)
    profile["pv_kw"] = source[pv_column].to_numpy(dtype=float)
    return profile


def _directional_quantile(
    history: Sequence[float],
    *,
    quantile: float,
    direction: Literal["positive", "negative"],
) -> float:
    if not history:
        return 0.0
    values = np.asarray(history, dtype=np.float64)
    if values.ndim != 1 or not np.all(np.isfinite(values)):
        raise RollingDispatchError("rolling reserve history must be a finite vector")
    directed = np.maximum(values, 0.0) if direction == "positive" else np.maximum(-values, 0.0)
    return float(np.quantile(directed, quantile))


def _planning_pcc_limits(
    base_dispatch: DispatchConfig,
    policy: RollingPCCPolicy,
    *,
    prior_net_forecast_errors_kw: Sequence[float],
    prior_ac_loss_deltas_kw: Sequence[float],
) -> _PlanningPCCLimits:
    physical_import = float(base_dispatch.grid_import_limit_kw)
    physical_export = float(base_dispatch.grid_export_limit_kw)
    if not policy.robust:
        return _PlanningPCCLimits(
            physical_import_limit_kw=physical_import,
            physical_export_limit_kw=physical_export,
            tightened_import_limit_kw=physical_import,
            tightened_export_limit_kw=physical_export,
            import_forecast_error_reserve_kw=0.0,
            export_forecast_error_reserve_kw=0.0,
            import_loss_reserve_kw=0.0,
            prior_forecast_error_observations=len(prior_net_forecast_errors_kw),
            prior_loss_observations=len(prior_ac_loss_deltas_kw),
        )

    import_error_reserve = max(
        policy.minimum_forecast_reserve_fraction * physical_import,
        _directional_quantile(
            prior_net_forecast_errors_kw,
            quantile=policy.forecast_error_quantile,
            direction="positive",
        ),
    )
    export_error_reserve = max(
        policy.minimum_forecast_reserve_fraction * physical_export,
        _directional_quantile(
            prior_net_forecast_errors_kw,
            quantile=policy.forecast_error_quantile,
            direction="negative",
        ),
    )
    loss_reserve = max(
        policy.minimum_import_loss_reserve_fraction * physical_import,
        _directional_quantile(
            prior_ac_loss_deltas_kw,
            quantile=policy.loss_quantile,
            direction="positive",
        ),
    )
    tightened_import = physical_import - import_error_reserve - loss_reserve
    tightened_export = physical_export - export_error_reserve
    if tightened_import < -PCC_LIMIT_TOLERANCE_KW or tightened_export < -PCC_LIMIT_TOLERANCE_KW:
        raise RollingDispatchError(
            "causal PCC reserve exceeds the physical PCC rating; the rolling scenario "
            "does not have enough auditable headroom"
        )
    return _PlanningPCCLimits(
        physical_import_limit_kw=physical_import,
        physical_export_limit_kw=physical_export,
        tightened_import_limit_kw=max(tightened_import, 0.0),
        tightened_export_limit_kw=max(tightened_export, 0.0),
        import_forecast_error_reserve_kw=import_error_reserve,
        export_forecast_error_reserve_kw=export_error_reserve,
        import_loss_reserve_kw=loss_reserve,
        prior_forecast_error_observations=len(prior_net_forecast_errors_kw),
        prior_loss_observations=len(prior_ac_loss_deltas_kw),
    )


def _slice_dispatch_inputs(inputs: DispatchInputs, step: int) -> DispatchInputs:
    selection = slice(step, step + 1)
    return DispatchInputs.from_arrays(
        load_kw=inputs.load_kw[selection],
        pv_available_kw=inputs.pv_available_kw[selection],
        wind_available_kw=inputs.wind_available_kw[selection],
        buy_price_per_kwh=inputs.buy_price_per_kwh[selection],
        sell_price_per_kwh=inputs.sell_price_per_kwh[selection],
        grid_carbon_kg_per_kwh=inputs.grid_carbon_kg_per_kwh[selection],
        fixed_generation_kw=inputs.fixed_generation_kw[selection],
        fixed_generation_carbon_kg_per_kwh=(
            inputs.fixed_generation_carbon_kg_per_kwh[selection]
        ),
        pv_carbon_kg_per_kwh=inputs.pv_carbon_kg_per_kwh[selection],
        wind_carbon_kg_per_kwh=inputs.wind_carbon_kg_per_kwh[selection],
        battery_initial_stored_carbon_kg_per_kwh=(
            inputs.battery_initial_stored_carbon_kg_per_kwh
        ),
        hydrogen_initial_stored_carbon_kg_per_kwh=(
            inputs.hydrogen_initial_stored_carbon_kg_per_kwh
        ),
    )


def _storage_power_bounds(
    *,
    enabled: bool,
    energy_kwh: float,
    capacity_kwh: float,
    power_limit_kw: float,
    minimum_soc: float,
    maximum_soc: float,
    charge_efficiency: float,
    discharge_efficiency: float,
    step_hours: float,
) -> tuple[float, float]:
    if not enabled:
        return 0.0, 0.0
    minimum_energy = minimum_soc * capacity_kwh
    maximum_energy = maximum_soc * capacity_kwh
    charge_limit = min(
        power_limit_kw,
        max(maximum_energy - energy_kwh, 0.0) / (charge_efficiency * step_hours),
    )
    discharge_limit = min(
        power_limit_kw,
        max(energy_kwh - minimum_energy, 0.0) * discharge_efficiency / step_hours,
    )
    return -charge_limit, discharge_limit


def _bounded_storage_energy(
    *,
    carrier: str,
    energy_kwh: float,
    capacity_kwh: float,
    minimum_soc: float,
    maximum_soc: float,
) -> float:
    minimum = minimum_soc * capacity_kwh
    maximum = maximum_soc * capacity_kwh
    bounded = float(np.clip(energy_kwh, minimum, maximum))
    if abs(bounded - energy_kwh) >= STATE_CARRY_TOLERANCE:
        raise RollingDispatchError(
            f"{carrier} execution energy exceeds its state bound by "
            f"{abs(bounded - energy_kwh):.12g} kWh"
        )
    return bounded


def _operational_validation_feasible(validation: PowerFlowValidation) -> bool:
    current_ok = True if validation.current_feasible is None else validation.current_feasible
    return bool(
        validation.all_converged
        and validation.voltage_feasible
        and current_ok
        and validation.grid_feasible is True
    )


def _lossless_pcc_feasible(dispatch: Any) -> bool:
    return all(
        dispatch.violation[key] <= LOSSLESS_PCC_NUMERICAL_TOLERANCE_KW
        for key in ("grid_import", "grid_export")
    )


def _causal_project_execution(
    *,
    actual_inputs: DispatchInputs,
    execution_config: DispatchConfig,
    network: IEEE33ScheduleValidator,
    planned_battery_power_kw: Sequence[float],
    planned_hydrogen_power_kw: Sequence[float],
    planned_renewable_fraction: Sequence[float],
    policy: RollingPCCPolicy,
) -> _CausalProjectionResult:
    """Project each executed hour using only its realized inputs and opening state."""

    horizon = actual_inputs.horizon
    planned_battery = np.asarray(planned_battery_power_kw, dtype=np.float64)
    planned_hydrogen = np.asarray(planned_hydrogen_power_kw, dtype=np.float64)
    planned_renewable = np.asarray(planned_renewable_fraction, dtype=np.float64)
    for name, values in (
        ("planned_battery_power_kw", planned_battery),
        ("planned_hydrogen_power_kw", planned_hydrogen),
        ("planned_renewable_fraction", planned_renewable),
    ):
        if values.shape != (horizon,) or not np.all(np.isfinite(values)):
            raise ValueError(f"{name} must be a finite vector with shape ({horizon},)")

    battery_energy = execution_config.battery_initial_soc * execution_config.battery_capacity_kwh
    hydrogen_energy = (
        execution_config.hydrogen_initial_soc * execution_config.hydrogen_capacity_kwh
    )
    accepted_battery = np.empty(horizon, dtype=np.float64)
    accepted_hydrogen = np.empty(horizon, dtype=np.float64)
    accepted_renewable = np.empty(horizon, dtype=np.float64)
    records: list[dict[str, Any]] = []

    for step in range(horizon):
        battery_bounds = _storage_power_bounds(
            enabled=execution_config.battery_enabled,
            energy_kwh=battery_energy,
            capacity_kwh=execution_config.battery_capacity_kwh,
            power_limit_kw=execution_config.battery_power_kw,
            minimum_soc=execution_config.battery_min_soc,
            maximum_soc=execution_config.battery_max_soc,
            charge_efficiency=execution_config.battery_charge_efficiency,
            discharge_efficiency=execution_config.battery_discharge_efficiency,
            step_hours=execution_config.step_hours,
        )
        hydrogen_bounds = _storage_power_bounds(
            enabled=execution_config.hydrogen_enabled,
            energy_kwh=hydrogen_energy,
            capacity_kwh=execution_config.hydrogen_capacity_kwh,
            power_limit_kw=execution_config.hydrogen_power_kw,
            minimum_soc=execution_config.hydrogen_min_soc,
            maximum_soc=execution_config.hydrogen_max_soc,
            charge_efficiency=execution_config.electrolyzer_efficiency,
            discharge_efficiency=execution_config.fuel_cell_efficiency,
            step_hours=execution_config.step_hours,
        )
        candidate = np.array(
            [
                np.clip(planned_battery[step], *battery_bounds),
                np.clip(planned_hydrogen[step], *hydrogen_bounds),
                np.clip(planned_renewable[step], 0.0, 1.0),
            ],
            dtype=np.float64,
        )
        state_clip_applied = not np.allclose(
            candidate,
            [planned_battery[step], planned_hydrogen[step], planned_renewable[step]],
            rtol=0.0,
            atol=1e-12,
        )
        step_inputs = _slice_dispatch_inputs(actual_inputs, step)
        step_config = replace(
            execution_config,
            horizon_steps=1,
            battery_initial_soc=(
                _bounded_storage_energy(
                    carrier="battery",
                    energy_kwh=battery_energy,
                    capacity_kwh=execution_config.battery_capacity_kwh,
                    minimum_soc=execution_config.battery_min_soc,
                    maximum_soc=execution_config.battery_max_soc,
                )
                / execution_config.battery_capacity_kwh
                if execution_config.battery_enabled
                else execution_config.battery_initial_soc
            ),
            hydrogen_initial_soc=(
                _bounded_storage_energy(
                    carrier="hydrogen",
                    energy_kwh=hydrogen_energy,
                    capacity_kwh=execution_config.hydrogen_capacity_kwh,
                    minimum_soc=execution_config.hydrogen_min_soc,
                    maximum_soc=execution_config.hydrogen_max_soc,
                )
                / execution_config.hydrogen_capacity_kwh
                if execution_config.hydrogen_enabled
                else execution_config.hydrogen_initial_soc
            ),
        )
        step_problem = MultiEnergyDispatchProblem(step_inputs, step_config)
        network_evaluations = 0

        def evaluate_action(
            action: np.ndarray,
        ) -> tuple[Any, PowerFlowValidation, float]:
            nonlocal network_evaluations
            decision = np.array([action[0], action[1], action[2]], dtype=np.float64)
            evaluation = step_problem.evaluate(
                decision,
                enforce_terminal_inventory=False,
            )
            validation = network.validate(
                step_inputs,
                evaluation,
                grid_import_limit_kw=execution_config.grid_import_limit_kw,
                grid_export_limit_kw=execution_config.grid_export_limit_kw,
            )
            network_evaluations += 1
            slack = float(validation.timeseries["slack_power_kw"].iloc[0])
            return evaluation, validation, slack

        def action_feasible(trial: tuple[Any, PowerFlowValidation, float]) -> bool:
            evaluation, validation, slack = trial
            device_power_ok = all(
                evaluation.violation[key] <= 1e-10
                for key in (
                    "battery_power",
                    "hydrogen_power",
                    "renewable_fraction",
                )
            )
            device_state_ok = all(
                evaluation.violation[key] < STATE_CARRY_TOLERANCE
                for key in ("battery_state", "hydrogen_state")
            )
            import_headroom = min(
                policy.execution_headroom_kw,
                execution_config.grid_import_limit_kw,
            )
            export_headroom = min(
                policy.execution_headroom_kw,
                execution_config.grid_export_limit_kw,
            )
            lossless = float(evaluation.grid_power_kw[0])
            lossless_headroom_ok = bool(
                lossless
                <= execution_config.grid_import_limit_kw - import_headroom
                and lossless
                >= -execution_config.grid_export_limit_kw + export_headroom
            )
            ac_headroom_ok = bool(
                slack
                <= execution_config.grid_import_limit_kw - import_headroom
                and slack
                >= -execution_config.grid_export_limit_kw + export_headroom
            )
            return (
                device_power_ok
                and device_state_ok
                and lossless_headroom_ok
                and ac_headroom_ok
                and _operational_validation_feasible(validation)
            )

        candidate_evaluation, candidate_validation, initial_slack = evaluate_action(candidate)
        accepted = candidate
        accepted_evaluation = candidate_evaluation
        accepted_validation = candidate_validation
        final_slack = initial_slack
        direction = "none"
        interpolation_fraction = 0.0
        pcc_projection_applied = False

        if policy.robust and not action_feasible(
            (candidate_evaluation, candidate_validation, initial_slack)
        ):
            if not candidate_validation.all_converged or not math.isfinite(initial_slack):
                raise RollingDispatchError(
                    f"causal PCC projection cannot evaluate AC flow at execution step {step}"
                )
            import_headroom = min(
                policy.execution_headroom_kw,
                execution_config.grid_import_limit_kw,
            )
            export_headroom = min(
                policy.execution_headroom_kw,
                execution_config.grid_export_limit_kw,
            )
            candidate_lossless = float(candidate_evaluation.grid_power_kw[0])
            if (
                initial_slack
                > execution_config.grid_import_limit_kw - import_headroom
                or candidate_lossless
                > execution_config.grid_import_limit_kw - import_headroom
            ):
                direction = "import"
                extreme = np.array(
                    [battery_bounds[1], hydrogen_bounds[1], 1.0],
                    dtype=np.float64,
                )
            elif (
                initial_slack
                < -execution_config.grid_export_limit_kw + export_headroom
                or candidate_lossless
                < -execution_config.grid_export_limit_kw + export_headroom
            ):
                direction = "export"
                extreme = np.array(
                    [battery_bounds[0], hydrogen_bounds[0], 0.0],
                    dtype=np.float64,
                )
            else:
                raise RollingDispatchError(
                    f"actual execution is AC-infeasible without a PCC violation at step {step}"
                )

            lower_fraction = 0.0
            upper_fraction: float | None = None
            upper_result: tuple[Any, PowerFlowValidation, float] | None = None
            for fraction in np.linspace(1.0 / 32.0, 1.0, 32):
                action = candidate + float(fraction) * (extreme - candidate)
                trial = evaluate_action(action)
                if action_feasible(trial):
                    upper_fraction = float(fraction)
                    upper_result = trial
                    break
                lower_fraction = float(fraction)
            if upper_fraction is None or upper_result is None:
                raise RollingDispatchError(
                    f"causal PCC projection has insufficient device/curtailment headroom "
                    f"at execution step {step}"
                )
            for _ in range(policy.projection_bisection_iterations):
                midpoint = 0.5 * (lower_fraction + upper_fraction)
                action = candidate + midpoint * (extreme - candidate)
                trial = evaluate_action(action)
                if action_feasible(trial):
                    upper_fraction = midpoint
                    upper_result = trial
                else:
                    lower_fraction = midpoint
            accepted = candidate + upper_fraction * (extreme - candidate)
            accepted_evaluation, accepted_validation, final_slack = upper_result
            interpolation_fraction = upper_fraction
            pcc_projection_applied = True

        if policy.robust and not action_feasible(
            (accepted_evaluation, accepted_validation, final_slack)
        ):
            raise RollingDispatchError(
                f"loss-adjusted PCC feasibility is a hard execution requirement at step {step}"
            )
        battery_energy = _bounded_storage_energy(
            carrier="battery",
            energy_kwh=float(accepted_evaluation.battery_energy_kwh[-1]),
            capacity_kwh=execution_config.battery_capacity_kwh,
            minimum_soc=execution_config.battery_min_soc,
            maximum_soc=execution_config.battery_max_soc,
        )
        hydrogen_energy = _bounded_storage_energy(
            carrier="hydrogen",
            energy_kwh=float(accepted_evaluation.hydrogen_energy_kwh[-1]),
            capacity_kwh=execution_config.hydrogen_capacity_kwh,
            minimum_soc=execution_config.hydrogen_min_soc,
            maximum_soc=execution_config.hydrogen_max_soc,
        )
        accepted_battery[step] = accepted[0]
        accepted_hydrogen[step] = accepted[1]
        accepted_renewable[step] = accepted[2]
        renewable_available = float(step_inputs.renewable_available_kw[0])
        correction_l1_kw = float(
            abs(accepted[0] - planned_battery[step])
            + abs(accepted[1] - planned_hydrogen[step])
            + renewable_available * abs(accepted[2] - planned_renewable[step])
        )
        records.append(
            {
                "step": step,
                "state_clip_applied": state_clip_applied,
                "pcc_projection_applied": pcc_projection_applied,
                "pcc_projection_direction": direction,
                "pcc_projection_fraction": interpolation_fraction,
                "pcc_slack_before_projection_kw": initial_slack,
                "pcc_slack_after_projection_kw": final_slack,
                "lossless_grid_before_projection_kw": float(
                    candidate_evaluation.grid_power_kw[0]
                ),
                "lossless_grid_after_projection_kw": float(
                    accepted_evaluation.grid_power_kw[0]
                ),
                "execution_correction_l1_kw": correction_l1_kw,
                "projection_network_evaluations": network_evaluations,
            }
        )

    return _CausalProjectionResult(
        decision=np.concatenate(
            [accepted_battery, accepted_hydrogen, accepted_renewable]
        ),
        records=pd.DataFrame.from_records(records),
    )


def _network_metrics(
    validation: PowerFlowValidation,
    step_hours: float,
    *,
    grid_import_limit_kw: float | None = None,
    grid_export_limit_kw: float | None = None,
) -> dict[str, Any]:
    timeseries = validation.timeseries
    slack = timeseries["slack_power_kw"].to_numpy(dtype=float)
    if validation.grid_feasible is not None:
        pcc_feasible = validation.grid_feasible
    elif grid_import_limit_kw is not None or grid_export_limit_kw is not None:
        import_limit = math.inf if grid_import_limit_kw is None else grid_import_limit_kw
        export_limit = math.inf if grid_export_limit_kw is None else grid_export_limit_kw
        pcc_feasible = bool(
            np.all(slack <= import_limit + 1e-6)
            and np.all(slack >= -export_limit - 1e-6)
        )
    else:
        pcc_feasible = None
    current_ok = True if validation.current_feasible is None else validation.current_feasible
    pcc_ok = True if pcc_feasible is None else pcc_feasible
    physical_feasible = (
        validation.all_converged and validation.voltage_feasible and current_ok
    )
    return {
        "network_feasible": physical_feasible and pcc_ok,
        "physical_network_feasible": physical_feasible,
        "all_converged": validation.all_converged,
        "voltage_feasible": validation.voltage_feasible,
        "current_feasible": validation.current_feasible,
        "pcc_limit_feasible": pcc_feasible,
        "minimum_voltage_pu": float(timeseries["min_voltage_pu"].min()),
        "maximum_voltage_pu": float(timeseries["max_voltage_pu"].max()),
        "maximum_pcc_import_kw": float(np.maximum(slack, 0.0).max()),
        "maximum_pcc_export_kw": float(np.maximum(-slack, 0.0).max()),
        "pcc_import_kwh": float(np.maximum(slack, 0.0).sum() * step_hours),
        "pcc_export_kwh": float(np.maximum(-slack, 0.0).sum() * step_hours),
        "active_loss_energy_kwh": float(timeseries["active_loss_kw"].sum() * step_hours),
    }


def _factor(inventory_kg: float, energy_kwh: float) -> float:
    if energy_kwh <= 1e-12:
        if abs(inventory_kg) > 1e-8:
            raise RollingDispatchError("positive carbon inventory remains in an empty reservoir")
        return 0.0
    return inventory_kg / energy_kwh


def _case_label(value: float) -> str:
    return f"initial_carbon_{value:.3f}".replace(".", "p")


def _boolean_series(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise RollingDispatchError(f"rolling daily metrics are missing {column}")

    def coerce(value: object) -> bool | None:
        if isinstance(value, (bool, np.bool_)):
            return bool(value)
        if isinstance(value, Integral) and value in (0, 1):
            return bool(value)
        text = str(value).strip().lower()
        if text in {"true", "1"}:
            return True
        if text in {"false", "0"}:
            return False
        return None

    converted = frame[column].map(coerce)
    if converted.isna().any():
        raise RollingDispatchError(f"rolling daily metric {column} is not boolean")
    return converted.astype(bool)


def _maximum_adjacent_carry_residual(
    daily: pd.DataFrame,
    column_pairs: Sequence[tuple[str, str]],
) -> float:
    if len(daily) < 2:
        return 0.0
    residual = 0.0
    for opening_column, closing_column in column_pairs:
        opening = daily[opening_column].to_numpy(dtype=float)[1:]
        prior_closing = daily[closing_column].to_numpy(dtype=float)[:-1]
        residual = max(
            residual,
            float(np.max(np.abs(opening - prior_closing))),
        )
    return residual


def _build_acceptance(
    daily: pd.DataFrame,
    *,
    maximum_energy_carry_residual_kwh: float,
    maximum_carbon_carry_residual_kg: float,
    maximum_green_inventory_carry_residual_kwh: float = math.inf,
    maximum_daily_green_inventory_balance_residual_kwh: float = math.inf,
    green_inventory_carry_implemented: bool = False,
) -> dict[str, Any]:
    checks = {
        "all_forecast_plans_network_feasible": bool(
            _boolean_series(daily, "plan_network_feasible").all()
        ),
        "all_forecast_plans_terminal_feasible": bool(
            daily["plan_terminal_error_kwh"].abs().max()
            < TERMINAL_ENERGY_TOLERANCE_KWH
        ),
        "all_actual_device_states_feasible": bool(
            _boolean_series(daily, "actual_device_state_feasible").all()
        ),
        "all_actual_lossless_pcc_feasible": bool(
            _boolean_series(daily, "actual_lossless_pcc_feasible").all()
        ),
        "all_actual_physical_ac_network_feasible": bool(
            _boolean_series(daily, "actual_physical_network_feasible").all()
        ),
        "all_actual_loss_adjusted_ac_pcc_feasible": bool(
            _boolean_series(daily, "actual_pcc_limit_feasible").all()
        ),
        "energy_state_carry_passed": (
            maximum_energy_carry_residual_kwh < STATE_CARRY_TOLERANCE
        ),
        "carbon_inventory_carry_passed": (
            maximum_carbon_carry_residual_kg < STATE_CARRY_TOLERANCE
        ),
        "green_inventory_carry_passed": bool(
            green_inventory_carry_implemented
            and maximum_green_inventory_carry_residual_kwh
            < GREEN_INVENTORY_TOLERANCE_KWH
        ),
        "green_inventory_conservation_passed": bool(
            green_inventory_carry_implemented
            and maximum_daily_green_inventory_balance_residual_kwh
            < GREEN_INVENTORY_TOLERANCE_KWH
        ),
        "copperplate_carbon_conservation_passed": bool(
            daily["actual_proxy_carbon_residual_kg"].abs().max()
            < PROXY_CARBON_TOLERANCE_KG
        ),
        "ac_carbon_conservation_passed": bool(
            daily["actual_ac_carbon_residual_kg"].abs().max()
            < AC_CARBON_TOLERANCE_KG
        ),
    }
    failed = [name for name, passed in checks.items() if not passed]
    passed = not failed
    return {
        "status": "passed" if passed else "failed",
        "passed": passed,
        **checks,
        "failure_reasons": failed,
        "branch_ampacity_ratings_available": False,
        "thermal_feasibility_evaluated": False,
        "green_inventory_carry_implemented": green_inventory_carry_implemented,
        "green_metrics_reportable_across_days": bool(
            checks["green_inventory_carry_passed"]
            and checks["green_inventory_conservation_passed"]
        ),
        "scope_note": (
            "Operational acceptance covers dispatch state bounds, both lossless and "
            "loss-adjusted PCC limits, voltage/convergence, state carry, and carbon "
            "and green-inventory conservation. IEEE33 thermal limits remain outside "
            "the implemented scope."
        ),
    }


def _method_scope(base_seeds: Sequence[int]) -> dict[str, Any]:
    seeds = tuple(int(seed) for seed in base_seeds)
    multi_seed = len(seeds) >= 3
    return {
        "stochastic_robustness": {
            "optimizer_realizations_per_day": len(seeds),
            "seed_policy": (
                "Each configured base seed is incremented by the zero-based execution-day "
                "index; the same daily seed set is reused for every initial-carbon-factor "
                "case as common random numbers."
            ),
            "base_seeds": list(seeds),
            "multi_seed_validation": multi_seed,
            "optimizer_restart_spread_reported": multi_seed,
            "ranking_uncertainty_quantified": False,
            "comparative_ranking_conclusion_permitted": False,
            "limitation": (
                "Non-selected restarts do not form independent cross-day state "
                "trajectories. The audit quantifies daily optimizer-restart spread, "
                "not uncertainty in the final rolling-policy ranking."
            ),
        },
        "terminal_policy": {
            "plan_energy_terminal_constraint": (
                "battery and hydrogen energy return to each plan's opening state at "
                "the end of the 48-hour lookahead"
            ),
            "executed_24_hour_terminal_constraint": False,
            "plan_carbon_terminal_constraint": False,
            "plan_green_inventory_terminal_constraint": False,
            "limitation": (
                "The 48-hour cyclic energy boundary can suppress longer-duration "
                "hydrogen value; the first 24 hours still carry realized energy and "
                "carbon inventories into the next optimization."
            ),
        },
        "state_inventory_scope": {
            "energy_carried_across_days": True,
            "carbon_inventory_carried_across_days": True,
            "green_inventory_carried_across_days": True,
            "green_metric_note": (
                "Battery and hydrogen green-label inventories are carried from each "
                "corrected execution day into the next day. The cumulative green-self-use "
                "rate uses new renewable generation plus only the first opening inventory."
            ),
        },
    }


def _network_provenance(network: IEEE33ScheduleValidator) -> dict[str, Any]:
    feeder = network.feeder
    branches = [
        {
            "from_bus_external": int(branch.from_bus_external),
            "to_bus_external": int(branch.to_bus_external),
            "resistance_ohm": float(branch.resistance_ohm),
            "reactance_ohm": float(branch.reactance_ohm),
            "normally_closed": bool(branch.normally_closed),
            "is_tie": bool(branch.is_tie),
        }
        for branch in feeder.branches
    ]
    structural_payload = {
        "name": str(feeder.name),
        "slack_bus_internal": int(feeder.slack_bus),
        "base_voltage_kv": float(feeder.base_voltage_kv),
        "base_power_mva": float(feeder.base_power_mva),
        "load_p_kw": np.asarray(feeder.load_p_kw, dtype=float).tolist(),
        "load_q_kvar": np.asarray(feeder.load_q_kvar, dtype=float).tolist(),
        "branches": branches,
    }
    canonical = json.dumps(structural_payload, sort_keys=True, separators=(",", ":"))
    solver_source = inspect.getsourcefile(network._solve)  # noqa: SLF001
    solver_path = Path(solver_source).resolve() if solver_source else None
    return {
        "model": "Canonical IEEE33 AC radial power flow",
        "network_structure_sha256": sha256(canonical.encode()).hexdigest(),
        "feeder_name": str(feeder.name),
        "bus_count": int(feeder.n_bus),
        "branch_count": int(feeder.n_branch),
        "placement": asdict(network.placement),
        "voltage_min_pu": float(network.voltage_min_pu),
        "voltage_max_pu": float(network.voltage_max_pu),
        "branch_ampacity_ratings_available": network.max_current_pu is not None,
        "power_flow_solver_source": str(solver_path) if solver_path else None,
        "power_flow_solver_source_sha256": (
            _file_sha256(solver_path)
            if solver_path is not None and solver_path.is_file()
            else None
        ),
    }


def _implementation_provenance() -> dict[str, Any]:
    project_root = Path(__file__).resolve().parents[2]
    relative_paths = (
        "pyproject.toml",
        "src/qingheng/cli.py",
        "src/qingheng/config.py",
        "src/qingheng/scenario.py",
        "src/qingheng/scenario_sizing.py",
        "src/qingheng/rolling_dispatch.py",
        "src/qingheng/rolling_optimization.py",
        "src/qingheng/pipeline.py",
        "src/qingheng/data/__init__.py",
        "src/qingheng/data/completeness.py",
        "src/qingheng/data/hybrid.py",
        "src/qingheng/data/ieee33.py",
        "src/qingheng/data/manifest.py",
        "src/qingheng/data/socal.py",
        "src/qingheng/dispatch/__init__.py",
        "src/qingheng/dispatch/problem.py",
        "src/qingheng/dispatch/optimizers.py",
        "src/qingheng/network/__init__.py",
        "src/qingheng/network/ieee33.py",
        "src/qingheng/carbon/__init__.py",
        "src/qingheng/carbon/metrics.py",
        "src/qingheng/carbon/reservoir.py",
        "src/qingheng/carbon/tracer.py",
    )
    files = [
        {
            "path": relative,
            "sha256": _file_sha256(project_root / relative),
        }
        for relative in relative_paths
    ]
    canonical = json.dumps(files, sort_keys=True, separators=(",", ":"))
    return {
        "python_version": sys.version,
        "numpy_version": np.__version__,
        "pandas_version": pd.__version__,
        "source_files": files,
        "source_bundle_sha256": sha256(canonical.encode()).hexdigest(),
    }


def _required_artifact_paths(provenance: Mapping[str, Any]) -> set[str]:
    configuration = provenance.get("rolling_configuration")
    if not isinstance(configuration, Mapping):
        raise RollingDispatchError("rolling provenance has no rolling configuration")
    factors = configuration.get("initial_carbon_factors_kg_per_kwh")
    if not isinstance(factors, list) or not factors:
        raise RollingDispatchError("rolling provenance has no initial carbon factors")
    required = {
        "rolling_carbon_sensitivity.csv",
        "rolling_carbon_sensitivity.json",
        "rolling_provenance.json",
    }
    source = provenance.get("source")
    if isinstance(source, Mapping) and source.get("sizing_sha256") is not None:
        required.add("sizing_manifest.json")
    records_seed_audit = isinstance(configuration.get("base_seeds"), list)
    for raw_factor in factors:
        try:
            label = _case_label(float(raw_factor))
        except (TypeError, ValueError) as exc:
            raise RollingDispatchError(
                "rolling provenance contains an invalid initial carbon factor"
            ) from exc
        required.update(
            {
                f"{label}/rolling_actual_schedule.csv",
                f"{label}/rolling_daily_metrics.csv",
                f"{label}/rolling_summary.json",
            }
        )
        if records_seed_audit:
            required.add(f"{label}/rolling_seed_audit.csv")
    return required


def write_rolling_artifact_manifest(output_dir: str | Path) -> Path:
    """Hash every rolling result file so post-run edits and stale files are detectable."""

    output = Path(output_dir).resolve()
    provenance_path = output / "rolling_provenance.json"
    if not provenance_path.is_file():
        raise RollingDispatchError("rolling provenance must exist before artifact hashing")
    provenance = _read_json(provenance_path)
    scenario_hash = provenance.get("rolling_scenario_sha256")
    if not isinstance(scenario_hash, str) or len(scenario_hash) != 64:
        raise RollingDispatchError("rolling provenance has no valid scenario hash")
    required_paths = _required_artifact_paths(provenance)

    manifest_path = output / ARTIFACT_MANIFEST_FILENAME
    entries: list[dict[str, Any]] = []
    excluded_names = {
        ARTIFACT_MANIFEST_FILENAME,
        f"{ARTIFACT_MANIFEST_FILENAME}.tmp",
    }
    for path in sorted(output.rglob("*")):
        if not path.is_file() or path.name in excluded_names:
            continue
        entries.append(
            {
                "path": path.relative_to(output).as_posix(),
                "size_bytes": path.stat().st_size,
                "sha256": _file_sha256(path),
            }
        )
    recorded_paths = {entry["path"] for entry in entries}
    missing = sorted(required_paths - recorded_paths)
    if missing:
        raise RollingDispatchError(f"rolling result set is incomplete: {missing}")
    document: dict[str, Any] = {
        "schema_version": "qingheng.rolling-artifact-manifest.v1",
        "rolling_scenario_sha256": scenario_hash,
        "result_complete": True,
        "required_file_count": len(required_paths),
        "file_count": len(entries),
        "files": entries,
    }
    canonical = json.dumps(document, sort_keys=True, separators=(",", ":"))
    document["manifest_sha256"] = sha256(canonical.encode()).hexdigest()
    temporary = manifest_path.with_suffix(".json.tmp")
    temporary.write_text(
        json.dumps(document, indent=2, ensure_ascii=True), encoding="utf-8"
    )
    temporary.replace(manifest_path)
    return manifest_path


def verify_rolling_artifact_manifest(manifest_path: str | Path) -> dict[str, Any]:
    """Verify an immutable rolling result directory against its output manifest."""

    manifest_file = Path(manifest_path).resolve()
    document = _read_json(manifest_file)
    if document.get("schema_version") != "qingheng.rolling-artifact-manifest.v1":
        raise RollingDispatchError("unsupported rolling artifact manifest schema")
    expected_manifest_hash = document.get("manifest_sha256")
    unsigned = dict(document)
    unsigned.pop("manifest_sha256", None)
    canonical = json.dumps(unsigned, sort_keys=True, separators=(",", ":"))
    if expected_manifest_hash != sha256(canonical.encode()).hexdigest():
        raise RollingDispatchError("rolling artifact manifest content hash does not match")
    entries = document.get("files")
    if not isinstance(entries, list) or document.get("file_count") != len(entries):
        raise RollingDispatchError("rolling artifact manifest has invalid file entries")

    output = manifest_file.parent
    recorded_paths: set[str] = set()
    for entry in entries:
        if not isinstance(entry, dict):
            raise RollingDispatchError("rolling artifact manifest file entry is invalid")
        relative = Path(str(entry.get("path", "")))
        if (
            not relative.parts
            or relative.is_absolute()
            or ".." in relative.parts
            or relative.name in {ARTIFACT_MANIFEST_FILENAME, f"{ARTIFACT_MANIFEST_FILENAME}.tmp"}
        ):
            raise RollingDispatchError("rolling artifact manifest contains an unsafe path")
        path = (output / relative).resolve()
        if output not in path.parents or not path.is_file():
            raise RollingDispatchError(f"rolling result file is missing: {relative.as_posix()}")
        if (
            entry.get("size_bytes") != path.stat().st_size
            or entry.get("sha256") != _file_sha256(path)
        ):
            raise RollingDispatchError(
                f"rolling result file does not match its manifest: {relative.as_posix()}"
            )
        recorded_paths.add(relative.as_posix())

    actual_paths = {
        path.relative_to(output).as_posix()
        for path in output.rglob("*")
        if path.is_file()
        and path.name
        not in {ARTIFACT_MANIFEST_FILENAME, f"{ARTIFACT_MANIFEST_FILENAME}.tmp"}
    }
    if actual_paths != recorded_paths:
        raise RollingDispatchError("rolling result directory contains unmanifested files")
    provenance = _read_json(output / "rolling_provenance.json")
    if document.get("rolling_scenario_sha256") != provenance.get(
        "rolling_scenario_sha256"
    ):
        raise RollingDispatchError("rolling artifact and provenance scenario hashes differ")
    missing = sorted(_required_artifact_paths(provenance) - recorded_paths)
    if missing or document.get("result_complete") is not True:
        raise RollingDispatchError(f"rolling artifact manifest is incomplete: {missing}")
    return document


def _write_case_outputs(
    output: Path,
    schedule_records: list[pd.DataFrame],
    day_records: list[dict[str, Any]],
    seed_records: list[pd.DataFrame],
    summary: dict[str, Any],
) -> None:
    output.mkdir(parents=True, exist_ok=True)
    pd.concat(schedule_records, ignore_index=True).to_csv(
        output / "rolling_actual_schedule.csv", index=False
    )
    pd.DataFrame.from_records(day_records).to_csv(output / "rolling_daily_metrics.csv", index=False)
    pd.concat(seed_records, ignore_index=True).to_csv(
        output / "rolling_seed_audit.csv", index=False
    )
    (output / "rolling_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=True), encoding="utf-8"
    )


def _run_factor_case(
    *,
    forecasts: pd.DataFrame,
    hybrid_profile: pd.DataFrame,
    execution_dates: Sequence[str],
    base_dispatch: DispatchConfig,
    carbon_config: CarbonConfig,
    network: IEEE33ScheduleValidator,
    output: Path,
    initial_carbon_factor: float,
    population: int,
    iterations: int,
    base_seeds: Sequence[int],
    carbon_warning_fraction: float,
    pcc_policy: RollingPCCPolicy,
) -> dict[str, Any]:
    battery_energy = base_dispatch.battery_capacity_kwh * base_dispatch.battery_initial_soc
    hydrogen_energy = base_dispatch.hydrogen_capacity_kwh * base_dispatch.hydrogen_initial_soc
    battery_factor = initial_carbon_factor if base_dispatch.battery_enabled else 0.0
    hydrogen_factor = initial_carbon_factor if base_dispatch.hydrogen_enabled else 0.0
    initial_battery_energy = battery_energy
    initial_hydrogen_energy = hydrogen_energy
    battery_green_inventory = 0.0
    hydrogen_green_inventory = 0.0
    initial_battery_green_inventory = battery_green_inventory
    initial_hydrogen_green_inventory = hydrogen_green_inventory
    schedule_records: list[pd.DataFrame] = []
    day_records: list[dict[str, Any]] = []
    seed_records: list[pd.DataFrame] = []
    maximum_daily_green_inventory_balance_residual = 0.0
    prior_net_forecast_errors_kw: list[float] = []
    prior_ac_loss_deltas_kw: list[float] = []

    for day_index, local_date in enumerate(execution_dates):
        pcc_limits = _planning_pcc_limits(
            base_dispatch,
            pcc_policy,
            prior_net_forecast_errors_kw=prior_net_forecast_errors_kw,
            prior_ac_loss_deltas_kw=prior_ac_loss_deltas_kw,
        )
        planning_frame, actual_frame = compose_rolling_lookahead(forecasts, local_date)
        planning_profile = _profile_with_power(
            hybrid_profile,
            planning_frame,
            load_column="load_dispatch_forecast_kw",
            pv_column="pv_dispatch_forecast_kw",
        )
        actual_profile = _profile_with_power(
            hybrid_profile,
            actual_frame,
            load_column="load_dispatch_actual_kw",
            pv_column="pv_dispatch_actual_kw",
        )
        battery_open_carbon = battery_energy * battery_factor
        hydrogen_open_carbon = hydrogen_energy * hydrogen_factor

        battery_soc = (
            battery_energy / base_dispatch.battery_capacity_kwh
            if base_dispatch.battery_enabled
            else base_dispatch.battery_initial_soc
        )
        hydrogen_soc = (
            hydrogen_energy / base_dispatch.hydrogen_capacity_kwh
            if base_dispatch.hydrogen_enabled
            else base_dispatch.hydrogen_initial_soc
        )
        planning_config = replace(
            base_dispatch,
            horizon_steps=LOOKAHEAD_HOURS,
            population=population,
            iterations=iterations,
            battery_initial_soc=battery_soc,
            hydrogen_initial_soc=hydrogen_soc,
            grid_import_limit_kw=pcc_limits.tightened_import_limit_kw,
            grid_export_limit_kw=pcc_limits.tightened_export_limit_kw,
        )
        carried_carbon = replace(
            carbon_config,
            battery_initial_stored_carbon_kg_per_kwh=battery_factor,
            hydrogen_initial_stored_carbon_kg_per_kwh=hydrogen_factor,
        )
        planning_inputs = make_profile_dispatch_inputs(
            planning_profile,
            planning_config,
            carried_carbon,
        )
        problem = MultiEnergyDispatchProblem(planning_inputs, planning_config)
        day_seeds = rolling_day_seeds(base_seeds, day_index)
        try:
            selection = select_forecast_feasible_seed(
                problem,
                network,
                seeds=day_seeds,
                population=population,
                iterations=iterations,
                terminal_tolerance_kwh=TERMINAL_ENERGY_TOLERANCE_KWH,
                carbon_tolerance_kg=PROXY_CARBON_TOLERANCE_KG,
                physical_grid_import_limit_kw=(
                    pcc_limits.physical_import_limit_kw
                ),
                physical_grid_export_limit_kw=(
                    pcc_limits.physical_export_limit_kw
                ),
            )
        except ForecastSeedSelectionError as exc:
            failed_audit = exc.audit.copy()
            failed_audit.insert(0, "local_date", local_date)
            failed_audit.insert(1, "day_index", day_index)
            failed_audit.insert(
                2,
                "initial_carbon_factor_sensitivity_kg_per_kwh",
                initial_carbon_factor,
            )
            output.mkdir(parents=True, exist_ok=True)
            frames = [*seed_records, failed_audit]
            pd.concat(frames, ignore_index=True).to_csv(
                output / "rolling_seed_audit_failed.csv",
                index=False,
            )
            raise RollingDispatchError(
                f"no eligible forecast-only optimizer realization for {local_date}: {exc}"
            ) from exc
        seed = selection.seed
        plan = selection.evaluation
        seed_audit = selection.audit.copy()
        seed_audit.insert(0, "local_date", local_date)
        seed_audit.insert(1, "day_index", day_index)
        seed_audit.insert(
            2,
            "initial_carbon_factor_sensitivity_kg_per_kwh",
            initial_carbon_factor,
        )
        seed_records.append(seed_audit)
        eligible_seed_scores = seed_audit.loc[
            seed_audit["eligible"].astype(bool), "score"
        ].astype(float)
        runtime = float(seed_audit["runtime_seconds"].sum())
        plan_terminal_error = max(
            abs(plan.battery_energy_kwh[-1] - plan.battery_energy_kwh[0]),
            abs(plan.hydrogen_energy_kwh[-1] - plan.hydrogen_energy_kwh[0]),
        )
        if not plan.feasible or plan_terminal_error >= TERMINAL_ENERGY_TOLERANCE_KWH:
            raise RollingDispatchError(
                f"48-hour plan for {local_date} is not dispatch/terminal feasible"
            )
        if abs(plan.carbon_balance_residual_proxy_kg) >= PROXY_CARBON_TOLERANCE_KG:
            raise RollingDispatchError(f"48-hour carbon proxy does not balance on {local_date}")
        plan_validation = selection.validation
        if not plan_validation.feasible:
            raise RollingDispatchError(f"48-hour forecast plan is AC/PCC infeasible on {local_date}")

        execution_config = replace(
            base_dispatch,
            horizon_steps=EXECUTION_HOURS,
            population=population,
            iterations=iterations,
            battery_initial_soc=battery_soc,
            hydrogen_initial_soc=hydrogen_soc,
        )
        actual_inputs = make_profile_dispatch_inputs(
            actual_profile,
            execution_config,
            carried_carbon,
        )
        open_loop_decision = np.concatenate(
            [
                plan.battery_power_kw[:EXECUTION_HOURS],
                plan.hydrogen_power_kw[:EXECUTION_HOURS],
                plan.renewable_fraction[:EXECUTION_HOURS],
            ]
        )
        execution_problem = MultiEnergyDispatchProblem(actual_inputs, execution_config)
        open_loop_replay = execution_problem.evaluate(
            open_loop_decision,
            enforce_terminal_inventory=False,
        )
        open_loop_validation = network.validate(
            actual_inputs,
            open_loop_replay,
            grid_import_limit_kw=execution_config.grid_import_limit_kw,
            grid_export_limit_kw=execution_config.grid_export_limit_kw,
        )
        open_loop_network_values = _network_metrics(
            open_loop_validation,
            execution_config.step_hours,
            grid_import_limit_kw=execution_config.grid_import_limit_kw,
            grid_export_limit_kw=execution_config.grid_export_limit_kw,
        )
        if not open_loop_network_values["physical_network_feasible"]:
            raise RollingDispatchError(
                f"open-loop actual execution has non-converged/voltage-infeasible "
                f"AC flow on {local_date}"
            )

        if pcc_policy.robust:
            projection = _causal_project_execution(
                actual_inputs=actual_inputs,
                execution_config=execution_config,
                network=network,
                planned_battery_power_kw=plan.battery_power_kw[:EXECUTION_HOURS],
                planned_hydrogen_power_kw=plan.hydrogen_power_kw[:EXECUTION_HOURS],
                planned_renewable_fraction=plan.renewable_fraction[:EXECUTION_HOURS],
                policy=pcc_policy,
            )
            execution_decision = projection.decision
            projection_records = projection.records
        else:
            execution_decision = open_loop_decision
            open_loop_slack = open_loop_validation.timeseries[
                "slack_power_kw"
            ].to_numpy(dtype=float)
            projection_records = pd.DataFrame(
                {
                    "step": np.arange(EXECUTION_HOURS),
                    "state_clip_applied": False,
                    "pcc_projection_applied": False,
                    "pcc_projection_direction": "none",
                    "pcc_projection_fraction": 0.0,
                    "pcc_slack_before_projection_kw": open_loop_slack,
                    "pcc_slack_after_projection_kw": open_loop_slack,
                    "lossless_grid_before_projection_kw": open_loop_replay.grid_power_kw,
                    "lossless_grid_after_projection_kw": open_loop_replay.grid_power_kw,
                    "execution_correction_l1_kw": 0.0,
                    "projection_network_evaluations": 0,
                }
            )

        replay = execution_problem.evaluate(
            execution_decision,
            enforce_terminal_inventory=False,
        )
        device_state_feasible = all(
            replay.violation[key] < STATE_CARRY_TOLERANCE
            for key in ("battery_state", "hydrogen_state")
        )
        lossless_pcc_feasible = _lossless_pcc_feasible(replay)
        if not device_state_feasible:
            raise RollingDispatchError(
                f"fixed actual execution violates a storage state bound on {local_date}"
            )
        replay_validation = network.validate(
            actual_inputs,
            replay,
            grid_import_limit_kw=execution_config.grid_import_limit_kw,
            grid_export_limit_kw=execution_config.grid_export_limit_kw,
        )
        replay_network_values = _network_metrics(
            replay_validation,
            execution_config.step_hours,
            grid_import_limit_kw=execution_config.grid_import_limit_kw,
            grid_export_limit_kw=execution_config.grid_export_limit_kw,
        )
        if not replay_network_values["physical_network_feasible"]:
            raise RollingDispatchError(
                f"corrected actual execution has non-converged/voltage-infeasible "
                f"AC flow on {local_date}"
            )
        if pcc_policy.robust and (
            not lossless_pcc_feasible or replay_validation.grid_feasible is not True
        ):
            slack = replay_validation.timeseries["slack_power_kw"].to_numpy(
                dtype=float
            )
            raise RollingDispatchError(
                "loss-adjusted PCC feasibility is a hard failure on "
                f"{local_date}: lossless_import_violation="
                f"{replay.violation['grid_import']:.12g}, "
                f"lossless_export_violation={replay.violation['grid_export']:.12g}, "
                f"maximum_ac_import_kw={max(0.0, float(np.max(slack))):.12g}, "
                f"maximum_ac_export_kw={max(0.0, float(np.max(-slack))):.12g}, "
                f"limits=({execution_config.grid_import_limit_kw:.12g}, "
                f"{execution_config.grid_export_limit_kw:.12g})"
            )

        open_loop_carbon = run_carbon_accounting(
            inputs=actual_inputs,
            dispatch=open_loop_replay,
            dispatch_config=execution_config,
            carbon_config=carried_carbon,
            validator=network,
            validation=open_loop_validation,
            initial_battery_factor_kg_per_kwh=battery_factor,
            initial_hydrogen_factor_kg_per_kwh=hydrogen_factor,
            initial_battery_green_inventory_kwh=battery_green_inventory,
            initial_hydrogen_green_inventory_kwh=hydrogen_green_inventory,
        )
        if np.array_equal(execution_decision, open_loop_decision):
            carbon = open_loop_carbon
        else:
            carbon = run_carbon_accounting(
                inputs=actual_inputs,
                dispatch=replay,
                dispatch_config=execution_config,
                carbon_config=carried_carbon,
                validator=network,
                validation=replay_validation,
                initial_battery_factor_kg_per_kwh=battery_factor,
                initial_hydrogen_factor_kg_per_kwh=hydrogen_factor,
                initial_battery_green_inventory_kwh=battery_green_inventory,
                initial_hydrogen_green_inventory_kwh=hydrogen_green_inventory,
            )
        if (
            abs(open_loop_replay.carbon_balance_residual_proxy_kg)
            >= PROXY_CARBON_TOLERANCE_KG
            or abs(open_loop_carbon.carbon_balance_residual_kg) >= AC_CARBON_TOLERANCE_KG
        ):
            raise RollingDispatchError(
                f"open-loop executed carbon flow does not balance on {local_date}"
            )
        if abs(replay.carbon_balance_residual_proxy_kg) >= PROXY_CARBON_TOLERANCE_KG:
            raise RollingDispatchError(f"executed carbon proxy does not balance on {local_date}")
        if abs(carbon.carbon_balance_residual_kg) >= AC_CARBON_TOLERANCE_KG:
            raise RollingDispatchError(f"executed AC carbon flow does not balance on {local_date}")

        battery_energy_end = float(replay.battery_energy_kwh[-1])
        hydrogen_energy_end = float(replay.hydrogen_energy_kwh[-1])
        battery_carbon_end = float(carbon.snapshots["battery_carbon_kg_end"].iloc[-1])
        hydrogen_carbon_end = float(carbon.snapshots["hydrogen_carbon_kg_end"].iloc[-1])
        battery_green_inventory_end = (
            carbon.closing_battery_green_inventory_kwh
        )
        hydrogen_green_inventory_end = (
            carbon.closing_hydrogen_green_inventory_kwh
        )
        daily_green_balance_residual = max(
            abs(carbon.battery_green_inventory_balance_residual_kwh),
            abs(carbon.hydrogen_green_inventory_balance_residual_kwh),
            abs(carbon.green_inventory_balance_residual_kwh),
        )
        maximum_daily_green_inventory_balance_residual = max(
            maximum_daily_green_inventory_balance_residual,
            daily_green_balance_residual,
        )
        network_values = replay_network_values
        plan_network_values = _network_metrics(
            plan_validation,
            planning_config.step_hours,
            grid_import_limit_kw=pcc_limits.physical_import_limit_kw,
            grid_export_limit_kw=pcc_limits.physical_export_limit_kw,
        )
        hourly_index = actual_profile.resample("1h").mean().index
        schedule = pd.DataFrame(
            {
                "timestamp": hourly_index,
                "local_date": local_date,
                "initial_carbon_factor_sensitivity_kg_per_kwh": initial_carbon_factor,
                "pcc_policy": pcc_policy.strategy,
                "forecast_load_kw": planning_inputs.load_kw[:EXECUTION_HOURS],
                "actual_load_kw": actual_inputs.load_kw,
                "forecast_pv_kw": planning_inputs.pv_available_kw[:EXECUTION_HOURS],
                "actual_pv_kw": actual_inputs.pv_available_kw,
                "planned_battery_power_kw": plan.battery_power_kw[:EXECUTION_HOURS],
                "planned_hydrogen_power_kw": plan.hydrogen_power_kw[:EXECUTION_HOURS],
                "planned_renewable_fraction": plan.renewable_fraction[:EXECUTION_HOURS],
                "open_loop_battery_power_kw": open_loop_replay.battery_power_kw,
                "open_loop_hydrogen_power_kw": open_loop_replay.hydrogen_power_kw,
                "open_loop_renewable_fraction": open_loop_replay.renewable_fraction,
                "battery_power_kw": replay.battery_power_kw,
                "hydrogen_power_kw": replay.hydrogen_power_kw,
                "renewable_fraction": replay.renewable_fraction,
                "forecast_grid_power_kw": plan.grid_power_kw[:EXECUTION_HOURS],
                "open_loop_actual_lossless_grid_power_kw": (
                    open_loop_replay.grid_power_kw
                ),
                "open_loop_actual_pcc_power_kw": open_loop_validation.timeseries[
                    "slack_power_kw"
                ].to_numpy(dtype=float),
                "actual_lossless_grid_power_kw": replay.grid_power_kw,
                "actual_pcc_power_kw": replay_validation.timeseries[
                    "slack_power_kw"
                ].to_numpy(dtype=float),
                "state_clip_applied": projection_records[
                    "state_clip_applied"
                ].to_numpy(dtype=bool),
                "pcc_projection_applied": projection_records[
                    "pcc_projection_applied"
                ].to_numpy(dtype=bool),
                "pcc_projection_direction": projection_records[
                    "pcc_projection_direction"
                ].to_numpy(),
                "pcc_projection_fraction": projection_records[
                    "pcc_projection_fraction"
                ].to_numpy(dtype=float),
                "pcc_slack_before_projection_kw": projection_records[
                    "pcc_slack_before_projection_kw"
                ].to_numpy(dtype=float),
                "pcc_slack_after_projection_kw": projection_records[
                    "pcc_slack_after_projection_kw"
                ].to_numpy(dtype=float),
                "execution_correction_l1_kw": projection_records[
                    "execution_correction_l1_kw"
                ].to_numpy(dtype=float),
                "projection_network_evaluations": projection_records[
                    "projection_network_evaluations"
                ].to_numpy(dtype=int),
                "battery_energy_kwh_start": replay.battery_energy_kwh[:-1],
                "battery_energy_kwh_end": replay.battery_energy_kwh[1:],
                "hydrogen_energy_kwh_start": replay.hydrogen_energy_kwh[:-1],
                "hydrogen_energy_kwh_end": replay.hydrogen_energy_kwh[1:],
                "load_carbon_intensity_proxy_kg_per_kwh": (
                    replay.carbon_intensity_proxy_kg_per_kwh
                ),
                "ac_load_allocated_emissions_kg": carbon.snapshots[
                    "load_allocated_emissions_kg"
                ].to_numpy(dtype=float),
                "open_loop_ac_load_allocated_emissions_kg": (
                    open_loop_carbon.snapshots[
                        "load_allocated_emissions_kg"
                    ].to_numpy(dtype=float)
                ),
                "battery_carbon_kg_end": carbon.snapshots[
                    "battery_carbon_kg_end"
                ].to_numpy(dtype=float),
                "hydrogen_carbon_kg_end": carbon.snapshots[
                    "hydrogen_carbon_kg_end"
                ].to_numpy(dtype=float),
                "battery_green_inventory_kwh_end": carbon.snapshots[
                    "battery_green_inventory_kwh_end"
                ].to_numpy(dtype=float),
                "hydrogen_green_inventory_kwh_end": carbon.snapshots[
                    "hydrogen_green_inventory_kwh_end"
                ].to_numpy(dtype=float),
            }
        )
        schedule_records.append(schedule)
        open_loop_device_state_feasible = all(
            open_loop_replay.violation[key] < STATE_CARRY_TOLERANCE
            for key in ("battery_state", "hydrogen_state")
        )
        open_loop_lossless_pcc_feasible = _lossless_pcc_feasible(
            open_loop_replay
        )
        projection_hours = int(projection_records["pcc_projection_applied"].sum())
        state_clip_hours = int(projection_records["state_clip_applied"].sum())
        correction_l1_total = float(
            projection_records["execution_correction_l1_kw"].sum()
        )
        correction_l1_maximum = float(
            projection_records["execution_correction_l1_kw"].max()
        )
        selected_seed_runtime = float(
            seed_audit.loc[
                seed_audit["selected"].astype(bool), "runtime_seconds"
            ].iloc[0]
        )
        green_generation_kwh = float(
            np.sum(
                (actual_inputs.pv_available_kw + actual_inputs.wind_available_kw)
                * replay.renewable_fraction
            )
            * execution_config.step_hours
        )
        day_records.append(
            {
                "local_date": local_date,
                "lookahead_end_local_date": (
                    pd.Timestamp(local_date) + pd.Timedelta(days=1)
                ).date().isoformat(),
                "optimizer": "pso",
                "seed": seed,
                "population": population,
                "iterations": iterations,
                "runtime_seconds": runtime,
                "selected_seed_runtime_seconds": selected_seed_runtime,
                "optimizer_realizations": len(day_seeds),
                "eligible_optimizer_realizations": int(
                    seed_audit["eligible"].astype(bool).sum()
                ),
                "eligible_plan_score_minimum": float(eligible_seed_scores.min()),
                "eligible_plan_score_mean": float(eligible_seed_scores.mean()),
                "eligible_plan_score_standard_deviation": float(
                    eligible_seed_scores.std(ddof=0)
                ),
                "eligible_plan_score_maximum": float(eligible_seed_scores.max()),
                "eligible_plan_score_spread": float(
                    eligible_seed_scores.max() - eligible_seed_scores.min()
                ),
                "pcc_policy": pcc_policy.strategy,
                "physical_grid_import_limit_kw": pcc_limits.physical_import_limit_kw,
                "physical_grid_export_limit_kw": pcc_limits.physical_export_limit_kw,
                "planning_grid_import_limit_kw": pcc_limits.tightened_import_limit_kw,
                "planning_grid_export_limit_kw": pcc_limits.tightened_export_limit_kw,
                "planning_import_forecast_error_reserve_kw": (
                    pcc_limits.import_forecast_error_reserve_kw
                ),
                "planning_export_forecast_error_reserve_kw": (
                    pcc_limits.export_forecast_error_reserve_kw
                ),
                "planning_import_loss_reserve_kw": pcc_limits.import_loss_reserve_kw,
                "planning_prior_forecast_error_observations": (
                    pcc_limits.prior_forecast_error_observations
                ),
                "planning_prior_loss_observations": pcc_limits.prior_loss_observations,
                "plan_score": plan.score,
                "plan_cost": plan.cost,
                "plan_load_carbon_proxy_kg": plan.load_allocated_emissions_proxy_kg,
                "plan_external_source_emissions_kg": plan.external_source_emissions_kg,
                "plan_terminal_error_kwh": plan_terminal_error,
                "plan_network_feasible": plan_validation.feasible,
                "plan_minimum_voltage_pu": plan_network_values["minimum_voltage_pu"],
                "plan_maximum_voltage_pu": plan_network_values["maximum_voltage_pu"],
                "open_loop_actual_score": open_loop_replay.score,
                "open_loop_actual_weighted_objective": (
                    open_loop_replay.weighted_objective
                ),
                "open_loop_actual_penalty": open_loop_replay.penalty,
                "open_loop_actual_device_state_feasible": (
                    open_loop_device_state_feasible
                ),
                "open_loop_actual_lossless_pcc_feasible": (
                    open_loop_lossless_pcc_feasible
                ),
                "open_loop_actual_cost": open_loop_replay.cost,
                "open_loop_actual_load_carbon_proxy_kg": (
                    open_loop_replay.load_allocated_emissions_proxy_kg
                ),
                "open_loop_actual_external_source_emissions_kg": (
                    open_loop_replay.external_source_emissions_kg
                ),
                "open_loop_actual_ac_load_allocated_emissions_kg": (
                    open_loop_carbon.load_allocated_emissions_kg
                ),
                "open_loop_actual_ac_external_source_emissions_kg": (
                    open_loop_carbon.external_source_emissions_kg
                ),
                "open_loop_actual_proxy_carbon_residual_kg": (
                    open_loop_replay.carbon_balance_residual_proxy_kg
                ),
                "open_loop_actual_ac_carbon_residual_kg": (
                    open_loop_carbon.carbon_balance_residual_kg
                ),
                "open_loop_actual_network_feasible": open_loop_network_values[
                    "network_feasible"
                ],
                **{
                    f"open_loop_actual_{key}": value
                    for key, value in open_loop_network_values.items()
                },
                "actual_score": replay.score,
                "actual_weighted_objective": replay.weighted_objective,
                "actual_penalty": replay.penalty,
                "actual_device_state_feasible": device_state_feasible,
                "actual_lossless_pcc_feasible": lossless_pcc_feasible,
                "actual_cost": replay.cost,
                "actual_load_carbon_proxy_kg": replay.load_allocated_emissions_proxy_kg,
                "actual_external_source_emissions_kg": replay.external_source_emissions_kg,
                "actual_ac_load_allocated_emissions_kg": carbon.load_allocated_emissions_kg,
                "actual_ac_external_source_emissions_kg": carbon.external_source_emissions_kg,
                "actual_proxy_carbon_residual_kg": replay.carbon_balance_residual_proxy_kg,
                "actual_ac_carbon_residual_kg": carbon.carbon_balance_residual_kg,
                "actual_network_feasible": network_values["network_feasible"],
                **{f"actual_{key}": value for key, value in network_values.items()},
                "pcc_projection_hours": projection_hours,
                "state_clip_hours": state_clip_hours,
                "execution_correction_l1_kw_total": correction_l1_total,
                "maximum_hourly_execution_correction_l1_kw": correction_l1_maximum,
                "load_forecast_mae_kw": float(
                    np.mean(np.abs(actual_inputs.load_kw - planning_inputs.load_kw[:24]))
                ),
                "pv_forecast_mae_kw": float(
                    np.mean(
                        np.abs(
                            actual_inputs.pv_available_kw
                            - planning_inputs.pv_available_kw[:24]
                        )
                    )
                ),
                "battery_throughput_kwh": float(
                    np.abs(replay.battery_power_kw).sum() * execution_config.step_hours
                ),
                "hydrogen_throughput_kwh": float(
                    np.abs(replay.hydrogen_power_kw).sum() * execution_config.step_hours
                ),
                "battery_energy_open_kwh": battery_energy,
                "battery_energy_close_kwh": battery_energy_end,
                "hydrogen_energy_open_kwh": hydrogen_energy,
                "hydrogen_energy_close_kwh": hydrogen_energy_end,
                "battery_carbon_open_kg": battery_open_carbon,
                "battery_carbon_close_kg": battery_carbon_end,
                "hydrogen_carbon_open_kg": hydrogen_open_carbon,
                "hydrogen_carbon_close_kg": hydrogen_carbon_end,
                "battery_green_inventory_open_kwh": battery_green_inventory,
                "battery_green_inventory_close_kwh": (
                    battery_green_inventory_end
                ),
                "hydrogen_green_inventory_open_kwh": hydrogen_green_inventory,
                "hydrogen_green_inventory_close_kwh": (
                    hydrogen_green_inventory_end
                ),
                "storage_green_inventory_open_kwh": (
                    battery_green_inventory + hydrogen_green_inventory
                ),
                "storage_green_inventory_close_kwh": (
                    battery_green_inventory_end + hydrogen_green_inventory_end
                ),
                "battery_green_inventory_balance_residual_kwh": (
                    carbon.battery_green_inventory_balance_residual_kwh
                ),
                "hydrogen_green_inventory_balance_residual_kwh": (
                    carbon.hydrogen_green_inventory_balance_residual_kwh
                ),
                "green_inventory_balance_residual_kwh": (
                    carbon.green_inventory_balance_residual_kwh
                ),
                "green_generation_kwh": green_generation_kwh,
                "direct_green_consumed_kwh": (
                    carbon.metrics.direct_green_consumed_kwh
                ),
                "mediated_green_consumed_kwh": (
                    carbon.metrics.mediated_green_consumed_kwh
                ),
                "daily_green_self_use_rate": carbon.metrics.green_self_use_rate,
                "battery_carbon_factor_open_kg_per_kwh": battery_factor,
                "battery_carbon_factor_close_kg_per_kwh": _factor(
                    battery_carbon_end, battery_energy_end
                ),
                "hydrogen_carbon_factor_open_kg_per_kwh": hydrogen_factor,
                "hydrogen_carbon_factor_close_kg_per_kwh": _factor(
                    hydrogen_carbon_end, hydrogen_energy_end
                ),
            }
        )
        forecast_net_kw = (
            planning_inputs.load_kw[:EXECUTION_HOURS]
            - planning_inputs.pv_available_kw[:EXECUTION_HOURS]
            - planning_inputs.wind_available_kw[:EXECUTION_HOURS]
            - planning_inputs.fixed_generation_kw[:EXECUTION_HOURS]
        )
        actual_net_kw = (
            actual_inputs.load_kw
            - actual_inputs.pv_available_kw
            - actual_inputs.wind_available_kw
            - actual_inputs.fixed_generation_kw
        )
        prior_net_forecast_errors_kw.extend(
            (actual_net_kw - forecast_net_kw).astype(float).tolist()
        )
        prior_ac_loss_deltas_kw.extend(
            (
                replay_validation.timeseries["slack_power_kw"].to_numpy(dtype=float)
                - replay.grid_power_kw
            ).tolist()
        )
        battery_energy = battery_energy_end
        hydrogen_energy = hydrogen_energy_end
        battery_green_inventory = battery_green_inventory_end
        hydrogen_green_inventory = hydrogen_green_inventory_end
        battery_factor = _factor(battery_carbon_end, battery_energy_end)
        hydrogen_factor = _factor(hydrogen_carbon_end, hydrogen_energy_end)

    daily = pd.DataFrame.from_records(day_records)
    maximum_energy_carry_residual = _maximum_adjacent_carry_residual(
        daily,
        (
            ("battery_energy_open_kwh", "battery_energy_close_kwh"),
            ("hydrogen_energy_open_kwh", "hydrogen_energy_close_kwh"),
        ),
    )
    maximum_carbon_carry_residual = _maximum_adjacent_carry_residual(
        daily,
        (
            ("battery_carbon_open_kg", "battery_carbon_close_kg"),
            ("hydrogen_carbon_open_kg", "hydrogen_carbon_close_kg"),
        ),
    )
    maximum_green_inventory_carry_residual = _maximum_adjacent_carry_residual(
        daily,
        (
            (
                "battery_green_inventory_open_kwh",
                "battery_green_inventory_close_kwh",
            ),
            (
                "hydrogen_green_inventory_open_kwh",
                "hydrogen_green_inventory_close_kwh",
            ),
        ),
    )
    proxy_total = float(daily["actual_load_carbon_proxy_kg"].sum())
    ac_total = float(daily["actual_ac_load_allocated_emissions_kg"].sum())
    open_loop_proxy_total = float(
        daily["open_loop_actual_load_carbon_proxy_kg"].sum()
    )
    open_loop_ac_total = float(
        daily["open_loop_actual_ac_load_allocated_emissions_kg"].sum()
    )
    deviation = abs(proxy_total - ac_total) / max(abs(ac_total), 1e-12)
    open_loop_deviation = abs(open_loop_proxy_total - open_loop_ac_total) / max(
        abs(open_loop_ac_total), 1e-12
    )
    warning = deviation > carbon_warning_fraction
    green_generation_total = float(daily["green_generation_kwh"].sum())
    direct_green_total = float(daily["direct_green_consumed_kwh"].sum())
    mediated_green_total = float(daily["mediated_green_consumed_kwh"].sum())
    opening_green_total = (
        initial_battery_green_inventory + initial_hydrogen_green_inventory
    )
    cumulative_green_self_use_rate = (
        (direct_green_total + mediated_green_total)
        / (opening_green_total + green_generation_total)
        if opening_green_total + green_generation_total > 0.0
        else 0.0
    )
    state_carry = {
        "initial_battery_energy_kwh": initial_battery_energy,
        "final_battery_energy_kwh": battery_energy,
        "initial_hydrogen_energy_kwh": initial_hydrogen_energy,
        "final_hydrogen_energy_kwh": hydrogen_energy,
        "final_battery_carbon_factor_kg_per_kwh": battery_factor,
        "final_hydrogen_carbon_factor_kg_per_kwh": hydrogen_factor,
        "maximum_energy_carry_residual_kwh": maximum_energy_carry_residual,
        "maximum_carbon_carry_residual_kg": maximum_carbon_carry_residual,
        "initial_battery_green_inventory_kwh": initial_battery_green_inventory,
        "final_battery_green_inventory_kwh": battery_green_inventory,
        "initial_hydrogen_green_inventory_kwh": initial_hydrogen_green_inventory,
        "final_hydrogen_green_inventory_kwh": hydrogen_green_inventory,
        "initial_green_inventory_policy": (
            "zero because the pre-horizon renewable origin of stored energy is "
            "not evidenced; initial carbon-factor sensitivity does not imply a "
            "green label"
        ),
        "maximum_green_inventory_carry_residual_kwh": (
            maximum_green_inventory_carry_residual
        ),
        "maximum_daily_green_inventory_balance_residual_kwh": (
            maximum_daily_green_inventory_balance_residual
        ),
        "energy_carried_across_days": True,
        "carbon_inventory_carried_across_days": True,
        "green_inventory_carried_across_days": True,
    }
    actual_ac_pcc = _boolean_series(daily, "actual_pcc_limit_feasible")
    actual_lossless_pcc = _boolean_series(daily, "actual_lossless_pcc_feasible")
    open_loop_ac_pcc = _boolean_series(daily, "open_loop_actual_pcc_limit_feasible")
    open_loop_lossless_pcc = _boolean_series(
        daily, "open_loop_actual_lossless_pcc_feasible"
    )
    feasibility = {
        "all_plan_network_feasible": bool(
            _boolean_series(daily, "plan_network_feasible").all()
        ),
        "all_actual_device_state_feasible": bool(
            _boolean_series(daily, "actual_device_state_feasible").all()
        ),
        "all_actual_network_feasible": bool(
            _boolean_series(daily, "actual_network_feasible").all()
        ),
        "all_actual_physical_network_feasible": bool(
            _boolean_series(daily, "actual_physical_network_feasible").all()
        ),
        "all_actual_lossless_pcc_feasible": bool(actual_lossless_pcc.all()),
        "all_actual_pcc_feasible": bool(actual_ac_pcc.all()),
        "all_actual_ac_loss_adjusted_pcc_feasible": bool(actual_ac_pcc.all()),
        "actual_pcc_violation_dates": daily.loc[
            ~actual_ac_pcc, "local_date"
        ].tolist(),
        "actual_ac_loss_adjusted_pcc_violation_dates": daily.loc[
            ~actual_ac_pcc, "local_date"
        ].tolist(),
        "actual_lossless_pcc_violation_dates": daily.loc[
            ~actual_lossless_pcc, "local_date"
        ].tolist(),
        "all_open_loop_actual_lossless_pcc_feasible": bool(
            open_loop_lossless_pcc.all()
        ),
        "all_open_loop_actual_ac_loss_adjusted_pcc_feasible": bool(
            open_loop_ac_pcc.all()
        ),
        "open_loop_actual_lossless_pcc_violation_dates": daily.loc[
            ~open_loop_lossless_pcc, "local_date"
        ].tolist(),
        "open_loop_actual_ac_loss_adjusted_pcc_violation_dates": daily.loc[
            ~open_loop_ac_pcc, "local_date"
        ].tolist(),
        "minimum_voltage_pu": float(daily["actual_minimum_voltage_pu"].min()),
        "maximum_voltage_pu": float(daily["actual_maximum_voltage_pu"].max()),
        "maximum_actual_penalty": float(daily["actual_penalty"].max()),
        "maximum_proxy_carbon_residual_kg": float(
            daily["actual_proxy_carbon_residual_kg"].abs().max()
        ),
        "maximum_ac_carbon_residual_kg": float(
            daily["actual_ac_carbon_residual_kg"].abs().max()
        ),
        "pcc_interpretation": (
            "Lossless PCC feasibility is the dispatch-model constraint; AC "
            "loss-adjusted PCC feasibility is computed from slack power. Operational "
            "acceptance requires both."
        ),
        "ampacity_note": (
            "Canonical IEEE33 has no branch ratings; current remains diagnostic only."
        ),
    }
    acceptance = _build_acceptance(
        daily,
        maximum_energy_carry_residual_kwh=maximum_energy_carry_residual,
        maximum_carbon_carry_residual_kg=maximum_carbon_carry_residual,
        maximum_green_inventory_carry_residual_kwh=(
            maximum_green_inventory_carry_residual
        ),
        maximum_daily_green_inventory_balance_residual_kwh=(
            maximum_daily_green_inventory_balance_residual
        ),
        green_inventory_carry_implemented=True,
    )
    summary: dict[str, Any] = {
        "schema_version": (
            "qingheng.rolling-dispatch.v3"
            if pcc_policy.robust
            else "qingheng.rolling-dispatch.v2"
        ),
        "initial_carbon_factor_kg_per_kwh": initial_carbon_factor,
        "execution_days": len(day_records),
        "first_local_date": day_records[0]["local_date"],
        "last_local_date": day_records[-1]["local_date"],
        "lookahead_hours": LOOKAHEAD_HOURS,
        "execution_hours": EXECUTION_HOURS,
        "optimizer": "pso",
        "population": population,
        "iterations": iterations,
        "base_seeds": list(base_seeds),
        "optimizer_realizations_per_day": len(base_seeds),
        "forecast_policy": {
            "first_24_hours": "validation-frozen operational forecast",
            "next_24_hours": "causal seven-day seasonal persistence",
            "future_actual_inputs_used": False,
        },
        "pcc_control_policy": {
            **asdict(pcc_policy),
            "reserve_history": (
                "Expanding hourly history through the end of the previous executed "
                "local day only. Net-load forecast error and realized AC-minus-lossless "
                "PCC deltas from the current/future day are unavailable to planning."
            ),
            "quantile_method": "numpy linear empirical quantile",
            "planning_limit_rule": (
                "Import limit = physical rating - directional forecast-error reserve "
                "- AC-loss reserve; export limit = physical rating - directional "
                "forecast-error reserve."
            ),
            "execution_information_set": (
                "At hour t, the projection uses the day-ahead planned action, realized "
                "load/PV/wind/fixed generation for hour t, and carried state at the "
                "start of hour t. Later actual hours are not inspected."
            ),
            "execution_projection": (
                "Minimum interpolation along a deterministic corrective path, found by "
                "causal AC power-flow screening and bisection."
            ),
            "loss_adjusted_pcc_hard_failure": pcc_policy.robust,
            "physical_ac_pcc_tolerance_kw": PCC_LIMIT_TOLERANCE_KW,
            "lossless_dispatch_pcc_numerical_tolerance_kw": (
                LOSSLESS_PCC_NUMERICAL_TOLERANCE_KW
            ),
            "legacy_open_loop_preserved": True,
            "open_loop_counterfactual_scope": (
                "Each day's pre-projection action is replayed from the corrected "
                "trajectory's opening state. Daily values may be summed as exposure "
                "along that realized state path, but they are not an independent "
                "cross-day open-loop state trajectory."
            ),
        },
        "state_carry": state_carry,
        "open_loop_actual_totals": {
            "interpretation": (
                "Sum of daily pre-projection counterfactuals conditioned on corrected "
                "opening states; not a standalone rolling trajectory."
            ),
            "cost": float(daily["open_loop_actual_cost"].sum()),
            "load_carbon_proxy_kg": open_loop_proxy_total,
            "external_source_emissions_kg": float(
                daily["open_loop_actual_external_source_emissions_kg"].sum()
            ),
            "ac_load_allocated_emissions_kg": open_loop_ac_total,
            "ac_external_source_emissions_kg": float(
                daily["open_loop_actual_ac_external_source_emissions_kg"].sum()
            ),
            "pcc_import_kwh": float(
                daily["open_loop_actual_pcc_import_kwh"].sum()
            ),
            "pcc_export_kwh": float(
                daily["open_loop_actual_pcc_export_kwh"].sum()
            ),
            "active_loss_energy_kwh": float(
                daily["open_loop_actual_active_loss_energy_kwh"].sum()
            ),
        },
        "actual_totals": {
            "cost": float(daily["actual_cost"].sum()),
            "load_carbon_proxy_kg": proxy_total,
            "external_source_emissions_kg": float(
                daily["actual_external_source_emissions_kg"].sum()
            ),
            "ac_load_allocated_emissions_kg": ac_total,
            "ac_external_source_emissions_kg": float(
                daily["actual_ac_external_source_emissions_kg"].sum()
            ),
            "pcc_import_kwh": float(daily["actual_pcc_import_kwh"].sum()),
            "pcc_export_kwh": float(daily["actual_pcc_export_kwh"].sum()),
            "battery_throughput_kwh": float(daily["battery_throughput_kwh"].sum()),
            "hydrogen_throughput_kwh": float(daily["hydrogen_throughput_kwh"].sum()),
            "active_loss_energy_kwh": float(daily["actual_active_loss_energy_kwh"].sum()),
            "pcc_projection_hours": int(daily["pcc_projection_hours"].sum()),
            "state_clip_hours": int(daily["state_clip_hours"].sum()),
            "execution_correction_l1_kw_total": float(
                daily["execution_correction_l1_kw_total"].sum()
            ),
            "maximum_hourly_execution_correction_l1_kw": float(
                daily["maximum_hourly_execution_correction_l1_kw"].max()
            ),
            "green_generation_kwh": green_generation_total,
            "direct_green_consumed_kwh": direct_green_total,
            "mediated_green_consumed_kwh": mediated_green_total,
            "opening_green_inventory_kwh": opening_green_total,
            "closing_green_inventory_kwh": float(
                battery_green_inventory + hydrogen_green_inventory
            ),
            "cumulative_green_self_use_rate": cumulative_green_self_use_rate,
        },
        "feasibility": feasibility,
        "acceptance": acceptance,
        "method_scope": _method_scope(base_seeds),
        "optimizer_selection": {
            "selection_information_set": "forecast conditions only",
            "selection_rule": (
                "Minimum forecast objective among realizations passing dispatch, "
                "48-hour cyclic energy, carbon conservation, and physical AC/PCC checks."
            ),
            "realizations_per_day": len(base_seeds),
            "total_realizations": int(
                daily["optimizer_realizations"].sum()
            ),
            "total_eligible_realizations": int(
                daily["eligible_optimizer_realizations"].sum()
            ),
            "maximum_daily_forecast_score_spread": float(
                daily["eligible_plan_score_spread"].max()
            ),
            "total_runtime_seconds": float(daily["runtime_seconds"].sum()),
        },
        "carbon_proxy_comparison": {
            "relative_deviation_fraction": deviation,
            "open_loop_relative_deviation_fraction": open_loop_deviation,
            "warning_threshold_fraction": carbon_warning_fraction,
            "warning": warning,
            "message": (
                "Copper-plate cumulative load-carbon proxy differs from AC nodal allocation "
                f"by {deviation:.2%}."
            ),
        },
    }
    _write_case_outputs(output, schedule_records, day_records, seed_records, summary)
    return summary


def run_rolling_dispatch_sensitivity(
    *,
    forecasts: pd.DataFrame,
    hybrid_profile: pd.DataFrame,
    base_dispatch: DispatchConfig,
    carbon_config: CarbonConfig,
    mpte_root: str | Path,
    output_dir: str | Path,
    initial_carbon_factors: Sequence[float] = (0.0, 0.041, 0.570),
    population: int = 60,
    iterations: int = 160,
    base_seed: int = 2029,
    base_seeds: Sequence[int] | None = None,
    max_days: int | None = None,
    carbon_warning_fraction: float = 0.05,
    pcc_policy: RollingPCCPolicy | None = None,
    provenance: Mapping[str, Any] | None = None,
    sizing_manifest: Mapping[str, Any] | None = None,
) -> RollingSensitivityResult:
    """Run 48/24 rolling dispatch with explicit legacy-v1 or robust-v2 PCC control."""

    if any(isinstance(value, bool) for value in initial_carbon_factors):
        raise ValueError("initial_carbon_factors must be finite and non-negative")
    factors = tuple(float(value) for value in initial_carbon_factors)
    if not factors or any(not math.isfinite(value) or value < 0.0 for value in factors):
        raise ValueError("initial_carbon_factors must be finite and non-negative")
    if len(set(factors)) != len(factors):
        raise ValueError("initial_carbon_factors must be unique")
    labels = tuple(_case_label(value) for value in factors)
    if len(set(labels)) != len(labels):
        raise ValueError("initial_carbon_factors collide after case-label rounding")
    if (
        isinstance(population, bool)
        or not isinstance(population, Integral)
        or isinstance(iterations, bool)
        or not isinstance(iterations, Integral)
        or population < 4
        or iterations < 1
    ):
        raise ValueError("population must be >=4 and iterations must be positive")
    if (
        isinstance(base_seed, bool)
        or not isinstance(base_seed, Integral)
        or base_seed < 0
    ):
        raise ValueError("base_seed must be a non-negative integer")
    if base_seeds is None:
        seeds = (int(base_seed),)
    else:
        try:
            seeds = tuple(base_seeds)
        except TypeError as exc:
            raise ValueError(
                "base_seeds must be a non-empty sequence of integers"
            ) from exc
        if not seeds or any(
            isinstance(seed, bool)
            or not isinstance(seed, Integral)
            or seed < 0
            for seed in seeds
        ):
            raise ValueError(
                "base_seeds must be a non-empty sequence of non-negative integers"
            )
        seeds = tuple(int(seed) for seed in seeds)
        if len(set(seeds)) != len(seeds):
            raise ValueError("base_seeds must be unique")
    if max_days is not None and (
        isinstance(max_days, bool)
        or not isinstance(max_days, Integral)
        or max_days < 1
    ):
        raise ValueError("max_days must be a positive integer when provided")
    if (
        isinstance(carbon_warning_fraction, bool)
        or not isinstance(carbon_warning_fraction, Real)
        or not math.isfinite(carbon_warning_fraction)
        or carbon_warning_fraction < 0.0
    ):
        raise ValueError("carbon_warning_fraction must be finite and non-negative")
    policy = RollingPCCPolicy() if pcc_policy is None else pcc_policy
    if not isinstance(policy, RollingPCCPolicy):
        raise TypeError("pcc_policy must be a RollingPCCPolicy")
    source_provenance = dict(provenance or {})
    if sizing_manifest is not None and not isinstance(sizing_manifest, Mapping):
        raise TypeError("sizing_manifest must be a mapping when provided")
    expected_sizing_sha = source_provenance.get("sizing_sha256")
    if expected_sizing_sha is not None:
        if sizing_manifest is None:
            raise ValueError(
                "sizing_manifest is required when provenance declares sizing_sha256"
            )
        if sizing_manifest.get("sizing_sha256") != expected_sizing_sha:
            raise ValueError("sizing manifest and provenance hashes differ")
    elif sizing_manifest is not None:
        raise ValueError(
            "provenance sizing_sha256 is required when sizing_manifest is provided"
        )
    sizing_document = dict(sizing_manifest) if sizing_manifest is not None else None

    dates = rolling_execution_dates(forecasts)
    if max_days is not None:
        dates = dates[:max_days]
    all_daily_seeds = [
        seed
        for day_index in range(len(dates))
        for seed in rolling_day_seeds(seeds, day_index)
    ]
    if len(set(all_daily_seeds)) != len(all_daily_seeds):
        raise ValueError(
            "base_seeds must be spaced by at least the execution-day count so "
            "optimizer random streams do not repeat across days"
        )
    output = Path(output_dir).resolve()
    if output.exists():
        if not output.is_dir():
            raise RollingDispatchError(f"rolling output path is not a directory: {output}")
        if next(output.iterdir(), None) is not None:
            raise RollingDispatchError(
                f"rolling output directory is not empty: {output}; use a fresh directory"
            )
    output.mkdir(parents=True, exist_ok=True)
    if sizing_document is not None:
        (output / "sizing_manifest.json").write_text(
            json.dumps(sizing_document, indent=2, ensure_ascii=True),
            encoding="utf-8",
        )
    network = IEEE33ScheduleValidator(mpte_root)
    cases: list[Path] = []
    rows: list[dict[str, Any]] = []
    documents: list[dict[str, Any]] = []
    for initial_factor in factors:
        case_output = output / _case_label(initial_factor)
        summary = _run_factor_case(
            forecasts=forecasts,
            hybrid_profile=hybrid_profile,
            execution_dates=dates,
            base_dispatch=base_dispatch,
            carbon_config=carbon_config,
            network=network,
            output=case_output,
            initial_carbon_factor=initial_factor,
            population=population,
            iterations=iterations,
            base_seeds=seeds,
            carbon_warning_fraction=carbon_warning_fraction,
            pcc_policy=policy,
        )
        cases.append(case_output)
        documents.append(summary)
        totals = summary["actual_totals"]
        open_loop_totals = summary["open_loop_actual_totals"]
        feasibility = summary["feasibility"]
        comparison = summary["carbon_proxy_comparison"]
        state = summary["state_carry"]
        rows.append(
            {
                "initial_carbon_factor_kg_per_kwh": initial_factor,
                "execution_days": summary["execution_days"],
                "pcc_policy": policy.strategy,
                "open_loop_actual_cost": open_loop_totals["cost"],
                "open_loop_actual_load_carbon_proxy_kg": open_loop_totals[
                    "load_carbon_proxy_kg"
                ],
                "open_loop_actual_ac_load_allocated_emissions_kg": open_loop_totals[
                    "ac_load_allocated_emissions_kg"
                ],
                "open_loop_all_actual_lossless_pcc_feasible": feasibility[
                    "all_open_loop_actual_lossless_pcc_feasible"
                ],
                "open_loop_all_actual_ac_loss_adjusted_pcc_feasible": feasibility[
                    "all_open_loop_actual_ac_loss_adjusted_pcc_feasible"
                ],
                "actual_cost": totals["cost"],
                "actual_load_carbon_proxy_kg": totals["load_carbon_proxy_kg"],
                "actual_external_source_emissions_kg": totals[
                    "external_source_emissions_kg"
                ],
                "actual_ac_load_allocated_emissions_kg": totals[
                    "ac_load_allocated_emissions_kg"
                ],
                "actual_ac_external_source_emissions_kg": totals[
                    "ac_external_source_emissions_kg"
                ],
                "pcc_import_kwh": totals["pcc_import_kwh"],
                "pcc_export_kwh": totals["pcc_export_kwh"],
                "battery_throughput_kwh": totals["battery_throughput_kwh"],
                "hydrogen_throughput_kwh": totals["hydrogen_throughput_kwh"],
                "pcc_projection_hours": totals["pcc_projection_hours"],
                "execution_correction_l1_kw_total": totals[
                    "execution_correction_l1_kw_total"
                ],
                "minimum_voltage_pu": feasibility["minimum_voltage_pu"],
                "maximum_voltage_pu": feasibility["maximum_voltage_pu"],
                "all_actual_network_feasible": feasibility["all_actual_network_feasible"],
                "all_actual_pcc_feasible": feasibility["all_actual_pcc_feasible"],
                "all_actual_lossless_pcc_feasible": feasibility[
                    "all_actual_lossless_pcc_feasible"
                ],
                "operational_acceptance_passed": summary["acceptance"]["passed"],
                "acceptance_status": summary["acceptance"]["status"],
                "maximum_energy_carry_residual_kwh": state[
                    "maximum_energy_carry_residual_kwh"
                ],
                "maximum_carbon_carry_residual_kg": state[
                    "maximum_carbon_carry_residual_kg"
                ],
                "maximum_green_inventory_carry_residual_kwh": state[
                    "maximum_green_inventory_carry_residual_kwh"
                ],
                "maximum_daily_green_inventory_balance_residual_kwh": state[
                    "maximum_daily_green_inventory_balance_residual_kwh"
                ],
                "green_generation_kwh": totals["green_generation_kwh"],
                "direct_green_consumed_kwh": totals[
                    "direct_green_consumed_kwh"
                ],
                "mediated_green_consumed_kwh": totals[
                    "mediated_green_consumed_kwh"
                ],
                "closing_green_inventory_kwh": totals[
                    "closing_green_inventory_kwh"
                ],
                "cumulative_green_self_use_rate": totals[
                    "cumulative_green_self_use_rate"
                ],
                "carbon_proxy_relative_deviation_fraction": comparison[
                    "relative_deviation_fraction"
                ],
                "carbon_proxy_warning": comparison["warning"],
                "optimizer_realizations_per_day": len(seeds),
                "multi_seed_validation": len(seeds) >= 3,
                "optimizer_restart_spread_reported": len(seeds) >= 3,
                "ranking_uncertainty_quantified": False,
                "comparative_ranking_conclusion_permitted": False,
            }
        )

    comparison_csv = output / "rolling_carbon_sensitivity.csv"
    comparison_json = output / "rolling_carbon_sensitivity.json"
    provenance_path = output / "rolling_provenance.json"
    pd.DataFrame.from_records(rows).to_csv(comparison_csv, index=False)
    all_cases_passed = all(document["acceptance"]["passed"] for document in documents)
    failed_factors = [
        document["initial_carbon_factor_kg_per_kwh"]
        for document in documents
        if not document["acceptance"]["passed"]
    ]
    comparison_json.write_text(
        json.dumps(
            {
                "schema_version": (
                    "qingheng.rolling-carbon-sensitivity.v3"
                    if policy.robust
                    else "qingheng.rolling-carbon-sensitivity.v2"
                ),
                "pcc_control_policy": asdict(policy),
                "acceptance": {
                    "status": "passed" if all_cases_passed else "failed",
                    "passed": all_cases_passed,
                    "failed_initial_carbon_factors_kg_per_kwh": failed_factors,
                    "all_cases_carbon_proxy_within_warning_threshold": all(
                        not document["carbon_proxy_comparison"]["warning"]
                        for document in documents
                    ),
                    "optimizer_realizations_per_day": len(seeds),
                    "multi_seed_validation": len(seeds) >= 3,
                    "optimizer_restart_spread_reported": len(seeds) >= 3,
                    "ranking_uncertainty_quantified": False,
                    "comparative_ranking_conclusion_permitted": False,
                    "message": (
                        "Daily common-random-number restarts support optimizer selection "
                        "and expose restart spread. They do not create independent full "
                        "rolling trajectories, so final ranking uncertainty remains "
                        "unquantified and no comparative ranking claim is authorized."
                    ),
                },
                "cases": documents,
            },
            indent=2,
            ensure_ascii=True,
        ),
        encoding="utf-8",
    )
    provenance_document = {
        "schema_version": (
            "qingheng.rolling-provenance.v3"
            if policy.robust
            else "qingheng.rolling-provenance.v2"
        ),
        "base_dispatch": asdict(base_dispatch),
        "carbon_config": asdict(carbon_config),
        "network": _network_provenance(network),
        "implementation": _implementation_provenance(),
        "rolling_configuration": {
            "lookahead_hours": LOOKAHEAD_HOURS,
            "execution_hours": EXECUTION_HOURS,
            "population": population,
            "iterations": iterations,
            "base_seed_legacy_fallback": int(base_seed),
            "base_seeds": list(seeds),
            "optimizer_realizations_per_day": len(seeds),
            "common_random_numbers_across_initial_carbon_factor_cases": True,
            "initial_carbon_factors_kg_per_kwh": list(factors),
            "max_days": max_days,
            "selected_execution_dates": list(dates),
            "optimizer": "pso",
            "pcc_control_policy": {
                **asdict(policy),
                "planning_reserve_causality": (
                    "Only expanding forecast-error and AC-loss observations from "
                    "previously completed execution days are eligible."
                ),
                "execution_projection_causality": (
                    "Only the current realized hour and its opening carried state are "
                    "eligible; no future actual hour is used."
                ),
                "open_loop_counterfactual_retained": True,
                "loss_adjusted_pcc_hard_failure": policy.robust,
                "physical_ac_pcc_tolerance_kw": PCC_LIMIT_TOLERANCE_KW,
                "lossless_dispatch_pcc_numerical_tolerance_kw": (
                    LOSSLESS_PCC_NUMERICAL_TOLERANCE_KW
                ),
            },
            "optimizer_basis": (
                "PSO had the best mean and best solution in the formal single-day benchmark; "
                "the improved WOA claim remains limited to comparison with standard WOA."
            ),
            "method_scope": _method_scope(seeds),
        },
        "source": source_provenance,
    }
    canonical = json.dumps(provenance_document, sort_keys=True, separators=(",", ":"))
    provenance_document["rolling_scenario_sha256"] = sha256(canonical.encode()).hexdigest()
    provenance_path.write_text(
        json.dumps(provenance_document, indent=2, ensure_ascii=True), encoding="utf-8"
    )
    artifact_manifest_path = write_rolling_artifact_manifest(output)
    return RollingSensitivityResult(
        comparison_csv=comparison_csv,
        comparison_json=comparison_json,
        provenance_path=provenance_path,
        artifact_manifest_path=artifact_manifest_path,
        cases=tuple(cases),
    )
