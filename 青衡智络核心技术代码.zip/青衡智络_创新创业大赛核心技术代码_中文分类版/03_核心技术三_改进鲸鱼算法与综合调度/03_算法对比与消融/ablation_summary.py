from __future__ import annotations

import json
import math
from collections.abc import Mapping
from hashlib import sha256
from pathlib import Path
from typing import Any

import pandas as pd


ABLATION_ARTIFACT_MANIFEST_FILENAME = "ablation_artifact_manifest.json"
EXPECTED_ABLATION_CASES = (
    "full",
    "battery_only",
    "hydrogen_only",
    "no_storage",
)
CORE_FILES = (
    "best_dispatch_metrics.json",
    "best_dispatch_schedule.csv",
    "carbon_metrics.json",
    "powerflow_summary.json",
    "scenario_provenance.json",
    "sizing_manifest.json",
    "optimizer_summary.csv",
)
REPLAY_FILES = (
    "actual_replay_metrics.json",
    "actual_replay_schedule.csv",
    "actual_replay_carbon_metrics.json",
    "actual_replay_powerflow_summary.json",
)
FORMAL_CASE_FILES = (
    "actual_replay.png",
    "actual_replay_carbon_metrics.json",
    "actual_replay_carbon_trace_timeseries.csv",
    "actual_replay_metrics.json",
    "actual_replay_powerflow_summary.json",
    "actual_replay_powerflow_validation.csv",
    "actual_replay_schedule.csv",
    "best_dispatch.png",
    "best_dispatch_metrics.json",
    "best_dispatch_schedule.csv",
    "carbon_metrics.json",
    "carbon_trace_timeseries.csv",
    "network_candidate_audit.csv",
    "optimizer_comparison.png",
    "optimizer_runs.csv",
    "optimizer_summary.csv",
    "powerflow_summary.json",
    "powerflow_validation.csv",
    "scenario_provenance.json",
    "sizing_manifest.json",
)
CONVERGENCE_CASE_FILES = (
    "optimizer_algorithm_comparison.pdf",
    "optimizer_algorithm_comparison.png",
    "optimizer_artifact_manifest.json",
    "optimizer_convergence.csv",
    "optimizer_protocol.json",
)
FORMAL_CASE_FILE_SETS = {
    "legacy-v1": FORMAL_CASE_FILES,
    "convergence-v2": FORMAL_CASE_FILES + CONVERGENCE_CASE_FILES,
}
FORMAL_ROOT_FILES = (
    "ablation_comparison.csv",
    "ablation_comparison.json",
)
SCHEDULE_COLUMNS = (
    "grid_power_kw",
    "battery_power_kw",
    "hydrogen_power_kw",
    "battery_energy_kwh_end",
    "hydrogen_energy_kwh_end",
)
REPLAY_EVALUATION_FIELDS = (
    "score",
    "cost",
    "feasible",
    "load_allocated_emissions_proxy_kg",
    "external_source_emissions_kg",
    "curtailment_kwh",
    "carbon_balance_residual_proxy_kg",
    "network_feasible",
    "powerflow_all_converged",
    "voltage_feasible",
    "current_feasible",
    "pcc_limit_feasible",
    "minimum_voltage_pu",
    "maximum_voltage_pu",
    "maximum_pcc_import_kw",
    "maximum_pcc_export_kw",
    "active_loss_energy_kwh",
    "loss_adjusted_cost",
    "loss_adjusted_source_emissions_kg",
    "grid_import_kwh",
    "grid_export_kwh",
    "battery_absolute_throughput_kwh",
    "hydrogen_absolute_throughput_kwh",
    "battery_terminal_error_kwh",
    "hydrogen_terminal_error_kwh",
    "ac_load_allocated_emissions_kg",
    "ac_external_source_emissions_kg",
    "ac_carbon_balance_residual_kg",
    "carbon_proxy_relative_deviation_fraction",
)


class AblationSummaryError(ValueError):
    """Raised when a dispatch case cannot be compared without ambiguity."""


def _read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise AblationSummaryError(f"cannot read valid JSON from {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise AblationSummaryError(f"expected a JSON object in {path}")
    return value


def _file_sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _require(mapping: Mapping[str, Any], key: str, source: Path) -> Any:
    if key not in mapping:
        raise AblationSummaryError(f"missing required field '{key}' in {source}")
    value = mapping[key]
    if value is None:
        raise AblationSummaryError(f"required field '{key}' is null in {source}")
    return value


def _number(mapping: Mapping[str, Any], key: str, source: Path) -> float:
    value = _require(mapping, key, source)
    if isinstance(value, bool):
        raise AblationSummaryError(f"field '{key}' in {source} must be numeric")
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise AblationSummaryError(f"field '{key}' in {source} must be numeric") from exc
    if not math.isfinite(result):
        raise AblationSummaryError(f"field '{key}' in {source} must be finite")
    return result


def _boolean(mapping: Mapping[str, Any], key: str, source: Path) -> bool:
    value = _require(mapping, key, source)
    if isinstance(value, bool):
        return value
    raise AblationSummaryError(f"field '{key}' in {source} must be boolean")


def _optional_boolean(mapping: Mapping[str, Any], key: str, source: Path) -> bool | None:
    value = (
        _require(mapping, key, source) if key not in mapping or mapping[key] is not None else None
    )
    if value is None or isinstance(value, bool):
        return value
    raise AblationSummaryError(f"field '{key}' in {source} must be boolean or null")


def _nested_mapping(mapping: Mapping[str, Any], key: str, source: Path) -> Mapping[str, Any]:
    value = _require(mapping, key, source)
    if not isinstance(value, Mapping):
        raise AblationSummaryError(f"field '{key}' in {source} must be an object")
    return value


def _read_schedule(path: Path) -> pd.DataFrame:
    try:
        frame = pd.read_csv(path)
    except (OSError, pd.errors.ParserError) as exc:
        raise AblationSummaryError(f"cannot read schedule CSV {path}: {exc}") from exc
    if frame.empty:
        raise AblationSummaryError(f"schedule CSV is empty: {path}")
    missing = [column for column in SCHEDULE_COLUMNS if column not in frame.columns]
    if missing:
        raise AblationSummaryError(f"missing required columns {missing} in {path}")
    for column in SCHEDULE_COLUMNS:
        values = pd.to_numeric(frame[column], errors="coerce")
        if values.isna().any() or not values.map(math.isfinite).all():
            raise AblationSummaryError(f"column '{column}' in {path} must be finite numeric data")
        frame[column] = values
    return frame


def _relative_deviation(proxy: float, reference: float) -> float:
    denominator = max(abs(reference), 1e-12)
    return abs(proxy - reference) / denominator


def _unavailable_replay_values(reason: str) -> dict[str, Any]:
    values = {f"actual_replay_{field}": None for field in REPLAY_EVALUATION_FIELDS}
    values.update(
        {
            "actual_replay_available": False,
            "actual_replay_unavailable_reason": reason,
            "actual_replay_carbon_available": False,
            "actual_replay_carbon_unavailable_reason": reason,
            "actual_replay_carbon_proxy_warning": False,
        }
    )
    return values


def _absolute_metric_values(
    rows: list[dict[str, Any]],
    columns: tuple[str, ...],
) -> tuple[list[float], bool]:
    values: list[float] = []
    complete = True
    for row in rows:
        for column in columns:
            value = row.get(column)
            if value is None:
                complete = False
                continue
            values.append(abs(float(value)))
    return values, complete


def _schedule_metrics(
    schedule: pd.DataFrame,
    dispatch_config: Mapping[str, Any],
    config_source: Path,
) -> dict[str, float]:
    step_hours = _number(dispatch_config, "step_hours", config_source)
    if step_hours <= 0.0:
        raise AblationSummaryError(f"field 'step_hours' in {config_source} must be positive")

    battery_capacity = _number(dispatch_config, "battery_capacity_kwh", config_source)
    battery_initial_soc = _number(dispatch_config, "battery_initial_soc", config_source)
    hydrogen_capacity = _number(dispatch_config, "hydrogen_capacity_kwh", config_source)
    hydrogen_initial_soc = _number(dispatch_config, "hydrogen_initial_soc", config_source)
    grid = schedule["grid_power_kw"]
    battery = schedule["battery_power_kw"]
    hydrogen = schedule["hydrogen_power_kw"]
    return {
        "grid_import_kwh": float(grid.clip(lower=0.0).sum() * step_hours),
        "grid_export_kwh": float((-grid.clip(upper=0.0)).sum() * step_hours),
        "battery_absolute_throughput_kwh": float(battery.abs().sum() * step_hours),
        "hydrogen_absolute_throughput_kwh": float(hydrogen.abs().sum() * step_hours),
        "battery_terminal_error_kwh": abs(
            float(schedule["battery_energy_kwh_end"].iloc[-1])
            - battery_capacity * battery_initial_soc
        ),
        "hydrogen_terminal_error_kwh": abs(
            float(schedule["hydrogen_energy_kwh_end"].iloc[-1])
            - hydrogen_capacity * hydrogen_initial_soc
        ),
    }


def _carbon_payload(
    document: Mapping[str, Any],
    source: Path,
    *,
    allow_unavailable: bool,
) -> tuple[bool, str | None, Mapping[str, Any]]:
    available = document.get("available", True)
    if not isinstance(available, bool):
        raise AblationSummaryError(f"field 'available' in {source} must be boolean")
    if not available:
        if not allow_unavailable:
            raise AblationSummaryError(
                f"carbon accounting is unavailable in required file {source}"
            )
        reason = document.get("reason")
        if not isinstance(reason, str) or not reason.strip():
            raise AblationSummaryError(
                f"unavailable carbon accounting must include a non-empty 'reason' in {source}"
            )
        return False, reason, {}
    payload = document.get("metrics", document)
    if not isinstance(payload, Mapping):
        raise AblationSummaryError(f"field 'metrics' in {source} must be an object")
    return True, None, payload


def _optimizer_records(path: Path) -> list[dict[str, Any]]:
    try:
        frame = pd.read_csv(path)
    except (OSError, pd.errors.ParserError) as exc:
        raise AblationSummaryError(f"cannot read optimizer summary CSV {path}: {exc}") from exc
    required = {"algorithm", "runs", "score_mean", "score_std"}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise AblationSummaryError(f"missing required columns {missing} in {path}")
    if frame.empty:
        raise AblationSummaryError(f"optimizer summary CSV is empty: {path}")
    records: list[dict[str, Any]] = []
    for raw in frame.to_dict(orient="records"):
        record: dict[str, Any] = {}
        for key, value in raw.items():
            if pd.isna(value):
                record[key] = None
            elif hasattr(value, "item"):
                record[key] = value.item()
            else:
                record[key] = value
        records.append(record)
    return records


def _extract_evaluation(
    metrics: Mapping[str, Any],
    metrics_source: Path,
    schedule: pd.DataFrame,
    dispatch_config: Mapping[str, Any],
    config_source: Path,
    carbon: Mapping[str, Any],
    carbon_source: Path,
    powerflow: Mapping[str, Any],
    powerflow_source: Path,
    *,
    prefix: str = "",
    carbon_available: bool = True,
    carbon_reason: str | None = None,
    warning_fraction: float,
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    values: dict[str, Any] = {
        f"{prefix}score": _number(metrics, "score", metrics_source),
        f"{prefix}cost": _number(metrics, "cost", metrics_source),
        f"{prefix}feasible": _boolean(metrics, "feasible", metrics_source),
        f"{prefix}load_allocated_emissions_proxy_kg": _number(
            metrics, "load_allocated_emissions_proxy_kg", metrics_source
        ),
        f"{prefix}external_source_emissions_kg": _number(
            metrics, "external_source_emissions_kg", metrics_source
        ),
        f"{prefix}curtailment_kwh": _number(metrics, "curtailment_kwh", metrics_source),
        f"{prefix}carbon_balance_residual_proxy_kg": _number(
            metrics, "carbon_balance_residual_proxy_kg", metrics_source
        ),
        f"{prefix}network_feasible": _boolean(powerflow, "feasible", powerflow_source),
        f"{prefix}powerflow_all_converged": _boolean(powerflow, "all_converged", powerflow_source),
        f"{prefix}voltage_feasible": _boolean(powerflow, "voltage_feasible", powerflow_source),
        f"{prefix}current_feasible": _optional_boolean(
            powerflow, "current_feasible", powerflow_source
        ),
        f"{prefix}pcc_limit_feasible": _boolean(powerflow, "pcc_limit_feasible", powerflow_source),
        f"{prefix}minimum_voltage_pu": _number(powerflow, "minimum_voltage_pu", powerflow_source),
        f"{prefix}maximum_voltage_pu": _number(powerflow, "maximum_voltage_pu", powerflow_source),
        f"{prefix}maximum_pcc_import_kw": _number(
            powerflow, "maximum_pcc_import_kw", powerflow_source
        ),
        f"{prefix}maximum_pcc_export_kw": _number(
            powerflow, "maximum_pcc_export_kw", powerflow_source
        ),
        f"{prefix}active_loss_energy_kwh": _number(
            powerflow, "active_loss_energy_kwh", powerflow_source
        ),
        f"{prefix}loss_adjusted_cost": _number(powerflow, "loss_adjusted_cost", powerflow_source),
        f"{prefix}loss_adjusted_source_emissions_kg": _number(
            powerflow, "loss_adjusted_source_emissions_kg", powerflow_source
        ),
        f"{prefix}carbon_available": carbon_available,
        f"{prefix}carbon_unavailable_reason": carbon_reason,
    }
    values.update(
        {
            f"{prefix}{key}": value
            for key, value in _schedule_metrics(schedule, dispatch_config, config_source).items()
        }
    )

    warning: dict[str, Any] | None = None
    if carbon_available:
        proxy = values[f"{prefix}load_allocated_emissions_proxy_kg"]
        ac_load = _number(carbon, "load_allocated_emissions_kg", carbon_source)
        deviation = _relative_deviation(proxy, ac_load)
        is_warning = deviation > warning_fraction
        values.update(
            {
                f"{prefix}ac_load_allocated_emissions_kg": ac_load,
                f"{prefix}ac_external_source_emissions_kg": _number(
                    carbon, "external_source_emissions_kg", carbon_source
                ),
                f"{prefix}ac_carbon_balance_residual_kg": _number(
                    carbon, "carbon_balance_residual_kg", carbon_source
                ),
                f"{prefix}carbon_proxy_relative_deviation_fraction": deviation,
                f"{prefix}carbon_proxy_warning": is_warning,
            }
        )
        if is_warning:
            warning = {
                "scope": "actual_replay" if prefix else "forecast_dispatch",
                "relative_deviation_fraction": deviation,
                "threshold_fraction": warning_fraction,
                "proxy_load_allocated_emissions_kg": proxy,
                "ac_load_allocated_emissions_kg": ac_load,
                "message": (
                    "Copper-plate load-carbon proxy differs from AC nodal load allocation "
                    f"by {deviation:.2%}, above the {warning_fraction:.2%} threshold."
                ),
            }
    else:
        values.update(
            {
                f"{prefix}ac_load_allocated_emissions_kg": None,
                f"{prefix}ac_external_source_emissions_kg": None,
                f"{prefix}ac_carbon_balance_residual_kg": None,
                f"{prefix}carbon_proxy_relative_deviation_fraction": None,
                f"{prefix}carbon_proxy_warning": False,
            }
        )
    return values, warning


def _validate_case_files(case: str, directory: Path) -> None:
    if not directory.is_dir():
        raise AblationSummaryError(f"case '{case}' directory does not exist: {directory}")
    missing = [filename for filename in CORE_FILES if not (directory / filename).is_file()]
    if missing:
        raise AblationSummaryError(
            f"case '{case}' is missing required files in {directory}: {missing}"
        )
    present_replay = [filename for filename in REPLAY_FILES if (directory / filename).is_file()]
    if present_replay and len(present_replay) != len(REPLAY_FILES):
        missing_replay = sorted(set(REPLAY_FILES).difference(present_replay))
        raise AblationSummaryError(
            f"case '{case}' has an incomplete actual replay; missing files: {missing_replay}"
        )


def summarize_dispatch_ablation(
    case_dirs: Mapping[str, Path],
    output_dir: Path,
    carbon_proxy_warning_fraction: float = 0.05,
) -> tuple[Path, Path]:
    """Validate and summarize four comparable dispatch ablation cases.

    The flat CSV is intended for paper tables. The JSON additionally retains each
    case's per-algorithm statistics and structured carbon-proxy warnings.
    """
    if len(case_dirs) != 4:
        raise AblationSummaryError(f"expected exactly four ablation cases, got {len(case_dirs)}")
    if not math.isfinite(carbon_proxy_warning_fraction) or carbon_proxy_warning_fraction < 0.0:
        raise AblationSummaryError("carbon_proxy_warning_fraction must be finite and non-negative")

    rows: list[dict[str, Any]] = []
    json_cases: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    sizing_hashes: dict[str, str] = {}

    for case, raw_directory in case_dirs.items():
        if not isinstance(case, str) or not case.strip():
            raise AblationSummaryError("case names must be non-empty strings")
        directory = Path(raw_directory)
        _validate_case_files(case, directory)

        metrics_path = directory / "best_dispatch_metrics.json"
        carbon_path = directory / "carbon_metrics.json"
        powerflow_path = directory / "powerflow_summary.json"
        provenance_path = directory / "scenario_provenance.json"
        sizing_path = directory / "sizing_manifest.json"
        metrics = _read_json(metrics_path)
        carbon_document = _read_json(carbon_path)
        carbon_available, carbon_reason, carbon = _carbon_payload(
            carbon_document, carbon_path, allow_unavailable=False
        )
        powerflow = _read_json(powerflow_path)
        provenance = _read_json(provenance_path)
        sizing = _read_json(sizing_path)

        sizing_hash = str(_require(sizing, "sizing_sha256", sizing_path))
        provenance_sizing_hash = str(_require(provenance, "sizing_sha256", provenance_path))
        if sizing_hash != provenance_sizing_hash:
            raise AblationSummaryError(
                f"case '{case}' sizing_sha256 differs between {sizing_path} and {provenance_path}"
            )
        applied_hash = str(_require(sizing, "applied_scenario_sha256", sizing_path))
        provenance_applied_hash = str(
            _require(provenance, "applied_scenario_sha256", provenance_path)
        )
        if applied_hash != provenance_applied_hash:
            raise AblationSummaryError(
                f"case '{case}' applied_scenario_sha256 differs between {sizing_path} "
                f"and {provenance_path}"
            )
        sizing_hashes[case] = sizing_hash

        post_sizing = _nested_mapping(sizing, "post_sizing_application", sizing_path)
        dispatch_config = _nested_mapping(post_sizing, "applied_dispatch", sizing_path)
        schedule = _read_schedule(directory / "best_dispatch_schedule.csv")
        row: dict[str, Any] = {
            "case": case,
            "sizing_sha256": sizing_hash,
            "applied_scenario_sha256": applied_hash,
            "selected_algorithm": _require(powerflow, "selected_algorithm", powerflow_path),
            "selected_seed": _require(powerflow, "selected_seed", powerflow_path),
        }
        evaluation, warning = _extract_evaluation(
            metrics,
            metrics_path,
            schedule,
            dispatch_config,
            sizing_path,
            carbon,
            carbon_path,
            powerflow,
            powerflow_path,
            carbon_available=carbon_available,
            carbon_reason=carbon_reason,
            warning_fraction=carbon_proxy_warning_fraction,
        )
        row.update(evaluation)
        if warning is not None:
            warning["case"] = case
            warnings.append(warning)

        optimizer_records = _optimizer_records(directory / "optimizer_summary.csv")
        replay_present = all((directory / filename).is_file() for filename in REPLAY_FILES)
        row.update(_unavailable_replay_values("Actual replay artifacts are absent for this case."))
        if replay_present:
            row["actual_replay_available"] = True
            row["actual_replay_unavailable_reason"] = None
            replay_metrics_path = directory / "actual_replay_metrics.json"
            replay_carbon_path = directory / "actual_replay_carbon_metrics.json"
            replay_powerflow_path = directory / "actual_replay_powerflow_summary.json"
            replay_metrics = _read_json(replay_metrics_path)
            replay_carbon_document = _read_json(replay_carbon_path)
            replay_carbon_available, replay_reason, replay_carbon = _carbon_payload(
                replay_carbon_document,
                replay_carbon_path,
                allow_unavailable=True,
            )
            replay_powerflow = _read_json(replay_powerflow_path)
            replay_schedule = _read_schedule(directory / "actual_replay_schedule.csv")
            replay_values, replay_warning = _extract_evaluation(
                replay_metrics,
                replay_metrics_path,
                replay_schedule,
                dispatch_config,
                sizing_path,
                replay_carbon,
                replay_carbon_path,
                replay_powerflow,
                replay_powerflow_path,
                prefix="actual_replay_",
                carbon_available=replay_carbon_available,
                carbon_reason=replay_reason,
                warning_fraction=carbon_proxy_warning_fraction,
            )
            row.update(replay_values)
            if replay_warning is not None:
                replay_warning["case"] = case
                warnings.append(replay_warning)

        rows.append(row)
        json_cases.append({"metrics": row, "optimizer_summary": optimizer_records})

    unique_sizing_hashes = set(sizing_hashes.values())
    if len(unique_sizing_hashes) != 1:
        detail = ", ".join(f"{case}={value}" for case, value in sizing_hashes.items())
        raise AblationSummaryError(f"ablation cases do not share one sizing_sha256: {detail}")
    applied_hashes = {str(row["applied_scenario_sha256"]) for row in rows}
    if len(applied_hashes) != len(rows):
        raise AblationSummaryError(
            "each ablation case must have a distinct applied_scenario_sha256"
        )

    forecast_ranking = [
        str(row["case"]) for row in sorted(rows, key=lambda value: float(value["score"]))
    ]
    all_replays_available = all(bool(row["actual_replay_available"]) for row in rows)
    actual_ranking = (
        [
            str(row["case"])
            for row in sorted(
                rows,
                key=lambda value: float(value["actual_replay_score"]),
            )
        ]
        if all_replays_available
        else None
    )
    ranking_consistent = actual_ranking == forecast_ranking
    algorithm_comparisons: dict[str, dict[str, bool | None]] = {}
    for case in json_cases:
        means = {
            str(record["algorithm"]): record.get("score_mean")
            for record in case["optimizer_summary"]
        }
        required_means = [means.get(name) for name in ("pso", "improved_woa", "standard_woa")]
        if any(value is None for value in required_means):
            comparison = {
                "improved_woa_better_than_standard_woa": None,
                "pso_better_than_improved_woa": None,
                "pso_best_of_three": None,
            }
        else:
            pso, improved, standard = (float(value) for value in required_means)
            comparison = {
                "improved_woa_better_than_standard_woa": improved < standard,
                "pso_better_than_improved_woa": pso < improved,
                "pso_best_of_three": pso < min(improved, standard),
            }
        algorithm_comparisons[str(case["metrics"]["case"])] = comparison

    terminal_columns = (
        "battery_terminal_error_kwh",
        "hydrogen_terminal_error_kwh",
        "actual_replay_battery_terminal_error_kwh",
        "actual_replay_hydrogen_terminal_error_kwh",
    )
    proxy_residual_columns = (
        "carbon_balance_residual_proxy_kg",
        "actual_replay_carbon_balance_residual_proxy_kg",
    )
    ac_residual_columns = (
        "ac_carbon_balance_residual_kg",
        "actual_replay_ac_carbon_balance_residual_kg",
    )
    terminal_values, terminal_results_complete = _absolute_metric_values(rows, terminal_columns)
    proxy_residual_values, proxy_results_complete = _absolute_metric_values(
        rows, proxy_residual_columns
    )
    ac_residual_values, ac_residual_results_complete = _absolute_metric_values(
        rows, ac_residual_columns
    )
    maximum_terminal_error = max(terminal_values, default=None)
    maximum_proxy_residual = max(proxy_residual_values, default=None)
    all_ac_carbon_available = all(
        bool(row.get("carbon_available")) and bool(row.get("actual_replay_carbon_available"))
        for row in rows
    )
    ac_results_complete = all_ac_carbon_available and ac_residual_results_complete
    maximum_ac_residual = max(ac_residual_values, default=None)
    acceptance = {
        "all_actual_replays_available": all_replays_available,
        "all_ac_carbon_results_available": all_ac_carbon_available,
        "distinct_applied_scenario_hashes": len(applied_hashes) == len(rows),
        "terminal_energy_results_complete": terminal_results_complete,
        "maximum_terminal_energy_error_kwh": maximum_terminal_error,
        "terminal_energy_threshold_kwh": 1e-8,
        "terminal_energy_passed": (
            terminal_results_complete
            and maximum_terminal_error is not None
            and maximum_terminal_error < 1e-8
        ),
        "copperplate_carbon_results_complete": proxy_results_complete,
        "maximum_copperplate_carbon_residual_kg": maximum_proxy_residual,
        "copperplate_carbon_threshold_kg": 1e-8,
        "copperplate_carbon_passed": (
            proxy_results_complete
            and maximum_proxy_residual is not None
            and maximum_proxy_residual < 1e-8
        ),
        "ac_carbon_results_complete": ac_results_complete,
        "maximum_ac_carbon_residual_kg": maximum_ac_residual,
        "ac_carbon_threshold_kg": 1e-6,
        "ac_carbon_passed": (
            ac_results_complete and maximum_ac_residual is not None and maximum_ac_residual < 1e-6
        ),
        "all_dispatch_feasible": all(bool(row["feasible"]) for row in rows),
        "all_actual_replay_dispatch_feasible": all(
            row.get("actual_replay_feasible") is True for row in rows
        ),
        "all_network_feasible": all(bool(row["network_feasible"]) for row in rows),
        "all_actual_replay_network_feasible": all(
            row.get("actual_replay_network_feasible") is True for row in rows
        ),
        "all_pcc_limits_feasible": all(bool(row["pcc_limit_feasible"]) for row in rows),
        "all_actual_replay_pcc_limits_feasible": all(
            row.get("actual_replay_pcc_limit_feasible") is True for row in rows
        ),
        "branch_ampacity_ratings_available": all(
            row["current_feasible"] is not None
            and row.get("actual_replay_current_feasible") is not None
            for row in rows
        ),
    }
    acceptance["passed"] = all(
        bool(acceptance[key])
        for key in (
            "all_actual_replays_available",
            "all_ac_carbon_results_available",
            "distinct_applied_scenario_hashes",
            "terminal_energy_passed",
            "copperplate_carbon_passed",
            "ac_carbon_passed",
            "all_dispatch_feasible",
            "all_actual_replay_dispatch_feasible",
            "all_network_feasible",
            "all_actual_replay_network_feasible",
            "all_pcc_limits_feasible",
            "all_actual_replay_pcc_limits_feasible",
        )
    )

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    csv_path = output / "ablation_comparison.csv"
    json_path = output / "ablation_comparison.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    document = {
        "schema_version": "qingheng.dispatch-ablation.v2",
        "sizing_sha256": next(iter(unique_sizing_hashes)),
        "carbon_proxy_warning_fraction": carbon_proxy_warning_fraction,
        "cases": json_cases,
        "warnings": warnings,
        "ranking": {
            "forecast_dispatch_by_score": forecast_ranking,
            "actual_replay_by_score": actual_ranking,
            "consistent": ranking_consistent,
            "selected_day_device_ranking_consistent": ranking_consistent,
            "selected_day_device_gain_conclusion_permitted": (
                ranking_consistent and acceptance["passed"]
            ),
            "device_gain_conclusion_permitted": (ranking_consistent and acceptance["passed"]),
            "conclusion_scope": "selected_natural_day_only",
            "general_device_gain_conclusion_permitted": False,
            "interpretation": (
                "Forecast and fixed-actual rankings agree. Device conclusions must still be "
                "limited to this selected natural day."
                if ranking_consistent and acceptance["passed"]
                else (
                    "Actual replay ranking is unavailable; do not make a device-gain conclusion."
                    if actual_ranking is None
                    else (
                        "Rankings agree, but at least one acceptance criterion failed; "
                        "do not make a device-gain conclusion."
                        if ranking_consistent
                        else "Rankings reverse; do not make a device-gain conclusion."
                    )
                )
            ),
        },
        "algorithm_comparison": algorithm_comparisons,
        "acceptance": acceptance,
    }
    json_path.write_text(json.dumps(document, indent=2, ensure_ascii=True), encoding="utf-8")
    return csv_path, json_path


def _formal_ablation_summary(output: Path) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    summary_path = output / "ablation_comparison.json"
    summary = _read_json(summary_path)
    if summary.get("schema_version") != "qingheng.dispatch-ablation.v2":
        raise AblationSummaryError("unsupported dispatch ablation summary schema")
    raw_cases = summary.get("cases")
    if not isinstance(raw_cases, list) or len(raw_cases) != len(EXPECTED_ABLATION_CASES):
        raise AblationSummaryError("formal ablation summary must contain exactly four cases")
    case_metrics: dict[str, dict[str, Any]] = {}
    for raw_case in raw_cases:
        if not isinstance(raw_case, Mapping):
            raise AblationSummaryError("formal ablation summary contains an invalid case")
        metrics = raw_case.get("metrics")
        if not isinstance(metrics, dict):
            raise AblationSummaryError("formal ablation summary case has no metrics object")
        name = metrics.get("case")
        if not isinstance(name, str) or name in case_metrics:
            raise AblationSummaryError("formal ablation summary has an invalid case name")
        case_metrics[name] = metrics
    if set(case_metrics) != set(EXPECTED_ABLATION_CASES):
        raise AblationSummaryError(
            "formal ablation summary must contain full, battery_only, hydrogen_only, and no_storage"
        )

    comparison_path = output / "ablation_comparison.csv"
    try:
        comparison = pd.read_csv(comparison_path)
    except (OSError, pd.errors.ParserError) as exc:
        raise AblationSummaryError(
            f"cannot read ablation comparison CSV {comparison_path}: {exc}"
        ) from exc
    if "case" not in comparison.columns or comparison["case"].tolist() != list(
        EXPECTED_ABLATION_CASES
    ):
        raise AblationSummaryError(
            "formal ablation comparison CSV must contain the four cases in canonical order"
        )

    sizing_sha = summary.get("sizing_sha256")
    if not isinstance(sizing_sha, str) or len(sizing_sha) != 64:
        raise AblationSummaryError("formal ablation summary has no valid sizing SHA-256")
    for name in EXPECTED_ABLATION_CASES:
        sizing_path = output / name / "sizing_manifest.json"
        sizing = _read_json(sizing_path)
        metrics = case_metrics[name]
        if sizing.get("sizing_sha256") != sizing_sha or metrics.get("sizing_sha256") != sizing_sha:
            raise AblationSummaryError(f"formal ablation sizing hash mismatch for case '{name}'")
        applied = sizing.get("applied_scenario_sha256")
        if not isinstance(applied, str) or len(applied) != 64:
            raise AblationSummaryError(
                f"formal ablation case '{name}' has no valid applied scenario SHA-256"
            )
        if metrics.get("applied_scenario_sha256") != applied:
            raise AblationSummaryError(
                f"formal ablation applied scenario hash mismatch for case '{name}'"
            )
    return summary, case_metrics


def _required_formal_ablation_paths(
    case_files: tuple[str, ...] = FORMAL_CASE_FILES,
) -> set[str]:
    required = set(FORMAL_ROOT_FILES)
    for case in EXPECTED_ABLATION_CASES:
        required.update(f"{case}/{filename}" for filename in case_files)
    return required


def _validate_formal_ablation_structure(
    output: Path,
    *,
    expected_case_file_set: str | None = None,
) -> tuple[set[str], str]:
    if not output.is_dir():
        raise AblationSummaryError(f"formal ablation result directory does not exist: {output}")
    direct_directories = {path.name for path in output.iterdir() if path.is_dir()}
    if direct_directories != set(EXPECTED_ABLATION_CASES):
        raise AblationSummaryError(
            "formal ablation root must contain exactly the four canonical case directories"
        )
    for case in EXPECTED_ABLATION_CASES:
        if any(path.is_dir() for path in (output / case).iterdir()):
            raise AblationSummaryError(
                f"formal ablation case '{case}' must not contain nested directories"
            )

    excluded = {
        ABLATION_ARTIFACT_MANIFEST_FILENAME,
        f"{ABLATION_ARTIFACT_MANIFEST_FILENAME}.tmp",
    }
    actual = {
        path.relative_to(output).as_posix()
        for path in output.rglob("*")
        if path.is_file() and path.name not in excluded
    }
    if expected_case_file_set is None:
        has_convergence_artifact = any(
            Path(relative).name in CONVERGENCE_CASE_FILES for relative in actual
        )
        case_file_set = "convergence-v2" if has_convergence_artifact else "legacy-v1"
    else:
        case_file_set = expected_case_file_set
    if case_file_set not in FORMAL_CASE_FILE_SETS:
        raise AblationSummaryError(f"unsupported formal case file set: {case_file_set}")
    required = _required_formal_ablation_paths(FORMAL_CASE_FILE_SETS[case_file_set])
    missing = sorted(required - actual)
    unexpected = sorted(actual - required)
    if missing or unexpected:
        raise AblationSummaryError(
            f"formal ablation result set mismatch; missing={missing}, unexpected={unexpected}"
        )
    return actual, case_file_set


def write_ablation_artifact_manifest(output_dir: str | Path) -> Path:
    """Freeze one complete four-case formal ablation result set."""

    output = Path(output_dir).resolve()
    summary, _ = _formal_ablation_summary(output)
    actual_paths, case_file_set = _validate_formal_ablation_structure(output)
    entries = []
    for relative_path in sorted(actual_paths):
        path = output / Path(relative_path)
        entries.append(
            {
                "path": relative_path,
                "size_bytes": path.stat().st_size,
                "sha256": _file_sha256(path),
            }
        )
    document: dict[str, Any] = {
        "schema_version": "qingheng.ablation-artifact-manifest.v1",
        "sizing_sha256": summary["sizing_sha256"],
        "case_names": list(EXPECTED_ABLATION_CASES),
        "case_file_set": case_file_set,
        "result_complete": True,
        "required_file_count": len(
            _required_formal_ablation_paths(FORMAL_CASE_FILE_SETS[case_file_set])
        ),
        "file_count": len(entries),
        "files": entries,
    }
    canonical = json.dumps(document, sort_keys=True, separators=(",", ":"))
    document["manifest_sha256"] = sha256(canonical.encode("utf-8")).hexdigest()
    manifest_path = output / ABLATION_ARTIFACT_MANIFEST_FILENAME
    temporary = manifest_path.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(document, indent=2, ensure_ascii=True), encoding="utf-8")
    temporary.replace(manifest_path)
    return manifest_path


def verify_ablation_artifact_manifest(manifest_path: str | Path) -> dict[str, Any]:
    """Verify every formal ablation file and reject stale or unrecorded artifacts."""

    manifest_file = Path(manifest_path).resolve()
    document = _read_json(manifest_file)
    if document.get("schema_version") != "qingheng.ablation-artifact-manifest.v1":
        raise AblationSummaryError("unsupported ablation artifact manifest schema")
    expected_manifest_hash = document.get("manifest_sha256")
    unsigned = dict(document)
    unsigned.pop("manifest_sha256", None)
    canonical = json.dumps(unsigned, sort_keys=True, separators=(",", ":"))
    if expected_manifest_hash != sha256(canonical.encode("utf-8")).hexdigest():
        raise AblationSummaryError("ablation artifact manifest content hash does not match")

    entries = document.get("files")
    case_file_set = str(document.get("case_file_set", "legacy-v1"))
    if case_file_set not in FORMAL_CASE_FILE_SETS:
        raise AblationSummaryError("unsupported ablation artifact case file set")
    required = _required_formal_ablation_paths(FORMAL_CASE_FILE_SETS[case_file_set])
    if (
        not isinstance(entries, list)
        or document.get("file_count") != len(entries)
        or document.get("required_file_count") != len(required)
    ):
        raise AblationSummaryError("ablation artifact manifest has invalid file entries")
    output = manifest_file.parent
    recorded_paths: set[str] = set()
    for entry in entries:
        if not isinstance(entry, dict):
            raise AblationSummaryError("ablation artifact manifest file entry is invalid")
        relative = Path(str(entry.get("path", "")))
        if (
            not relative.parts
            or relative.is_absolute()
            or bool(relative.drive)
            or ".." in relative.parts
            or relative.name
            in {
                ABLATION_ARTIFACT_MANIFEST_FILENAME,
                f"{ABLATION_ARTIFACT_MANIFEST_FILENAME}.tmp",
            }
        ):
            raise AblationSummaryError("ablation artifact manifest contains an unsafe path")
        relative_posix = relative.as_posix()
        if relative_posix in recorded_paths:
            raise AblationSummaryError("ablation artifact manifest contains duplicate paths")
        path = (output / relative).resolve()
        if output not in path.parents or not path.is_file():
            raise AblationSummaryError(f"ablation result file is missing: {relative_posix}")
        if entry.get("size_bytes") != path.stat().st_size or entry.get("sha256") != _file_sha256(
            path
        ):
            raise AblationSummaryError(
                f"ablation result file does not match its manifest: {relative_posix}"
            )
        recorded_paths.add(relative_posix)
    if recorded_paths != required:
        raise AblationSummaryError("ablation artifact manifest is incomplete or has extra paths")

    actual_paths, _ = _validate_formal_ablation_structure(
        output,
        expected_case_file_set=case_file_set,
    )
    if actual_paths != recorded_paths:
        raise AblationSummaryError("formal ablation directory contains unmanifested files")
    summary, _ = _formal_ablation_summary(output)
    if (
        document.get("case_names") != list(EXPECTED_ABLATION_CASES)
        or document.get("sizing_sha256") != summary.get("sizing_sha256")
        or document.get("result_complete") is not True
    ):
        raise AblationSummaryError("ablation artifact manifest metadata is inconsistent")
    return document
