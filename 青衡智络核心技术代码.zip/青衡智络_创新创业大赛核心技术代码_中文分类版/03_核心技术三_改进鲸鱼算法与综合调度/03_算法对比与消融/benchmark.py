from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
import json
from numbers import Integral
from pathlib import Path
from time import perf_counter

import numpy as np
import pandas as pd

from .optimizers import particle_swarm_optimization, whale_optimization
from .problem import DispatchEvaluation, MultiEnergyDispatchProblem


@dataclass(frozen=True)
class BenchmarkRun:
    algorithm: str
    seed: int
    score: float
    feasible: bool
    cost: float
    curtailment_kwh: float
    emissions_kg: float
    external_source_emissions_kg: float
    penalty: float
    runtime_seconds: float
    evaluations: int


OPTIMIZER_ARTIFACT_FILES = (
    "optimizer_algorithm_comparison.pdf",
    "optimizer_algorithm_comparison.png",
    "optimizer_comparison.png",
    "optimizer_convergence.csv",
    "optimizer_protocol.json",
    "optimizer_runs.csv",
    "optimizer_summary.csv",
)
OPTIMIZER_ARTIFACT_MANIFEST = "optimizer_artifact_manifest.json"


def _file_sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_optimizer_protocol(
    output_dir: str | Path,
    *,
    seeds: tuple[int, ...],
    population_size: int,
    iterations: int,
) -> Path:
    """Record the applied benchmark budget independently of scenario defaults."""

    if (
        not seeds
        or len(set(seeds)) != len(seeds)
        or population_size < 4
        or iterations < 1
    ):
        raise ValueError("optimizer protocol requires valid unique seeds and a positive budget")
    document: dict[str, object] = {
        "schema_version": "qingheng.optimizer-benchmark.v1",
        "algorithms": ["improved_woa", "standard_woa", "pso"],
        "seeds": list(seeds),
        "population_size": population_size,
        "iterations": iterations,
        "expected_function_evaluations_per_run": population_size * (iterations + 1),
        "convergence_history": {
            "semantics": "best objective after each completed optimizer iteration",
            "iteration_index": "1-based; initialization is not emitted as iteration zero",
            "initialization_evaluations": population_size,
            "evaluations_per_iteration": population_size,
            "best_so_far": True,
        },
    }
    canonical = json.dumps(document, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    document["protocol_sha256"] = sha256(canonical.encode("utf-8")).hexdigest()
    path = Path(output_dir) / "optimizer_protocol.json"
    path.write_text(
        json.dumps(document, indent=2, ensure_ascii=True),
        encoding="utf-8",
    )
    return path


def write_optimizer_artifact_manifest(output_dir: str | Path) -> Path:
    """Freeze the optimizer tables, protocol, and paper-ready figures."""

    directory = Path(output_dir).resolve()
    paths = [directory / filename for filename in OPTIMIZER_ARTIFACT_FILES]
    missing = [path.name for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"optimizer artifact set is incomplete: {missing}")

    protocol = json.loads((directory / "optimizer_protocol.json").read_text(encoding="utf-8"))
    unsigned_protocol = dict(protocol)
    expected_protocol_hash = unsigned_protocol.pop("protocol_sha256", None)
    canonical_protocol = json.dumps(
        unsigned_protocol,
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    )
    if expected_protocol_hash != sha256(canonical_protocol.encode("utf-8")).hexdigest():
        raise ValueError("optimizer protocol content hash does not match")

    runs = pd.read_csv(directory / "optimizer_runs.csv")
    convergence = pd.read_csv(directory / "optimizer_convergence.csv")
    algorithms = tuple(str(value) for value in protocol["algorithms"])
    seeds = tuple(int(value) for value in protocol["seeds"])
    expected_evaluations = int(protocol["expected_function_evaluations_per_run"])
    optimized_runs = runs.loc[runs["algorithm"].isin(algorithms)].copy()
    expected_keys = {(algorithm, seed) for algorithm in algorithms for seed in seeds}
    actual_keys = {
        (str(row.algorithm), int(row.seed)) for row in optimized_runs.itertuples(index=False)
    }
    if (
        actual_keys != expected_keys
        or not (optimized_runs["evaluations"].astype(int) == expected_evaluations).all()
    ):
        raise ValueError("optimizer runs do not match the applied protocol")

    expected_iterations = int(protocol["iterations"])
    if len(convergence) != len(expected_keys) * expected_iterations:
        raise ValueError("optimizer convergence table has an unexpected row count")
    for key, history in convergence.groupby(["algorithm", "seed"]):
        ordered = history.sort_values("iteration")
        iteration_values = ordered["iteration"].to_numpy(dtype=np.int64)
        score_values = ordered["best_score"].to_numpy(dtype=np.float64)
        if (
            (str(key[0]), int(key[1])) not in expected_keys
            or not np.array_equal(
                iteration_values,
                np.arange(1, expected_iterations + 1, dtype=np.int64),
            )
            or not np.all(np.isfinite(score_values))
            or np.any(np.diff(score_values) > 1e-12)
        ):
            raise ValueError("optimizer convergence history does not match the applied protocol")
    final_history = (
        convergence.sort_values("iteration").groupby(["algorithm", "seed"], as_index=False).tail(1)
    )
    final_scores = {
        (str(row.algorithm), int(row.seed)): float(row.best_score)
        for row in final_history.itertuples(index=False)
    }
    run_scores = {
        (str(row.algorithm), int(row.seed)): float(row.score)
        for row in optimized_runs.itertuples(index=False)
    }
    if final_scores.keys() != run_scores.keys() or any(
        not np.isclose(final_scores[key], score, rtol=1e-10, atol=1e-12)
        for key, score in run_scores.items()
    ):
        raise ValueError("optimizer convergence endpoints do not match optimizer runs")

    means = {
        algorithm: float(
            optimized_runs.loc[optimized_runs["algorithm"] == algorithm, "score"].mean()
        )
        for algorithm in algorithms
    }
    best_algorithm = min(means, key=means.__getitem__)
    improved_reduction = (
        100.0 * (means["standard_woa"] - means["improved_woa"]) / means["standard_woa"]
    )
    entries = [
        {
            "path": path.name,
            "size_bytes": path.stat().st_size,
            "sha256": _file_sha256(path),
        }
        for path in paths
    ]
    document: dict[str, object] = {
        "schema_version": "qingheng.optimizer-artifact-manifest.v1",
        "protocol_sha256": expected_protocol_hash,
        "algorithm_score_means": means,
        "best_algorithm_by_mean": best_algorithm,
        "improved_woa_reduction_vs_standard_woa_percent": improved_reduction,
        "interpretation_guardrail": (
            "Improved WOA may be compared directly with standard WOA. "
            "Do not claim overall optimizer superiority when another algorithm has "
            "a lower mean objective."
        ),
        "file_count": len(entries),
        "files": entries,
    }
    canonical = json.dumps(document, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    document["manifest_sha256"] = sha256(canonical.encode("utf-8")).hexdigest()
    path = directory / OPTIMIZER_ARTIFACT_MANIFEST
    temporary = path.with_suffix(".json.tmp")
    temporary.write_text(
        json.dumps(document, indent=2, ensure_ascii=True),
        encoding="utf-8",
    )
    temporary.replace(path)
    return path


def verify_optimizer_artifact_manifest(manifest_path: str | Path) -> dict[str, object]:
    """Verify every optimizer artifact frozen by its manifest."""

    path = Path(manifest_path).resolve()
    document = json.loads(path.read_text(encoding="utf-8"))
    if document.get("schema_version") != "qingheng.optimizer-artifact-manifest.v1":
        raise ValueError("unsupported optimizer artifact manifest schema")
    unsigned = dict(document)
    expected_manifest_hash = unsigned.pop("manifest_sha256", None)
    canonical = json.dumps(unsigned, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    if expected_manifest_hash != sha256(canonical.encode("utf-8")).hexdigest():
        raise ValueError("optimizer artifact manifest content hash does not match")
    entries = document.get("files")
    if not isinstance(entries, list) or document.get("file_count") != len(entries):
        raise ValueError("optimizer artifact manifest has invalid file entries")
    recorded: set[str] = set()
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError("optimizer artifact manifest file entry is invalid")
        filename = str(entry.get("path", ""))
        if Path(filename).name != filename or filename in recorded:
            raise ValueError("optimizer artifact manifest contains an unsafe or duplicate path")
        artifact = path.parent / filename
        if (
            not artifact.is_file()
            or entry.get("size_bytes") != artifact.stat().st_size
            or entry.get("sha256") != _file_sha256(artifact)
        ):
            raise ValueError(f"optimizer artifact does not match its manifest: {filename}")
        recorded.add(filename)
    if recorded != set(OPTIMIZER_ARTIFACT_FILES):
        raise ValueError("optimizer artifact manifest is incomplete")
    return document


def run_optimizer_benchmark(
    problem: MultiEnergyDispatchProblem,
    *,
    seeds: tuple[int, ...] | None = None,
    population_size: int | None = None,
    iterations: int | None = None,
    output_dir: str | Path | None = None,
) -> tuple[pd.DataFrame, dict[tuple[str, int], DispatchEvaluation]]:
    cfg = problem.config
    run_seeds = tuple(cfg.seeds if seeds is None else seeds)
    if not run_seeds or any(
        isinstance(seed, bool) or not isinstance(seed, Integral) for seed in run_seeds
    ):
        raise ValueError("seeds must be a non-empty sequence of integers")
    run_seeds = tuple(int(seed) for seed in run_seeds)
    if len(set(run_seeds)) != len(run_seeds):
        raise ValueError("seeds must be unique for a multi-run benchmark")
    population = cfg.population if population_size is None else population_size
    steps = cfg.iterations if iterations is None else iterations
    evaluations: dict[tuple[str, int], DispatchEvaluation] = {}
    records: list[BenchmarkRun] = []
    convergence_records: list[dict[str, str | int | float]] = []

    algorithms = (
        (
            "improved_woa",
            lambda seed: whale_optimization(
                problem.objective,
                problem.lower_bounds,
                problem.upper_bounds,
                population_size=population,
                iterations=steps,
                seed=seed,
                variant="improved",
                initial_candidate=problem.zero_decision(),
                repair=problem.repair_decision,
            ),
        ),
        (
            "standard_woa",
            lambda seed: whale_optimization(
                problem.objective,
                problem.lower_bounds,
                problem.upper_bounds,
                population_size=population,
                iterations=steps,
                seed=seed,
                variant="standard",
                initial_candidate=problem.zero_decision(),
                repair=problem.repair_decision,
            ),
        ),
        (
            "pso",
            lambda seed: particle_swarm_optimization(
                problem.objective,
                problem.lower_bounds,
                problem.upper_bounds,
                population_size=population,
                iterations=steps,
                seed=seed,
                initial_candidate=problem.zero_decision(),
                repair=problem.repair_decision,
            ),
        ),
    )
    for algorithm, optimize in algorithms:
        for seed in run_seeds:
            started = perf_counter()
            result = optimize(seed)
            elapsed = perf_counter() - started
            if result.algorithm != algorithm or result.seed != seed:
                raise ValueError(f"{algorithm} seed {seed} returned inconsistent result metadata")
            evaluation = problem.evaluate(result.best_position)
            history = np.asarray(result.history, dtype=np.float64)
            if history.shape != (steps,) or not np.all(np.isfinite(history)):
                raise ValueError(f"{algorithm} seed {seed} returned an invalid convergence history")
            if np.any(np.diff(history) > 1e-12):
                raise ValueError(f"{algorithm} seed {seed} convergence history is not best-so-far")
            if not np.isclose(history[-1], evaluation.score, rtol=1e-10, atol=1e-12):
                raise ValueError(
                    f"{algorithm} seed {seed} convergence history does not match final score"
                )
            if not np.isclose(result.best_score, evaluation.score, rtol=1e-10, atol=1e-12):
                raise ValueError(f"{algorithm} seed {seed} best score does not match reevaluation")
            evaluations[(algorithm, seed)] = evaluation
            convergence_records.extend(
                {
                    "algorithm": algorithm,
                    "seed": seed,
                    "iteration": iteration,
                    "function_evaluations": population * (iteration + 1),
                    "best_score": float(score),
                }
                for iteration, score in enumerate(history, start=1)
            )
            records.append(
                BenchmarkRun(
                    algorithm=algorithm,
                    seed=seed,
                    score=evaluation.score,
                    feasible=evaluation.feasible,
                    cost=evaluation.cost,
                    curtailment_kwh=evaluation.curtailment_kwh,
                    emissions_kg=evaluation.emissions_kg,
                    external_source_emissions_kg=evaluation.external_source_emissions_kg,
                    penalty=evaluation.penalty,
                    runtime_seconds=elapsed,
                    evaluations=result.evaluations,
                )
            )

    baseline = problem.zero_dispatch()
    evaluations[("zero_dispatch", -1)] = baseline
    records.append(
        BenchmarkRun(
            algorithm="zero_dispatch",
            seed=-1,
            score=baseline.score,
            feasible=baseline.feasible,
            cost=baseline.cost,
            curtailment_kwh=baseline.curtailment_kwh,
            emissions_kg=baseline.emissions_kg,
            external_source_emissions_kg=baseline.external_source_emissions_kg,
            penalty=baseline.penalty,
            runtime_seconds=0.0,
            evaluations=1,
        )
    )
    frame = pd.DataFrame([asdict(record) for record in records])
    if output_dir is not None:
        directory = Path(output_dir)
        directory.mkdir(parents=True, exist_ok=True)
        frame.to_csv(directory / "optimizer_runs.csv", index=False)
        pd.DataFrame(convergence_records).to_csv(
            directory / "optimizer_convergence.csv", index=False
        )
        write_optimizer_protocol(
            directory,
            seeds=run_seeds,
            population_size=population,
            iterations=steps,
        )
        summary = (
            frame.groupby("algorithm", as_index=False)
            .agg(
                runs=("score", "size"),
                score_mean=("score", "mean"),
                score_std=("score", "std"),
                feasible_rate=("feasible", "mean"),
                cost_mean=("cost", "mean"),
                curtailment_mean_kwh=("curtailment_kwh", "mean"),
                emissions_mean_kg=("emissions_kg", "mean"),
                external_source_emissions_mean_kg=("external_source_emissions_kg", "mean"),
                runtime_mean_seconds=("runtime_seconds", "mean"),
            )
            .sort_values("score_mean")
        )
        summary.to_csv(directory / "optimizer_summary.csv", index=False)
    return frame, evaluations


def best_evaluation(
    frame: pd.DataFrame,
    evaluations: dict[tuple[str, int], DispatchEvaluation],
) -> tuple[tuple[str, int], DispatchEvaluation]:
    candidates = frame[(frame["algorithm"] != "zero_dispatch") & frame["feasible"].astype(bool)]
    if candidates.empty:
        raise ValueError("benchmark contains no feasible optimizer run")
    row = candidates.loc[candidates["score"].idxmin()]
    key = (str(row["algorithm"]), int(row["seed"]))
    return key, evaluations[key]
