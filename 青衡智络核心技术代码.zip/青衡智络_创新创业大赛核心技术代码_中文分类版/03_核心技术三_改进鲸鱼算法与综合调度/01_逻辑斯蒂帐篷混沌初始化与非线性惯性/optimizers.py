from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Literal

import numpy as np
from numpy.typing import NDArray


FloatArray = NDArray[np.float64]
Objective = Callable[[FloatArray], float]
Repair = Callable[[FloatArray], FloatArray]


@dataclass(frozen=True)
class OptimizationResult:
    algorithm: str
    seed: int
    best_position: FloatArray
    best_score: float
    history: FloatArray
    evaluations: int


def logistic_tent_sequence(size: int, *, seed: int, logistic_weight: float = 0.5) -> FloatArray:
    """Generate an explicit Logistic-Tent chaotic sequence in (0, 1).

    The former slide formula used the value being defined on both sides. This
    implementation uses only x[n] on the right-hand side:

      x[n+1] = w*4*x[n]*(1-x[n]) + (1-w)*T(x[n])

    where T(x)=2x for x<0.5 and T(x)=2(1-x) otherwise.
    """

    if size <= 0:
        raise ValueError("size must be positive")
    if not 0.0 <= logistic_weight <= 1.0:
        raise ValueError("logistic_weight must be in [0, 1]")
    rng = np.random.default_rng(seed)
    x = float(rng.uniform(1e-6, 1.0 - 1e-6))
    sequence = np.empty(size, dtype=np.float64)
    for index in range(size):
        tent = 2.0 * x if x < 0.5 else 2.0 * (1.0 - x)
        x = logistic_weight * 4.0 * x * (1.0 - x) + (1.0 - logistic_weight) * tent
        x = float(np.clip(x, 1e-12, 1.0 - 1e-12))
        sequence[index] = x
    return sequence


def nonlinear_inertia(
    iteration: int,
    total_iterations: int,
    *,
    maximum: float = 0.9,
    minimum: float = 0.2,
) -> float:
    if total_iterations <= 1:
        return minimum
    progress = np.clip(iteration / (total_iterations - 1), 0.0, 1.0)
    return float(minimum + (maximum - minimum) * (1.0 - progress**2))


def _evaluate_population(population: FloatArray, objective: Objective) -> FloatArray:
    scores = np.fromiter(
        (objective(candidate) for candidate in population),
        dtype=np.float64,
        count=population.shape[0],
    )
    if not np.all(np.isfinite(scores)):
        raise ValueError("objective must return a finite score for every candidate")
    return scores


def _validated_bounds(
    lower_bounds: FloatArray,
    upper_bounds: FloatArray,
) -> tuple[FloatArray, FloatArray]:
    lower = np.asarray(lower_bounds, dtype=np.float64)
    upper = np.asarray(upper_bounds, dtype=np.float64)
    if lower.shape != upper.shape or lower.ndim != 1 or lower.size == 0:
        raise ValueError("bounds must be non-empty one-dimensional arrays with equal shape")
    if not np.all(np.isfinite(lower)) or not np.all(np.isfinite(upper)):
        raise ValueError("bounds must contain only finite values")
    if np.any(upper < lower):
        raise ValueError("every upper bound must be greater than or equal to its lower bound")
    return lower, upper


def _repair_population(
    population: FloatArray,
    repair: Repair | None,
    lower: FloatArray,
    upper: FloatArray,
) -> FloatArray:
    if repair is None:
        return population
    repaired = np.stack(
        [np.asarray(repair(candidate), dtype=np.float64) for candidate in population]
    )
    if repaired.shape != population.shape or not np.all(np.isfinite(repaired)):
        raise ValueError("repair must return one finite vector with the original shape")
    if np.any(repaired < lower) or np.any(repaired > upper):
        raise ValueError("repair returned a candidate outside optimizer bounds")
    return repaired


def whale_optimization(
    objective: Objective,
    lower_bounds: FloatArray,
    upper_bounds: FloatArray,
    *,
    population_size: int = 60,
    iterations: int = 160,
    seed: int = 2026,
    variant: Literal["standard", "improved"] = "improved",
    initial_candidate: FloatArray | None = None,
    repair: Repair | None = None,
) -> OptimizationResult:
    lower, upper = _validated_bounds(lower_bounds, upper_bounds)
    if population_size < 4 or iterations < 1:
        raise ValueError("population_size must be >=4 and iterations must be positive")

    rng = np.random.default_rng(seed)
    dimension = lower.size
    if variant == "improved":
        unit = logistic_tent_sequence(population_size * dimension, seed=seed).reshape(
            population_size, dimension
        )
    elif variant == "standard":
        unit = rng.random((population_size, dimension))
    else:
        raise ValueError(f"Unknown WOA variant: {variant}")
    population = lower + unit * (upper - lower)
    if initial_candidate is not None:
        candidate = np.asarray(initial_candidate, dtype=np.float64)
        if (
            candidate.shape != lower.shape
            or not np.all(np.isfinite(candidate))
            or np.any(candidate < lower)
            or np.any(candidate > upper)
        ):
            raise ValueError("initial_candidate must match and lie within bounds")
        population[0] = candidate
    population = _repair_population(population, repair, lower, upper)
    previous = population.copy()
    scores = _evaluate_population(population, objective)
    evaluations = population_size
    best_index = int(np.argmin(scores))
    best = population[best_index].copy()
    best_score = float(scores[best_index])
    history = np.empty(iterations, dtype=np.float64)

    for iteration in range(iterations):
        progress = iteration / max(iterations - 1, 1)
        a = 2.0 * (1.0 - progress)
        inertia = nonlinear_inertia(iteration, iterations) if variant == "improved" else 0.0
        updated = np.empty_like(population)
        for index, current in enumerate(population):
            r1, r2, probability = rng.random(3)
            coefficient_a = 2.0 * a * r1 - a
            coefficient_c = 2.0 * r2
            if probability < 0.5:
                if abs(coefficient_a) < 1.0:
                    target = best
                else:
                    target = population[int(rng.integers(population_size))]
                distance = np.abs(coefficient_c * target - current)
                base_candidate = target - coefficient_a * distance
            else:
                distance = np.abs(best - current)
                spiral = rng.uniform(-1.0, 1.0)
                base_candidate = distance * np.exp(spiral) * np.cos(2.0 * np.pi * spiral) + best

            if variant == "improved":
                momentum = current - previous[index]
                base_candidate = base_candidate + inertia * momentum
            updated[index] = np.clip(base_candidate, lower, upper)

        updated = _repair_population(updated, repair, lower, upper)
        previous, population = population, updated
        scores = _evaluate_population(population, objective)
        evaluations += population_size
        candidate_index = int(np.argmin(scores))
        if scores[candidate_index] < best_score:
            best = population[candidate_index].copy()
            best_score = float(scores[candidate_index])
        history[iteration] = best_score

    return OptimizationResult(
        algorithm="improved_woa" if variant == "improved" else "standard_woa",
        seed=seed,
        best_position=best,
        best_score=best_score,
        history=history,
        evaluations=evaluations,
    )


def particle_swarm_optimization(
    objective: Objective,
    lower_bounds: FloatArray,
    upper_bounds: FloatArray,
    *,
    population_size: int = 60,
    iterations: int = 160,
    seed: int = 2026,
    initial_candidate: FloatArray | None = None,
    repair: Repair | None = None,
) -> OptimizationResult:
    lower, upper = _validated_bounds(lower_bounds, upper_bounds)
    if population_size < 4 or iterations < 1:
        raise ValueError("population_size must be >=4 and iterations must be positive")
    rng = np.random.default_rng(seed)
    span = upper - lower
    positions = lower + rng.random((population_size, lower.size)) * span
    if initial_candidate is not None:
        candidate = np.asarray(initial_candidate, dtype=np.float64)
        if (
            candidate.shape != lower.shape
            or not np.all(np.isfinite(candidate))
            or np.any(candidate < lower)
            or np.any(candidate > upper)
        ):
            raise ValueError("initial_candidate must match and lie within bounds")
        positions[0] = candidate
    positions = _repair_population(positions, repair, lower, upper)
    velocities = rng.uniform(-0.1, 0.1, positions.shape) * span
    scores = _evaluate_population(positions, objective)
    evaluations = population_size
    personal_best = positions.copy()
    personal_scores = scores.copy()
    best_index = int(np.argmin(scores))
    global_best = positions[best_index].copy()
    global_score = float(scores[best_index])
    history = np.empty(iterations, dtype=np.float64)

    for iteration in range(iterations):
        inertia = nonlinear_inertia(iteration, iterations, maximum=0.9, minimum=0.4)
        cognitive = 1.7 * rng.random(positions.shape) * (personal_best - positions)
        social = 1.7 * rng.random(positions.shape) * (global_best - positions)
        velocities = np.clip(inertia * velocities + cognitive + social, -0.2 * span, 0.2 * span)
        positions = np.clip(positions + velocities, lower, upper)
        positions = _repair_population(positions, repair, lower, upper)
        scores = _evaluate_population(positions, objective)
        evaluations += population_size
        improved = scores < personal_scores
        personal_best[improved] = positions[improved]
        personal_scores[improved] = scores[improved]
        best_index = int(np.argmin(personal_scores))
        if personal_scores[best_index] < global_score:
            global_best = personal_best[best_index].copy()
            global_score = float(personal_scores[best_index])
        history[iteration] = global_score

    return OptimizationResult(
        algorithm="pso",
        seed=seed,
        best_position=global_best,
        best_score=global_score,
        history=history,
        evaluations=evaluations,
    )
