from __future__ import annotations

import importlib
from dataclasses import dataclass
from numbers import Integral, Real
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from numpy.typing import NDArray

from qingheng.data.ieee33 import load_ieee33_from_mpte
from qingheng.dispatch.problem import DispatchEvaluation, DispatchInputs


FloatArray = NDArray[np.float64]


@dataclass(frozen=True)
class DevicePlacement:
    pv_bus: int = 18
    wind_bus: int = 33
    battery_bus: int = 14
    hydrogen_bus: int = 30
    fixed_generation_bus: int = 6


@dataclass(frozen=True)
class PowerFlowValidation:
    timeseries: pd.DataFrame
    branch_flows_kw: FloatArray
    branch_to_end_flows_kw: FloatArray
    bus_injections_kw: FloatArray
    branch_from_bus: NDArray[np.int64]
    branch_to_bus: NDArray[np.int64]
    all_converged: bool
    voltage_feasible: bool
    current_feasible: bool | None
    grid_feasible: bool | None

    @property
    def feasible(self) -> bool:
        current_ok = True if self.current_feasible is None else self.current_feasible
        grid_ok = True if self.grid_feasible is None else self.grid_feasible
        return self.all_converged and self.voltage_feasible and current_ok and grid_ok


def _load_mpte(mpte_root: str | Path) -> tuple[Any, Any]:
    network = load_ieee33_from_mpte(mpte_root)
    feeder = network.external_feeder
    package_name = feeder.__class__.__module__.split(".feeders.", maxsplit=1)[0]
    powerflow_module = importlib.import_module(f"{package_name}.simulation.powerflow")
    return feeder, powerflow_module.solve_radial_power_flow


class IEEE33ScheduleValidator:
    """Read-only adapter around the existing MPTE IEEE33 power-flow engine."""

    def __init__(
        self,
        mpte_root: str | Path,
        *,
        placement: DevicePlacement | None = None,
        voltage_min_pu: float = 0.95,
        voltage_max_pu: float = 1.05,
        max_current_pu: float | None = None,
    ) -> None:
        self.feeder, solve = _load_mpte(mpte_root)
        self._solve = solve
        self.placement = placement or DevicePlacement()
        self.voltage_min_pu = voltage_min_pu
        self.voltage_max_pu = voltage_max_pu
        self.max_current_pu = max_current_pu
        if (
            isinstance(voltage_min_pu, bool)
            or isinstance(voltage_max_pu, bool)
            or not isinstance(voltage_min_pu, Real)
            or not isinstance(voltage_max_pu, Real)
            or not np.isfinite(voltage_min_pu)
            or not np.isfinite(voltage_max_pu)
            or not 0 < voltage_min_pu < voltage_max_pu
        ):
            raise ValueError("invalid voltage limits")
        if max_current_pu is not None and (
            isinstance(max_current_pu, bool)
            or not isinstance(max_current_pu, Real)
            or not np.isfinite(max_current_pu)
            or max_current_pu <= 0.0
        ):
            raise ValueError("max_current_pu must be finite and positive")
        slack_external = int(self.feeder.ordering.to_external(self.feeder.slack_bus))
        for name, bus in vars(self.placement).items():
            if isinstance(bus, bool) or not isinstance(bus, Integral):
                raise ValueError(f"{name} must be an integer external bus label")
            if not 1 <= bus <= self.feeder.n_bus:
                raise ValueError(
                    f"{name} must use an external bus label in [1, {self.feeder.n_bus}]"
                )
            if int(bus) == slack_external:
                raise ValueError(
                    f"{name} cannot use slack bus {slack_external}; "
                    "the power-flow engine ignores specified slack injections"
                )

    def _internal(self, external_bus: int) -> int:
        return int(self.feeder.ordering.to_internal(external_bus))

    def validate(
        self,
        inputs: DispatchInputs,
        dispatch: DispatchEvaluation,
        *,
        grid_import_limit_kw: float | None = None,
        grid_export_limit_kw: float | None = None,
    ) -> PowerFlowValidation:
        if inputs.horizon != dispatch.grid_power_kw.size:
            raise ValueError("inputs and dispatch horizons differ")
        for name, values in (
            ("grid_power_kw", dispatch.grid_power_kw),
            ("battery_power_kw", dispatch.battery_power_kw),
            ("hydrogen_power_kw", dispatch.hydrogen_power_kw),
            ("renewable_fraction", dispatch.renewable_fraction),
        ):
            array = np.asarray(values, dtype=np.float64)
            if array.shape != (inputs.horizon,) or not np.all(np.isfinite(array)):
                raise ValueError(
                    f"dispatch {name} must be a finite vector with shape ({inputs.horizon},)"
                )
        if np.any(dispatch.renewable_fraction < 0.0) or np.any(
            dispatch.renewable_fraction > 1.0
        ):
            raise ValueError("dispatch renewable_fraction must be in [0, 1]")
        for name, limit in (
            ("grid_import_limit_kw", grid_import_limit_kw),
            ("grid_export_limit_kw", grid_export_limit_kw),
        ):
            if limit is not None and (
                isinstance(limit, bool)
                or not isinstance(limit, Real)
                or not np.isfinite(limit)
                or limit < 0
            ):
                raise ValueError(f"{name} must be finite and non-negative")
        feeder = self.feeder
        total_base_load = float(np.sum(feeder.load_p_kw))
        if total_base_load <= 0:
            raise ValueError("IEEE33 feeder has no base load")

        records: list[dict[str, float | int | bool]] = []
        branch_flows = np.full((inputs.horizon, feeder.n_branch), np.nan)
        branch_to_flows = np.full((inputs.horizon, feeder.n_branch), np.nan)
        bus_injections = np.full((inputs.horizon, feeder.n_bus), np.nan)
        for step in range(inputs.horizon):
            load_scale = inputs.load_kw[step] / total_base_load
            p_kw = -feeder.load_p_kw * load_scale
            q_kvar = -feeder.load_q_kvar * load_scale
            fraction = dispatch.renewable_fraction[step]
            p_kw[self._internal(self.placement.pv_bus)] += inputs.pv_available_kw[step] * fraction
            p_kw[self._internal(self.placement.wind_bus)] += (
                inputs.wind_available_kw[step] * fraction
            )
            p_kw[self._internal(self.placement.battery_bus)] += dispatch.battery_power_kw[step]
            p_kw[self._internal(self.placement.hydrogen_bus)] += dispatch.hydrogen_power_kw[step]
            p_kw[self._internal(self.placement.fixed_generation_bus)] += inputs.fixed_generation_kw[
                step
            ]
            p_pu = p_kw / (feeder.base_power_mva * 1000.0)
            q_pu = q_kvar / (feeder.base_power_mva * 1000.0)
            try:
                result = self._solve(feeder, p_pu, q_pu)
                voltage = np.abs(result.voltage)
                branch_kw = result.branch_from_power.real * feeder.base_power_mva * 1000.0
                branch_to_kw = result.branch_to_power.real * feeder.base_power_mva * 1000.0
                branch_flows[step] = branch_kw
                branch_to_flows[step] = branch_to_kw
                bus_injections[step] = result.power_injection.real * feeder.base_power_mva * 1000.0
                slack_power_kw = float(bus_injections[step, feeder.slack_bus])
                records.append(
                    {
                        "step": step,
                        "converged": bool(result.converged),
                        "iterations": int(result.iterations),
                        "min_voltage_pu": float(np.min(voltage)),
                        "max_voltage_pu": float(np.max(voltage)),
                        "max_branch_current_pu": float(result.max_branch_current_pu),
                        "active_loss_kw": float(
                            np.sum(result.power_injection.real) * feeder.base_power_mva * 1000.0
                        ),
                        "slack_power_kw": slack_power_kw,
                    }
                )
            except (ValueError, RuntimeError, FloatingPointError, np.linalg.LinAlgError):
                records.append(
                    {
                        "step": step,
                        "converged": False,
                        "iterations": 0,
                        "min_voltage_pu": np.nan,
                        "max_voltage_pu": np.nan,
                        "max_branch_current_pu": np.nan,
                        "active_loss_kw": np.nan,
                        "slack_power_kw": np.nan,
                    }
                )

        frame = pd.DataFrame.from_records(records)
        all_converged = bool(frame["converged"].all())
        voltage_feasible = bool(
            all_converged
            and (frame["min_voltage_pu"] >= self.voltage_min_pu).all()
            and (frame["max_voltage_pu"] <= self.voltage_max_pu).all()
        )
        if self.max_current_pu is None:
            current_feasible = None
        else:
            current_feasible = bool(
                all_converged and (frame["max_branch_current_pu"] <= self.max_current_pu).all()
            )
        if grid_import_limit_kw is None and grid_export_limit_kw is None:
            grid_feasible = None
        else:
            import_limit = np.inf if grid_import_limit_kw is None else grid_import_limit_kw
            export_limit = np.inf if grid_export_limit_kw is None else grid_export_limit_kw
            grid_feasible = bool(
                all_converged
                and (frame["slack_power_kw"] <= import_limit + 1e-6).all()
                and (frame["slack_power_kw"] >= -export_limit - 1e-6).all()
            )
        branch_from = np.asarray(
            [branch.from_bus_external for branch in feeder.branches], dtype=np.int64
        )
        branch_to = np.asarray(
            [branch.to_bus_external for branch in feeder.branches], dtype=np.int64
        )
        return PowerFlowValidation(
            timeseries=frame,
            branch_flows_kw=branch_flows,
            branch_to_end_flows_kw=branch_to_flows,
            bus_injections_kw=bus_injections,
            branch_from_bus=branch_from,
            branch_to_bus=branch_to,
            all_converged=all_converged,
            voltage_feasible=voltage_feasible,
            current_feasible=current_feasible,
            grid_feasible=grid_feasible,
        )


def directed_branch_records(
    validation: PowerFlowValidation, step: int, *, tolerance_kw: float = 1e-6
) -> list[tuple[int, int, float]]:
    """Convert signed canonical branch powers into directed sending-end records."""

    if isinstance(step, bool) or not isinstance(step, Integral):
        raise TypeError("step must be an integer")
    if step < 0 or step >= validation.branch_flows_kw.shape[0]:
        raise IndexError("step is outside the validation horizon")
    if (
        isinstance(tolerance_kw, bool)
        or not isinstance(tolerance_kw, Real)
        or not np.isfinite(tolerance_kw)
        or tolerance_kw < 0.0
    ):
        raise ValueError("tolerance_kw must be finite and non-negative")
    from_end_flows = validation.branch_flows_kw[step]
    to_end_flows = validation.branch_to_end_flows_kw[step]
    records: list[tuple[int, int, float]] = []
    for source, target, from_flow, to_flow in zip(
        validation.branch_from_bus,
        validation.branch_to_bus,
        from_end_flows,
        to_end_flows,
        strict=True,
    ):
        if not np.isfinite(from_flow) or not np.isfinite(to_flow):
            continue
        if from_flow > tolerance_kw:
            records.append((int(source), int(target), float(from_flow)))
        elif from_flow < -tolerance_kw and to_flow > tolerance_kw:
            records.append((int(target), int(source), float(to_flow)))
    return records
