"""Read-only adapter for the MPTE IEEE 33-bus feeder and topology state."""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import importlib
import importlib.util
from pathlib import Path
import sys
from typing import Any

import numpy as np
from numpy.typing import NDArray


@dataclass(frozen=True)
class IEEE33NetworkData:
    name: str
    n_bus: int
    n_branch: int
    slack_bus: int
    base_voltage_kv: float
    base_power_mva: float
    branch_from: NDArray[np.int64]
    branch_to: NDArray[np.int64]
    resistance_ohm: NDArray[np.float64]
    reactance_ohm: NDArray[np.float64]
    base_switch_state: NDArray[np.bool_]
    load_p_kw: NDArray[np.float64]
    load_q_kvar: NDArray[np.float64]
    topology_hash: str
    source_root: Path
    source_files: tuple[Path, ...]
    external_feeder: Any = field(repr=False, compare=False)


def _readonly_array(value: Any, dtype: Any) -> np.ndarray:
    array = np.asarray(value, dtype=dtype).copy()
    array.setflags(write=False)
    return array


def _load_isolated_mpte_package(root: Path) -> str:
    """Import MPTE under a path-derived private name without changing sys.path."""

    package_init = root / "__init__.py"
    if not package_init.is_file():
        raise FileNotFoundError(f"MPTE package marker not found: {package_init}")
    identity = hashlib.sha256(str(root).encode("utf-8")).hexdigest()[:16]
    package_name = f"_qingheng_mpte_{identity}"
    if package_name in sys.modules:
        return package_name
    spec = importlib.util.spec_from_file_location(
        package_name,
        package_init,
        submodule_search_locations=[str(root)],
    )
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot create an import specification for {root}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[package_name] = module
    previous = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(package_name, None)
        raise
    finally:
        sys.dont_write_bytecode = previous
    return package_name


def load_ieee33_from_mpte(
    mpte_root: str | Path,
    *,
    base_voltage_kv: float = 12.66,
    base_power_mva: float = 100.0,
) -> IEEE33NetworkData:
    """Load and detach the canonical feeder arrays from an external MPTE checkout.

    The external project is imported through a private package namespace with
    bytecode writes disabled.  All public arrays returned by this adapter are
    immutable copies, so downstream simulations cannot mutate the source model.
    """

    root = Path(mpte_root).resolve()
    required = (
        root / "feeders" / "load_ieee33.py",
        root / "feeders" / "bus_ordering.py",
        root / "feeders" / "per_unit.py",
        root / "topology" / "topology_encoding.py",
    )
    missing = [path for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"incomplete MPTE checkout; missing {missing[0]}")

    package_name = _load_isolated_mpte_package(root)
    previous = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        feeder_module = importlib.import_module(f"{package_name}.feeders.load_ieee33")
        topology_module = importlib.import_module(f"{package_name}.topology.topology_encoding")
    finally:
        sys.dont_write_bytecode = previous
    feeder = feeder_module.load_ieee33(
        base_voltage_kv=base_voltage_kv,
        base_power_mva=base_power_mva,
    )
    switch_state = _readonly_array(feeder.base_switch_state, np.bool_)
    encoded = topology_module.TopologyEncoding.from_switch_state(
        switch_state, network_name=feeder.name
    )
    resistance = [branch.resistance_ohm for branch in feeder.branches]
    reactance = [branch.reactance_ohm for branch in feeder.branches]
    network = IEEE33NetworkData(
        name=str(feeder.name),
        n_bus=int(feeder.n_bus),
        n_branch=int(feeder.n_branch),
        slack_bus=int(feeder.slack_bus),
        base_voltage_kv=float(feeder.base_voltage_kv),
        base_power_mva=float(feeder.base_power_mva),
        branch_from=_readonly_array(feeder.branch_from, np.int64),
        branch_to=_readonly_array(feeder.branch_to, np.int64),
        resistance_ohm=_readonly_array(resistance, np.float64),
        reactance_ohm=_readonly_array(reactance, np.float64),
        base_switch_state=switch_state,
        load_p_kw=_readonly_array(feeder.load_p_kw, np.float64),
        load_q_kvar=_readonly_array(feeder.load_q_kvar, np.float64),
        topology_hash=str(encoded.topology_hash),
        source_root=root,
        source_files=tuple(path.resolve() for path in required),
        external_feeder=feeder,
    )
    if network.n_bus != 33 or network.n_branch != 37:
        raise ValueError(
            f"expected IEEE33 dimensions (33, 37), got ({network.n_bus}, {network.n_branch})"
        )
    if int(network.base_switch_state.sum()) != 32:
        raise ValueError("IEEE33 base topology must contain exactly 32 closed branches")
    return network


__all__ = ["IEEE33NetworkData", "load_ieee33_from_mpte"]
