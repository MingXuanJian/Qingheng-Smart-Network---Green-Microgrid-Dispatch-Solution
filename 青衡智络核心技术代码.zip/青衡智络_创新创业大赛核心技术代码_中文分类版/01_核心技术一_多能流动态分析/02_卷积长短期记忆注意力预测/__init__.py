"""Leakage-safe CNN-LSTM-Attention forecasting and evaluation."""

from .data import (
    ForecastDependencyError,
    StandardScaler,
    TemporalBoundaries,
    WindowDataset,
    WindowedSplits,
    prepare_windowed_data,
    temporal_boundaries,
)
from .metrics import (
    clip_nonnegative_predictions,
    mae,
    per_target_metrics,
    persistence_forecast,
    regression_metrics,
    rmse,
    smape,
)
from .model import CNNLSTMAttention, ModelSpec
from .training import (
    ForecastPredictions,
    LoadedForecastArtifact,
    TrainingConfig,
    TrainingHistory,
    TrainingResult,
    fit_model,
    load_forecast_artifact,
    predict_dataset,
    save_forecast_artifact,
    set_reproducible_seed,
    train_forecaster,
)

__all__ = [
    "CNNLSTMAttention",
    "ForecastDependencyError",
    "ForecastPredictions",
    "LoadedForecastArtifact",
    "ModelSpec",
    "StandardScaler",
    "TemporalBoundaries",
    "TrainingConfig",
    "TrainingHistory",
    "TrainingResult",
    "WindowDataset",
    "WindowedSplits",
    "clip_nonnegative_predictions",
    "fit_model",
    "load_forecast_artifact",
    "mae",
    "per_target_metrics",
    "persistence_forecast",
    "predict_dataset",
    "prepare_windowed_data",
    "regression_metrics",
    "rmse",
    "save_forecast_artifact",
    "set_reproducible_seed",
    "smape",
    "temporal_boundaries",
    "train_forecaster",
]
