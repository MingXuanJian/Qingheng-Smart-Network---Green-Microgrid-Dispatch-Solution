"""Leakage-safe preprocessing and temporal windows for forecasting."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd

try:
    import torch
    from torch.utils.data import Dataset
except ImportError:  # pragma: no cover - exercised in environments without the extra
    torch = None

    class Dataset:  # type: ignore[no-redef]
        """Placeholder that keeps the base package importable without PyTorch."""


class ForecastDependencyError(ImportError):
    """Raised when an optional forecasting dependency is required but unavailable."""


def require_torch() -> None:
    if torch is None:
        raise ForecastDependencyError(
            "PyTorch is required for the forecasting model. "
            "Install the optional dependency with `pip install -e .[forecast]`."
        )


@dataclass(frozen=True)
class StandardScaler:
    """Small serializable standard scaler with no scikit-learn dependency."""

    mean: np.ndarray
    scale: np.ndarray

    def __post_init__(self) -> None:
        mean = np.asarray(self.mean, dtype=np.float64)
        scale = np.asarray(self.scale, dtype=np.float64)
        if mean.ndim != 1 or scale.ndim != 1 or mean.shape != scale.shape or mean.size == 0:
            raise ValueError("mean and scale must be non-empty one-dimensional arrays")
        if not np.isfinite(mean).all() or not np.isfinite(scale).all():
            raise ValueError("mean and scale must contain only finite values")
        if np.any(scale <= 0.0):
            raise ValueError("scale values must be positive")
        object.__setattr__(self, "mean", mean.copy())
        object.__setattr__(self, "scale", scale.copy())

    @classmethod
    def fit(cls, values: np.ndarray) -> "StandardScaler":
        array = _as_2d_finite(values, "values")
        mean = array.mean(axis=0, dtype=np.float64)
        scale = array.std(axis=0, dtype=np.float64)
        scale = np.where(scale < 1e-12, 1.0, scale)
        return cls(mean=mean, scale=scale)

    def transform(self, values: np.ndarray) -> np.ndarray:
        array = np.asarray(values, dtype=np.float64)
        if array.ndim == 0 or array.shape[-1] != self.mean.size:
            received = 0 if array.ndim == 0 else array.shape[-1]
            raise ValueError(f"Expected {self.mean.size} columns, received {received}")
        if not np.isfinite(array).all():
            raise ValueError("values contain NaN or infinite values")
        return ((array - self.mean) / self.scale).astype(np.float32, copy=False)

    def inverse_transform(self, values: np.ndarray) -> np.ndarray:
        array = np.asarray(values, dtype=np.float64)
        if array.ndim == 0 or array.shape[-1] != self.mean.size:
            received = 0 if array.ndim == 0 else array.shape[-1]
            raise ValueError(f"Expected {self.mean.size} columns, received {received}")
        if not np.isfinite(array).all():
            raise ValueError("values contain NaN or infinite values")
        return (array * self.scale + self.mean).astype(np.float64, copy=False)

    def to_dict(self) -> dict[str, list[float]]:
        return {"mean": self.mean.tolist(), "scale": self.scale.tolist()}

    @classmethod
    def from_dict(cls, payload: Mapping[str, Sequence[float]]) -> "StandardScaler":
        return cls(
            mean=np.asarray(payload["mean"], dtype=np.float64),
            scale=np.asarray(payload["scale"], dtype=np.float64),
        )


def _as_2d_finite(values: np.ndarray, name: str) -> np.ndarray:
    array = np.asarray(values, dtype=np.float64)
    if array.ndim != 2:
        raise ValueError(f"{name} must be a two-dimensional array")
    if len(array) == 0:
        raise ValueError(f"{name} cannot be empty")
    if not np.isfinite(array).all():
        raise ValueError(f"{name} contains NaN or infinite values; impute before windowing")
    return array


@dataclass(frozen=True)
class TemporalBoundaries:
    """Half-open row boundaries used to assign forecast targets to each split."""

    train_end: int
    validation_end: int
    total: int

    @property
    def train(self) -> tuple[int, int]:
        return (0, self.train_end)

    @property
    def validation(self) -> tuple[int, int]:
        return (self.train_end, self.validation_end)

    @property
    def test(self) -> tuple[int, int]:
        return (self.validation_end, self.total)


class WindowDataset(Dataset):
    """Lazy sliding windows whose target horizon stays wholly inside one split."""

    def __init__(
        self,
        features: np.ndarray,
        targets: np.ndarray,
        *,
        input_steps: int,
        horizon_steps: int,
        target_start: int,
        target_stop: int,
        stride: int = 1,
    ) -> None:
        require_torch()
        feature_array = _as_2d_finite(features, "features").astype(np.float32)
        target_array = _as_2d_finite(targets, "targets").astype(np.float32)
        if len(feature_array) != len(target_array):
            raise ValueError("features and targets must contain the same number of rows")
        if input_steps <= 0 or horizon_steps <= 0 or stride <= 0:
            raise ValueError("input_steps, horizon_steps, and stride must be positive")
        if not 0 <= target_start < target_stop <= len(feature_array):
            raise ValueError("target bounds must define a non-empty range within the data")

        first_window_start = max(0, target_start - input_steps)
        last_window_start = target_stop - input_steps - horizon_steps
        starts = np.arange(
            first_window_start,
            last_window_start + 1,
            stride,
            dtype=np.int64,
        )
        forecast_starts = starts + input_steps
        self.starts = starts[forecast_starts >= target_start]
        if len(self.starts) == 0:
            raise ValueError(
                "The split is too short for one complete input/forecast window; "
                "reduce input_steps or horizon_steps"
            )

        self.features = feature_array
        self.targets = target_array
        self.input_steps = input_steps
        self.horizon_steps = horizon_steps
        self.target_start = target_start
        self.target_stop = target_stop

    def __len__(self) -> int:
        return int(len(self.starts))

    def __getitem__(self, index: int) -> tuple[Any, Any]:
        start = int(self.starts[index])
        forecast_start = start + self.input_steps
        x = self.features[start:forecast_start]
        y = self.targets[forecast_start : forecast_start + self.horizon_steps]
        return torch.from_numpy(x), torch.from_numpy(y)

    @property
    def target_row_ranges(self) -> np.ndarray:
        """Return each sample's half-open target range for audit and testing."""

        starts = self.starts + self.input_steps
        return np.column_stack((starts, starts + self.horizon_steps))

    def persistence_predictions(self) -> np.ndarray:
        """Repeat the last observed target value over every forecast horizon."""

        last_observed_rows = self.starts + self.input_steps - 1
        last_values = self.targets[last_observed_rows]
        return np.repeat(last_values[:, None, :], self.horizon_steps, axis=1)

    def seasonal_persistence_predictions(self, period_steps: int) -> np.ndarray:
        """Use the matching observations from one complete seasonal period ago.

        The requested period must fit inside the model input and must be at least
        as long as the forecast horizon. This prevents the baseline from reading
        target rows that would not yet be observable at the forecast origin.
        """

        if period_steps <= 0:
            raise ValueError("period_steps must be positive")
        if period_steps > self.input_steps:
            raise ValueError("period_steps cannot exceed the input history")
        if self.horizon_steps > period_steps:
            raise ValueError("horizon_steps cannot exceed the seasonal period")

        forecast_starts = self.starts + self.input_steps
        reference_starts = forecast_starts - period_steps
        if np.any(reference_starts < self.starts):
            raise RuntimeError("seasonal reference falls outside the input window")
        offsets = np.arange(self.horizon_steps, dtype=np.int64)
        reference_rows = reference_starts[:, None] + offsets[None, :]
        return self.targets[reference_rows]

    def target_values(self) -> np.ndarray:
        return np.stack([self[index][1].numpy() for index in range(len(self))])


@dataclass(frozen=True)
class WindowedSplits:
    train: WindowDataset
    validation: WindowDataset
    test: WindowDataset
    feature_scaler: StandardScaler
    target_scaler: StandardScaler
    feature_columns: tuple[str, ...]
    target_columns: tuple[str, ...]
    boundaries: TemporalBoundaries


def temporal_boundaries(
    row_count: int,
    *,
    train_fraction: float = 0.70,
    validation_fraction: float = 0.15,
) -> TemporalBoundaries:
    if row_count < 3:
        raise ValueError("At least three rows are required")
    if not 0 < train_fraction < 1 or not 0 < validation_fraction < 1:
        raise ValueError("train_fraction and validation_fraction must be between zero and one")
    if train_fraction + validation_fraction >= 1:
        raise ValueError("train_fraction + validation_fraction must be less than one")

    train_end = int(np.floor(row_count * train_fraction))
    validation_end = train_end + int(np.floor(row_count * validation_fraction))
    if train_end == 0 or validation_end == train_end or validation_end == row_count:
        raise ValueError("Fractions produce an empty chronological split")
    return TemporalBoundaries(train_end, validation_end, row_count)


def prepare_windowed_data(
    frame: pd.DataFrame,
    *,
    feature_columns: Sequence[str],
    target_columns: Sequence[str],
    input_steps: int,
    horizon_steps: int,
    train_fraction: float = 0.70,
    validation_fraction: float = 0.15,
    stride: int = 1,
) -> WindowedSplits:
    """Scale on training rows only, then create leakage-safe chronological datasets.

    Validation and test inputs may use preceding context, but every target row remains
    inside its assigned half-open split. The frame must already be regularly sampled
    and missing values must already have been handled by the data layer.
    """

    require_torch()
    if frame.empty:
        raise ValueError("frame cannot be empty")
    if not frame.index.is_monotonic_increasing or not frame.index.is_unique:
        raise ValueError("frame index must be unique and monotonically increasing")
    features_requested = tuple(feature_columns)
    targets_requested = tuple(target_columns)
    if not features_requested or not targets_requested:
        raise ValueError("feature_columns and target_columns cannot be empty")
    missing = sorted((set(features_requested) | set(targets_requested)) - set(frame.columns))
    if missing:
        raise ValueError(f"Columns not present in frame: {missing}")

    raw_features = _as_2d_finite(
        frame.loc[:, features_requested].to_numpy(dtype=np.float64), "features"
    )
    raw_targets = _as_2d_finite(
        frame.loc[:, targets_requested].to_numpy(dtype=np.float64), "targets"
    )
    boundaries = temporal_boundaries(
        len(frame),
        train_fraction=train_fraction,
        validation_fraction=validation_fraction,
    )

    # Fitting both scalers before touching validation/test rows makes leakage auditable.
    feature_scaler = StandardScaler.fit(raw_features[: boundaries.train_end])
    target_scaler = StandardScaler.fit(raw_targets[: boundaries.train_end])
    features = feature_scaler.transform(raw_features)
    targets = target_scaler.transform(raw_targets)

    common = {
        "features": features,
        "targets": targets,
        "input_steps": input_steps,
        "horizon_steps": horizon_steps,
        "stride": stride,
    }
    train = WindowDataset(
        **common,
        target_start=0,
        target_stop=boundaries.train_end,
    )
    validation = WindowDataset(
        **common,
        target_start=boundaries.train_end,
        target_stop=boundaries.validation_end,
    )
    test = WindowDataset(
        **common,
        target_start=boundaries.validation_end,
        target_stop=boundaries.total,
    )
    return WindowedSplits(
        train=train,
        validation=validation,
        test=test,
        feature_scaler=feature_scaler,
        target_scaler=target_scaler,
        feature_columns=features_requested,
        target_columns=targets_requested,
        boundaries=boundaries,
    )
