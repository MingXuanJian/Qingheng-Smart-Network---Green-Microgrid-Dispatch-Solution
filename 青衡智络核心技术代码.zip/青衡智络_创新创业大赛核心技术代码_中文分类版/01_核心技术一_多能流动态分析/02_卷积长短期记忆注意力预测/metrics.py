"""Forecast metrics and a transparent persistence baseline."""

from __future__ import annotations

from typing import Sequence

import numpy as np


def _paired_arrays(actual: np.ndarray, predicted: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    y_true = np.asarray(actual, dtype=np.float64)
    y_pred = np.asarray(predicted, dtype=np.float64)
    if y_true.shape != y_pred.shape:
        raise ValueError(f"Shape mismatch: actual {y_true.shape}, predicted {y_pred.shape}")
    if y_true.size == 0:
        raise ValueError("Metric inputs cannot be empty")
    if not np.isfinite(y_true).all() or not np.isfinite(y_pred).all():
        raise ValueError("Metric inputs contain NaN or infinite values")
    return y_true, y_pred


def mae(actual: np.ndarray, predicted: np.ndarray) -> float:
    y_true, y_pred = _paired_arrays(actual, predicted)
    return float(np.mean(np.abs(y_true - y_pred)))


def rmse(actual: np.ndarray, predicted: np.ndarray) -> float:
    y_true, y_pred = _paired_arrays(actual, predicted)
    return float(np.sqrt(np.mean(np.square(y_true - y_pred))))


def smape(actual: np.ndarray, predicted: np.ndarray, *, epsilon: float = 1e-8) -> float:
    """Symmetric MAPE in percent, bounded approximately between 0 and 200."""

    if epsilon <= 0:
        raise ValueError("epsilon must be positive")
    y_true, y_pred = _paired_arrays(actual, predicted)
    denominator = np.abs(y_true) + np.abs(y_pred)
    ratio = np.divide(
        2.0 * np.abs(y_pred - y_true),
        denominator,
        out=np.zeros_like(denominator),
        where=denominator > epsilon,
    )
    return float(100.0 * np.mean(ratio))


def regression_metrics(actual: np.ndarray, predicted: np.ndarray) -> dict[str, float]:
    return {
        "mae": mae(actual, predicted),
        "rmse": rmse(actual, predicted),
        "smape_percent": smape(actual, predicted),
    }


def per_target_metrics(
    actual: np.ndarray,
    predicted: np.ndarray,
    target_names: Sequence[str],
) -> dict[str, dict[str, float]]:
    y_true, y_pred = _paired_arrays(actual, predicted)
    if y_true.ndim < 2:
        raise ValueError("Per-target metrics require a target dimension")
    if y_true.shape[-1] != len(target_names):
        raise ValueError("target_names length does not match the final array dimension")
    return {
        name: regression_metrics(y_true[..., index], y_pred[..., index])
        for index, name in enumerate(target_names)
    }


def clip_nonnegative_predictions(
    predicted: np.ndarray,
    target_names: Sequence[str],
) -> tuple[np.ndarray, dict[str, object]]:
    """Project power forecasts onto the nonnegative domain and audit every clip."""

    values = np.asarray(predicted, dtype=np.float64)
    if values.ndim < 1 or values.shape[-1] != len(target_names):
        raise ValueError("target_names length must match the final prediction dimension")
    if values.size == 0:
        raise ValueError("predicted cannot be empty")
    if not np.isfinite(values).all():
        raise ValueError("predicted contains NaN or infinite values")

    clipped_mask = values < 0.0
    clipped_count = int(clipped_mask.sum())
    physical = np.maximum(values, 0.0)
    audit: dict[str, object] = {
        "rule": "max(prediction, 0.0) for nonnegative power targets",
        "clipped_value_count": clipped_count,
        "total_value_count": int(values.size),
        "clipped_fraction": float(clipped_count / values.size),
        "per_target_clipped_value_count": {
            name: int(clipped_mask[..., index].sum()) for index, name in enumerate(target_names)
        },
    }
    return physical, audit


def persistence_forecast(history: np.ndarray, horizon_steps: int) -> np.ndarray:
    """Repeat each sample's latest observed value across the requested horizon.

    Accepted shapes are ``[time, target]`` and ``[sample, time, target]``. The
    returned shapes are respectively ``[horizon, target]`` and
    ``[sample, horizon, target]``.
    """

    values = np.asarray(history)
    if horizon_steps <= 0:
        raise ValueError("horizon_steps must be positive")
    if values.ndim == 2:
        if values.shape[0] == 0:
            raise ValueError("history cannot be empty")
        return np.repeat(values[-1][None, :], horizon_steps, axis=0)
    if values.ndim == 3:
        if values.shape[1] == 0:
            raise ValueError("history cannot be empty")
        return np.repeat(values[:, -1:, :], horizon_steps, axis=1)
    raise ValueError("history must have shape [time, target] or [sample, time, target]")
