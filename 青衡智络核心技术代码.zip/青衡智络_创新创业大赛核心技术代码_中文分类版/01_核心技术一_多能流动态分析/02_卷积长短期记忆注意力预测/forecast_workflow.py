from __future__ import annotations

from dataclasses import dataclass, replace
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
import pandas as pd

from qingheng.config import ForecastConfig
from qingheng.data import verify_socal_cache_manifest
from qingheng.forecast import (
    ModelSpec,
    TrainingConfig,
    clip_nonnegative_predictions,
    load_forecast_artifact,
    per_target_metrics,
    predict_dataset,
    prepare_windowed_data,
    regression_metrics,
    train_forecaster,
)


@dataclass(frozen=True)
class ForecastExperimentResult:
    artifact_path: Path
    metrics_path: Path
    history_path: Path
    predictions_path: Path
    model_metrics: dict[str, object]
    raw_model_metrics: dict[str, object]
    persistence_metrics: dict[str, object]
    last_value_persistence_metrics: dict[str, object]
    weekly_persistence_metrics: dict[str, object]
    seasonal_blend_metrics: dict[str, object]
    operational_metrics: dict[str, object]
    validation_blend_weights: dict[str, object]
    postprocessing: dict[str, object]
    rows: int
    train_windows: int
    validation_windows: int
    test_windows: int


@dataclass(frozen=True)
class DailyForecastExportResult:
    csv_path: Path
    manifest_path: Path
    rows: int
    days: int
    sha256: str


class _WindowSubset:
    def __init__(self, dataset: object, indices: np.ndarray):
        self.dataset = dataset
        self.indices = np.asarray(indices, dtype=np.int64)

    def __len__(self) -> int:
        return int(len(self.indices))

    def __getitem__(self, index: int) -> object:
        return self.dataset[int(self.indices[index])]  # type: ignore[index]


def _file_sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _verify_optional_artifact_binding(metrics: dict[str, object], artifact: Path) -> None:
    """Verify a direct sidecar-to-model hash when a v5 producer provides one."""

    binding = metrics.get("forecast_artifact")
    if binding is None:
        return
    if not isinstance(binding, dict):
        raise ValueError("forecast metrics forecast_artifact binding must be an object")
    if binding.get("filename") != artifact.name:
        raise ValueError("forecast metrics artifact filename does not match the selected model")
    expected_sha256 = binding.get("sha256")
    if not isinstance(expected_sha256, str) or len(expected_sha256) != 64:
        raise ValueError("forecast metrics artifact SHA-256 is invalid")
    if _file_sha256(artifact) != expected_sha256.lower():
        raise ValueError("forecast artifact hash does not match the forecast metrics sidecar")


def _complete_local_day_sample_indices(
    index: pd.DatetimeIndex,
    target_row_ranges: np.ndarray,
    *,
    horizon_steps: int,
    timezone: str = "America/Los_Angeles",
) -> np.ndarray:
    """Locate fixed 24-hour forecast windows aligned to local calendar days."""

    if index.tz is None:
        raise ValueError("forecast frame index must be timezone-aware")
    ranges = np.asarray(target_row_ranges, dtype=np.int64)
    if ranges.ndim != 2 or ranges.shape[1] != 2:
        raise ValueError("target_row_ranges must have shape [sample, 2]")
    selected: list[int] = []
    dates: set[object] = set()
    for sample, (raw_start, raw_stop) in enumerate(ranges):
        start = int(raw_start)
        stop = int(raw_stop)
        if stop - start != horizon_steps or start < 0 or stop > len(index):
            continue
        local = index[start:stop].tz_convert(timezone)
        if len(local) != horizon_steps:
            continue
        first = local[0]
        last = local[-1]
        if not (
            first.hour == 0
            and first.minute == 0
            and last.hour == 23
            and last.minute == 45
            and first.date() == last.date()
        ):
            continue
        if first.date() in dates:
            raise RuntimeError(f"multiple forecast windows found for local date {first.date()}")
        dates.add(first.date())
        selected.append(sample)
    return np.asarray(selected, dtype=np.int64)


def _training_climatology_predictions(
    frame: pd.DataFrame,
    *,
    target_columns: tuple[str, ...],
    train_end: int,
    target_row_ranges: np.ndarray,
    timezone: str = "America/Los_Angeles",
) -> np.ndarray:
    """Predict each horizon row from training-only local time-of-day means."""

    if not 0 < train_end <= len(frame):
        raise ValueError("train_end must select a non-empty prefix of the frame")
    ranges = np.asarray(target_row_ranges, dtype=np.int64)
    if ranges.ndim != 2 or ranges.shape[1] != 2 or len(ranges) == 0:
        raise ValueError("target_row_ranges must have shape [sample, 2]")
    horizon_lengths = ranges[:, 1] - ranges[:, 0]
    if np.any(horizon_lengths <= 0) or not np.all(horizon_lengths == horizon_lengths[0]):
        raise ValueError("target ranges must use one positive fixed horizon")
    horizon = int(horizon_lengths[0])
    rows = ranges[:, 0, None] + np.arange(horizon, dtype=np.int64)[None, :]
    if rows.min() < 0 or rows.max() >= len(frame):
        raise ValueError("target ranges fall outside the frame")

    local_index = frame.index.tz_convert(timezone)
    slots = (local_index.hour * 60 + local_index.minute).to_numpy(dtype=np.int64)
    training = frame.iloc[:train_end].loc[:, target_columns].astype(float).copy()
    training["_slot"] = slots[:train_end]
    climatology = training.groupby("_slot").mean()
    fallback = training.loc[:, target_columns].mean()
    lookup = climatology.reindex(np.unique(slots)).fillna(fallback)
    by_slot = {
        int(slot): lookup.loc[slot, list(target_columns)].to_numpy() for slot in lookup.index
    }
    flat = np.stack([by_slot[int(slot)] for slot in slots[rows].ravel()])
    return flat.reshape(len(ranges), horizon, len(target_columns))


def _seasonal_lag_predictions(
    frame: pd.DataFrame,
    *,
    target_columns: tuple[str, ...],
    target_row_ranges: np.ndarray,
    period_steps: int,
) -> np.ndarray:
    """Return a causal fixed-elapsed-step seasonal forecast in raw units.

    On a UTC-regular series this is an elapsed-time lag. It matches the same local
    wall-clock slot only when the timezone offset does not change across the lag.
    """

    if period_steps <= 0:
        raise ValueError("period_steps must be positive")
    ranges = np.asarray(target_row_ranges, dtype=np.int64)
    if ranges.ndim != 2 or ranges.shape[1] != 2 or len(ranges) == 0:
        raise ValueError("target_row_ranges must have shape [sample, 2]")
    horizon_lengths = ranges[:, 1] - ranges[:, 0]
    if np.any(horizon_lengths <= 0) or not np.all(horizon_lengths == horizon_lengths[0]):
        raise ValueError("target ranges must use one positive fixed horizon")
    horizon = int(horizon_lengths[0])
    if horizon > period_steps:
        raise ValueError("forecast horizon cannot exceed the seasonal period")
    target_rows = ranges[:, 0, None] + np.arange(horizon, dtype=np.int64)[None, :]
    reference_rows = target_rows - period_steps
    if reference_rows.min() < 0 or target_rows.max() >= len(frame):
        raise ValueError("seasonal reference or target rows fall outside the frame")
    values = frame.loc[:, target_columns].to_numpy(dtype=np.float64)
    return values[reference_rows]


def _seasonal_reference_audit(
    frame: pd.DataFrame,
    *,
    target_row_ranges: np.ndarray,
    period_steps: int,
    timezone: str = "America/Los_Angeles",
) -> dict[str, object]:
    """Report whether a fixed-step lag also matches local wall-clock slots."""

    if period_steps <= 0:
        raise ValueError("period_steps must be positive")
    if not isinstance(frame.index, pd.DatetimeIndex) or frame.index.tz is None:
        raise ValueError("forecast frame index must be timezone-aware")
    if len(frame.index) < 2:
        raise ValueError("forecast frame needs at least two timestamps")
    deltas = np.diff(frame.index.asi8)
    if np.any(deltas != deltas[0]) or deltas[0] <= 0:
        raise ValueError("forecast frame index must use one positive fixed interval")

    ranges = np.asarray(target_row_ranges, dtype=np.int64)
    if ranges.ndim != 2 or ranges.shape[1] != 2 or len(ranges) == 0:
        raise ValueError("target_row_ranges must have shape [sample, 2]")
    horizon_lengths = ranges[:, 1] - ranges[:, 0]
    if np.any(horizon_lengths <= 0) or not np.all(horizon_lengths == horizon_lengths[0]):
        raise ValueError("target ranges must use one positive fixed horizon")
    horizon = int(horizon_lengths[0])
    target_rows = ranges[:, 0, None] + np.arange(horizon, dtype=np.int64)[None, :]
    reference_rows = target_rows - period_steps
    if reference_rows.min() < 0 or target_rows.max() >= len(frame):
        raise ValueError("seasonal reference or target rows fall outside the frame")

    target_local = frame.index.take(target_rows.ravel()).tz_convert(timezone)
    reference_local = frame.index.take(reference_rows.ravel()).tz_convert(timezone)
    wall_clock_match = (
        (target_local.hour == reference_local.hour)
        & (target_local.minute == reference_local.minute)
        & (target_local.second == reference_local.second)
    )
    mismatch_count = int((~wall_clock_match).sum())
    value_count = int(wall_clock_match.size)
    return {
        "reference_basis": "fixed elapsed steps on the UTC-regular series",
        "period_steps": int(period_steps),
        "fixed_elapsed_hours": float(period_steps * deltas[0] / (60 * 60 * 1e9)),
        "local_timezone": timezone,
        "scored_value_count": value_count,
        "local_wall_clock_mismatch_value_count": mismatch_count,
        "local_wall_clock_mismatch_fraction": float(mismatch_count / value_count),
        "same_local_wall_clock_for_all_scored_values": mismatch_count == 0,
        "interpretation": (
            "A nonzero mismatch means this elapsed-time baseline must not be described "
            "as the same local time yesterday or last week across a DST offset change."
        ),
    }


def _target_values_from_frame(
    frame: pd.DataFrame,
    *,
    target_columns: tuple[str, ...],
    target_row_ranges: np.ndarray,
) -> np.ndarray:
    """Read exact raw targets, preserving physical zeros lost in float32 scaling."""

    ranges = np.asarray(target_row_ranges, dtype=np.int64)
    if ranges.ndim != 2 or ranges.shape[1] != 2 or len(ranges) == 0:
        raise ValueError("target_row_ranges must have shape [sample, 2]")
    horizon_lengths = ranges[:, 1] - ranges[:, 0]
    if np.any(horizon_lengths <= 0) or not np.all(horizon_lengths == horizon_lengths[0]):
        raise ValueError("target ranges must use one positive fixed horizon")
    horizon = int(horizon_lengths[0])
    rows = ranges[:, 0, None] + np.arange(horizon, dtype=np.int64)[None, :]
    if rows.min() < 0 or rows.max() >= len(frame):
        raise ValueError("target ranges fall outside the frame")
    values = frame.loc[:, target_columns].to_numpy(dtype=np.float64)
    return values[rows]


def _validation_selected_blend(
    actual: np.ndarray,
    left: np.ndarray,
    right: np.ndarray,
    target_columns: tuple[str, ...],
) -> tuple[np.ndarray, dict[str, float]]:
    """Select per-target convex weights on validation MAE only."""

    if actual.shape != left.shape or actual.shape != right.shape:
        raise ValueError("blend arrays must have identical shapes")
    if actual.shape[-1] != len(target_columns):
        raise ValueError("target_columns does not match blend arrays")
    candidates = np.linspace(0.0, 1.0, 101)
    weights: dict[str, float] = {}
    blended = np.empty_like(left, dtype=np.float64)
    for target, name in enumerate(target_columns):
        errors = [
            float(
                np.mean(
                    np.abs(
                        actual[..., target]
                        - (weight * left[..., target] + (1.0 - weight) * right[..., target])
                    )
                )
            )
            for weight in candidates
        ]
        weight = float(candidates[int(np.argmin(errors))])
        weights[name] = weight
        blended[..., target] = weight * left[..., target] + (1.0 - weight) * right[..., target]
    return blended, weights


def _apply_target_blend(
    left: np.ndarray,
    right: np.ndarray,
    weights: dict[str, float],
    target_columns: tuple[str, ...],
) -> np.ndarray:
    if left.shape != right.shape or left.shape[-1] != len(target_columns):
        raise ValueError("blend inputs and target columns are incompatible")
    result = np.empty_like(left, dtype=np.float64)
    for target, name in enumerate(target_columns):
        weight = float(weights[name])
        if not 0.0 <= weight <= 1.0:
            raise ValueError("blend weights must be in [0, 1]")
        result[..., target] = weight * left[..., target] + (1.0 - weight) * right[..., target]
    return result


def _metric_bundle(
    actual: np.ndarray,
    predicted: np.ndarray,
    target_columns: tuple[str, ...],
) -> dict[str, object]:
    return {
        "basis": (
            "overlapping forecast-window values; each forecast-origin/lead-time pair "
            "receives equal weight"
        ),
        "overall": regression_metrics(actual, predicted),
        "per_target": per_target_metrics(actual, predicted, target_columns),
    }


def _window_overlap_audit(target_row_ranges: np.ndarray) -> dict[str, object]:
    ranges = np.asarray(target_row_ranges, dtype=np.int64)
    if ranges.ndim != 2 or ranges.shape[1] != 2 or len(ranges) == 0:
        raise ValueError("target_row_ranges must have shape [sample, 2]")
    lengths = ranges[:, 1] - ranges[:, 0]
    if np.any(lengths <= 0):
        raise ValueError("target ranges must have positive lengths")
    first = int(ranges[:, 0].min())
    stop = int(ranges[:, 1].max())
    if first < 0:
        raise ValueError("target ranges cannot contain negative rows")
    multiplicity = np.zeros(stop - first, dtype=np.int64)
    for start, end in ranges:
        multiplicity[int(start) - first : int(end) - first] += 1
    covered = multiplicity[multiplicity > 0]
    return {
        "forecast_window_count": int(len(ranges)),
        "scored_window_value_count": int(lengths.sum()),
        "unique_target_row_count": int(len(covered)),
        "mean_target_row_multiplicity": float(covered.mean()),
        "minimum_target_row_multiplicity": int(covered.min()),
        "maximum_target_row_multiplicity": int(covered.max()),
        "headline_weighting": (
            "equal weight per forecast-origin/lead-time pair, not equal weight per "
            "unique timestamp"
        ),
    }


def _target_interval_summary(
    frame: pd.DataFrame,
    target_row_ranges: np.ndarray,
    *,
    interval: pd.Timedelta,
) -> dict[str, object]:
    ranges = np.asarray(target_row_ranges, dtype=np.int64)
    first = int(ranges[0, 0])
    stop = int(ranges[-1, 1])
    return {
        "forecast_windows": int(len(ranges)),
        "target_start": frame.index[first].isoformat(),
        "target_end_exclusive": (frame.index[stop - 1] + interval).isoformat(),
    }


def _non_overlapping_metric_bundle(
    actual: np.ndarray,
    predicted: np.ndarray,
    target_row_ranges: np.ndarray,
    target_columns: tuple[str, ...],
) -> dict[str, object]:
    ranges = np.asarray(target_row_ranges, dtype=np.int64)
    selected: list[int] = []
    next_start = -1
    for sample, (start, stop) in enumerate(ranges):
        if int(start) >= next_start:
            selected.append(sample)
            next_start = int(stop)
    indices = np.asarray(selected, dtype=np.int64)
    bundle = _metric_bundle(actual[indices], predicted[indices], target_columns)
    bundle["basis"] = "chronological greedy non-overlapping forecast-window values"
    return {
        "selection_policy": (
            "select the earliest remaining window, then skip every window whose "
            "target interval overlaps it"
        ),
        "window_count": int(len(indices)),
        **bundle,
    }


def _pv_conditioned_metrics(
    frame: pd.DataFrame,
    actual: np.ndarray,
    predicted: np.ndarray,
    target_row_ranges: np.ndarray,
    *,
    pv_target_index: int,
    timezone: str = "America/Los_Angeles",
) -> dict[str, object]:
    """Expose daylight and positive-PV errors hidden by zero-valued night rows."""

    ranges = np.asarray(target_row_ranges, dtype=np.int64)
    horizon = actual.shape[1]
    rows = ranges[:, 0, None] + np.arange(horizon, dtype=np.int64)[None, :]
    timestamps = frame.index.take(rows.ravel()).tz_convert(timezone)
    hours = timestamps.hour.to_numpy().reshape(rows.shape)
    actual_pv = np.asarray(actual[..., pv_target_index], dtype=np.float64)
    predicted_pv = np.asarray(predicted[..., pv_target_index], dtype=np.float64)
    daylight = (hours >= 8) & (hours < 17)
    positive = actual_pv > 0.0

    def selected_metrics(mask: np.ndarray) -> dict[str, object]:
        if not np.any(mask):
            return {
                "value_count": 0,
                "mae": None,
                "rmse": None,
                "smape_percent": None,
            }
        return {
            "value_count": int(mask.sum()),
            **regression_metrics(actual_pv[mask], predicted_pv[mask]),
        }

    return {
        "basis": "overlapping forecast-window values",
        "actual_zero_fraction": float(np.mean(actual_pv == 0.0)),
        "daylight_local_hours": "08:00<=time<17:00",
        "smape_caution": (
            "For exact-zero actual PV, any nonzero forecast makes pointwise sMAPE "
            "saturate at 200%; use zero-actual MAE/RMSE for magnitude interpretation."
        ),
        "daylight": selected_metrics(daylight),
        "positive_actual": selected_metrics(positive),
        "zero_actual": selected_metrics(~positive),
    }


def prepare_socal_forecast_frame(
    frame: pd.DataFrame,
    *,
    expected_minutes: int = 15,
) -> pd.DataFrame:
    """Add causal missing handling and calendar features to a 15-minute cache."""

    if expected_minutes <= 0:
        raise ValueError("expected_minutes must be positive")
    if not isinstance(frame.index, pd.DatetimeIndex):
        if "timestamp" not in frame.columns:
            raise TypeError("SoCal cache must have a DatetimeIndex or timestamp column")
        frame = frame.set_index(pd.to_datetime(frame.pop("timestamp"), utc=True))
    frame = frame.sort_index().copy()
    if frame.empty:
        raise ValueError("SoCal cache cannot be empty")
    if frame.index.has_duplicates:
        raise ValueError("SoCal cache timestamps must be unique")
    if frame.index.tz is None:
        raise ValueError("SoCal cache timestamps must be timezone-aware")
    frame.index = frame.index.tz_convert("UTC")
    interval = pd.Timedelta(minutes=expected_minutes)
    timestamp_ns = frame.index.asi8
    if len(timestamp_ns) and np.any(timestamp_ns % interval.value != 0):
        raise ValueError(
            f"SoCal cache timestamps must align to exact {expected_minutes}-minute boundaries"
        )
    if len(timestamp_ns) > 1:
        deltas = np.diff(timestamp_ns)
        invalid = np.flatnonzero(deltas != interval.value)
        if invalid.size:
            position = int(invalid[0])
            raise ValueError(
                "SoCal cache must be a gap-free regular time series: "
                f"{frame.index[position]} to {frame.index[position + 1]} is "
                f"{pd.Timedelta(int(deltas[position]), unit='ns')}, expected {interval}"
            )
    required = {"load_kw", "pv_kw", "grid_kw", "fuel_cell_kw"}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"SoCal cache is missing columns: {missing}")

    power_columns = ["load_kw", "pv_kw", "grid_kw", "fuel_cell_kw"]
    frame[power_columns] = frame[power_columns].ffill(limit=4)
    first_valid = frame[power_columns].notna().all(axis=1).to_numpy().argmax()
    frame = frame.iloc[int(first_valid) :].copy()
    if frame[power_columns].isna().any().any():
        raise ValueError("SoCal cache has a missing run longer than four 15-minute intervals")
    for name in ("load_missing", "pv_missing", "grid_missing", "fuel_cell_missing"):
        if name not in frame:
            frame[name] = False
        frame[name] = frame[name].astype(float)

    local_index = frame.index.tz_convert("America/Los_Angeles")
    hour = local_index.hour.to_numpy() + local_index.minute.to_numpy() / 60.0
    day = local_index.dayofyear.to_numpy()
    weekday = local_index.dayofweek.to_numpy()
    frame["hour_sin"] = np.sin(2.0 * np.pi * hour / 24.0)
    frame["hour_cos"] = np.cos(2.0 * np.pi * hour / 24.0)
    frame["day_sin"] = np.sin(2.0 * np.pi * day / 365.25)
    frame["day_cos"] = np.cos(2.0 * np.pi * day / 365.25)
    frame["weekday_sin"] = np.sin(2.0 * np.pi * weekday / 7.0)
    frame["weekday_cos"] = np.cos(2.0 * np.pi * weekday / 7.0)
    return frame


def run_socal_forecast_experiment(
    cache_path: str | Path,
    output_dir: str | Path,
    config: ForecastConfig,
    *,
    quick: bool = False,
    epochs: int | None = None,
) -> ForecastExperimentResult:
    """Train and compare CNN-LSTM-Attention with persistence on real SoCal data."""

    cache = Path(cache_path).resolve()
    if not cache.is_file():
        raise FileNotFoundError(f"SoCal Parquet cache not found: {cache}")
    cache_manifest = verify_socal_cache_manifest(cache)
    selected_complete_months = cache_manifest["derivation"]["selected_complete_months"]
    frame = prepare_socal_forecast_frame(
        pd.read_parquet(cache),
        expected_minutes=config.resample_minutes,
    )
    source_rows = len(frame)
    source_start = frame.index[0]
    source_end = frame.index[-1]
    experiment_config = config
    if quick:
        required = config.input_steps + config.horizon_steps * 4 + 300
        frame = frame.iloc[: max(required, 1200)].copy()
        experiment_config = replace(
            config,
            hidden_size=16,
            conv_channels=8,
            epochs=1,
            batch_size=min(config.batch_size, 64),
        )
    if epochs is not None:
        experiment_config = replace(experiment_config, epochs=epochs)

    if 24 * 60 % experiment_config.resample_minutes:
        raise ValueError("resample_minutes must divide one day for daily persistence")
    daily_period_steps = 24 * 60 // experiment_config.resample_minutes
    weekly_period_steps = 7 * daily_period_steps
    if experiment_config.input_steps < daily_period_steps:
        raise ValueError("input_steps must include at least one day for daily persistence")
    if experiment_config.horizon_steps > daily_period_steps:
        raise ValueError("horizon_steps cannot exceed one day for daily persistence")

    feature_columns = (
        "load_kw",
        "pv_kw",
        "grid_kw",
        "fuel_cell_kw",
        "hour_sin",
        "hour_cos",
        "day_sin",
        "day_cos",
        "weekday_sin",
        "weekday_cos",
        "load_missing",
        "pv_missing",
        "grid_missing",
        "fuel_cell_missing",
    )
    target_columns = ("load_kw", "pv_kw")
    splits = prepare_windowed_data(
        frame,
        feature_columns=feature_columns,
        target_columns=target_columns,
        input_steps=experiment_config.input_steps,
        horizon_steps=experiment_config.horizon_steps,
    )
    interval = pd.Timedelta(minutes=experiment_config.resample_minutes)
    experiment_interval = {
        "rows": int(len(frame)),
        "start": frame.index[0].isoformat(),
        "end_inclusive": frame.index[-1].isoformat(),
        "quick_truncation": bool(quick),
    }
    split_intervals = {
        "train": _target_interval_summary(frame, splits.train.target_row_ranges, interval=interval),
        "validation": _target_interval_summary(
            frame, splits.validation.target_row_ranges, interval=interval
        ),
        "test": _target_interval_summary(frame, splits.test.target_row_ranges, interval=interval),
    }
    model_spec = ModelSpec(
        input_features=len(feature_columns),
        target_count=len(target_columns),
        horizon_steps=experiment_config.horizon_steps,
        conv_channels=experiment_config.conv_channels,
        kernel_size=experiment_config.kernel_size,
        hidden_size=experiment_config.hidden_size,
        attention_heads=4,
        dropout=experiment_config.dropout,
        residual_period_steps=daily_period_steps,
    )
    training_config = TrainingConfig(
        epochs=experiment_config.epochs,
        learning_rate=experiment_config.learning_rate,
        seed=experiment_config.seed,
        patience=min(6, experiment_config.epochs),
    )
    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    artifact_path = output / "cnn_lstm_attention.pt"
    trained = train_forecaster(
        splits,
        spec=model_spec,
        training=training_config,
        artifact_path=artifact_path,
        batch_size=experiment_config.batch_size,
        metadata={
            "dataset": "SoCal real selected magnitudes",
            "cache_path": str(cache),
            "sampling_minutes": experiment_config.resample_minutes,
            "calendar_feature_timezone": "America/Los_Angeles",
            "selected_complete_months": selected_complete_months,
            "cache_output_sha256": cache_manifest["output_sha256"],
            "source_cache_rows": source_rows,
            "source_cache_start": source_start.isoformat(),
            "source_cache_end_inclusive": source_end.isoformat(),
            "experiment_interval": experiment_interval,
            "target_split_intervals": split_intervals,
            "chronological_split": [0.70, 0.15, 0.15],
            "quick_smoke": quick,
        },
    )
    validation_predictions = predict_dataset(
        trained.model,
        splits.validation,
        target_scaler=splits.target_scaler,
        batch_size=256,
    )
    predictions = predict_dataset(
        trained.model,
        splits.test,
        target_scaler=splits.target_scaler,
        batch_size=256,
    )
    validation_actual = _target_values_from_frame(
        frame,
        target_columns=target_columns,
        target_row_ranges=splits.validation.target_row_ranges,
    )
    if not np.allclose(validation_actual, validation_predictions.actual, atol=1e-4):
        raise RuntimeError("validation targets do not match the prepared validation split")
    validation_daily = _seasonal_lag_predictions(
        frame,
        target_columns=target_columns,
        target_row_ranges=splits.validation.target_row_ranges,
        period_steps=daily_period_steps,
    )
    validation_weekly = _seasonal_lag_predictions(
        frame,
        target_columns=target_columns,
        target_row_ranges=splits.validation.target_row_ranges,
        period_steps=weekly_period_steps,
    )
    validation_physical, validation_postprocessing = clip_nonnegative_predictions(
        validation_predictions.predicted,
        target_columns,
    )

    last_value_scaled = splits.test.persistence_predictions()
    last_value_persistence = splits.target_scaler.inverse_transform(last_value_scaled)
    persistence_actual = _target_values_from_frame(
        frame,
        target_columns=target_columns,
        target_row_ranges=splits.test.target_row_ranges,
    )
    if not np.allclose(persistence_actual, predictions.actual, atol=1e-4):
        raise RuntimeError("test prediction targets do not match the prepared test split")
    daily_persistence = _seasonal_lag_predictions(
        frame,
        target_columns=target_columns,
        target_row_ranges=splits.test.target_row_ranges,
        period_steps=daily_period_steps,
    )
    weekly_persistence = _seasonal_lag_predictions(
        frame,
        target_columns=target_columns,
        target_row_ranges=splits.test.target_row_ranges,
        period_steps=weekly_period_steps,
    )
    physical_predictions, postprocessing = clip_nonnegative_predictions(
        predictions.predicted,
        target_columns,
    )
    test_climatology = _training_climatology_predictions(
        frame,
        target_columns=target_columns,
        train_end=splits.boundaries.train_end,
        target_row_ranges=splits.test.target_row_ranges,
    )
    _, seasonal_weights = _validation_selected_blend(
        validation_actual,
        validation_daily,
        validation_weekly,
        target_columns,
    )
    validation_guardrail = _apply_target_blend(
        validation_daily,
        validation_weekly,
        seasonal_weights,
        target_columns,
    )
    test_guardrail = _apply_target_blend(
        daily_persistence,
        weekly_persistence,
        seasonal_weights,
        target_columns,
    )
    _, operational_weights = _validation_selected_blend(
        validation_actual,
        validation_physical,
        validation_guardrail,
        target_columns,
    )
    operational_predictions = _apply_target_blend(
        physical_predictions,
        test_guardrail,
        operational_weights,
        target_columns,
    )

    raw_model_metrics = _metric_bundle(persistence_actual, predictions.predicted, target_columns)
    model_metrics = _metric_bundle(persistence_actual, physical_predictions, target_columns)
    persistence_metrics = _metric_bundle(persistence_actual, daily_persistence, target_columns)
    weekly_persistence_metrics = _metric_bundle(
        persistence_actual, weekly_persistence, target_columns
    )
    last_value_persistence_metrics = _metric_bundle(
        persistence_actual, last_value_persistence, target_columns
    )
    seasonal_blend_metrics = _metric_bundle(persistence_actual, test_guardrail, target_columns)
    operational_metrics = _metric_bundle(
        persistence_actual, operational_predictions, target_columns
    )
    payload = {
        "schema_version": "qingheng.forecast-metrics.v5",
        "forecast_artifact": {
            "filename": artifact_path.name,
            "sha256": _file_sha256(artifact_path),
            "format_version": 1,
        },
        "data_provenance": {
            "cache_path": str(cache),
            "cache_output_sha256": cache_manifest["output_sha256"],
            "selected_complete_months": selected_complete_months,
            "source_cache_rows": source_rows,
            "source_cache_start": source_start.isoformat(),
            "source_cache_end_inclusive": source_end.isoformat(),
            "experiment_interval": experiment_interval,
            "target_split_intervals": split_intervals,
        },
        "model_spec": model_spec.to_dict(),
        "training": {
            "loss": "SmoothL1Loss",
            "learning_rate": training_config.learning_rate,
            "seed": training_config.seed,
            "requested_epochs": training_config.epochs,
            **trained.history.to_dict(),
        },
        "model": model_metrics,
        "model_raw": raw_model_metrics,
        "model_physical": model_metrics,
        "physical_postprocessing": postprocessing,
        "validation_physical_postprocessing": validation_postprocessing,
        "persistence": persistence_metrics,
        "daily_seasonal_persistence": persistence_metrics,
        "daily_period_steps": daily_period_steps,
        "weekly_seasonal_persistence": weekly_persistence_metrics,
        "weekly_period_steps": weekly_period_steps,
        "last_value_persistence": last_value_persistence_metrics,
        "training_climatology": _metric_bundle(
            persistence_actual, test_climatology, target_columns
        ),
        "validation_selected_daily_weekly_blend": seasonal_blend_metrics,
        "seasonal_daily_persistence_weight": seasonal_weights,
        "operational_forecast": operational_metrics,
        "operational_neural_weight": operational_weights,
        "validation_selection_metrics": {
            "daily_seasonal_persistence": _metric_bundle(
                validation_actual, validation_daily, target_columns
            ),
            "weekly_seasonal_persistence": _metric_bundle(
                validation_actual, validation_weekly, target_columns
            ),
            "selected_daily_weekly_blend": _metric_bundle(
                validation_actual, validation_guardrail, target_columns
            ),
            "model_physical": _metric_bundle(
                validation_actual, validation_physical, target_columns
            ),
            "operational_forecast": _metric_bundle(
                validation_actual,
                _apply_target_blend(
                    validation_physical,
                    validation_guardrail,
                    operational_weights,
                    target_columns,
                ),
                target_columns,
            ),
        },
        "operational_selection_policy": (
            "Per-target convex weights are selected on validation MAE only. The held-out "
            "test interval is evaluated once after weights are frozen."
        ),
        "model_beats_persistence_mae": (
            model_metrics["overall"]["mae"] < persistence_metrics["overall"]["mae"]
        ),
        "model_beats_daily_seasonal_persistence_mae": (
            model_metrics["overall"]["mae"] < persistence_metrics["overall"]["mae"]
        ),
        "operational_beats_daily_seasonal_persistence_mae": (
            operational_metrics["overall"]["mae"] < persistence_metrics["overall"]["mae"]
        ),
        "evaluation_diagnostics": {
            "window_weighting": _window_overlap_audit(splits.test.target_row_ranges),
            "seasonal_reference": {
                "policy": (
                    "Daily, weekly, and aligned-history baselines use fixed elapsed "
                    "steps on the UTC-regular series, not calendar-day lookup."
                ),
                "validation_daily": _seasonal_reference_audit(
                    frame,
                    target_row_ranges=splits.validation.target_row_ranges,
                    period_steps=daily_period_steps,
                ),
                "validation_weekly": _seasonal_reference_audit(
                    frame,
                    target_row_ranges=splits.validation.target_row_ranges,
                    period_steps=weekly_period_steps,
                ),
                "test_daily_and_model_aligned_history": _seasonal_reference_audit(
                    frame,
                    target_row_ranges=splits.test.target_row_ranges,
                    period_steps=daily_period_steps,
                ),
                "test_weekly": _seasonal_reference_audit(
                    frame,
                    target_row_ranges=splits.test.target_row_ranges,
                    period_steps=weekly_period_steps,
                ),
            },
            "non_overlapping_test_windows": {
                "model_physical": _non_overlapping_metric_bundle(
                    persistence_actual,
                    physical_predictions,
                    splits.test.target_row_ranges,
                    target_columns,
                ),
                "daily_seasonal_persistence": _non_overlapping_metric_bundle(
                    persistence_actual,
                    daily_persistence,
                    splits.test.target_row_ranges,
                    target_columns,
                ),
                "validation_selected_daily_weekly_blend": _non_overlapping_metric_bundle(
                    persistence_actual,
                    test_guardrail,
                    splits.test.target_row_ranges,
                    target_columns,
                ),
                "operational_forecast": _non_overlapping_metric_bundle(
                    persistence_actual,
                    operational_predictions,
                    splits.test.target_row_ranges,
                    target_columns,
                ),
            },
            "pv_conditioned": {
                "model_physical": _pv_conditioned_metrics(
                    frame,
                    persistence_actual,
                    physical_predictions,
                    splits.test.target_row_ranges,
                    pv_target_index=1,
                ),
                "daily_seasonal_persistence": _pv_conditioned_metrics(
                    frame,
                    persistence_actual,
                    daily_persistence,
                    splits.test.target_row_ranges,
                    pv_target_index=1,
                ),
                "operational_forecast": _pv_conditioned_metrics(
                    frame,
                    persistence_actual,
                    operational_predictions,
                    splits.test.target_row_ranges,
                    pv_target_index=1,
                ),
            },
        },
        "interpretation": (
            "A smoke run verifies the pipeline only; accuracy claims require the full "
            "chronological experiment and repeated seeds. The operational output is a "
            "validation-selected blend; its weights never use held-out test targets."
            if quick
            else (
                "Metrics are from the held-out chronological test interval; baselines "
                "include fixed 24-hour and 7-day seasonal persistence. Daily/weekly and "
                "neural/seasonal blend weights were frozen using validation data."
            )
        ),
    }
    metrics_path = output / "forecast_metrics.json"
    history_path = output / "training_history.csv"
    pd.DataFrame(
        {
            "epoch": np.arange(1, len(trained.history.train_loss) + 1),
            "train_loss": trained.history.train_loss,
            "validation_loss": trained.history.validation_loss,
        }
    ).to_csv(history_path, index=False)
    predictions_path = output / "first_test_forecast.csv"
    target_starts = splits.test.target_row_ranges[:, 0]
    aligned_samples: list[int] = []
    local_timezone = "America/Los_Angeles"
    for sample, row in enumerate(target_starts):
        last_row = int(row) + experiment_config.horizon_steps - 1
        if last_row >= len(frame):
            continue
        local_start = frame.index[int(row)].tz_convert(local_timezone)
        local_end = frame.index[last_row].tz_convert(local_timezone)
        if (
            local_start.hour == 0
            and local_start.minute == 0
            and local_end.hour == 23
            and local_end.minute == 45
            and local_start.date() == local_end.date()
        ):
            aligned_samples.append(sample)
    if not aligned_samples:
        raise ValueError("test split has no complete local calendar day for dispatch export")
    export_sample = aligned_samples[0]
    first_target_start = int(target_starts[export_sample])
    forecast_timestamps = frame.index[
        first_target_start : first_target_start + experiment_config.horizon_steps
    ]
    first_actual = persistence_actual[export_sample]
    first_model_raw = predictions.predicted[export_sample]
    first_model = physical_predictions[export_sample]
    first_climatology = test_climatology[export_sample]
    first_guardrail = test_guardrail[export_sample]
    first_operational = operational_predictions[export_sample]
    first_daily_persistence = daily_persistence[export_sample]
    first_last_value_persistence = last_value_persistence[export_sample]
    export_frame = pd.DataFrame(
        {
            "timestamp": forecast_timestamps,
            "horizon_step": np.arange(1, experiment_config.horizon_steps + 1),
            "load_actual_kw": first_actual[:, 0],
            "load_model_kw": first_model[:, 0],
            "load_model_raw_kw": first_model_raw[:, 0],
            "load_operational_kw": first_operational[:, 0],
            "load_climatology_kw": first_climatology[:, 0],
            "load_guardrail_kw": first_guardrail[:, 0],
            "load_persistence_kw": first_daily_persistence[:, 0],
            "load_daily_persistence_kw": first_daily_persistence[:, 0],
            "load_weekly_persistence_kw": weekly_persistence[export_sample, :, 0],
            "load_last_value_persistence_kw": first_last_value_persistence[:, 0],
            "pv_actual_kw": first_actual[:, 1],
            "pv_model_kw": first_model[:, 1],
            "pv_model_raw_kw": first_model_raw[:, 1],
            "pv_operational_kw": first_operational[:, 1],
            "pv_climatology_kw": first_climatology[:, 1],
            "pv_guardrail_kw": first_guardrail[:, 1],
            "pv_persistence_kw": first_daily_persistence[:, 1],
            "pv_daily_persistence_kw": first_daily_persistence[:, 1],
            "pv_weekly_persistence_kw": weekly_persistence[export_sample, :, 1],
            "pv_last_value_persistence_kw": first_last_value_persistence[:, 1],
        }
    )
    export_frame.to_csv(predictions_path, index=False)
    local_export_start = forecast_timestamps[0].tz_convert(local_timezone)
    local_export_end = forecast_timestamps[-1].tz_convert(local_timezone)
    payload["dispatch_export"] = {
        "filename": predictions_path.name,
        "sha256": _file_sha256(predictions_path),
        "rows": int(len(export_frame)),
        "start": forecast_timestamps[0].isoformat(),
        "end_inclusive": forecast_timestamps[-1].isoformat(),
        "local_timezone": local_timezone,
        "local_date": local_export_start.date().isoformat(),
        "local_start": local_export_start.isoformat(),
        "local_end_inclusive": local_export_end.isoformat(),
        "is_complete_local_calendar_day": True,
    }
    metrics_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return ForecastExperimentResult(
        artifact_path=artifact_path,
        metrics_path=metrics_path,
        history_path=history_path,
        predictions_path=predictions_path,
        model_metrics=model_metrics,
        raw_model_metrics=raw_model_metrics,
        persistence_metrics=persistence_metrics,
        last_value_persistence_metrics=last_value_persistence_metrics,
        weekly_persistence_metrics=weekly_persistence_metrics,
        seasonal_blend_metrics=seasonal_blend_metrics,
        operational_metrics=operational_metrics,
        validation_blend_weights={
            "seasonal_daily_persistence_weight": seasonal_weights,
            "operational_neural_weight": operational_weights,
        },
        postprocessing=postprocessing,
        rows=len(frame),
        train_windows=len(splits.train),
        validation_windows=len(splits.validation),
        test_windows=len(splits.test),
    )


def export_socal_test_daily_forecasts(
    cache_path: str | Path,
    artifact_path: str | Path,
    metrics_path: str | Path,
    output_dir: str | Path,
    config: ForecastConfig,
) -> DailyForecastExportResult:
    """Recreate every complete held-out local day from an authenticated v5 artifact.

    This performs inference only. It deliberately reconstructs the chronological
    split and validates the saved scalers, cache hash, and split boundaries before
    exporting any row.
    """

    cache = Path(cache_path).resolve()
    artifact = Path(artifact_path).resolve()
    sidecar = Path(metrics_path).resolve()
    for label, path in (("SoCal cache", cache), ("forecast artifact", artifact), ("metrics", sidecar)):
        if not path.is_file():
            raise FileNotFoundError(f"{label} not found: {path}")

    cache_manifest = verify_socal_cache_manifest(cache)
    try:
        metrics = json.loads(sidecar.read_text(encoding="utf-8"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid forecast metrics sidecar: {sidecar}") from exc
    if metrics.get("schema_version") != "qingheng.forecast-metrics.v5":
        raise ValueError("daily export requires a qingheng.forecast-metrics.v5 sidecar")
    _verify_optional_artifact_binding(metrics, artifact)
    provenance = metrics.get("data_provenance")
    if not isinstance(provenance, dict):
        raise ValueError("forecast metrics sidecar has no data_provenance")
    if provenance.get("cache_output_sha256") != cache_manifest.get("output_sha256"):
        raise ValueError("forecast artifact and current cache have different content hashes")
    derivation = cache_manifest.get("derivation")
    selected_months = (
        derivation.get("selected_complete_months") if isinstance(derivation, dict) else None
    )
    if provenance.get("selected_complete_months") != selected_months:
        raise ValueError("forecast artifact and cache have different complete-month selections")
    experiment = provenance.get("experiment_interval")
    if not isinstance(experiment, dict) or experiment.get("quick_truncation") is not False:
        raise ValueError("rolling daily export requires an untruncated full forecast experiment")

    raw = pd.read_parquet(cache)
    frame = prepare_socal_forecast_frame(raw, expected_minutes=config.resample_minutes)
    if provenance.get("source_cache_rows") != len(frame):
        raise ValueError("forecast source row count differs from the current cache")
    loaded = load_forecast_artifact(artifact, device="cpu")
    if loaded.metadata.get("cache_output_sha256") != cache_manifest.get("output_sha256"):
        raise ValueError("saved model metadata does not match the current cache hash")
    if loaded.metadata.get("selected_complete_months") != selected_months:
        raise ValueError("saved model metadata does not match the complete-month selection")
    if loaded.model.spec.horizon_steps != config.horizon_steps:
        raise ValueError("forecast config horizon does not match the saved model")

    splits = prepare_windowed_data(
        frame,
        feature_columns=loaded.feature_columns,
        target_columns=loaded.target_columns,
        input_steps=config.input_steps,
        horizon_steps=config.horizon_steps,
    )
    if not (
        np.allclose(splits.feature_scaler.mean, loaded.feature_scaler.mean, atol=1e-12)
        and np.allclose(splits.feature_scaler.scale, loaded.feature_scaler.scale, atol=1e-12)
        and np.allclose(splits.target_scaler.mean, loaded.target_scaler.mean, atol=1e-12)
        and np.allclose(splits.target_scaler.scale, loaded.target_scaler.scale, atol=1e-12)
    ):
        raise ValueError("reconstructed training-only scalers do not match the saved artifact")
    interval = pd.Timedelta(minutes=config.resample_minutes)
    reconstructed_intervals = {
        "train": _target_interval_summary(frame, splits.train.target_row_ranges, interval=interval),
        "validation": _target_interval_summary(
            frame, splits.validation.target_row_ranges, interval=interval
        ),
        "test": _target_interval_summary(frame, splits.test.target_row_ranges, interval=interval),
    }
    if provenance.get("target_split_intervals") != reconstructed_intervals:
        raise ValueError("reconstructed chronological split does not match the v5 sidecar")

    local_timezone = "America/Los_Angeles"
    selected_indices = _complete_local_day_sample_indices(
        frame.index,
        splits.test.target_row_ranges,
        horizon_steps=config.horizon_steps,
        timezone=local_timezone,
    )
    if len(selected_indices) == 0:
        raise ValueError("held-out test split has no complete fixed 24-hour local calendar day")
    selected_ranges = splits.test.target_row_ranges[selected_indices]
    subset = _WindowSubset(splits.test, selected_indices)
    predicted = predict_dataset(
        loaded.model,
        subset,  # type: ignore[arg-type]
        target_scaler=loaded.target_scaler,
        batch_size=min(256, len(subset)),
        device="cpu",
    )
    actual = _target_values_from_frame(
        frame,
        target_columns=loaded.target_columns,
        target_row_ranges=selected_ranges,
    )
    daily = _seasonal_lag_predictions(
        frame,
        target_columns=loaded.target_columns,
        target_row_ranges=selected_ranges,
        period_steps=24 * 60 // config.resample_minutes,
    )
    weekly = _seasonal_lag_predictions(
        frame,
        target_columns=loaded.target_columns,
        target_row_ranges=selected_ranges,
        period_steps=7 * 24 * 60 // config.resample_minutes,
    )
    physical, _ = clip_nonnegative_predictions(predicted.predicted, loaded.target_columns)
    seasonal_weights = metrics.get("seasonal_daily_persistence_weight")
    operational_weights = metrics.get("operational_neural_weight")
    if not isinstance(seasonal_weights, dict) or not isinstance(operational_weights, dict):
        raise ValueError("v5 sidecar is missing validation-frozen blend weights")
    guardrail = _apply_target_blend(
        daily, weekly, seasonal_weights, loaded.target_columns
    )
    operational = _apply_target_blend(
        physical, guardrail, operational_weights, loaded.target_columns
    )
    climatology = _training_climatology_predictions(
        frame,
        target_columns=loaded.target_columns,
        train_end=splits.boundaries.train_end,
        target_row_ranges=selected_ranges,
    )
    last_value_scaled = splits.test.persistence_predictions()[selected_indices]
    last_value = loaded.target_scaler.inverse_transform(last_value_scaled)

    records: list[pd.DataFrame] = []
    for output_sample, (raw_start, raw_stop) in enumerate(selected_ranges):
        start = int(raw_start)
        stop = int(raw_stop)
        timestamps = frame.index[start:stop]
        local_date = timestamps[0].tz_convert(local_timezone).date().isoformat()
        sample = pd.DataFrame(
            {
                "timestamp": timestamps,
                "forecast_origin": np.repeat(timestamps[0], len(timestamps)),
                "local_date": local_date,
                "horizon_step": np.arange(1, config.horizon_steps + 1),
                "load_actual_kw": actual[output_sample, :, 0],
                "load_model_kw": physical[output_sample, :, 0],
                "load_model_raw_kw": predicted.predicted[output_sample, :, 0],
                "load_operational_kw": operational[output_sample, :, 0],
                "load_climatology_kw": climatology[output_sample, :, 0],
                "load_guardrail_kw": guardrail[output_sample, :, 0],
                "load_persistence_kw": daily[output_sample, :, 0],
                "load_daily_persistence_kw": daily[output_sample, :, 0],
                "load_weekly_persistence_kw": weekly[output_sample, :, 0],
                "load_last_value_persistence_kw": last_value[output_sample, :, 0],
                "pv_actual_kw": actual[output_sample, :, 1],
                "pv_model_kw": physical[output_sample, :, 1],
                "pv_model_raw_kw": predicted.predicted[output_sample, :, 1],
                "pv_operational_kw": operational[output_sample, :, 1],
                "pv_climatology_kw": climatology[output_sample, :, 1],
                "pv_guardrail_kw": guardrail[output_sample, :, 1],
                "pv_persistence_kw": daily[output_sample, :, 1],
                "pv_daily_persistence_kw": daily[output_sample, :, 1],
                "pv_weekly_persistence_kw": weekly[output_sample, :, 1],
                "pv_last_value_persistence_kw": last_value[output_sample, :, 1],
            }
        )
        records.append(sample)
    export = pd.concat(records, ignore_index=True)

    authenticated = metrics.get("dispatch_export")
    if not isinstance(authenticated, dict):
        raise ValueError("v5 sidecar has no authenticated single-day dispatch export")
    authenticated_path = sidecar.parent / str(authenticated.get("filename", ""))
    if not authenticated_path.is_file() or _file_sha256(authenticated_path) != authenticated.get(
        "sha256"
    ):
        raise ValueError("authenticated single-day forecast is missing or has changed")
    first_date = str(authenticated.get("local_date"))
    recreated = export.loc[export["local_date"] == first_date].copy()
    original = pd.read_csv(authenticated_path, parse_dates=["timestamp"])
    if len(recreated) != len(original):
        raise ValueError("recreated first dispatch day has a different row count")
    recreated_timestamps = pd.to_datetime(recreated["timestamp"], utc=True)
    original_timestamps = pd.to_datetime(original["timestamp"], utc=True)
    if not recreated_timestamps.reset_index(drop=True).equals(
        original_timestamps.reset_index(drop=True)
    ):
        raise ValueError("recreated first dispatch day has different timestamps")
    common_numeric = [
        column
        for column in original.columns
        if column != "timestamp" and column in recreated.columns
    ]
    if not np.allclose(
        recreated.loc[:, common_numeric].to_numpy(dtype=float),
        original.loc[:, common_numeric].to_numpy(dtype=float),
        rtol=1e-7,
        atol=1e-6,
    ):
        raise ValueError("saved artifact does not reproduce the authenticated dispatch day")

    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    csv_path = output / "all_test_daily_forecasts.csv"
    manifest_path = output / "all_test_daily_forecasts_manifest.json"
    export.to_csv(csv_path, index=False)
    csv_sha256 = _file_sha256(csv_path)
    local_dates = export["local_date"].drop_duplicates().tolist()
    manifest = {
        "schema_version": "qingheng.daily-forecast-export.v1",
        "source": {
            "forecast_metrics": str(sidecar),
            "forecast_metrics_schema": metrics["schema_version"],
            "forecast_artifact": str(artifact),
            "forecast_artifact_sha256": _file_sha256(artifact),
            "cache": str(cache),
            "cache_output_sha256": cache_manifest["output_sha256"],
            "selected_complete_months": selected_months,
            "target_split_intervals": reconstructed_intervals,
            "authenticated_dispatch_export_sha256": authenticated["sha256"],
        },
        "output": {
            "filename": csv_path.name,
            "sha256": csv_sha256,
            "rows": int(len(export)),
            "complete_local_days": len(local_dates),
            "first_local_date": local_dates[0],
            "last_local_date": local_dates[-1],
            "local_timezone": local_timezone,
            "steps_per_day": config.horizon_steps,
        },
        "rolling_forecast_policy": {
            "first_24_hours": "validation-frozen operational forecast issued at local midnight",
            "next_24_hours": (
                "seven-day seasonal persistence for the following local day; its reference "
                "day is fully observed at the current local-midnight decision origin"
            ),
            "future_actual_inputs_used": False,
        },
    }
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=True), encoding="utf-8"
    )
    return DailyForecastExportResult(
        csv_path=csv_path,
        manifest_path=manifest_path,
        rows=len(export),
        days=len(local_dates),
        sha256=csv_sha256,
    )
