"""Deterministic training, early stopping, inference, and model artifacts."""

from __future__ import annotations

import copy
import json
import random
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Mapping

import numpy as np

from .data import StandardScaler, WindowDataset, WindowedSplits, require_torch
from .metrics import regression_metrics
from .model import CNNLSTMAttention, ModelSpec

try:
    import torch
    from torch import nn
    from torch.utils.data import DataLoader
except ImportError:  # pragma: no cover - exercised in environments without the extra
    torch = None
    nn = None
    DataLoader = None


@dataclass(frozen=True)
class TrainingConfig:
    epochs: int = 30
    learning_rate: float = 1e-3
    weight_decay: float = 1e-5
    patience: int = 6
    min_delta: float = 1e-5
    gradient_clip: float | None = 1.0
    seed: int = 20260714
    device: str = "auto"
    loss: str = "smooth_l1"
    huber_beta: float = 0.5

    def __post_init__(self) -> None:
        if self.epochs <= 0 or self.learning_rate <= 0 or self.patience <= 0:
            raise ValueError("epochs, learning_rate, and patience must be positive")
        if self.weight_decay < 0 or self.min_delta < 0:
            raise ValueError("weight_decay and min_delta cannot be negative")
        if self.gradient_clip is not None and self.gradient_clip <= 0:
            raise ValueError("gradient_clip must be positive when provided")
        if self.loss not in {"mse", "smooth_l1"}:
            raise ValueError("loss must be 'mse' or 'smooth_l1'")
        if self.huber_beta <= 0:
            raise ValueError("huber_beta must be positive")


@dataclass
class TrainingHistory:
    train_loss: list[float] = field(default_factory=list)
    validation_loss: list[float] = field(default_factory=list)
    best_epoch: int = 0
    best_validation_loss: float = float("inf")
    stopped_early: bool = False
    initial_validation_loss: float = float("inf")
    residual_gains: list[float] = field(default_factory=list)
    calibrated_validation_mae: float = float("inf")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "TrainingHistory":
        return cls(
            train_loss=[float(value) for value in payload.get("train_loss", [])],
            validation_loss=[float(value) for value in payload.get("validation_loss", [])],
            best_epoch=int(payload.get("best_epoch", 0)),
            best_validation_loss=float(payload.get("best_validation_loss", float("inf"))),
            stopped_early=bool(payload.get("stopped_early", False)),
            initial_validation_loss=float(payload.get("initial_validation_loss", float("inf"))),
            residual_gains=[float(value) for value in payload.get("residual_gains", [])],
            calibrated_validation_mae=float(payload.get("calibrated_validation_mae", float("inf"))),
        )


@dataclass(frozen=True)
class ForecastPredictions:
    predicted: np.ndarray
    actual: np.ndarray

    def metrics(self) -> dict[str, float]:
        return regression_metrics(self.actual, self.predicted)


@dataclass
class TrainingResult:
    model: CNNLSTMAttention
    history: TrainingHistory
    artifact_path: Path


@dataclass
class LoadedForecastArtifact:
    model: CNNLSTMAttention
    feature_scaler: StandardScaler
    target_scaler: StandardScaler
    feature_columns: tuple[str, ...]
    target_columns: tuple[str, ...]
    history: TrainingHistory
    metadata: dict[str, Any]


def set_reproducible_seed(seed: int) -> None:
    """Seed Python, NumPy, and PyTorch and request deterministic kernels."""

    random.seed(seed)
    np.random.seed(seed)
    if torch is None:
        return
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(True, warn_only=True)
    if torch.backends.cudnn.is_available():
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True


def resolve_device(requested: str = "auto") -> Any:
    require_torch()
    normalized = requested.lower()
    if normalized == "auto":
        normalized = "cuda" if torch.cuda.is_available() else "cpu"
    if normalized.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available")
    try:
        return torch.device(normalized)
    except (RuntimeError, ValueError) as exc:
        raise ValueError(f"Invalid PyTorch device: {requested}") from exc


def _epoch_loss(
    model: Any,
    loader: Any,
    loss_function: Any,
    device: Any,
    optimizer: Any | None,
    gradient_clip: float | None,
) -> float:
    training = optimizer is not None
    model.train(training)
    total_loss = 0.0
    total_samples = 0
    context = torch.enable_grad() if training else torch.no_grad()
    with context:
        for inputs, targets in loader:
            inputs = inputs.to(device=device, dtype=torch.float32, non_blocking=True)
            targets = targets.to(device=device, dtype=torch.float32, non_blocking=True)
            if training:
                optimizer.zero_grad(set_to_none=True)
            outputs = model(inputs)
            loss = loss_function(outputs, targets)
            if training:
                loss.backward()
                if gradient_clip is not None:
                    nn.utils.clip_grad_norm_(model.parameters(), gradient_clip)
                optimizer.step()
            batch_size = int(inputs.shape[0])
            total_loss += float(loss.detach().cpu()) * batch_size
            total_samples += batch_size
    if total_samples == 0:
        raise ValueError("DataLoader is empty")
    return total_loss / total_samples


def _calibrate_residual_gains(
    model: CNNLSTMAttention,
    validation_loader: Any,
    device: Any,
) -> tuple[list[float], float]:
    """Shrink each target correction using validation MAE, then bake it into the head."""

    if model.spec.residual_baseline != "aligned_history":
        return [], float("inf")
    model.eval()
    baselines: list[np.ndarray] = []
    corrections: list[np.ndarray] = []
    actuals: list[np.ndarray] = []
    indices = list(model.spec.resolved_target_feature_indices)
    with torch.no_grad():
        for inputs, targets in validation_loader:
            inputs = inputs.to(device=device, dtype=torch.float32, non_blocking=True)
            outputs = model(inputs)
            reference_start = inputs.shape[1] - model.spec.resolved_residual_period_steps
            reference_stop = reference_start + model.spec.horizon_steps
            baseline = inputs[:, reference_start:reference_stop, indices]
            baselines.append(baseline.cpu().numpy())
            corrections.append((outputs - baseline).cpu().numpy())
            actuals.append(targets.numpy())

    baseline_values = np.concatenate(baselines, axis=0)
    correction_values = np.concatenate(corrections, axis=0)
    actual_values = np.concatenate(actuals, axis=0)
    candidates = np.linspace(0.0, 1.0, 101, dtype=np.float64)
    gains: list[float] = []
    for target in range(model.spec.target_count):
        baseline_target = baseline_values[..., target]
        correction_target = correction_values[..., target]
        actual_target = actual_values[..., target]
        losses = [
            float(np.mean(np.abs(actual_target - (baseline_target + gain * correction_target))))
            for gain in candidates
        ]
        gains.append(float(candidates[int(np.argmin(losses))]))

    projection = model.output[-1]
    with torch.no_grad():
        for target, gain in enumerate(gains):
            projection.weight[target :: model.spec.target_count].mul_(gain)
            projection.bias[target :: model.spec.target_count].mul_(gain)

    calibrated = baseline_values + correction_values * np.asarray(gains)[None, None, :]
    calibrated_mae = float(np.mean(np.abs(actual_values - calibrated)))
    return gains, calibrated_mae


def fit_model(
    model: CNNLSTMAttention,
    train_loader: Any,
    validation_loader: Any,
    config: TrainingConfig,
) -> TrainingHistory:
    """Train a residual model and retain the untrained baseline as a checkpoint."""

    require_torch()
    set_reproducible_seed(config.seed)
    device = resolve_device(config.device)
    model.to(device)
    loss_function = (
        nn.MSELoss() if config.loss == "mse" else nn.SmoothL1Loss(beta=config.huber_beta)
    )
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=config.learning_rate,
        weight_decay=config.weight_decay,
    )
    history = TrainingHistory()
    initial_validation_loss = _epoch_loss(
        model,
        validation_loader,
        loss_function,
        device,
        optimizer=None,
        gradient_clip=None,
    )
    history.initial_validation_loss = initial_validation_loss
    history.best_validation_loss = initial_validation_loss
    history.best_epoch = 0
    best_state: dict[str, Any] | None = copy.deepcopy(model.state_dict())
    stale_epochs = 0

    for epoch in range(1, config.epochs + 1):
        train_loss = _epoch_loss(
            model,
            train_loader,
            loss_function,
            device,
            optimizer,
            config.gradient_clip,
        )
        validation_loss = _epoch_loss(
            model,
            validation_loader,
            loss_function,
            device,
            optimizer=None,
            gradient_clip=None,
        )
        history.train_loss.append(train_loss)
        history.validation_loss.append(validation_loss)

        if validation_loss < history.best_validation_loss - config.min_delta:
            history.best_validation_loss = validation_loss
            history.best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            stale_epochs = 0
        else:
            stale_epochs += 1
            if stale_epochs >= config.patience:
                history.stopped_early = True
                break

    if best_state is None:  # pragma: no cover - defensive; initialized above
        raise RuntimeError("Training did not produce a finite validation checkpoint")
    model.load_state_dict(best_state)
    history.residual_gains, history.calibrated_validation_mae = _calibrate_residual_gains(
        model,
        validation_loader,
        device,
    )
    return history


def save_forecast_artifact(
    path: str | Path,
    *,
    model: CNNLSTMAttention,
    feature_scaler: StandardScaler,
    target_scaler: StandardScaler,
    feature_columns: tuple[str, ...],
    target_columns: tuple[str, ...],
    history: TrainingHistory,
    metadata: Mapping[str, Any] | None = None,
) -> Path:
    """Save weights plus all preprocessing state needed for reproducible inference."""

    require_torch()
    artifact_path = Path(path)
    artifact_path.parent.mkdir(parents=True, exist_ok=True)
    metadata_json = json.dumps(dict(metadata or {}), ensure_ascii=True, sort_keys=True)
    history_json = json.dumps(history.to_dict(), ensure_ascii=True, sort_keys=True)
    payload = {
        "format_version": 1,
        "model_spec": model.spec.to_dict(),
        "model_state": model.state_dict(),
        "feature_scaler": feature_scaler.to_dict(),
        "target_scaler": target_scaler.to_dict(),
        "feature_columns": list(feature_columns),
        "target_columns": list(target_columns),
        "history_json": history_json,
        "metadata_json": metadata_json,
    }
    torch.save(payload, artifact_path)
    return artifact_path


def load_forecast_artifact(
    path: str | Path,
    *,
    device: str = "cpu",
) -> LoadedForecastArtifact:
    require_torch()
    map_location = resolve_device(device)
    try:
        payload = torch.load(Path(path), map_location=map_location, weights_only=True)
    except TypeError:  # PyTorch before the weights_only parameter
        payload = torch.load(Path(path), map_location=map_location)
    if not isinstance(payload, Mapping):
        raise ValueError("Forecast artifact payload must be a mapping")
    if int(payload.get("format_version", -1)) != 1:
        raise ValueError("Unsupported forecast artifact format")

    required = {
        "model_spec",
        "model_state",
        "feature_scaler",
        "target_scaler",
        "feature_columns",
        "target_columns",
        "history_json",
        "metadata_json",
    }
    missing = sorted(required - set(payload))
    if missing:
        raise ValueError(f"Forecast artifact is missing required fields: {missing}")

    try:
        spec = ModelSpec.from_dict(dict(payload["model_spec"]))
        feature_scaler = StandardScaler.from_dict(payload["feature_scaler"])
        target_scaler = StandardScaler.from_dict(payload["target_scaler"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("Forecast artifact contains invalid model or scaler state") from exc

    feature_columns = _artifact_columns(payload["feature_columns"], "feature_columns")
    target_columns = _artifact_columns(payload["target_columns"], "target_columns")
    if len(feature_columns) != spec.input_features:
        raise ValueError("Forecast artifact feature_columns do not match model input_features")
    if len(target_columns) != spec.target_count:
        raise ValueError("Forecast artifact target_columns do not match model target_count")
    if feature_scaler.mean.size != len(feature_columns):
        raise ValueError("Forecast artifact feature scaler width does not match feature_columns")
    if target_scaler.mean.size != len(target_columns):
        raise ValueError("Forecast artifact target scaler width does not match target_columns")
    if spec.residual_baseline == "aligned_history":
        indices = spec.resolved_target_feature_indices
        residual_columns = tuple(feature_columns[index] for index in indices)
        if residual_columns != target_columns:
            raise ValueError(
                "Forecast artifact aligned-history feature columns do not match target_columns"
            )
        if not (
            np.allclose(feature_scaler.mean[list(indices)], target_scaler.mean)
            and np.allclose(feature_scaler.scale[list(indices)], target_scaler.scale)
        ):
            raise ValueError(
                "Forecast artifact aligned-history feature and target scalers are incompatible"
            )

    history_payload = _artifact_json_mapping(payload["history_json"], "history_json")
    metadata = _artifact_json_mapping(payload["metadata_json"], "metadata_json")
    model = CNNLSTMAttention(spec)
    try:
        model.load_state_dict(payload["model_state"])
    except (TypeError, RuntimeError) as exc:
        raise ValueError("Forecast artifact model_state is incompatible with model_spec") from exc
    model.to(map_location)
    model.eval()
    return LoadedForecastArtifact(
        model=model,
        feature_scaler=feature_scaler,
        target_scaler=target_scaler,
        feature_columns=feature_columns,
        target_columns=target_columns,
        history=TrainingHistory.from_dict(history_payload),
        metadata=metadata,
    )


def _artifact_columns(payload: Any, name: str) -> tuple[str, ...]:
    if not isinstance(payload, (list, tuple)) or not payload:
        raise ValueError(f"Forecast artifact {name} must be a non-empty sequence")
    columns = tuple(payload)
    if any(not isinstance(column, str) or not column for column in columns):
        raise ValueError(f"Forecast artifact {name} must contain non-empty strings")
    if len(set(columns)) != len(columns):
        raise ValueError(f"Forecast artifact {name} cannot contain duplicates")
    return columns


def _artifact_json_mapping(payload: Any, name: str) -> dict[str, Any]:
    if not isinstance(payload, str):
        raise ValueError(f"Forecast artifact {name} must be JSON text")
    try:
        decoded = json.loads(payload)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Forecast artifact {name} is invalid JSON") from exc
    if not isinstance(decoded, dict):
        raise ValueError(f"Forecast artifact {name} must decode to an object")
    return decoded


def train_forecaster(
    splits: WindowedSplits,
    *,
    spec: ModelSpec,
    training: TrainingConfig,
    artifact_path: str | Path,
    batch_size: int = 64,
    num_workers: int = 0,
    metadata: Mapping[str, Any] | None = None,
) -> TrainingResult:
    """End-to-end training entry point used by the pipeline and notebook."""

    require_torch()
    if batch_size <= 0 or num_workers < 0:
        raise ValueError("batch_size must be positive and num_workers cannot be negative")
    if spec.input_features != len(splits.feature_columns):
        raise ValueError("Model input_features does not match prepared feature columns")
    if spec.target_count != len(splits.target_columns):
        raise ValueError("Model target_count does not match prepared target columns")
    if spec.horizon_steps != splits.train.horizon_steps:
        raise ValueError("Model horizon_steps does not match prepared windows")
    if spec.residual_baseline == "aligned_history":
        if spec.resolved_residual_period_steps > splits.train.input_steps:
            raise ValueError(
                "aligned_history residual_period_steps cannot exceed prepared input_steps"
            )
        indices = spec.resolved_target_feature_indices
        residual_feature_columns = tuple(splits.feature_columns[index] for index in indices)
        if residual_feature_columns != splits.target_columns:
            raise ValueError(
                "aligned_history target features must match target_columns in the same order; "
                "set target_feature_indices explicitly or use residual_baseline='none'"
            )
        if not (
            np.allclose(splits.feature_scaler.mean[list(indices)], splits.target_scaler.mean)
            and np.allclose(splits.feature_scaler.scale[list(indices)], splits.target_scaler.scale)
        ):
            raise ValueError(
                "aligned_history target features and targets must share scaling coordinates"
            )

    set_reproducible_seed(training.seed)
    generator = torch.Generator()
    generator.manual_seed(training.seed)
    train_loader = DataLoader(
        splits.train,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        generator=generator,
    )
    validation_loader = DataLoader(
        splits.validation,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
    )
    model = CNNLSTMAttention(spec)
    history = fit_model(model, train_loader, validation_loader, training)
    saved_path = save_forecast_artifact(
        artifact_path,
        model=model,
        feature_scaler=splits.feature_scaler,
        target_scaler=splits.target_scaler,
        feature_columns=splits.feature_columns,
        target_columns=splits.target_columns,
        history=history,
        metadata=metadata,
    )
    return TrainingResult(model=model, history=history, artifact_path=saved_path)


def predict_dataset(
    model: CNNLSTMAttention,
    dataset: WindowDataset,
    *,
    target_scaler: StandardScaler | None = None,
    batch_size: int = 256,
    device: str = "auto",
) -> ForecastPredictions:
    """Predict a dataset in chronological order, optionally in original units."""

    require_torch()
    if batch_size <= 0:
        raise ValueError("batch_size must be positive")
    resolved_device = resolve_device(device)
    model.to(resolved_device)
    model.eval()
    predicted_batches: list[np.ndarray] = []
    actual_batches: list[np.ndarray] = []
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
    with torch.no_grad():
        for inputs, targets in loader:
            outputs = model(inputs.to(resolved_device, dtype=torch.float32))
            predicted_batches.append(outputs.cpu().numpy())
            actual_batches.append(targets.numpy())
    predicted = np.concatenate(predicted_batches, axis=0)
    actual = np.concatenate(actual_batches, axis=0)
    if target_scaler is not None:
        predicted = target_scaler.inverse_transform(predicted)
        actual = target_scaler.inverse_transform(actual)
    return ForecastPredictions(predicted=predicted, actual=actual)
