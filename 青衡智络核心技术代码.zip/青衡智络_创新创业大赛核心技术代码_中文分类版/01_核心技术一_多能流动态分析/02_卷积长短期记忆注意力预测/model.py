"""CNN-LSTM-Attention model for multi-target, multi-horizon forecasts."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from .data import require_torch

try:
    import torch
    from torch import nn
except ImportError:  # pragma: no cover - exercised in environments without the extra
    torch = None
    nn = None


@dataclass(frozen=True)
class ModelSpec:
    input_features: int
    target_count: int
    horizon_steps: int
    conv_channels: int = 32
    kernel_size: int = 3
    hidden_size: int = 64
    lstm_layers: int = 1
    attention_heads: int = 4
    dropout: float = 0.1
    residual_baseline: str = "aligned_history"
    residual_period_steps: int | None = None
    target_feature_indices: tuple[int, ...] | None = None

    def __post_init__(self) -> None:
        positive = {
            "input_features": self.input_features,
            "target_count": self.target_count,
            "horizon_steps": self.horizon_steps,
            "conv_channels": self.conv_channels,
            "kernel_size": self.kernel_size,
            "hidden_size": self.hidden_size,
            "lstm_layers": self.lstm_layers,
            "attention_heads": self.attention_heads,
        }
        invalid = [name for name, value in positive.items() if value <= 0]
        if invalid:
            raise ValueError(f"Model dimensions must be positive: {invalid}")
        if self.kernel_size % 2 == 0:
            raise ValueError("kernel_size must be odd so temporal length is preserved")
        if self.hidden_size % self.attention_heads != 0:
            raise ValueError("hidden_size must be divisible by attention_heads")
        if not 0 <= self.dropout < 1:
            raise ValueError("dropout must be in [0, 1)")
        if self.residual_baseline not in {"none", "aligned_history"}:
            raise ValueError("residual_baseline must be 'none' or 'aligned_history'")
        if self.resolved_residual_period_steps < self.horizon_steps:
            raise ValueError("residual_period_steps cannot be shorter than horizon_steps")
        indices = self.resolved_target_feature_indices
        if len(indices) != self.target_count:
            raise ValueError("target_feature_indices must contain one index per target")
        if len(set(indices)) != len(indices):
            raise ValueError("target_feature_indices cannot contain duplicates")
        if any(index < 0 or index >= self.input_features for index in indices):
            raise ValueError("target_feature_indices must refer to model input features")

    @property
    def resolved_target_feature_indices(self) -> tuple[int, ...]:
        """Input columns that carry the targets in target-scaler coordinates."""

        if self.target_feature_indices is None:
            return tuple(range(self.target_count))
        return tuple(self.target_feature_indices)

    @property
    def resolved_residual_period_steps(self) -> int:
        """Seasonal offset used by the aligned-history residual baseline."""

        if self.residual_period_steps is None:
            return self.horizon_steps
        if self.residual_period_steps <= 0:
            raise ValueError("residual_period_steps must be positive")
        return self.residual_period_steps

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "ModelSpec":
        values = dict(payload)
        # Artifacts written before the residual architecture must retain their
        # original direct-forecast semantics when loaded.
        values.setdefault("residual_baseline", "none")
        if values.get("target_feature_indices") is not None:
            values["target_feature_indices"] = tuple(values["target_feature_indices"])
        return cls(**values)


if nn is not None:

    class CNNLSTMAttention(nn.Module):
        """CNN-LSTM-Attention residual forecaster over an aligned-history baseline."""

        def __init__(self, spec: ModelSpec) -> None:
            super().__init__()
            self.spec = spec
            self.temporal_conv = nn.Sequential(
                nn.Conv1d(
                    in_channels=spec.input_features,
                    out_channels=spec.conv_channels,
                    kernel_size=spec.kernel_size,
                    padding=spec.kernel_size // 2,
                ),
                nn.GELU(),
                nn.Dropout(spec.dropout),
            )
            self.recurrent = nn.LSTM(
                input_size=spec.conv_channels,
                hidden_size=spec.hidden_size,
                num_layers=spec.lstm_layers,
                batch_first=True,
                dropout=spec.dropout if spec.lstm_layers > 1 else 0.0,
            )
            self.self_attention = nn.MultiheadAttention(
                embed_dim=spec.hidden_size,
                num_heads=spec.attention_heads,
                dropout=spec.dropout,
                batch_first=True,
            )
            self.attention_norm = nn.LayerNorm(spec.hidden_size)
            self.pool_score = nn.Sequential(
                nn.Linear(spec.hidden_size, spec.hidden_size),
                nn.Tanh(),
                nn.Linear(spec.hidden_size, 1, bias=False),
            )
            self.output = nn.Sequential(
                nn.Dropout(spec.dropout),
                nn.Linear(spec.hidden_size, spec.horizon_steps * spec.target_count),
            )
            if spec.residual_baseline == "aligned_history":
                # An untrained model is exactly the strong seasonal baseline. The
                # network therefore learns corrections instead of relearning the
                # dominant daily profile from scratch.
                projection = self.output[-1]
                nn.init.zeros_(projection.weight)
                nn.init.zeros_(projection.bias)

        def forward(
            self,
            inputs: Any,
            *,
            return_attention: bool = False,
        ) -> Any:
            if inputs.ndim != 3:
                raise ValueError("inputs must have shape [batch, time, feature]")
            if inputs.shape[-1] != self.spec.input_features:
                raise ValueError(
                    f"Expected {self.spec.input_features} features, received {inputs.shape[-1]}"
                )

            convolved = self.temporal_conv(inputs.transpose(1, 2)).transpose(1, 2)
            recurrent, _ = self.recurrent(convolved)
            attended, _ = self.self_attention(
                recurrent,
                recurrent,
                recurrent,
                need_weights=False,
            )
            attended = self.attention_norm(recurrent + attended)
            pooling_weights = torch.softmax(self.pool_score(attended), dim=1)
            context = torch.sum(pooling_weights * attended, dim=1)
            correction = self.output(context).reshape(
                inputs.shape[0],
                self.spec.horizon_steps,
                self.spec.target_count,
            )
            if self.spec.residual_baseline == "aligned_history":
                period_steps = self.spec.resolved_residual_period_steps
                if inputs.shape[1] < period_steps:
                    raise ValueError(
                        "aligned_history residual baseline requires input time steps "
                        "to cover residual_period_steps"
                    )
                indices = list(self.spec.resolved_target_feature_indices)
                reference_start = inputs.shape[1] - period_steps
                reference_stop = reference_start + self.spec.horizon_steps
                baseline = inputs[:, reference_start:reference_stop, indices]
                forecast = baseline + correction
            else:
                forecast = correction
            if return_attention:
                return forecast, pooling_weights.squeeze(-1)
            return forecast

else:

    class CNNLSTMAttention:  # pragma: no cover - exercised without the optional extra
        """Dependency-error placeholder used when PyTorch is not installed."""

        def __init__(self, spec: ModelSpec) -> None:
            del spec
            require_torch()
