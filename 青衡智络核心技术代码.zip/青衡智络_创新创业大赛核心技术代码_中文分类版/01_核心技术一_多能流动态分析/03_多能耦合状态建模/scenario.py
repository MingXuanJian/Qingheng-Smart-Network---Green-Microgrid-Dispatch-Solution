from __future__ import annotations

import numpy as np
import pandas as pd

from qingheng.config import CarbonConfig, DispatchConfig
from qingheng.dispatch.problem import DispatchInputs


SOCAL_TIMEZONE = "America/Los_Angeles"


def make_builtin_scenario(
    dispatch: DispatchConfig,
    carbon: CarbonConfig | None = None,
    *,
    seed: int = 20260714,
) -> DispatchInputs:
    """Create a deterministic IEEE33-scale benchmark with transparent assumptions."""

    horizon = dispatch.horizon_steps
    dt = dispatch.step_hours
    hour = np.arange(horizon, dtype=np.float64) * dt
    day_hour = np.mod(hour, 24.0)
    rng = np.random.default_rng(seed)

    morning = 310.0 * np.exp(-0.5 * ((day_hour - 8.0) / 2.2) ** 2)
    evening = 520.0 * np.exp(-0.5 * ((day_hour - 19.0) / 2.8) ** 2)
    load = 900.0 + morning + evening + 45.0 * np.sin(2 * np.pi * day_hour / 24.0)
    load *= np.clip(1.0 + rng.normal(0.0, 0.015, horizon), 0.95, 1.05)

    solar_shape = np.sin(np.pi * np.clip((day_hour - 6.0) / 12.0, 0.0, 1.0))
    pv = 850.0 * np.maximum(solar_shape, 0.0) ** 1.7
    wind = 210.0 + 80.0 * np.sin(2 * np.pi * (day_hour + 3.0) / 24.0)
    wind += rng.normal(0.0, 18.0, horizon)
    wind = np.clip(wind, 60.0, 360.0)

    buy_price = np.full(horizon, 0.62)
    buy_price[(day_hour >= 7.0) & (day_hour < 10.0)] = 0.92
    buy_price[(day_hour >= 17.0) & (day_hour < 22.0)] = 1.18
    buy_price[(day_hour < 6.0)] = 0.38
    sell_price = dispatch.grid_export_price_fraction * buy_price

    carbon_cfg = carbon or CarbonConfig()
    grid_carbon = carbon_cfg.grid_kg_per_kwh * (
        1.0
        + 0.16 * np.exp(-0.5 * ((day_hour - 20.0) / 3.0) ** 2)
        - 0.12 * np.exp(-0.5 * ((day_hour - 13.0) / 3.0) ** 2)
    )
    fixed_fuel_cell = np.full(horizon, 90.0)
    fixed_factor = np.full(horizon, carbon_cfg.fuel_cell_kg_per_kwh)
    return DispatchInputs.from_arrays(
        load_kw=load,
        pv_available_kw=pv,
        wind_available_kw=wind,
        buy_price_per_kwh=buy_price,
        sell_price_per_kwh=sell_price,
        grid_carbon_kg_per_kwh=grid_carbon,
        pv_carbon_kg_per_kwh=np.full(horizon, carbon_cfg.pv_kg_per_kwh),
        wind_carbon_kg_per_kwh=np.full(horizon, carbon_cfg.wind_kg_per_kwh),
        fixed_generation_kw=fixed_fuel_cell,
        fixed_generation_carbon_kg_per_kwh=fixed_factor,
        battery_initial_stored_carbon_kg_per_kwh=(
            carbon_cfg.battery_initial_stored_carbon_kg_per_kwh
        ),
        hydrogen_initial_stored_carbon_kg_per_kwh=(
            carbon_cfg.hydrogen_initial_stored_carbon_kg_per_kwh
        ),
    )


def make_profile_dispatch_inputs(
    frame_15min: pd.DataFrame,
    dispatch: DispatchConfig,
    carbon: CarbonConfig | None = None,
    *,
    load_column: str = "load_kw",
    pv_column: str = "pv_kw",
    wind_column: str = "wind_kw",
    fixed_generation_column: str | None = None,
) -> DispatchInputs:
    """Aggregate one complete real/hybrid 15-minute horizon into hourly inputs."""

    if not isinstance(frame_15min.index, pd.DatetimeIndex):
        raise TypeError("frame_15min must use a DatetimeIndex")
    if abs(dispatch.step_hours - 1.0) > 1e-12:
        raise ValueError("profile aggregation currently requires one-hour dispatch steps")
    _validate_profile_index(frame_15min.index, expected_rows=dispatch.horizon_steps * 4)
    if frame_15min.columns.has_duplicates:
        raise ValueError("dispatch profile column labels must be unique")
    role_columns = [load_column, pv_column, wind_column]
    if fixed_generation_column is not None:
        role_columns.append(fixed_generation_column)
    if len(set(role_columns)) != len(role_columns):
        raise ValueError("load, PV, wind, and fixed-generation columns must be distinct")
    required = {load_column, pv_column, wind_column}
    if fixed_generation_column is not None:
        required.add(fixed_generation_column)
    missing = sorted(required - set(frame_15min.columns))
    if missing:
        raise ValueError(f"profile is missing dispatch columns: {missing}")
    selected = frame_15min.loc[:, sorted(required)].astype(float)
    if not np.all(np.isfinite(selected.to_numpy())):
        raise ValueError("dispatch profile contains missing or non-finite values")
    if np.any(selected.to_numpy() < 0.0):
        raise ValueError("dispatch profile power inputs must be non-negative")
    hourly_counts = selected[load_column].resample("1h").count()
    if len(hourly_counts) != dispatch.horizon_steps or not hourly_counts.eq(4).all():
        raise ValueError("each dispatch hour must contain exactly four 15-minute samples")
    hourly = selected.resample("1h").mean()
    local_index = hourly.index.tz_convert(SOCAL_TIMEZONE)
    day_hour = local_index.hour.to_numpy(dtype=np.float64)
    buy_price = np.full(len(hourly), 0.62)
    buy_price[(day_hour >= 7.0) & (day_hour < 10.0)] = 0.92
    buy_price[(day_hour >= 17.0) & (day_hour < 22.0)] = 1.18
    buy_price[day_hour < 6.0] = 0.38
    carbon_cfg = carbon or CarbonConfig()
    grid_carbon = carbon_cfg.grid_kg_per_kwh * (
        1.0
        + 0.16 * np.exp(-0.5 * ((day_hour - 20.0) / 3.0) ** 2)
        - 0.12 * np.exp(-0.5 * ((day_hour - 13.0) / 3.0) ** 2)
    )
    fixed_generation = (
        hourly[fixed_generation_column].to_numpy()
        if fixed_generation_column is not None
        else np.zeros(len(hourly), dtype=np.float64)
    )
    return DispatchInputs.from_arrays(
        load_kw=hourly[load_column].to_numpy(),
        pv_available_kw=hourly[pv_column].to_numpy(),
        wind_available_kw=hourly[wind_column].to_numpy(),
        buy_price_per_kwh=buy_price,
        sell_price_per_kwh=dispatch.grid_export_price_fraction * buy_price,
        grid_carbon_kg_per_kwh=grid_carbon,
        pv_carbon_kg_per_kwh=np.full(len(hourly), carbon_cfg.pv_kg_per_kwh),
        wind_carbon_kg_per_kwh=np.full(len(hourly), carbon_cfg.wind_kg_per_kwh),
        fixed_generation_kw=fixed_generation,
        fixed_generation_carbon_kg_per_kwh=np.full(len(hourly), carbon_cfg.fuel_cell_kg_per_kwh),
        battery_initial_stored_carbon_kg_per_kwh=(
            carbon_cfg.battery_initial_stored_carbon_kg_per_kwh
        ),
        hydrogen_initial_stored_carbon_kg_per_kwh=(
            carbon_cfg.hydrogen_initial_stored_carbon_kg_per_kwh
        ),
    )


def _validate_profile_index(index: pd.DatetimeIndex, *, expected_rows: int) -> None:
    if index.tz is None:
        raise ValueError("frame_15min index must be timezone-aware")
    if index.has_duplicates:
        raise ValueError("frame_15min index contains duplicate timestamps")
    if not index.is_monotonic_increasing:
        raise ValueError("frame_15min index must be strictly increasing")
    if len(index) != expected_rows:
        raise ValueError(f"profile must contain exactly {expected_rows} 15-minute samples")
    if (
        np.any(index.minute % 15)
        or np.any(index.second)
        or np.any(index.microsecond)
        or np.any(index.nanosecond)
    ):
        raise ValueError("frame_15min timestamps must align to exact 15-minute boundaries")
    if len(index) > 1 and not np.all(np.diff(index.asi8) == pd.Timedelta(minutes=15).value):
        raise ValueError("frame_15min index must be continuous at 15-minute intervals")
