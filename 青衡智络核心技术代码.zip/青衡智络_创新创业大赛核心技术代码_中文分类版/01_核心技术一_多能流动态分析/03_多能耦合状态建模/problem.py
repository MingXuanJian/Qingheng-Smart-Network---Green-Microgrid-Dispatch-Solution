from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import numpy as np
from numpy.typing import ArrayLike, NDArray

from qingheng.config import DispatchConfig


FloatArray = NDArray[np.float64]


def _vector(values: ArrayLike, horizon: int, name: str) -> FloatArray:
    array = np.array(values, dtype=np.float64, copy=True)
    if array.shape != (horizon,):
        raise ValueError(f"{name} must have shape ({horizon},), got {array.shape}")
    if not np.all(np.isfinite(array)):
        raise ValueError(f"{name} contains non-finite values")
    array.setflags(write=False)
    return array


def _repair_storage_schedule(
    requested_power_kw: FloatArray,
    *,
    capacity_kwh: float,
    power_limit_kw: float,
    initial_soc: float,
    minimum_soc: float,
    maximum_soc: float,
    charge_efficiency: float,
    discharge_efficiency: float,
    step_hours: float,
    terminal_steps: int,
) -> FloatArray:
    """Project a raw device trajectory onto state bounds and exact terminal inventory.

    The final ``terminal_steps`` intervals are reserved for an evenly distributed
    terminal correction. If the requested prefix would exceed their combined
    correction power, its amplitude is reduced before reconstruction.
    """

    requested = np.asarray(requested_power_kw, dtype=np.float64)
    if requested.ndim != 1 or requested.size == 0:
        raise ValueError("requested_power_kw must be a non-empty vector")
    if not 1 <= terminal_steps <= requested.size:
        raise ValueError("terminal_steps must be within the schedule horizon")
    initial_energy = initial_soc * capacity_kwh
    minimum_energy = minimum_soc * capacity_kwh
    maximum_energy = maximum_soc * capacity_kwh

    def build(scale: float) -> tuple[FloatArray, float]:
        schedule = np.zeros_like(requested)
        energy = initial_energy
        prefix_end = len(schedule) - terminal_steps
        for step in range(prefix_end):
            maximum_charge = (maximum_energy - energy) / (charge_efficiency * step_hours)
            maximum_discharge = (energy - minimum_energy) * discharge_efficiency / step_hours
            schedule[step] = np.clip(
                requested[step] * scale,
                -min(power_limit_kw, maximum_charge),
                min(power_limit_kw, maximum_discharge),
            )
            energy += step_hours * (
                max(-schedule[step], 0.0) * charge_efficiency
                - max(schedule[step], 0.0) / discharge_efficiency
            )
        if energy >= initial_energy:
            terminal_power = (energy - initial_energy) * discharge_efficiency / step_hours
        else:
            terminal_power = -((initial_energy - energy) / (charge_efficiency * step_hours))
        return schedule, float(terminal_power)

    repaired, terminal_power = build(1.0)
    terminal_power_budget = terminal_steps * power_limit_kw
    if abs(terminal_power) > terminal_power_budget:
        scale = min(1.0, terminal_power_budget / abs(terminal_power))
        for _ in range(32):
            repaired, terminal_power = build(scale)
            if abs(terminal_power) <= terminal_power_budget + 1e-9:
                break
            scale *= 0.9
    if abs(terminal_power) > terminal_power_budget + 1e-7:
        repaired, terminal_power = build(0.0)
    per_step_terminal_power = np.clip(
        terminal_power / terminal_steps, -power_limit_kw, power_limit_kw
    )
    repaired[-terminal_steps:] = per_step_terminal_power
    return repaired


@dataclass(frozen=True)
class DispatchInputs:
    load_kw: FloatArray
    pv_available_kw: FloatArray
    wind_available_kw: FloatArray
    buy_price_per_kwh: FloatArray
    sell_price_per_kwh: FloatArray
    grid_carbon_kg_per_kwh: FloatArray
    fixed_generation_kw: FloatArray
    fixed_generation_carbon_kg_per_kwh: FloatArray
    pv_carbon_kg_per_kwh: FloatArray
    wind_carbon_kg_per_kwh: FloatArray
    battery_initial_stored_carbon_kg_per_kwh: float
    hydrogen_initial_stored_carbon_kg_per_kwh: float

    @classmethod
    def from_arrays(
        cls,
        *,
        load_kw: ArrayLike,
        pv_available_kw: ArrayLike,
        wind_available_kw: ArrayLike,
        buy_price_per_kwh: ArrayLike,
        grid_carbon_kg_per_kwh: ArrayLike,
        sell_price_per_kwh: ArrayLike | None = None,
        fixed_generation_kw: ArrayLike | None = None,
        fixed_generation_carbon_kg_per_kwh: ArrayLike | None = None,
        pv_carbon_kg_per_kwh: ArrayLike | None = None,
        wind_carbon_kg_per_kwh: ArrayLike | None = None,
        battery_initial_stored_carbon_kg_per_kwh: float | None = None,
        hydrogen_initial_stored_carbon_kg_per_kwh: float | None = None,
    ) -> "DispatchInputs":
        load = np.asarray(load_kw, dtype=np.float64)
        if load.ndim != 1 or load.size == 0:
            raise ValueError("load_kw must be a non-empty one-dimensional array")
        horizon = load.size
        zeros = np.zeros(horizon, dtype=np.float64)
        grid_carbon = _vector(grid_carbon_kg_per_kwh, horizon, "grid_carbon_kg_per_kwh")
        battery_initial_factor = (
            float(grid_carbon[0])
            if battery_initial_stored_carbon_kg_per_kwh is None
            else float(battery_initial_stored_carbon_kg_per_kwh)
        )
        hydrogen_initial_factor = (
            float(grid_carbon[0])
            if hydrogen_initial_stored_carbon_kg_per_kwh is None
            else float(hydrogen_initial_stored_carbon_kg_per_kwh)
        )
        inputs = cls(
            load_kw=_vector(load, horizon, "load_kw"),
            pv_available_kw=_vector(pv_available_kw, horizon, "pv_available_kw"),
            wind_available_kw=_vector(wind_available_kw, horizon, "wind_available_kw"),
            buy_price_per_kwh=_vector(buy_price_per_kwh, horizon, "buy_price_per_kwh"),
            sell_price_per_kwh=_vector(
                zeros if sell_price_per_kwh is None else sell_price_per_kwh,
                horizon,
                "sell_price_per_kwh",
            ),
            grid_carbon_kg_per_kwh=grid_carbon,
            fixed_generation_kw=_vector(
                zeros if fixed_generation_kw is None else fixed_generation_kw,
                horizon,
                "fixed_generation_kw",
            ),
            fixed_generation_carbon_kg_per_kwh=_vector(
                zeros
                if fixed_generation_carbon_kg_per_kwh is None
                else fixed_generation_carbon_kg_per_kwh,
                horizon,
                "fixed_generation_carbon_kg_per_kwh",
            ),
            pv_carbon_kg_per_kwh=_vector(
                zeros if pv_carbon_kg_per_kwh is None else pv_carbon_kg_per_kwh,
                horizon,
                "pv_carbon_kg_per_kwh",
            ),
            wind_carbon_kg_per_kwh=_vector(
                zeros if wind_carbon_kg_per_kwh is None else wind_carbon_kg_per_kwh,
                horizon,
                "wind_carbon_kg_per_kwh",
            ),
            battery_initial_stored_carbon_kg_per_kwh=battery_initial_factor,
            hydrogen_initial_stored_carbon_kg_per_kwh=hydrogen_initial_factor,
        )
        if np.any(inputs.load_kw < 0):
            raise ValueError("load_kw cannot be negative")
        if np.any(inputs.pv_available_kw < 0) or np.any(inputs.wind_available_kw < 0):
            raise ValueError("renewable availability cannot be negative")
        if np.any(inputs.fixed_generation_kw < 0):
            raise ValueError("fixed_generation_kw cannot be negative")
        carbon_factors = (
            inputs.grid_carbon_kg_per_kwh,
            inputs.fixed_generation_carbon_kg_per_kwh,
            inputs.pv_carbon_kg_per_kwh,
            inputs.wind_carbon_kg_per_kwh,
        )
        if any(np.any(values < 0) for values in carbon_factors):
            raise ValueError("carbon factors cannot be negative")
        initial_factors = (
            inputs.battery_initial_stored_carbon_kg_per_kwh,
            inputs.hydrogen_initial_stored_carbon_kg_per_kwh,
        )
        if any(not np.isfinite(value) or value < 0.0 for value in initial_factors):
            raise ValueError("initial stored-carbon factors must be finite and non-negative")
        return inputs

    @property
    def horizon(self) -> int:
        return int(self.load_kw.size)

    @property
    def renewable_available_kw(self) -> FloatArray:
        return self.pv_available_kw + self.wind_available_kw


@dataclass(frozen=True)
class DispatchEvaluation:
    score: float
    weighted_objective: float
    penalty: float
    feasible: bool
    cost: float
    curtailment_kwh: float
    emissions_kg: float
    load_allocated_emissions_proxy_kg: float
    external_source_emissions_kg: float
    export_allocated_emissions_proxy_kg: float
    opening_storage_carbon_kg: float
    closing_storage_carbon_proxy_kg: float
    carbon_balance_residual_proxy_kg: float
    unit_load_carbon_intensity_proxy_kg_per_kwh: float
    carbon_intensity_proxy_kg_per_kwh: FloatArray
    terminal_replenishment_cost: float
    terminal_replenishment_emissions_kg: float
    normalized_components: Mapping[str, float]
    battery_power_kw: FloatArray
    hydrogen_power_kw: FloatArray
    renewable_fraction: FloatArray
    renewable_used_kw: FloatArray
    pv_used_kw: FloatArray
    wind_used_kw: FloatArray
    grid_power_kw: FloatArray
    battery_energy_kwh: FloatArray
    hydrogen_energy_kwh: FloatArray
    violation: Mapping[str, float]

    def as_summary(self) -> dict[str, float | bool | str]:
        return {
            "score": self.score,
            "weighted_objective": self.weighted_objective,
            "penalty": self.penalty,
            "feasible": self.feasible,
            "cost": self.cost,
            "curtailment_kwh": self.curtailment_kwh,
            "emissions_kg": self.emissions_kg,
            "emissions_objective_interpretation": "lossless_copperplate_load_allocated_proxy",
            "load_allocated_emissions_proxy_kg": self.load_allocated_emissions_proxy_kg,
            "external_source_emissions_kg": self.external_source_emissions_kg,
            "export_allocated_emissions_proxy_kg": self.export_allocated_emissions_proxy_kg,
            "opening_storage_carbon_kg": self.opening_storage_carbon_kg,
            "closing_storage_carbon_proxy_kg": self.closing_storage_carbon_proxy_kg,
            "carbon_balance_residual_proxy_kg": self.carbon_balance_residual_proxy_kg,
            "unit_load_carbon_intensity_proxy_kg_per_kwh": (
                self.unit_load_carbon_intensity_proxy_kg_per_kwh
            ),
            "terminal_replenishment_cost": self.terminal_replenishment_cost,
            "terminal_replenishment_emissions_kg": self.terminal_replenishment_emissions_kg,
            **{f"normalized_{key}": value for key, value in self.normalized_components.items()},
            **{f"violation_{key}": value for key, value in self.violation.items()},
        }


class MultiEnergyDispatchProblem:
    """A 24-hour electrical-battery-hydrogen dispatch problem.

    Battery and hydrogen powers are signed to prevent simultaneous charging and
    discharging. Positive values supply the AC bus; negative values consume from it.
    Hydrogen state is represented as lower-heating-value energy in the tank.
    """

    def __init__(self, inputs: DispatchInputs, config: DispatchConfig):
        if inputs.horizon != config.horizon_steps:
            raise ValueError(
                f"Input horizon {inputs.horizon} does not match config {config.horizon_steps}"
            )
        self.inputs = inputs
        self.config = config
        self._lower, self._upper = self._make_bounds()
        self._scales = self._reference_scales()

    @property
    def dimension(self) -> int:
        return 3 * self.inputs.horizon

    @property
    def lower_bounds(self) -> FloatArray:
        return self._lower.copy()

    @property
    def upper_bounds(self) -> FloatArray:
        return self._upper.copy()

    def _make_bounds(self) -> tuple[FloatArray, FloatArray]:
        horizon = self.inputs.horizon
        lower = np.concatenate(
            [
                np.full(horizon, -self.config.battery_power_kw),
                np.full(horizon, -self.config.hydrogen_power_kw),
                np.zeros(horizon),
            ]
        )
        upper = np.concatenate(
            [
                np.full(horizon, self.config.battery_power_kw),
                np.full(horizon, self.config.hydrogen_power_kw),
                np.ones(horizon),
            ]
        )
        return lower, upper

    def _reference_scales(self) -> dict[str, float]:
        dt = self.config.step_hours
        # Gross-load grid-only references stay well-scaled even when the actual
        # scenario is a net exporter or contains negative-price intervals.
        cost = np.sum(
            np.abs(self.inputs.load_kw * self.inputs.buy_price_per_kwh)
        ) * dt
        emissions = np.sum(self.inputs.load_kw * self.inputs.grid_carbon_kg_per_kwh) * dt
        renewable = np.sum(self.inputs.renewable_available_kw) * dt
        return {
            "cost": max(abs(float(cost)), 1.0),
            "curtailment": max(float(renewable), 1.0),
            "emissions": max(float(emissions), 1.0),
        }

    def _carbon_proxy(
        self,
        *,
        battery_power_kw: FloatArray,
        hydrogen_power_kw: FloatArray,
        battery_energy_kwh: FloatArray,
        hydrogen_energy_kwh: FloatArray,
        pv_used_kw: FloatArray,
        wind_used_kw: FloatArray,
        imported_kw: FloatArray,
        exported_kw: FloatArray,
        terminal_replenishment_emissions_kg: float,
    ) -> tuple[dict[str, float], FloatArray]:
        """Lossless copper-plate proportional-sharing proxy used during optimization."""

        cfg = self.config
        dt = cfg.step_hours
        battery_carbon = (
            battery_energy_kwh[0] * self.inputs.battery_initial_stored_carbon_kg_per_kwh
        )
        hydrogen_carbon = (
            hydrogen_energy_kwh[0] * self.inputs.hydrogen_initial_stored_carbon_kg_per_kwh
        )
        opening_carbon = float(battery_carbon + hydrogen_carbon)
        external_emissions = 0.0
        load_emissions = 0.0
        export_emissions = 0.0
        bus_intensity_signal = np.zeros(self.inputs.horizon, dtype=np.float64)
        for step in range(self.inputs.horizon):
            battery_density = (
                battery_carbon / battery_energy_kwh[step]
                if battery_energy_kwh[step] > 1e-12
                else 0.0
            )
            hydrogen_density = (
                hydrogen_carbon / hydrogen_energy_kwh[step]
                if hydrogen_energy_kwh[step] > 1e-12
                else 0.0
            )
            battery_discharge = max(float(battery_power_kw[step]), 0.0)
            hydrogen_discharge = max(float(hydrogen_power_kw[step]), 0.0)
            external_rate = float(
                imported_kw[step] * self.inputs.grid_carbon_kg_per_kwh[step]
                + self.inputs.fixed_generation_kw[step]
                * self.inputs.fixed_generation_carbon_kg_per_kwh[step]
                + pv_used_kw[step] * self.inputs.pv_carbon_kg_per_kwh[step]
                + wind_used_kw[step] * self.inputs.wind_carbon_kg_per_kwh[step]
            )
            source_carbon_rate = (
                external_rate
                + battery_discharge * battery_density / cfg.battery_discharge_efficiency
                + hydrogen_discharge * hydrogen_density / cfg.fuel_cell_efficiency
            )
            source_power = float(
                imported_kw[step]
                + self.inputs.fixed_generation_kw[step]
                + pv_used_kw[step]
                + wind_used_kw[step]
                + battery_discharge
                + hydrogen_discharge
            )
            bus_intensity = source_carbon_rate / source_power if source_power > 1e-12 else 0.0
            bus_intensity_signal[step] = bus_intensity
            external_emissions += external_rate * dt
            load_emissions += float(self.inputs.load_kw[step]) * bus_intensity * dt
            export_emissions += float(exported_kw[step]) * bus_intensity * dt

            if battery_power_kw[step] > 0.0:
                battery_carbon -= (
                    battery_power_kw[step] / cfg.battery_discharge_efficiency * battery_density * dt
                )
            elif battery_power_kw[step] < 0.0:
                battery_carbon += -battery_power_kw[step] * bus_intensity * dt
            if hydrogen_power_kw[step] > 0.0:
                hydrogen_carbon -= (
                    hydrogen_power_kw[step] / cfg.fuel_cell_efficiency * hydrogen_density * dt
                )
            elif hydrogen_power_kw[step] < 0.0:
                hydrogen_carbon += -hydrogen_power_kw[step] * bus_intensity * dt
            battery_carbon = max(float(battery_carbon), 0.0)
            hydrogen_carbon = max(float(hydrogen_carbon), 0.0)

        external_emissions += terminal_replenishment_emissions_kg
        load_emissions += terminal_replenishment_emissions_kg
        closing_carbon = float(battery_carbon + hydrogen_carbon)
        residual = (
            external_emissions
            + opening_carbon
            - (load_emissions + export_emissions + closing_carbon)
        )
        return (
            {
                "load": float(load_emissions),
                "external": float(external_emissions),
                "export": float(export_emissions),
                "opening": opening_carbon,
                "closing": closing_carbon,
                "residual": float(residual),
            },
            bus_intensity_signal,
        )

    def decode(self, decision: ArrayLike) -> tuple[FloatArray, FloatArray, FloatArray]:
        vector = np.asarray(decision, dtype=np.float64)
        if vector.shape != (self.dimension,):
            raise ValueError(f"decision must have shape ({self.dimension},)")
        if not np.all(np.isfinite(vector)):
            raise ValueError("decision must contain only finite values")
        horizon = self.inputs.horizon
        return vector[:horizon], vector[horizon : 2 * horizon], vector[2 * horizon :]

    def repair_decision(self, decision: ArrayLike) -> FloatArray:
        """Return an optimizer candidate with feasible device states and terminals."""

        battery, hydrogen, renewable_fraction = self.decode(decision)
        cfg = self.config
        battery = _repair_storage_schedule(
            battery,
            capacity_kwh=cfg.battery_capacity_kwh,
            power_limit_kw=cfg.battery_power_kw,
            initial_soc=cfg.battery_initial_soc,
            minimum_soc=cfg.battery_min_soc,
            maximum_soc=cfg.battery_max_soc,
            charge_efficiency=cfg.battery_charge_efficiency,
            discharge_efficiency=cfg.battery_discharge_efficiency,
            step_hours=cfg.step_hours,
            terminal_steps=min(cfg.terminal_repair_steps, self.inputs.horizon),
        )
        hydrogen = _repair_storage_schedule(
            hydrogen,
            capacity_kwh=cfg.hydrogen_capacity_kwh,
            power_limit_kw=cfg.hydrogen_power_kw,
            initial_soc=cfg.hydrogen_initial_soc,
            minimum_soc=cfg.hydrogen_min_soc,
            maximum_soc=cfg.hydrogen_max_soc,
            charge_efficiency=cfg.electrolyzer_efficiency,
            discharge_efficiency=cfg.fuel_cell_efficiency,
            step_hours=cfg.step_hours,
            terminal_steps=min(cfg.terminal_repair_steps, self.inputs.horizon),
        )
        return np.concatenate([battery, hydrogen, np.clip(renewable_fraction, 0.0, 1.0)])

    def evaluate(
        self,
        decision: ArrayLike,
        *,
        enforce_terminal_inventory: bool = True,
    ) -> DispatchEvaluation:
        """Evaluate a fixed schedule.

        Optimizer calls use the default cyclic terminal inventory. Rolling-horizon
        execution can disable that accounting term for the first, actually executed
        part of a longer plan; state and grid bounds remain enforced.
        """

        if not isinstance(enforce_terminal_inventory, bool):
            raise TypeError("enforce_terminal_inventory must be a boolean")
        battery, hydrogen, renewable_fraction = self.decode(decision)
        dt = self.config.step_hours
        cfg = self.config

        pv_used = renewable_fraction * self.inputs.pv_available_kw
        wind_used = renewable_fraction * self.inputs.wind_available_kw
        renewable_used = pv_used + wind_used
        grid = (
            self.inputs.load_kw
            - renewable_used
            - self.inputs.fixed_generation_kw
            - battery
            - hydrogen
        )

        battery_energy = np.empty(self.inputs.horizon + 1, dtype=np.float64)
        hydrogen_energy = np.empty(self.inputs.horizon + 1, dtype=np.float64)
        battery_energy[0] = cfg.battery_initial_soc * cfg.battery_capacity_kwh
        hydrogen_energy[0] = cfg.hydrogen_initial_soc * cfg.hydrogen_capacity_kwh
        for step in range(self.inputs.horizon):
            battery_energy[step + 1] = battery_energy[step] + dt * (
                max(-battery[step], 0.0) * cfg.battery_charge_efficiency
                - max(battery[step], 0.0) / cfg.battery_discharge_efficiency
            )
            hydrogen_energy[step + 1] = hydrogen_energy[step] + dt * (
                max(-hydrogen[step], 0.0) * cfg.electrolyzer_efficiency
                - max(hydrogen[step], 0.0) / cfg.fuel_cell_efficiency
            )

        imported = np.maximum(grid, 0.0)
        exported = np.maximum(-grid, 0.0)
        battery_shortfall_kwh = (
            max(battery_energy[0] - battery_energy[-1], 0.0)
            if enforce_terminal_inventory
            else 0.0
        )
        hydrogen_shortfall_kwh = (
            max(hydrogen_energy[0] - hydrogen_energy[-1], 0.0)
            if enforce_terminal_inventory
            else 0.0
        )
        replacement_bus_energy_kwh = (
            battery_shortfall_kwh / cfg.battery_charge_efficiency
            + hydrogen_shortfall_kwh / cfg.electrolyzer_efficiency
        )
        terminal_replenishment_cost = float(
            replacement_bus_energy_kwh * np.mean(self.inputs.buy_price_per_kwh)
        )
        terminal_replenishment_emissions = float(
            replacement_bus_energy_kwh * np.mean(self.inputs.grid_carbon_kg_per_kwh)
        )
        cycling_cost = cfg.battery_throughput_cost_per_kwh * np.abs(
            battery
        ) + cfg.hydrogen_throughput_cost_per_kwh * np.abs(hydrogen)
        cost = float(
            np.sum(
                imported * self.inputs.buy_price_per_kwh
                - exported * self.inputs.sell_price_per_kwh
                + cycling_cost
            )
            * dt
            + terminal_replenishment_cost
        )
        curtailment = float(np.sum(self.inputs.renewable_available_kw - renewable_used) * dt)
        carbon_proxy, carbon_intensity_signal = self._carbon_proxy(
            battery_power_kw=battery,
            hydrogen_power_kw=hydrogen,
            battery_energy_kwh=battery_energy,
            hydrogen_energy_kwh=hydrogen_energy,
            pv_used_kw=pv_used,
            wind_used_kw=wind_used,
            imported_kw=imported,
            exported_kw=exported,
            terminal_replenishment_emissions_kg=terminal_replenishment_emissions,
        )
        emissions = carbon_proxy["load"]
        normalized = {
            "cost": cost / self._scales["cost"],
            "curtailment": curtailment / self._scales["curtailment"],
            "emissions": emissions / self._scales["emissions"],
        }
        weighted = float(sum(cfg.objective_weights[key] * normalized[key] for key in normalized))

        battery_min = cfg.battery_min_soc * cfg.battery_capacity_kwh
        battery_max = cfg.battery_max_soc * cfg.battery_capacity_kwh
        hydrogen_min = cfg.hydrogen_min_soc * cfg.hydrogen_capacity_kwh
        hydrogen_max = cfg.hydrogen_max_soc * cfg.hydrogen_capacity_kwh
        violations = {
            "battery_power": float(
                np.sum(np.maximum(np.abs(battery) - cfg.battery_power_kw, 0.0) ** 2)
            )
            / max(cfg.battery_power_kw**2, 1.0),
            "hydrogen_power": float(
                np.sum(np.maximum(np.abs(hydrogen) - cfg.hydrogen_power_kw, 0.0) ** 2)
            )
            / max(cfg.hydrogen_power_kw**2, 1.0),
            "renewable_fraction": float(
                np.sum(np.maximum(-renewable_fraction, 0.0) ** 2)
                + np.sum(np.maximum(renewable_fraction - 1.0, 0.0) ** 2)
            ),
            "battery_state": float(
                np.sum(np.maximum(battery_min - battery_energy, 0.0) ** 2)
                + np.sum(np.maximum(battery_energy - battery_max, 0.0) ** 2)
            )
            / max(cfg.battery_capacity_kwh**2, 1.0),
            "hydrogen_state": float(
                np.sum(np.maximum(hydrogen_min - hydrogen_energy, 0.0) ** 2)
                + np.sum(np.maximum(hydrogen_energy - hydrogen_max, 0.0) ** 2)
            )
            / max(cfg.hydrogen_capacity_kwh**2, 1.0),
            "grid_import": float(np.sum(np.maximum(grid - cfg.grid_import_limit_kw, 0.0) ** 2))
            / max(cfg.grid_import_limit_kw**2, 1.0),
            "grid_export": float(np.sum(np.maximum(-grid - cfg.grid_export_limit_kw, 0.0) ** 2))
            / max(cfg.grid_export_limit_kw**2, 1.0),
            "battery_terminal": (
                float(
                    max(
                        abs(battery_energy[-1] - battery_energy[0])
                        / max(cfg.battery_capacity_kwh, 1.0)
                        - cfg.terminal_tolerance,
                        0.0,
                    )
                    ** 2
                )
                if enforce_terminal_inventory
                else 0.0
            ),
            "hydrogen_terminal": (
                float(
                    max(
                        abs(hydrogen_energy[-1] - hydrogen_energy[0])
                        / max(cfg.hydrogen_capacity_kwh, 1.0)
                        - cfg.terminal_tolerance,
                        0.0,
                    )
                    ** 2
                )
                if enforce_terminal_inventory
                else 0.0
            ),
        }
        total_violation = float(sum(violations.values()))
        penalty = (100.0 if total_violation > 1e-10 else 0.0) + 1_000.0 * total_violation
        feasible = all(value <= 1e-10 for value in violations.values())
        return DispatchEvaluation(
            score=weighted + penalty,
            weighted_objective=weighted,
            penalty=penalty,
            feasible=feasible,
            cost=cost,
            curtailment_kwh=curtailment,
            emissions_kg=emissions,
            load_allocated_emissions_proxy_kg=carbon_proxy["load"],
            external_source_emissions_kg=carbon_proxy["external"],
            export_allocated_emissions_proxy_kg=carbon_proxy["export"],
            opening_storage_carbon_kg=carbon_proxy["opening"],
            closing_storage_carbon_proxy_kg=carbon_proxy["closing"],
            carbon_balance_residual_proxy_kg=carbon_proxy["residual"],
            unit_load_carbon_intensity_proxy_kg_per_kwh=(
                carbon_proxy["load"] / max(float(np.sum(self.inputs.load_kw) * dt), 1e-12)
            ),
            carbon_intensity_proxy_kg_per_kwh=carbon_intensity_signal,
            terminal_replenishment_cost=terminal_replenishment_cost,
            terminal_replenishment_emissions_kg=terminal_replenishment_emissions,
            normalized_components=normalized,
            battery_power_kw=battery.copy(),
            hydrogen_power_kw=hydrogen.copy(),
            renewable_fraction=renewable_fraction.copy(),
            renewable_used_kw=renewable_used,
            pv_used_kw=pv_used,
            wind_used_kw=wind_used,
            grid_power_kw=grid,
            battery_energy_kwh=battery_energy,
            hydrogen_energy_kwh=hydrogen_energy,
            violation=violations,
        )

    def objective(self, decision: ArrayLike) -> float:
        return self.evaluate(decision).score

    def zero_dispatch(self) -> DispatchEvaluation:
        return self.evaluate(self.zero_decision())

    def zero_decision(self) -> FloatArray:
        return np.concatenate(
            [
                np.zeros(2 * self.inputs.horizon, dtype=np.float64),
                np.ones(self.inputs.horizon, dtype=np.float64),
            ]
        )
