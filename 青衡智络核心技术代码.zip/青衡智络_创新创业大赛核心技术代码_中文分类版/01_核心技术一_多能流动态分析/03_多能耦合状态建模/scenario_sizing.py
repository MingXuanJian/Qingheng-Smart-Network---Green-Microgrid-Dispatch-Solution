"""Training-only sizing rules for the SoCal research dispatch scenario."""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from hashlib import sha256
import json
from math import ceil
from typing import Any, Mapping

import numpy as np
import pandas as pd

from qingheng.config import DispatchConfig
from qingheng.data.hybrid import (
    WIND_TRACE_ANCHOR,
    WIND_TRACE_VERSION,
    synthetic_wind_availability,
)


@dataclass(frozen=True)
class SoCalSizingResult:
    dispatch: DispatchConfig
    wind_capacity_kw: float
    manifest: dict[str, Any]


def _round_up(value: float, quantum: float, *, minimum: float = 0.0) -> float:
    return float(max(minimum, ceil(max(value, 0.0) / quantum - 1e-12) * quantum))


def _complete_local_days(hourly: pd.DataFrame, timezone: str) -> list[pd.DataFrame]:
    local = hourly.index.tz_convert(timezone)
    groups: list[pd.DataFrame] = []
    for _, positions in pd.Series(np.arange(len(hourly)), index=local).groupby(local.date):
        selected = hourly.iloc[positions.to_numpy(dtype=np.int64)]
        selected_local = selected.index.tz_convert(timezone)
        clock_hours = selected_local.hour.to_numpy(dtype=np.int64)
        on_whole_hour = bool(
            (selected_local.minute == 0).all()
            and (selected_local.second == 0).all()
            and (selected_local.microsecond == 0).all()
            and (selected_local.nanosecond == 0).all()
        )
        if (
            len(selected_local) == 24
            and on_whole_hour
            and np.array_equal(clock_hours, np.arange(24, dtype=np.int64))
        ):
            groups.append(selected)
    return groups


def calibrate_socal_dispatch(
    frame: pd.DataFrame,
    base: DispatchConfig,
    *,
    cache_manifest: Mapping[str, Any] | None = None,
    wind_capacity_kw: float = 0.0,
    wind_seed: int = 20260714,
    input_steps: int = 96,
    train_fraction: float = 0.70,
    train_start: str | pd.Timestamp | None = None,
    train_end_exclusive: str | pd.Timestamp | None = None,
    timezone: str = "America/Los_Angeles",
) -> SoCalSizingResult:
    """Size a transparent research scenario using forecast-training rows only.

    This is a reproducible scenario calibration, not capacity optimization. It
    deliberately excludes the validation/test periods and does not include CAPEX.
    """

    if not isinstance(frame.index, pd.DatetimeIndex) or frame.index.tz is None:
        raise ValueError("sizing frame must use a timezone-aware DatetimeIndex")
    if frame.index.has_duplicates or not frame.index.is_monotonic_increasing:
        raise ValueError("sizing frame timestamps must be unique and sorted")
    if (
        np.any(frame.index.minute % 15)
        or np.any(frame.index.second)
        or np.any(frame.index.microsecond)
        or np.any(frame.index.nanosecond)
    ):
        raise ValueError("sizing timestamps must align to exact 15-minute boundaries")
    missing = sorted({"load_kw", "pv_kw"} - set(frame.columns))
    if missing:
        raise ValueError(f"sizing frame is missing columns: {missing}")
    if wind_capacity_kw < 0.0 or not np.isfinite(wind_capacity_kw):
        raise ValueError("wind_capacity_kw must be finite and non-negative")
    if input_steps <= 0 or not 0.0 < train_fraction < 1.0:
        raise ValueError("input_steps and train_fraction are invalid")

    wind = synthetic_wind_availability(frame.index, wind_capacity_kw, wind_seed)
    explicit_interval = train_start is not None or train_end_exclusive is not None
    if explicit_interval:
        if train_start is None or train_end_exclusive is None:
            raise ValueError("train_start and train_end_exclusive must be provided together")
        start = pd.Timestamp(train_start)
        end = pd.Timestamp(train_end_exclusive)
        if start.tzinfo is None or end.tzinfo is None or end <= start:
            raise ValueError("explicit sizing interval must be timezone-aware and non-empty")
        start = start.tz_convert(frame.index.tz)
        end = end.tz_convert(frame.index.tz)
        mask = (frame.index >= start) & (frame.index < end)
        training = frame.loc[mask, ["load_kw", "pv_kw"]].copy()
        training["wind_kw"] = wind[mask]
        recorded_train_fraction: float | None = None
        excluded_context_rows: int | None = None
    else:
        train_end = int(np.floor(len(frame) * train_fraction))
        if train_end <= input_steps:
            raise ValueError("sizing frame is too short for the forecast training interval")
        training = frame.iloc[input_steps:train_end].loc[:, ["load_kw", "pv_kw"]].copy()
        training["wind_kw"] = wind[input_steps:train_end]
        recorded_train_fraction = float(train_fraction)
        excluded_context_rows = int(input_steps)
    if training.empty:
        raise ValueError("sizing training interval contains no rows")
    training_values = training[["load_kw", "pv_kw", "wind_kw"]].to_numpy(dtype=np.float64)
    if not np.all(np.isfinite(training_values)):
        raise ValueError("sizing training interval contains missing or non-finite power values")
    if np.any(training_values < 0.0):
        raise ValueError("sizing training interval power values must be non-negative")
    training_index = training.index
    if (
        np.any(training_index.minute % 15)
        or np.any(training_index.second)
        or np.any(training_index.microsecond)
        or np.any(training_index.nanosecond)
    ):
        raise ValueError("sizing timestamps must align to exact 15-minute boundaries")
    if len(training_index) > 1 and not np.all(
        np.diff(training_index.asi8) == pd.Timedelta(minutes=15).value
    ):
        raise ValueError("sizing training interval must be continuous at 15-minute resolution")
    hourly_counts = training["load_kw"].resample("1h").count()
    incomplete = hourly_counts.ne(4)
    if incomplete.iloc[1:-1].any():
        raise ValueError("sizing interval contains an incomplete interior hour")
    complete_hours = hourly_counts.index[~incomplete]
    hourly = training.resample("1h").mean().loc[complete_hours]
    hourly["net_kw"] = hourly["load_kw"] - hourly["pv_kw"] - hourly["wind_kw"]
    days = _complete_local_days(hourly, timezone)
    if not days:
        raise ValueError("sizing interval contains no complete local days")

    deficits = np.asarray([float(np.maximum(day["net_kw"].to_numpy(), 0.0).sum()) for day in days])
    surpluses = np.asarray(
        [float(np.maximum(-day["net_kw"].to_numpy(), 0.0).sum()) for day in days]
    )
    battery_roundtrip = base.battery_charge_efficiency * base.battery_discharge_efficiency
    battery_daily_delivery = np.minimum(deficits, battery_roundtrip * surpluses)
    battery_typical_delivery = float(np.quantile(battery_daily_delivery, 0.50))
    battery_usable_fraction = base.battery_max_soc - base.battery_min_soc
    battery_enabled = battery_typical_delivery > 1e-9
    battery_capacity = (
        _round_up(
            battery_typical_delivery
            / (base.battery_discharge_efficiency * battery_usable_fraction),
            25.0,
            minimum=25.0,
        )
        if battery_enabled
        else 0.0
    )
    battery_power = _round_up(battery_capacity / 4.0, 5.0, minimum=5.0) if battery_enabled else 0.0

    battery_served = np.minimum.reduce(
        [
            deficits,
            battery_roundtrip * surpluses,
            np.full_like(deficits, battery_typical_delivery),
        ]
    )
    surplus_after_battery = np.maximum(surpluses - battery_served / battery_roundtrip, 0.0)
    deficit_after_battery = np.maximum(deficits - battery_served, 0.0)
    hydrogen_roundtrip = base.electrolyzer_efficiency * base.fuel_cell_efficiency
    hydrogen_daily_delivery = np.minimum(
        deficit_after_battery, hydrogen_roundtrip * surplus_after_battery
    )
    hydrogen_design_delivery = float(np.quantile(hydrogen_daily_delivery, 0.90))
    hydrogen_usable_fraction = base.hydrogen_max_soc - base.hydrogen_min_soc
    hydrogen_enabled = hydrogen_design_delivery > 1e-9
    hydrogen_capacity = (
        _round_up(
            hydrogen_design_delivery / (base.fuel_cell_efficiency * hydrogen_usable_fraction),
            25.0,
            minimum=25.0,
        )
        if hydrogen_enabled
        else 0.0
    )
    electrolyzer_power = hydrogen_design_delivery / max(hydrogen_roundtrip * 8.0, 1e-12)
    fuel_cell_power = hydrogen_design_delivery / 12.0
    hydrogen_power = (
        _round_up(max(electrolyzer_power, fuel_cell_power), 5.0, minimum=5.0)
        if hydrogen_enabled
        else 0.0
    )

    import_reference = np.maximum(hourly["net_kw"].to_numpy(), 0.0)
    export_reference = np.maximum(-hourly["net_kw"].to_numpy(), 0.0)
    grid_import_limit = _round_up(1.10 * float(np.quantile(import_reference, 0.995)), 25.0)
    grid_export_limit = _round_up(1.10 * float(np.quantile(export_reference, 0.995)), 25.0)
    battery_initial_soc = 0.5 * (base.battery_min_soc + base.battery_max_soc)
    hydrogen_initial_soc = 0.5 * (base.hydrogen_min_soc + base.hydrogen_max_soc)
    calibrated = replace(
        base,
        battery_enabled=battery_enabled,
        battery_capacity_kwh=battery_capacity,
        battery_power_kw=battery_power,
        battery_initial_soc=battery_initial_soc,
        hydrogen_enabled=hydrogen_enabled,
        hydrogen_capacity_kwh=hydrogen_capacity,
        hydrogen_power_kw=hydrogen_power,
        hydrogen_initial_soc=hydrogen_initial_soc,
        grid_import_limit_kw=grid_import_limit,
        grid_export_limit_kw=grid_export_limit,
        grid_export_price_fraction=0.0,
    )

    load_energy = float(hourly["load_kw"].sum())
    renewable_energy = float((hourly["pv_kw"] + hourly["wind_kw"]).sum())
    manifest: dict[str, Any] = {
        "schema_version": "qingheng.socal-sizing.v1",
        "interpretation": (
            "Training-only reproducible research-scenario sizing; not economic capacity "
            "optimization and not evidence of an installed device."
        ),
        "source": {
            "cache_output_sha256": (
                None if cache_manifest is None else cache_manifest.get("output_sha256")
            ),
            "selected_complete_months": (
                None
                if cache_manifest is None
                else cache_manifest.get("derivation", {}).get("selected_complete_months")
            ),
            "frame_rows": int(len(frame)),
        },
        "training_interval": {
            "selection": "forecast artifact target train interval"
            if explicit_interval
            else "fraction",
            "input_context_rows_excluded": excluded_context_rows,
            "start": training.index[0].isoformat(),
            "end_exclusive": (training.index[-1] + pd.Timedelta(minutes=15)).isoformat(),
            "rows_15min": int(len(training)),
            "rows_hourly": int(len(hourly)),
            "complete_local_days": int(len(days)),
            "complete_local_day_policy": (
                "exactly 24 whole-hour bins with unique local clock hours 00-23; "
                "DST transition days are excluded"
            ),
            "train_fraction": recorded_train_fraction,
            "timezone": timezone,
        },
        "wind": {
            "capacity_kw": float(wind_capacity_kw),
            "seed": int(wind_seed),
            "trace_version": WIND_TRACE_VERSION,
            "trace_anchor": WIND_TRACE_ANCHOR.isoformat(),
            "measured": False,
        },
        "method": {
            "battery": (
                "median daily min(deficit, roundtrip*surplus), divided by discharge "
                "efficiency and usable SOC span; four-hour power rating"
            ),
            "hydrogen": (
                "90th percentile residual daily deliverable energy after battery; "
                "eight-hour electrolysis and twelve-hour generation power rating"
            ),
            "grid": "110% of training hourly net import/export 99.5th percentile",
            "rounding": "energy 25 kWh, power 5 kW, grid 25 kW, all upward",
            "export_price": "zero credit because no SoCal tariff evidence is available",
        },
        "training_diagnostics": {
            "load_energy_kwh": load_energy,
            "renewable_available_energy_kwh": renewable_energy,
            "renewable_to_load_energy_ratio": renewable_energy / max(load_energy, 1e-12),
            "renewable_surplus_hour_fraction": float(np.mean(hourly["net_kw"].to_numpy() < 0.0)),
            "peak_net_import_kw": float(import_reference.max()),
            "peak_net_export_kw": float(export_reference.max()),
            "median_battery_daily_delivery_kwh": battery_typical_delivery,
            "p90_hydrogen_daily_delivery_kwh": hydrogen_design_delivery,
        },
        "calibrated_dispatch": asdict(calibrated),
    }
    canonical = json.dumps(manifest, sort_keys=True, separators=(",", ":"))
    manifest["sizing_sha256"] = sha256(canonical.encode("utf-8")).hexdigest()
    return SoCalSizingResult(
        dispatch=calibrated,
        wind_capacity_kw=float(wind_capacity_kw),
        manifest=manifest,
    )


__all__ = ["SoCalSizingResult", "calibrate_socal_dispatch"]
