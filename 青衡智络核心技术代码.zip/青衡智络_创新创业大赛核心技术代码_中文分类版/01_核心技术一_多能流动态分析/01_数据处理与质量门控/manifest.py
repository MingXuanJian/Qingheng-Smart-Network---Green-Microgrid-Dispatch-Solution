"""Provenance manifests for derived datasets.

Only files explicitly passed by a data adapter are fingerprinted.  The helper
never scans a raw dataset root, which keeps large archives read-only and avoids
accidentally including unrelated secrets in a manifest.
"""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable, Literal


HashMode = Literal["metadata", "full"]


def _full_file_sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(chunk_size):
            digest.update(block)
    return digest.hexdigest()


def fingerprint_file(path: str | Path, mode: HashMode = "metadata") -> dict[str, Any]:
    """Return a reproducible fingerprint for one file.

    ``full`` hashes the bytes.  ``metadata`` hashes the resolved path, byte
    size and nanosecond modification time; it is intentionally faster for the
    30 GB SoCal archive and is labelled as a metadata fingerprint.
    """

    source = Path(path).resolve()
    if not source.is_file():
        raise FileNotFoundError(source)
    if mode not in ("metadata", "full"):
        raise ValueError("hash mode must be 'metadata' or 'full'")

    stat = source.stat()
    if mode == "full":
        digest = _full_file_sha256(source)
    else:
        payload = f"{source}|{stat.st_size}|{stat.st_mtime_ns}".encode("utf-8")
        digest = hashlib.sha256(payload).hexdigest()
    return {
        "path": str(source),
        "size_bytes": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
        "hash_mode": mode,
        "sha256": digest,
    }


def create_manifest(
    *,
    dataset: str,
    raw_root: str | Path,
    source_files: Iterable[str | Path],
    hash_mode: HashMode = "metadata",
    derivation: dict[str, Any] | None = None,
    output_file: str | Path | None = None,
) -> dict[str, Any]:
    """Create a JSON-serialisable provenance manifest."""

    files = sorted({Path(path).resolve() for path in source_files}, key=str)
    manifest: dict[str, Any] = {
        "schema_version": "qingheng.data-manifest.v1",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "dataset": dataset,
        "raw_root": str(Path(raw_root).resolve()),
        "raw_data_policy": "read_only_references; raw files are not copied",
        "hash_mode": hash_mode,
        "source_files": [fingerprint_file(path, hash_mode) for path in files],
        "derivation": derivation or {},
    }
    if output_file is not None:
        output = Path(output_file).resolve()
        manifest["output_file"] = str(output)
        if output.is_file():
            manifest["output_sha256"] = _full_file_sha256(output)
    return manifest


def write_manifest(manifest: dict[str, Any], path: str | Path) -> Path:
    """Write a manifest atomically and return its resolved path."""

    target = Path(path).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + ".tmp")
    temporary.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=True, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return target


__all__ = [
    "HashMode",
    "create_manifest",
    "fingerprint_file",
    "write_manifest",
]
