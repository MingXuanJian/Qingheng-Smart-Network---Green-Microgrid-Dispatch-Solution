"""Download-plan based completeness gates for the evolving SoCal archive."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
import json
from pathlib import Path
from typing import Iterable, Sequence


_COMPLETE_STATUSES = {
    "complete",
    "completed",
    "completed_without_gaps",
    "recovery_batch_completed",
    "success",
    "success_marker",
}


@dataclass(frozen=True)
class BatchCompleteness:
    batch_id: str
    month: str
    data_type: str
    resolution_seconds: int | None
    complete: bool
    status: str
    marker_path: Path | None


@dataclass(frozen=True)
class MonthCompleteness:
    month: str
    required_data_types: tuple[str, ...]
    planned_by_type: dict[str, int]
    complete_by_type: dict[str, int]
    status_counts: dict[str, int]
    complete: bool


@dataclass(frozen=True)
class DownloadCompletenessReport:
    raw_root: Path
    plan_path: Path
    required_data_types: tuple[str, ...]
    resolution_seconds: int | None
    batches: tuple[BatchCompleteness, ...]
    months: tuple[MonthCompleteness, ...]
    complete_months: tuple[str, ...]
    contiguous_complete_runs: tuple[tuple[str, ...], ...]

    @property
    def longest_contiguous_run(self) -> tuple[str, ...]:
        if not self.contiguous_complete_runs:
            return ()
        return max(self.contiguous_complete_runs, key=lambda run: (len(run), tuple(reversed(run))))

    def marker_paths(self, months: Iterable[str]) -> tuple[Path, ...]:
        selected = set(months)
        return tuple(
            batch.marker_path
            for batch in self.batches
            if batch.month in selected and batch.marker_path is not None
        )

    def as_dict(self) -> dict[str, object]:
        return {
            "raw_root": str(self.raw_root),
            "plan_path": str(self.plan_path),
            "required_data_types": list(self.required_data_types),
            "resolution_seconds": self.resolution_seconds,
            "complete_months": list(self.complete_months),
            "contiguous_complete_runs": [list(run) for run in self.contiguous_complete_runs],
            "selected_longest_contiguous_run": list(self.longest_contiguous_run),
            "months": [
                {
                    "month": month.month,
                    "complete": month.complete,
                    "planned_by_type": month.planned_by_type,
                    "complete_by_type": month.complete_by_type,
                    "status_counts": month.status_counts,
                }
                for month in self.months
            ],
        }


def _next_month(month: str) -> str:
    parsed = datetime.strptime(month, "%Y-%m")
    year = parsed.year + (1 if parsed.month == 12 else 0)
    value = 1 if parsed.month == 12 else parsed.month + 1
    return f"{year:04d}-{value:02d}"


def _contiguous_runs(months: Sequence[str]) -> tuple[tuple[str, ...], ...]:
    if not months:
        return ()
    runs: list[list[str]] = [[months[0]]]
    for month in months[1:]:
        if month == _next_month(runs[-1][-1]):
            runs[-1].append(month)
        else:
            runs.append([month])
    return tuple(tuple(run) for run in runs)


def _batch_status(marker_path: Path) -> tuple[bool, str]:
    if not marker_path.is_file():
        return False, "missing_marker"
    try:
        payload = json.loads(marker_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return False, "invalid_marker"
    status = str(payload.get("status", "success_marker")).strip().lower()
    server_gaps = payload.get("server_gaps")
    if server_gaps:
        return False, status if "gap" in status else "server_gaps"
    return status in _COMPLETE_STATUSES, status


def audit_download_completeness(
    raw_root: str | Path,
    *,
    required_data_types: Sequence[str] = ("magnitudes", "phasors"),
    resolution_seconds: int | None = None,
    download_plan_path: str | Path | None = None,
) -> DownloadCompletenessReport:
    """Audit only planned batches and their top-level success markers.

    A calendar month is accepted only when every planned batch for every
    required data type has a valid marker and no declared server gaps. This
    intentionally fails closed while the downloader is still running.
    """

    root = Path(raw_root).resolve()
    plan_path = (
        Path(download_plan_path).resolve()
        if download_plan_path is not None
        else root / "download_plan.json"
    )
    if not plan_path.is_file():
        raise FileNotFoundError(f"SoCal download plan not found: {plan_path}")
    try:
        plan = json.loads(plan_path.read_text(encoding="utf-8"))
    except (UnicodeError, json.JSONDecodeError) as error:
        raise ValueError(f"Invalid SoCal download plan: {plan_path}") from error
    raw_batches = plan.get("batches")
    if not isinstance(raw_batches, list) or not raw_batches:
        raise ValueError("download_plan.json contains no batches")
    required = tuple(dict.fromkeys(str(value) for value in required_data_types))
    if not required:
        raise ValueError("required_data_types cannot be empty")
    if resolution_seconds is not None and resolution_seconds <= 0:
        raise ValueError("resolution_seconds must be positive")

    batches: list[BatchCompleteness] = []
    planned: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    completed: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    statuses: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for raw in raw_batches:
        if not isinstance(raw, dict):
            raise ValueError("download plan batch entries must be objects")
        try:
            batch_id = str(raw["batch_id"])
            data_type = str(raw["data_type"])
            month = str(raw["start"])[:7]
        except KeyError as error:
            raise ValueError(f"download plan batch misses {error.args[0]}") from error
        if data_type not in required:
            continue
        raw_resolution = raw.get("resolution_seconds")
        batch_resolution = int(raw_resolution) if raw_resolution is not None else None
        if resolution_seconds is not None and batch_resolution != resolution_seconds:
            continue
        marker = root / data_type / batch_id / "_SUCCESS.json"
        complete, status = _batch_status(marker)
        batches.append(
            BatchCompleteness(
                batch_id=batch_id,
                month=month,
                data_type=data_type,
                resolution_seconds=batch_resolution,
                complete=complete,
                status=status,
                marker_path=marker if marker.is_file() else None,
            )
        )
        planned[month][data_type] += 1
        completed[month][data_type] += int(complete)
        statuses[month][status] += 1

    month_results: list[MonthCompleteness] = []
    for month in sorted(planned):
        planned_by_type = {name: planned[month].get(name, 0) for name in required}
        complete_by_type = {name: completed[month].get(name, 0) for name in required}
        complete = all(
            planned_by_type[name] > 0 and complete_by_type[name] == planned_by_type[name]
            for name in required
        )
        month_results.append(
            MonthCompleteness(
                month=month,
                required_data_types=required,
                planned_by_type=planned_by_type,
                complete_by_type=complete_by_type,
                status_counts=dict(statuses[month]),
                complete=complete,
            )
        )
    complete_months = tuple(month.month for month in month_results if month.complete)
    return DownloadCompletenessReport(
        raw_root=root,
        plan_path=plan_path,
        required_data_types=required,
        resolution_seconds=resolution_seconds,
        batches=tuple(batches),
        months=tuple(month_results),
        complete_months=complete_months,
        contiguous_complete_runs=_contiguous_runs(complete_months),
    )


__all__ = [
    "BatchCompleteness",
    "DownloadCompletenessReport",
    "MonthCompleteness",
    "audit_download_completeness",
]
