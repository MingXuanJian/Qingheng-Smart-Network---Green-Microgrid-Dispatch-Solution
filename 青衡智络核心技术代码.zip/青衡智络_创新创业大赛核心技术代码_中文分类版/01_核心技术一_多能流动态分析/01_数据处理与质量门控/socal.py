"""Streaming adapter for the Caltech SoCal distribution measurements.

The raw archive is treated as read-only.  Only explicitly selected magnitude
channels are opened, resampled in chunks, and written to a small derived cache.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import json
from pathlib import Path
import re
from typing import Any, Iterable, Literal, Sequence

import numpy as np
import pandas as pd

from .manifest import HashMode, create_manifest, fingerprint_file, write_manifest
from .completeness import DownloadCompletenessReport, audit_download_completeness


PowerUnitPolicy = Literal["socal_calibrated_kw", "metadata_w", "auto"]

_TIME_ALIASES = ("t", "time", "timestamp", "datetime", "date_time", "date")
_VALUE_ALIASES = ("v", "value", "magnitude", "power", "reading", "measurement")
_KNOWN_NAMEPLATE_KW = {
    "egauge_16-NorthPV_Power": 500.0,
    "egauge_16-SouthPV_Power": 333.0,
}


@dataclass(frozen=True)
class ChannelCatalog:
    root: Path
    path: Path
    magnitudes: frozenset[str]
    phasors: frozenset[str]
    generated_at: str | None = None

    @classmethod
    def from_root(cls, root: str | Path) -> "ChannelCatalog":
        dataset_root = Path(root).resolve()
        catalog_path = dataset_root / "channel_catalog.json"
        if not catalog_path.is_file():
            raise FileNotFoundError(f"SoCal channel catalog not found: {catalog_path}")
        with catalog_path.open("r", encoding="utf-8") as stream:
            raw = json.load(stream)
        magnitudes = raw.get("magnitudes", [])
        phasors = raw.get("phasors", [])
        if not isinstance(magnitudes, list) or not all(
            isinstance(value, str) for value in magnitudes
        ):
            raise ValueError("channel_catalog.json has an invalid magnitudes list")
        if not isinstance(phasors, list) or not all(isinstance(value, str) for value in phasors):
            raise ValueError("channel_catalog.json has an invalid phasors list")
        return cls(
            root=dataset_root,
            path=catalog_path,
            magnitudes=frozenset(magnitudes),
            phasors=frozenset(phasors),
            generated_at=raw.get("generated_at"),
        )

    def magnitude_files(
        self,
        channel: str,
        *,
        months: Sequence[str] | None = None,
        resolution_seconds: int | None = None,
    ) -> tuple[Path, ...]:
        """Locate monthly CSV parts for an exact catalogued channel."""

        if channel not in self.magnitudes:
            raise KeyError(f"magnitude channel is not catalogued: {channel}")
        if Path(channel).name != channel or any(separator in channel for separator in ("/", "\\")):
            raise ValueError("channel names may not contain path separators")
        base = self.root / "magnitudes"
        direct = sorted(base.glob(f"*/magnitudes/{channel}.csv"))
        files = direct or sorted(base.rglob(f"{channel}.csv"))
        resolved = tuple(
            path.resolve()
            for path in files
            if path.is_file()
            and not path.relative_to(base).parts[0].endswith(".partial")
        )
        if resolution_seconds is not None:
            if resolution_seconds <= 0:
                raise ValueError("resolution_seconds must be positive")
            resolution_pattern = re.compile(r"_r(?P<seconds>\d+)s(?:_|$)")

            def has_resolution(path: Path) -> bool:
                batch_name = path.relative_to(base).parts[0]
                match = resolution_pattern.search(batch_name)
                return match is not None and int(match.group("seconds")) == resolution_seconds

            resolved = tuple(path for path in resolved if has_resolution(path))
        if months is not None:
            selected = tuple(dict.fromkeys(months))
            invalid = [month for month in selected if not re.fullmatch(r"\d{4}-\d{2}", month)]
            if invalid:
                raise ValueError(f"invalid YYYY-MM month values: {invalid}")
            allowed = set(selected)
            resolved = tuple(path for path in resolved if path.parent.parent.name[:7] in allowed)
            present = {path.parent.parent.name[:7] for path in resolved}
            missing_months = sorted(allowed - present)
            if missing_months:
                raise FileNotFoundError(
                    f"channel {channel!r} has no magnitude file for months {missing_months}"
                )
        if not resolved:
            raise FileNotFoundError(f"no CSV parts found for magnitude channel {channel!r}")
        return resolved


@dataclass(frozen=True)
class SoCalChannelSelection:
    pv_channels: tuple[str, ...] = (
        "egauge_16-NorthPV_Power",
        "egauge_16-SouthPV_Power",
    )
    grid_channel: str = "egauge_16-Mains_Power"
    fuel_cell_channels: tuple[str, ...] = ("egauge_22-es1_Power",)

    @property
    def all_channels(self) -> tuple[str, ...]:
        return tuple(
            dict.fromkeys((*self.pv_channels, self.grid_channel, *self.fuel_cell_channels))
        )


@dataclass(frozen=True)
class UnitDecision:
    channel: str
    metadata_unit: str
    output_unit: str
    scale_to_kw: float
    policy: PowerUnitPolicy
    observed_abs_p99: float | None
    reason: str


@dataclass(frozen=True)
class ResampledChannel:
    channel: str
    values_kw: pd.Series
    sample_count: pd.Series
    missing: pd.Series
    source_files: tuple[Path, ...]
    unit_decision: UnitDecision


@dataclass(frozen=True)
class SoCalProfile:
    frame: pd.DataFrame
    source_files: tuple[Path, ...]
    unit_decisions: dict[str, UnitDecision]
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SoCalCacheResult:
    parquet_path: Path
    manifest_path: Path
    rows: int
    manifest: dict[str, Any]
    selected_months: tuple[str, ...] = ()


def verify_socal_cache_manifest(
    cache_path: str | Path,
    manifest_path: str | Path | None = None,
    *,
    verify_source_files: bool = False,
) -> dict[str, Any]:
    """Verify that a cache is the recorded complete-month derivative.

    Source fingerprints are optional because older manifests may reference a
    mutable top-level download plan. Set ``verify_source_files=True`` for a
    strict raw-lineage audit when the manifest pins immutable source files.
    """

    cache = Path(cache_path).resolve()
    manifest_file = (
        Path(manifest_path).resolve()
        if manifest_path is not None
        else cache.with_name(f"{cache.stem}.manifest.json")
    )
    if not cache.is_file():
        raise FileNotFoundError(f"SoCal cache not found: {cache}")
    if not manifest_file.is_file():
        raise FileNotFoundError(f"SoCal cache manifest not found: {manifest_file}")
    try:
        manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    except (UnicodeError, json.JSONDecodeError) as error:
        raise ValueError(f"Invalid SoCal cache manifest: {manifest_file}") from error
    if manifest.get("dataset") != "Caltech_SoCal28_15min_derivative":
        raise ValueError("manifest does not describe a Qingheng SoCal 15-minute derivative")
    recorded_output = Path(str(manifest.get("output_file", ""))).resolve()
    if recorded_output != cache:
        raise ValueError(f"manifest output path {recorded_output} does not match cache {cache}")
    expected_hash = manifest.get("output_sha256")
    if (
        not isinstance(expected_hash, str)
        or fingerprint_file(cache, "full")["sha256"] != expected_hash
    ):
        raise ValueError("SoCal cache content does not match its manifest hash")

    derivation = manifest.get("derivation")
    if not isinstance(derivation, dict):
        raise ValueError("SoCal cache manifest has no derivation record")
    selected = derivation.get("selected_complete_months")
    if (
        not isinstance(selected, list)
        or not selected
        or not all(
            isinstance(month, str) and re.fullmatch(r"\d{4}-\d{2}", month) for month in selected
        )
    ):
        raise ValueError("SoCal cache manifest has no selected complete calendar months")
    download = derivation.get("download_completeness")
    required_types = download.get("required_data_types", []) if isinstance(download, dict) else []
    if "magnitudes" not in required_types:
        raise ValueError("SoCal cache was not gated on magnitude download completeness")
    if isinstance(download, dict) and "resolution_seconds" in download:
        if download["resolution_seconds"] != derivation.get("source_resolution_seconds"):
            raise ValueError("SoCal cache completeness cadence does not match its source cadence")
    quality = derivation.get("month_quality")
    if not isinstance(quality, dict) or any(
        not isinstance(quality.get(month), dict) or not quality[month].get("accepted", False)
        for month in selected
    ):
        raise ValueError("one or more selected SoCal months lacks an accepted quality record")
    if verify_source_files:
        source_files = manifest.get("source_files")
        if not isinstance(source_files, list) or not source_files:
            raise ValueError("SoCal cache manifest has no source fingerprints")
        mismatches: list[str] = []
        for entry in source_files:
            if not isinstance(entry, dict):
                mismatches.append("<invalid source entry>")
                continue
            source = Path(str(entry.get("path", "")))
            mode = entry.get("hash_mode")
            expected = entry.get("sha256")
            if mode not in ("metadata", "full") or not isinstance(expected, str):
                mismatches.append(str(source))
                continue
            try:
                current = fingerprint_file(source, mode)
            except (OSError, ValueError):
                mismatches.append(str(source))
                continue
            if current["sha256"] != expected:
                mismatches.append(str(source))
        if mismatches:
            preview = ", ".join(mismatches[:3])
            remainder = len(mismatches) - min(len(mismatches), 3)
            suffix = f" (+{remainder} more)" if remainder else ""
            raise ValueError(
                "SoCal cache source lineage no longer matches its manifest: "
                f"{preview}{suffix}"
            )
    return manifest


def _detect_csv_columns(path: Path) -> tuple[str, str]:
    sample = pd.read_csv(path, nrows=32)
    if len(sample.columns) < 2:
        raise ValueError(f"expected at least two CSV columns in {path}")
    lookup = {str(column).strip().lower(): str(column) for column in sample.columns}
    time_column = next((lookup[name] for name in _TIME_ALIASES if name in lookup), None)
    value_column = next((lookup[name] for name in _VALUE_ALIASES if name in lookup), None)

    if time_column is None:
        for column in sample.columns:
            parsed = pd.to_datetime(sample[column], errors="coerce", utc=True, format="mixed")
            if len(parsed) and float(parsed.notna().mean()) >= 0.8:
                time_column = str(column)
                break
    if value_column is None:
        for column in sample.columns:
            if str(column) == time_column:
                continue
            numeric = pd.to_numeric(sample[column], errors="coerce")
            if len(numeric) and float(numeric.notna().mean()) >= 0.8:
                value_column = str(column)
                break
    if time_column is None or value_column is None or time_column == value_column:
        raise ValueError(f"could not identify timestamp and value columns in {path}")
    return time_column, value_column


def _utc_bound(value: str | pd.Timestamp | None) -> pd.Timestamp | None:
    if value is None:
        return None
    timestamp = pd.Timestamp(value)
    return timestamp.tz_localize("UTC") if timestamp.tzinfo is None else timestamp.tz_convert("UTC")


def _unit_decision(
    channel: str,
    values: pd.Series,
    policy: PowerUnitPolicy,
) -> UnitDecision:
    finite = np.abs(values.to_numpy(dtype=float, na_value=np.nan))
    finite = finite[np.isfinite(finite)]
    p99 = float(np.quantile(finite, 0.99)) if finite.size else None

    if policy == "metadata_w":
        scale = 1e-3
        reason = "Register metadata unit W was applied literally."
    elif policy == "socal_calibrated_kw":
        scale = 1.0
        reason = (
            "SoCal downloaded Power magnitudes are treated as kW: audited PV peaks are "
            "approximately 492 and 333, matching the 500 kW and 333 kW nameplates even "
            "though the topology register labels the unit as W."
        )
    elif policy == "auto":
        nameplate = _KNOWN_NAMEPLATE_KW.get(channel)
        if p99 is None or p99 == 0 or nameplate is None:
            scale = 1.0
            reason = (
                "No usable nameplate comparison was available; used the audited SoCal "
                "package convention that downloaded Power magnitudes are kW."
            )
        elif 0.01 <= p99 / nameplate <= 5.0:
            scale = 1.0
            reason = "Observed magnitude is compatible with the channel kW nameplate."
        elif 0.01 <= (p99 / 1000.0) / nameplate <= 5.0:
            scale = 1e-3
            reason = "Observed magnitude is compatible with W and was divided by 1000."
        else:
            raise ValueError(
                f"cannot infer W versus kW for {channel}: p99={p99:g}, nameplate={nameplate:g} kW"
            )
    else:
        raise ValueError(f"unknown unit policy: {policy}")
    return UnitDecision(
        channel=channel,
        metadata_unit="W",
        output_unit="kW",
        scale_to_kw=scale,
        policy=policy,
        observed_abs_p99=p99,
        reason=reason,
    )


def read_magnitude_channel_15min(
    catalog: ChannelCatalog,
    channel: str,
    *,
    resample_minutes: int = 15,
    source_resolution_seconds: int = 60,
    min_coverage: float = 0.8,
    start: str | pd.Timestamp | None = None,
    end: str | pd.Timestamp | None = None,
    chunksize: int = 100_000,
    unit_policy: PowerUnitPolicy = "socal_calibrated_kw",
    months: Sequence[str] | None = None,
) -> ResampledChannel:
    """Stream one magnitude channel and aggregate it without retaining raw minutes."""

    if not channel.lower().endswith("_power"):
        raise ValueError(
            "the kW normalizer accepts only SoCal channels whose names end in '_Power'"
        )
    if resample_minutes <= 0 or source_resolution_seconds <= 0 or chunksize <= 0:
        raise ValueError("resampling, source resolution and chunk size must be positive")
    if not 0 < min_coverage <= 1:
        raise ValueError("min_coverage must be in (0, 1]")
    files = catalog.magnitude_files(
        channel,
        months=months,
        resolution_seconds=source_resolution_seconds,
    )
    start_utc, end_utc = _utc_bound(start), _utc_bound(end)
    if start_utc is not None and end_utc is not None and start_utc >= end_utc:
        raise ValueError("start must be earlier than end")

    frequency = f"{resample_minutes}min"
    partials: list[pd.DataFrame] = []
    for path in files:
        try:
            time_column, value_column = _detect_csv_columns(path)
            chunks = pd.read_csv(path, usecols=[time_column, value_column], chunksize=chunksize)
        except pd.errors.EmptyDataError:
            continue
        for chunk in chunks:
            timestamps = pd.to_datetime(
                chunk[time_column], errors="coerce", utc=True, format="mixed"
            )
            values = pd.to_numeric(chunk[value_column], errors="coerce")
            valid = timestamps.notna() & values.notna()
            if start_utc is not None:
                valid &= timestamps >= start_utc
            if end_utc is not None:
                valid &= timestamps < end_utc
            if not valid.any():
                continue
            clean = pd.DataFrame(
                {"timestamp": timestamps[valid], "value": values[valid].astype(float)}
            ).drop_duplicates("timestamp", keep="last")
            partials.append(clean)

    if not partials:
        empty_index = pd.DatetimeIndex([], tz="UTC", name="timestamp")
        empty_float = pd.Series(index=empty_index, dtype=float, name=channel)
        empty_count = pd.Series(index=empty_index, dtype="int64", name=f"{channel}_count")
        empty_bool = pd.Series(index=empty_index, dtype=bool, name=f"{channel}_missing")
        decision = _unit_decision(channel, empty_float, unit_policy)
        return ResampledChannel(channel, empty_float, empty_count, empty_bool, files, decision)

    # Chunks and recovery files can overlap. Deduplicate globally before
    # resampling so repeated timestamps cannot inflate a bin's coverage.
    samples = (
        pd.concat(partials, ignore_index=True)
        .drop_duplicates("timestamp", keep="last")
        .sort_values("timestamp")
    )
    samples["bin"] = samples["timestamp"].dt.floor(frequency)
    aggregate = samples.groupby("bin")["value"].agg(["sum", "count"]).sort_index()
    first = start_utc.floor(frequency) if start_utc is not None else aggregate.index.min()
    if end_utc is not None:
        last = (end_utc - pd.Timedelta(1, "ns")).floor(frequency)
    else:
        last = aggregate.index.max()
    complete_index = pd.date_range(first, last, freq=frequency, tz="UTC", name="timestamp")
    aggregate = aggregate.reindex(complete_index, fill_value=0)
    raw_values = aggregate["sum"].div(aggregate["count"].replace(0, np.nan))
    decision = _unit_decision(channel, raw_values, unit_policy)
    values_kw = (raw_values * decision.scale_to_kw).rename(channel)
    sample_count = aggregate["count"].astype("int64").rename(f"{channel}_count")
    expected = (resample_minutes * 60) / source_resolution_seconds
    missing = (sample_count < expected * min_coverage).rename(f"{channel}_missing")
    return ResampledChannel(channel, values_kw, sample_count, missing, files, decision)


def _combine_channels(
    readings: Iterable[ResampledChannel],
    index: pd.DatetimeIndex,
    *,
    clip_generation: bool,
) -> tuple[pd.Series, pd.Series]:
    selected = list(readings)
    if not selected:
        raise ValueError("at least one source channel is required")
    components = [item.values_kw.reindex(index) for item in selected]
    combined = pd.concat(components, axis=1).sum(axis=1, min_count=len(components))
    if clip_generation:
        combined = combined.clip(lower=0.0)
    missing = pd.concat(
        [item.missing.reindex(index, fill_value=True) for item in selected], axis=1
    ).any(axis=1)
    return combined, missing


def load_socal_15min_profile(
    root: str | Path,
    *,
    selection: SoCalChannelSelection | None = None,
    resample_minutes: int = 15,
    source_resolution_seconds: int = 60,
    min_coverage: float = 0.8,
    start: str | pd.Timestamp | None = None,
    end: str | pd.Timestamp | None = None,
    chunksize: int = 100_000,
    unit_policy: PowerUnitPolicy = "socal_calibrated_kw",
    months: Sequence[str] | None = None,
) -> SoCalProfile:
    """Build the standard real-data profile used by forecasting and dispatch.

    ``grid_kw`` preserves the meter sign convention (positive import, negative
    export). ``load_kw`` is reconstructed only inside the coherent eGauge16
    boundary as ``pv_kw + grid_kw``. The eGauge22 fuel-cell channel is retained
    as an auxiliary observation and is not inserted into that balance.
    """

    catalog = ChannelCatalog.from_root(root)
    selected = selection or SoCalChannelSelection()
    readings = {
        channel: read_magnitude_channel_15min(
            catalog,
            channel,
            resample_minutes=resample_minutes,
            source_resolution_seconds=source_resolution_seconds,
            min_coverage=min_coverage,
            start=start,
            end=end,
            chunksize=chunksize,
            unit_policy=unit_policy,
            months=months,
        )
        for channel in selected.all_channels
    }
    non_empty = [item.values_kw.index for item in readings.values() if len(item.values_kw)]
    if not non_empty:
        raise ValueError("selected SoCal channels contain no data in the requested interval")
    first = min(index.min() for index in non_empty)
    last = max(index.max() for index in non_empty)
    index = pd.date_range(first, last, freq=f"{resample_minutes}min", tz="UTC", name="timestamp")
    if months is not None:
        allowed = set(months)
        index = index[index.strftime("%Y-%m").isin(allowed)]

    pv_kw, pv_missing = _combine_channels(
        (readings[channel] for channel in selected.pv_channels),
        index,
        clip_generation=True,
    )
    fuel_cell_kw, fuel_cell_missing = _combine_channels(
        (readings[channel] for channel in selected.fuel_cell_channels),
        index,
        clip_generation=True,
    )
    grid_reading = readings[selected.grid_channel]
    grid_kw = grid_reading.values_kw.reindex(index)
    grid_missing = grid_reading.missing.reindex(index, fill_value=True)
    pv_sample_count_min = pd.concat(
        [readings[channel].sample_count.reindex(index) for channel in selected.pv_channels],
        axis=1,
    ).min(axis=1)
    fuel_cell_sample_count_min = pd.concat(
        [readings[channel].sample_count.reindex(index) for channel in selected.fuel_cell_channels],
        axis=1,
    ).min(axis=1)
    grid_sample_count = grid_reading.sample_count.reindex(index)
    expected_samples_per_bin = (resample_minutes * 60) / source_resolution_seconds
    load_raw = pv_kw + grid_kw
    invalid_balance = load_raw < 0
    load_missing = pv_missing | grid_missing | load_raw.isna() | invalid_balance

    frame = pd.DataFrame(
        {
            "pv_kw": pv_kw,
            "grid_kw": grid_kw,
            "fuel_cell_kw": fuel_cell_kw,
            "load_kw": load_raw.clip(lower=0.0),
            "load_kw_raw_balance": load_raw,
            "pv_missing": pv_missing.astype(bool),
            "grid_missing": grid_missing.astype(bool),
            "fuel_cell_missing": fuel_cell_missing.astype(bool),
            "load_missing": load_missing.astype(bool),
            "load_balance_invalid": invalid_balance.fillna(True).astype(bool),
            "pv_sample_count_min": pv_sample_count_min.fillna(0).astype("int64"),
            "grid_sample_count": grid_sample_count.fillna(0).astype("int64"),
            "fuel_cell_sample_count_min": fuel_cell_sample_count_min.fillna(0).astype("int64"),
            "all_channels_strict_complete": (
                (pv_sample_count_min >= expected_samples_per_bin)
                & (grid_sample_count >= expected_samples_per_bin)
                & (fuel_cell_sample_count_min >= expected_samples_per_bin)
            ).astype(bool),
            "joint_all_zero": ((pv_kw == 0) & (grid_kw == 0) & (fuel_cell_kw == 0)).astype(bool),
        },
        index=index,
    )
    source_files = tuple(
        sorted(
            {path for reading in readings.values() for path in reading.source_files},
            key=str,
        )
    )
    metadata = {
        "dataset": "Caltech_SoCal28_hybrid_timeseries",
        "timezone": "UTC",
        "resample_minutes": resample_minutes,
        "source_resolution_seconds": source_resolution_seconds,
        "min_coverage": min_coverage,
        "channels": {
            "pv": list(selected.pv_channels),
            "grid": selected.grid_channel,
            "fuel_cell": list(selected.fuel_cell_channels),
        },
        "grid_sign_convention": "positive import; negative export",
        "load_kw_derivation": "max(0, egauge16_pv_kw + egauge16_mains_grid_kw)",
        "load_kw_caveat": (
            "eGauge16 building-boundary proxy, not a directly metered campus load; "
            "eGauge22 fuel-cell power belongs to another topology group and is excluded"
        ),
        "fuel_cell_boundary_note": (
            "egauge_22-es1_Power is retained as an auxiliary real channel only; it is not "
            "part of the eGauge16 load reconstruction"
        ),
        "raw_data_policy": "read only; selected CSVs are referenced, never copied",
        "selected_months": list(months) if months is not None else None,
    }
    return SoCalProfile(
        frame=frame,
        source_files=source_files,
        unit_decisions={channel: reading.unit_decision for channel, reading in readings.items()},
        metadata=metadata,
    )


def build_socal_15min_cache(
    root: str | Path,
    cache_root: str | Path,
    *,
    filename: str = "socal_15min.parquet",
    manifest_filename: str = "socal_15min.manifest.json",
    hash_mode: HashMode = "metadata",
    complete_months_only: bool = True,
    completeness_data_types: Sequence[str] = ("magnitudes",),
    min_month_usable_bin_fraction: float = 0.999,
    min_month_strict_bin_fraction: float = 0.999,
    max_joint_zero_run_bins: int = 16,
    download_plan_path: str | Path | None = None,
    **profile_options: Any,
) -> SoCalCacheResult:
    """Write a Parquet derivative from complete, quality-gated calendar months.

    Completeness is scoped to the modalities this derivative actually reads.
    The default therefore gates monthly magnitude batches, not the independently
    downloaded phasor archive. Selected-channel quality checks are applied after
    the batch marker gate and the longest contiguous accepted run is retained.
    """

    raw_root = Path(root).resolve()
    output_dir = Path(cache_root).resolve()
    if output_dir == raw_root or raw_root in output_dir.parents:
        raise ValueError("cache_root must be outside the read-only SoCal raw dataset")
    if Path(filename).name != filename or not filename.endswith(".parquet"):
        raise ValueError("filename must be a simple .parquet filename")
    if Path(manifest_filename).name != manifest_filename or not manifest_filename.endswith(".json"):
        raise ValueError("manifest_filename must be a simple .json filename")
    output_dir.mkdir(parents=True, exist_ok=True)
    for name, value in {
        "min_month_usable_bin_fraction": min_month_usable_bin_fraction,
        "min_month_strict_bin_fraction": min_month_strict_bin_fraction,
    }.items():
        if not 0 < value <= 1:
            raise ValueError(f"{name} must be in (0, 1]")
    if max_joint_zero_run_bins < 0:
        raise ValueError("max_joint_zero_run_bins cannot be negative")

    completeness: DownloadCompletenessReport | None = None
    selected_months: tuple[str, ...] = ()
    completeness_sources: tuple[Path, ...] = ()
    month_quality: dict[str, dict[str, Any]] = {}
    stable_sources_before: dict[Path, tuple[int, int]] = {}
    if complete_months_only:
        source_resolution_seconds = int(profile_options.get("source_resolution_seconds", 60))
        completeness = audit_download_completeness(
            raw_root,
            required_data_types=completeness_data_types,
            resolution_seconds=source_resolution_seconds,
            download_plan_path=download_plan_path,
        )
        candidate_months = completeness.complete_months
        if not candidate_months:
            raise ValueError(
                "No fully downloaded SoCal month is available for "
                f"data types {tuple(completeness_data_types)} at "
                f"{source_resolution_seconds}-second resolution"
            )
        requested_months = profile_options.pop("months", None)
        requested_start = _utc_bound(profile_options.get("start"))
        requested_end = _utc_bound(profile_options.get("end"))
        if (
            requested_start is not None
            and requested_end is not None
            and requested_start >= requested_end
        ):
            raise ValueError("start must be earlier than end")
        if requested_months is not None:
            requested = tuple(sorted(dict.fromkeys(requested_months)))
            unavailable = sorted(set(requested) - set(completeness.complete_months))
            if unavailable:
                raise ValueError(f"requested months are not fully downloaded: {unavailable}")
            candidate_months = requested
        else:
            candidate_months = tuple(
                month
                for month in candidate_months
                if (
                    requested_start is None
                    or pd.Timestamp(f"{month}-01", tz="UTC") >= requested_start
                )
                and (
                    requested_end is None
                    or pd.Timestamp(f"{month}-01", tz="UTC") + pd.offsets.MonthBegin(1)
                    <= requested_end
                )
            )
            if not candidate_months:
                raise ValueError("requested interval contains no fully downloaded calendar month")

        audit_options = dict(profile_options)
        audit_options["months"] = candidate_months
        audit_options["start"] = pd.Timestamp(f"{candidate_months[0]}-01", tz="UTC")
        audit_options["end"] = pd.Timestamp(
            f"{candidate_months[-1]}-01", tz="UTC"
        ) + pd.offsets.MonthBegin(1)
        audit_profile = load_socal_15min_profile(raw_root, **audit_options)
        valid_months: list[str] = []
        resample_minutes = int(audit_profile.metadata["resample_minutes"])
        for month in candidate_months:
            subset = audit_profile.frame.loc[audit_profile.frame.index.strftime("%Y-%m") == month]
            expected_rows = int(
                pd.Period(month, freq="M").days_in_month * 24 * 60 / resample_minutes
            )
            usable_fraction = float((~subset["load_missing"]).mean()) if len(subset) else 0.0
            strict_fraction = (
                float(subset["all_channels_strict_complete"].mean()) if len(subset) else 0.0
            )
            zero_values = subset["joint_all_zero"].to_numpy(dtype=bool)
            maximum_zero_run = 0
            current_zero_run = 0
            for is_zero in zero_values:
                current_zero_run = current_zero_run + 1 if is_zero else 0
                maximum_zero_run = max(maximum_zero_run, current_zero_run)
            rejection_reasons: list[str] = []
            if len(subset) != expected_rows:
                rejection_reasons.append(f"rows={len(subset)} expected={expected_rows}")
            if usable_fraction < min_month_usable_bin_fraction:
                rejection_reasons.append(f"usable_fraction={usable_fraction:.6f}")
            if strict_fraction < min_month_strict_bin_fraction:
                rejection_reasons.append(f"strict_fraction={strict_fraction:.6f}")
            if maximum_zero_run > max_joint_zero_run_bins:
                rejection_reasons.append(f"joint_zero_run_bins={maximum_zero_run}")
            month_quality[month] = {
                "rows": len(subset),
                "expected_rows": expected_rows,
                "usable_bin_fraction": usable_fraction,
                "strict_complete_bin_fraction": strict_fraction,
                "missing_bins": int(subset["load_missing"].sum()),
                "maximum_joint_zero_run_bins": maximum_zero_run,
                "accepted": not rejection_reasons,
                "rejection_reasons": rejection_reasons,
            }
            if not rejection_reasons:
                valid_months.append(month)

        valid_runs: list[list[str]] = []
        for month in valid_months:
            if not valid_runs:
                valid_runs.append([month])
                continue
            previous = pd.Period(valid_runs[-1][-1], freq="M")
            if pd.Period(month, freq="M") == previous + 1:
                valid_runs[-1].append(month)
            else:
                valid_runs.append([month])
        if requested_months is not None:
            if len(valid_runs) != 1 or tuple(valid_runs[0]) != tuple(candidate_months):
                rejected = {
                    month: month_quality[month]["rejection_reasons"]
                    for month in candidate_months
                    if not month_quality[month]["accepted"]
                }
                raise ValueError(f"requested months fail data-quality checks: {rejected}")
            selected_months = tuple(candidate_months)
        elif valid_runs:
            selected_months = tuple(max(valid_runs, key=lambda run: (len(run), run[0])))
        else:
            raise ValueError(
                "Downloaded months exist, but none passes selected-channel quality gates"
            )

        run_start = pd.Timestamp(f"{selected_months[0]}-01", tz="UTC")
        run_end = pd.Timestamp(f"{selected_months[-1]}-01", tz="UTC") + pd.offsets.MonthBegin(1)
        if requested_start is not None and requested_start > run_start:
            raise ValueError("start would truncate a selected complete calendar month")
        if requested_end is not None and requested_end < run_end:
            raise ValueError("end would truncate a selected complete calendar month")
        profile_options["start"] = run_start
        profile_options["end"] = run_end
        profile_options["months"] = selected_months
        completeness_sources = (
            completeness.plan_path,
            *completeness.marker_paths(selected_months),
        )
        selected_channels = profile_options.get("selection") or SoCalChannelSelection()
        catalog = ChannelCatalog.from_root(raw_root)
        stable_paths = {
            path
            for channel in selected_channels.all_channels
            for path in catalog.magnitude_files(
                channel,
                months=selected_months,
                resolution_seconds=source_resolution_seconds,
            )
        }
        stable_paths.update(completeness_sources)
        stable_paths.add(catalog.path)
        stable_sources_before = {
            path: (path.stat().st_size, path.stat().st_mtime_ns) for path in stable_paths
        }
    profile = load_socal_15min_profile(raw_root, **profile_options)
    changed_sources = [
        str(path)
        for path, before in stable_sources_before.items()
        if not path.is_file() or (path.stat().st_size, path.stat().st_mtime_ns) != before
    ]
    if changed_sources:
        raise RuntimeError(
            "SoCal source files changed while the cache was being built; retry after the "
            f"downloader finishes the selected months: {changed_sources}"
        )
    parquet_path = output_dir / filename
    temporary = parquet_path.with_suffix(".parquet.tmp")
    try:
        profile.frame.to_parquet(temporary, engine="pyarrow", index=True)
    except ImportError as error:
        raise RuntimeError("Parquet cache creation requires the pyarrow dependency") from error
    temporary.replace(parquet_path)

    catalog_path = raw_root / "channel_catalog.json"
    derivation = dict(profile.metadata)
    derivation["unit_decisions"] = {
        channel: asdict(decision) for channel, decision in profile.unit_decisions.items()
    }
    if completeness is not None:
        derivation["download_completeness"] = completeness.as_dict()
        derivation["selected_complete_months"] = list(selected_months)
        derivation["month_quality"] = month_quality
        derivation["min_month_usable_bin_fraction"] = min_month_usable_bin_fraction
        derivation["min_month_strict_bin_fraction"] = min_month_strict_bin_fraction
        derivation["max_joint_zero_run_bins"] = max_joint_zero_run_bins
        derivation["source_stability_check"] = {
            "checked": True,
            "files": len(stable_sources_before),
            "result": "unchanged_during_final_read",
        }
    manifest = create_manifest(
        dataset="Caltech_SoCal28_15min_derivative",
        raw_root=raw_root,
        source_files=(catalog_path, *completeness_sources, *profile.source_files),
        hash_mode=hash_mode,
        derivation=derivation,
        output_file=parquet_path,
    )
    manifest_path = write_manifest(manifest, output_dir / manifest_filename)
    return SoCalCacheResult(
        parquet_path, manifest_path, len(profile.frame), manifest, selected_months
    )


def channel_slug(channel: str) -> str:
    """Return a stable identifier for optional per-channel quality columns."""

    return re.sub(r"[^a-z0-9]+", "_", channel.lower()).strip("_")


__all__ = [
    "ChannelCatalog",
    "PowerUnitPolicy",
    "ResampledChannel",
    "SoCalCacheResult",
    "SoCalChannelSelection",
    "SoCalProfile",
    "UnitDecision",
    "build_socal_15min_cache",
    "channel_slug",
    "load_socal_15min_profile",
    "read_magnitude_channel_15min",
    "verify_socal_cache_manifest",
]
