"""Reproducible synthetic assets layered on the real SoCal time series."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from math import isfinite
from numbers import Integral
from typing import Any

import numpy as np
import pandas as pd

from qingheng.config import DispatchConfig

from .socal import SoCalProfile


WIND_TRACE_ANCHOR = pd.Timestamp("2024-09-01T00:00:00Z")
WIND_TRACE_VERSION = "bounded-ar1-fixed-anchor-v1"


@dataclass(frozen=True)
class HybridAssetAssumptions:
    seed: int = 20260714
    wind_capacity_kw: float = 0.0
    battery_capacity_kwh: float = 1200.0
    battery_power_limit_kw: float = 400.0
    battery_initial_soc: float = 0.50
    hydrogen_capacity_kwh: float = 1800.0
    electrolyzer_power_limit_kw: float = 300.0
    hydrogen_fuel_cell_power_limit_kw: float = 300.0
    hydrogen_initial_soc: float = 0.40

    @classmethod
    def from_dispatch_config(
        cls,
        dispatch: DispatchConfig,
        *,
        seed: int = 20260714,
        wind_capacity_kw: float = 0.0,
    ) -> "HybridAssetAssumptions":
        return cls(
            seed=seed,
            wind_capacity_kw=wind_capacity_kw,
            battery_capacity_kwh=dispatch.battery_capacity_kwh,
            battery_power_limit_kw=dispatch.battery_power_kw,
            battery_initial_soc=dispatch.battery_initial_soc,
            hydrogen_capacity_kwh=dispatch.hydrogen_capacity_kwh,
            electrolyzer_power_limit_kw=dispatch.hydrogen_power_kw,
            hydrogen_fuel_cell_power_limit_kw=dispatch.hydrogen_power_kw,
            hydrogen_initial_soc=dispatch.hydrogen_initial_soc,
        )

    def validate(self) -> None:
        storage = (
            self.battery_capacity_kwh,
            self.battery_power_limit_kw,
            self.hydrogen_capacity_kwh,
            self.electrolyzer_power_limit_kw,
            self.hydrogen_fuel_cell_power_limit_kw,
        )
        if any(not isfinite(value) or value < 0 for value in storage):
            raise ValueError("storage capacities and device limits must be non-negative")
        battery_disabled = self.battery_capacity_kwh == self.battery_power_limit_kw == 0.0
        battery_enabled = self.battery_capacity_kwh > 0.0 and self.battery_power_limit_kw > 0.0
        hydrogen_disabled = (
            self.hydrogen_capacity_kwh
            == self.electrolyzer_power_limit_kw
            == self.hydrogen_fuel_cell_power_limit_kw
            == 0.0
        )
        hydrogen_enabled = (
            self.hydrogen_capacity_kwh > 0.0
            and self.electrolyzer_power_limit_kw > 0.0
            and self.hydrogen_fuel_cell_power_limit_kw > 0.0
        )
        if not (battery_disabled or battery_enabled):
            raise ValueError("battery capacity and power must be both zero or both positive")
        if not (hydrogen_disabled or hydrogen_enabled):
            raise ValueError("hydrogen capacity and powers must be all zero or all positive")
        if not isfinite(self.wind_capacity_kw) or self.wind_capacity_kw < 0:
            raise ValueError("synthetic wind capacity must be non-negative")
        if (
            not isfinite(self.battery_initial_soc)
            or not isfinite(self.hydrogen_initial_soc)
            or not 0 <= self.battery_initial_soc <= 1
            or not 0 <= self.hydrogen_initial_soc <= 1
        ):
            raise ValueError("initial state of charge values must be in [0, 1]")
        if isinstance(self.seed, bool) or not isinstance(self.seed, Integral):
            raise ValueError("seed must be an integer")


@dataclass(frozen=True)
class HybridProfile:
    frame: pd.DataFrame
    metadata: dict[str, Any]


def synthetic_wind_availability(
    index: pd.DatetimeIndex,
    capacity_kw: float,
    seed: int,
    *,
    anchor: pd.Timestamp = WIND_TRACE_ANCHOR,
) -> np.ndarray:
    """Generate a timestamp-stable bounded autocorrelated wind availability trace."""

    if index.tz is None:
        raise ValueError("synthetic wind index must be timezone-aware")
    if not isfinite(capacity_kw) or capacity_kw < 0.0:
        raise ValueError("synthetic wind capacity must be non-negative")
    utc_index = index.tz_convert("UTC")
    anchor = pd.Timestamp(anchor).tz_convert("UTC")
    if len(index) and utc_index.min() < anchor:
        raise ValueError("synthetic wind index precedes the fixed trace anchor")
    if not len(index):
        return np.empty(0, dtype=float)
    full_index = pd.date_range(anchor, utc_index.max(), freq="15min", tz="UTC")
    positions = full_index.get_indexer(utc_index)
    if np.any(positions < 0):
        raise ValueError("synthetic wind timestamps must align to the 15-minute anchor grid")
    rng = np.random.default_rng(seed)
    innovations = rng.normal(0.0, 0.11, len(full_index))
    state = np.empty(len(full_index), dtype=float)
    utc_hour = full_index.hour.to_numpy() + full_index.minute.to_numpy() / 60.0
    seasonal = 0.42 + 0.08 * np.sin(2 * np.pi * (full_index.dayofyear.to_numpy() - 20) / 365.25)
    diurnal = 0.05 * np.cos(2 * np.pi * (utc_hour - 5.0) / 24.0)
    target = np.clip(seasonal + diurnal, 0.12, 0.78)
    state[0] = np.clip(target[0] + innovations[0], 0.02, 0.95)
    for position in range(1, len(full_index)):
        state[position] = np.clip(
            0.88 * state[position - 1] + 0.12 * target[position] + innovations[position],
            0.02,
            0.95,
        )
    return capacity_kw * state[positions]


def build_hybrid_profile(
    real_profile: SoCalProfile | pd.DataFrame,
    assumptions: HybridAssetAssumptions | None = None,
) -> HybridProfile:
    """Add synthetic wind and storage/H2 parameters to a real-data profile.

    Battery and hydrogen schedules are intentionally *not* fabricated here;
    they are dispatch decision variables.  This builder supplies explicit,
    reproducible device assumptions and labels their provenance.
    """

    assets = assumptions or HybridAssetAssumptions()
    assets.validate()
    if isinstance(real_profile, SoCalProfile):
        frame = real_profile.frame.copy()
        upstream = dict(real_profile.metadata)
    else:
        frame = real_profile.copy()
        upstream = {}
    required = {"pv_kw", "grid_kw", "fuel_cell_kw", "load_kw"}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"real profile is missing required columns: {', '.join(missing)}")
    if not isinstance(frame.index, pd.DatetimeIndex):
        raise TypeError("real profile must use a DatetimeIndex")
    if frame.index.has_duplicates or not frame.index.is_monotonic_increasing:
        raise ValueError("real profile timestamps must be unique and sorted")

    frame["wind_kw"] = synthetic_wind_availability(
        frame.index, assets.wind_capacity_kw, assets.seed
    )
    frame["battery_capacity_kwh"] = assets.battery_capacity_kwh
    frame["battery_power_limit_kw"] = assets.battery_power_limit_kw
    frame["battery_initial_soc"] = assets.battery_initial_soc
    frame["hydrogen_capacity_kwh"] = assets.hydrogen_capacity_kwh
    frame["electrolyzer_power_limit_kw"] = assets.electrolyzer_power_limit_kw
    frame["hydrogen_fuel_cell_power_limit_kw"] = assets.hydrogen_fuel_cell_power_limit_kw
    frame["hydrogen_initial_soc"] = assets.hydrogen_initial_soc
    wind_enabled = assets.wind_capacity_kw > 0.0
    battery_enabled = assets.battery_capacity_kwh > 0.0
    hydrogen_enabled = assets.hydrogen_capacity_kwh > 0.0
    frame["wind_is_synthetic"] = wind_enabled
    frame["battery_is_synthetic"] = battery_enabled
    frame["hydrogen_is_synthetic"] = hydrogen_enabled

    metadata: dict[str, Any] = {
        "profile_kind": "hybrid_real_timeseries_plus_synthetic_assets",
        "real_columns": ["pv_kw", "grid_kw", "fuel_cell_kw", "load_kw"],
        "synthetic_columns": [
            *(["wind_kw"] if wind_enabled else []),
            *(
                [
                    "battery_capacity_kwh",
                    "battery_power_limit_kw",
                    "battery_initial_soc",
                ]
                if battery_enabled
                else []
            ),
            *(
                [
                    "hydrogen_capacity_kwh",
                    "electrolyzer_power_limit_kw",
                    "hydrogen_fuel_cell_power_limit_kw",
                    "hydrogen_initial_soc",
                ]
                if hydrogen_enabled
                else []
            ),
        ],
        "asset_assumptions": asdict(assets),
        "wind_policy": (
            f"synthetic {WIND_TRACE_VERSION} trace anchored at {WIND_TRACE_ANCHOR.isoformat()}"
            if wind_enabled
            else "disabled because the SoCal cache has no confirmed wind measurement"
        ),
        "storage_schedule_policy": (
            "battery and hydrogen operating powers are optimization decisions, not input data"
        ),
        "upstream": upstream,
    }
    return HybridProfile(frame=frame, metadata=metadata)


__all__ = [
    "HybridAssetAssumptions",
    "HybridProfile",
    "WIND_TRACE_ANCHOR",
    "WIND_TRACE_VERSION",
    "build_hybrid_profile",
    "synthetic_wind_availability",
]
