"""Data adapters and derived dataset builders."""

from .completeness import (
    BatchCompleteness,
    DownloadCompletenessReport,
    MonthCompleteness,
    audit_download_completeness,
)
from .hybrid import HybridAssetAssumptions, HybridProfile, build_hybrid_profile
from .ieee33 import IEEE33NetworkData, load_ieee33_from_mpte
from .manifest import HashMode, create_manifest, fingerprint_file, write_manifest
from .socal import (
    ChannelCatalog,
    PowerUnitPolicy,
    ResampledChannel,
    SoCalCacheResult,
    SoCalChannelSelection,
    SoCalProfile,
    UnitDecision,
    build_socal_15min_cache,
    load_socal_15min_profile,
    read_magnitude_channel_15min,
    verify_socal_cache_manifest,
)

__all__ = [
    "BatchCompleteness",
    "ChannelCatalog",
    "DownloadCompletenessReport",
    "HashMode",
    "HybridAssetAssumptions",
    "HybridProfile",
    "IEEE33NetworkData",
    "MonthCompleteness",
    "PowerUnitPolicy",
    "ResampledChannel",
    "SoCalCacheResult",
    "SoCalChannelSelection",
    "SoCalProfile",
    "UnitDecision",
    "audit_download_completeness",
    "build_hybrid_profile",
    "build_socal_15min_cache",
    "create_manifest",
    "fingerprint_file",
    "load_ieee33_from_mpte",
    "load_socal_15min_profile",
    "read_magnitude_channel_15min",
    "verify_socal_cache_manifest",
    "write_manifest",
]
